package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.bol.util.BOLId;
/**
 * This class is used to create objects to hold
 * BOL additional data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
public class BOLAdditionalChargesData implements java.io.Serializable {
	private String fieldAuthEmerRteInd = BOLId.STRING_INIT;
	private String fieldInOutCode = BOLId.STRING_INIT;
	private String fieldTranTypeOut = BOLId.STRING_INIT;
	private String fieldSuppDlrFacCd = BOLId.STRING_INIT;
	private String fieldWtSeqCd = BOLId.STRING_INIT;
	private String fieldTrailerAbbr = BOLId.STRING_INIT;
	private String fieldCarrierCode = BOLId.STRING_INIT;
	private String fieldCarrierName = BOLId.STRING_INIT;
	private String fieldTranspMode = BOLId.STRING_INIT;
	private String fieldTrlLdInd = BOLId.STRING_INIT;
	private String fieldContrInd = BOLId.STRING_INIT;
	private String fieldLdWideInd = BOLId.STRING_INIT;
	private String fieldStartEffDate = BOLId.STRING_INIT;
	
/**
 * BOLAdditionalCharges default constructor.
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLAdditionalChargesData() {
	super();
}
/**
 * Gets AuthEmerRteInd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getAuthEmerRteInd() {
	return fieldAuthEmerRteInd;
}
/**
 * Gets carrier code.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getCarrierCode() {
	return fieldCarrierCode;
}
/**
 * Gets carrier name.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getCarrierName() {
	return fieldCarrierName;
}
/**
 * Gets contr ind.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getContrInd() {
	return fieldContrInd;
}
/**
 * Gets InOut code.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getInOutCode() {
	return fieldInOutCode;
}
/**
 * Gets LdWide ind.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getLdWideInd() {
	return fieldLdWideInd;
}
/**
 * Gets Start Effective date.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getStartEffDate() {
	return fieldStartEffDate;
}
/**
 * Gets SuppDlrFacCd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getSuppDlrFacCd() {
	return fieldSuppDlrFacCd;
}
/**
 * Gets TrailerAbbr.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getTrailerAbbr() {
	return fieldTrailerAbbr;
}
/**
 * Gets TranspMode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getTranspMode() {
	return fieldTranspMode;
}
/**
 * Gets TranTypeOut.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getTranTypeOut() {
	return fieldTranTypeOut;
}
/**
 * Gets TrlLdInd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getTrlLdInd() {
	return fieldTrlLdInd;
}
/**
 * Gets WtSeqCd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getWtSeqCd() {
	return fieldWtSeqCd;
}
/**
 * Sets AuthEmerRteInd
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param authEmerRteInd java.lang.String
 */
public void setAuthEmerRteInd(String authEmerRteInd) {
	fieldAuthEmerRteInd = authEmerRteInd;
}
/**
 * Sets CarrierCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param carrierCode java.lang.String
 */
public void setCarrierCode(String carrierCode) {
	fieldCarrierCode = carrierCode;
}
/**
 * Sets CarrierName.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param carrierName java.lang.String
 */
public void setCarrierName(String carrierName) {
	fieldCarrierName = carrierName;
}
/**
 * Sets ContrInd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param one java.lang.String
 */
public void setContrInd(String contrInd) {
	fieldContrInd = contrInd;
}
/**
 * Sets InOutCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inOutCode java.lang.String
 */
public void setInOutCode(String inOutCode) {
	fieldInOutCode = inOutCode;
}
/**
 * Sets ldWideInd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param ldWideInd java.lang.String
 */
public void setLdWideInd(String ldWideInd) {
	fieldLdWideInd = ldWideInd;
}
/**
 * Sets startEffDate.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param startEffDate java.lang.String
 */
public void setStartEffDate(String startEffDate) {
	fieldStartEffDate = startEffDate;
}
/**
 * Sets suppDlrFacCd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param suppDlrFacCd java.lang.String
 */
public void setSuppDlrFacCd(String suppDlrFacCd) {
	fieldSuppDlrFacCd = suppDlrFacCd;
}
/**
 * Sets trailerAbbr.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param trailerAbbr java.lang.String
 */
public void setTrailerAbbr(String trailerAbbr) {
	fieldTrailerAbbr = trailerAbbr;
}
/**
 * Sets transpMode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param transpMode java.lang.String
 */
public void setTranspMode(String transpMode) {
	fieldTranspMode = transpMode;
}
/**
 * Sets tranTypeOut.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param tranTypeOut java.lang.String
 */
public void setTranTypeOut(String tranTypeOut) {
	fieldTranTypeOut = tranTypeOut;
}
/**
 * Sets trlLdInd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param trlLdInd java.lang.String
 */
public void setTrlLdInd(String trlLdInd) {
	fieldTrlLdInd = trlLdInd;
}
/**
 * Sets wtSeqCd.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param wtSeqCd java.lang.String
 */
public void setWtSeqCd(String wtSeqCd) {
	fieldWtSeqCd = wtSeqCd;
}
}
