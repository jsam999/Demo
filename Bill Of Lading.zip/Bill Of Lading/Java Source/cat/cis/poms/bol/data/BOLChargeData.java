package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

 import cat.cis.poms.bol.util.BOLId;

 /**
 * This class is used to create objects to hold
 * BOL charge data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */

public class BOLChargeData {
	private String fieldRefNo = BOLId.STRING_INIT;
	private String fieldDescription = BOLId.STRING_INIT;
	private String fieldUnits = BOLId.STRING_INIT;
	private String fieldRate = BOLId.STRING_INIT;
	private String fieldFlatCharges = BOLId.STRING_INIT;
	private String fieldChargeCode = BOLId.STRING_INIT;
	private String fieldTotal = BOLId.STRING_INIT;
	private boolean flag = false;
/**
 * BOLChargeData constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLChargeData() {
	super();
}
/**
* Gets ChargeCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getChargeCode()
{
    return fieldChargeCode;
}
/**
* Gets Description.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getDescription()
{
    return fieldDescription;
}
/**
* Gets FlatCharges.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getFlatCharges()
{
    return fieldFlatCharges;
}
/**
* Gets Rate.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getRate()
{
    return fieldRate;
}
/**
* Gets RefNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getRefNo()
{
    return fieldRefNo;
}
/**
* Gets Total.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getTotal()
{
    return fieldTotal;
}
/**
* Get Units.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getUnits()
{
    return fieldUnits;
}
/**
* Method to check if this object represents total charges.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.boolean
*/
public boolean isTotal()
{
    return flag;
}
/**
* Sets ChargeCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param ChargeCode java.lang.String
*/
public void setChargeCode(String chargeCode)
{
    fieldChargeCode = chargeCode;
}
/**
* Sets description.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param description java.lang.String
*/
public void setDescription(String description)
{
    fieldDescription = description;
}
/**
* Sets flatCharges.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param flatCharges java.lang.String
*/
public void setFlatCharges(String flatCharges)
{
    fieldFlatCharges = flatCharges;
}
/**
* Sets rate.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param rate java.lang.String
*/
public void setRate(String rate)
{
    fieldRate = rate;
}
/**
* Sets refNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param refNo java.lang.String
*/
public void setRefNo(String refNo)
{
    fieldRefNo = refNo;
}
/**
* Sets total.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param total java.lang.String
*/
public void setTotal(String total)
{
    fieldTotal = total;
}
/**
* Sets totalFlag.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param totalFlag java.lang.String
*/
public void setTotalFlag(boolean totalFlag)
{
    flag = totalFlag;
}
/**
* Sets units.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param units java.lang.String
*/
public void setUnits(String units)
{
    fieldUnits = units;
}
}
