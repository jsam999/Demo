package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

import cat.cis.poms.bol.util.BOLId;
/**
 * This class is used to create objects to hold
 * BOL Details data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */

public class BOLDetailsData {
	private String fieldQty = BOLId.STRING_INIT;
	private String fieldUnits = BOLId.STRING_INIT;
	private String fieldDesc = BOLId.STRING_INIT;
	private String fieldHeight = BOLId.STRING_INIT;
	private String fieldWidth = BOLId.STRING_INIT;
	private String fieldLength = BOLId.STRING_INIT;
	private String fieldWeight = BOLId.STRING_INIT;
	private String fieldLineNo = BOLId.STRING_INIT;
/**
 * BOLDetailsData constructor comment.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLDetailsData() {
	super();
}
/**
* Gets Description.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getDesc()
{
    return fieldDesc;
}
/**
* Gets Height.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getHeight()
{
    return fieldHeight;
}
/**
* Gets Length.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getLength()
{
    return fieldLength;
}
/**
* Gets LineNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getLineNo()
{
    return fieldLineNo;
}
/**
* Gets Qty.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getQty()
{
    return fieldQty;
}
/**
* Gets Units.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getUnits()
{
    return fieldUnits;
}
/**
* Gets Weight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getWeight()
{
    return fieldWeight;
}
/**
* Gets Width.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getWidth()
{
    return fieldWidth;
}
/**
* Sets Desccription.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setDesc(String desc)
{
    fieldDesc = desc;
}
/**
* Sets Height.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setHeight(String height)
{
    fieldHeight = height;
}
/**
* Sets Length.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setLength(String length)
{
    fieldLength = length;
}
/**
* Sets LineNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setLineNo(String lineNo)
{
    fieldLineNo = lineNo;
}
/**
* Sets Qty.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setQty(String qty)
{
    fieldQty = qty;
}
/**
* Sets Units.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setUnits(String units)
{
    fieldUnits = units;
}
/**
* Sets Weight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setWeight(String weight)
{
    fieldWeight = weight;
}
/**
* Sets Width.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param one java.lang.String
*/
public void setWidth(String width)
{
    fieldWidth = width;
}
}
