package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.bol.util.BOLId;
 
/**
 * This class is used to create objects to hold
 * BOL Footer data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */


public class BOLFooterData
{
    private String fieldAcctFac = BOLId.STRING_INIT;
    private String fieldAcctDept = BOLId.STRING_INIT;
    private String fieldAcctDiv = BOLId.STRING_INIT;
    private String fieldAcctSect = BOLId.STRING_INIT;
    private String fieldAcctExp = BOLId.STRING_INIT;
    private String fieldAcctOrderNo = BOLId.STRING_INIT;
    private String fieldAcctMisc = BOLId.STRING_INIT;

/**
 * BOLFooterData constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLFooterData() {
	super();
}
/**
* Gets AcctDept.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctDept()
{
    return fieldAcctDept;
}
/**
* Gets AcctDiv.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctDiv()
{
    return fieldAcctDiv;
}
/**
* Gets AcctExp.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctExp()
{
    return fieldAcctExp;
}
/**
* Gets AcctFac.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctFac()
{
    return fieldAcctFac;
}
/**
* Gets AcctMisc.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctMisc()
{
    return fieldAcctMisc;
}
/**
* Gets AcctOrderNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctOrderNo()
{
    return fieldAcctOrderNo;
}
/**
* Gets AcctSect.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getAcctSect()
{
    return fieldAcctSect;
}
/**
* Sets acctDept.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctDept java.lang.String
*/
public void setAcctDept(String acctDept)
{
    fieldAcctDept = acctDept;
}
/**
* Sets acctDiv.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctDiv java.lang.String
*/
public void setAcctDiv(String acctDiv)
{
    fieldAcctDiv = acctDiv;
}
/**
* Sets acctExp.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctExp java.lang.String
*/
public void setAcctExp(String acctExp)
{
    fieldAcctExp = acctExp;
}
/**
* Sets acctFac.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctFac java.lang.String
*/
public void setAcctFac(String acctFac)
{
    fieldAcctFac = acctFac;
}
/**
* Sets acctMisc.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctMisc java.lang.String
*/
public void setAcctMisc(String acctMisc)
{
    fieldAcctMisc = acctMisc;
}
/**
* Sets acctOrderNo
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctOrderNo java.lang.String
*/
public void setAcctOrderNo(String acctOrderNo)
{
    fieldAcctOrderNo = acctOrderNo;
}
/**
* Sets acctSect.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param acctSect java.lang.String
*/
public void setAcctSect(String acctSect)
{
    fieldAcctSect = acctSect;
}
}
