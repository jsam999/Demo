package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.bol.util.BOLId;

/**
 * This class is used to create objects to hold
 * BOL Header data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */

public class BOLHeaderData
{
    private String factory = BOLId.STRING_INIT;
    private String building = BOLId.STRING_INIT;
    private String dock = BOLId.STRING_INIT;
    private String bolNum = BOLId.STRING_INIT;
    private String issue = BOLId.STRING_INIT;
    private String originCode = BOLId.STRING_INIT;
    private String originCity = BOLId.STRING_INIT;
    private String originState = BOLId.STRING_INIT;
    private String destinationCode = BOLId.STRING_INIT;
    private String contractNo = BOLId.STRING_INIT;
    private String carrierCode = BOLId.STRING_INIT;
    private String carrierName = BOLId.STRING_INIT;
    private String shipVia = BOLId.STRING_INIT;
    private String carOrderNo = BOLId.STRING_INIT;
    private String consignee = BOLId.STRING_INIT;
    private String freight = BOLId.STRING_INIT;
    private String dealerCode = BOLId.STRING_INIT;
    private String addressName = BOLId.STRING_INIT;
    private String addressLine1 = BOLId.STRING_INIT;
    private String addressLine2 = BOLId.STRING_INIT;
    private String addressCity = BOLId.STRING_INIT;
    private String addressState = BOLId.STRING_INIT;
    private String addressPostal = BOLId.STRING_INIT;
    private String addressCountry = BOLId.STRING_INIT;
    private String deliveryInstLine1 = BOLId.STRING_INIT;
    private String deliveryInstLine2 = BOLId.STRING_INIT;
    private String deliveryInstLine3 = BOLId.STRING_INIT;
    private String deliveryInstLine4 = BOLId.STRING_INIT;
    private String deliveryInstLine5 = BOLId.STRING_INIT;
    private String totalWeight = BOLId.STRING_INIT;
    private String committedDate = BOLId.STRING_INIT;
    private String exportTo = BOLId.STRING_INIT;
    private String ltLind = BOLId.STRING_INIT;
    private String cargoDesc = BOLId.STRING_INIT;
    private String vehicleBreakDown = BOLId.STRING_INIT;
    private String notesBreakDown80 = BOLId.STRING_INIT;
    private String notesBreakDown31 = BOLId.STRING_INIT;
    private String dateShipped = BOLId.STRING_INIT;
    private String sealNo1 = BOLId.STRING_INIT;
    private String sealNo2 = BOLId.STRING_INIT;
    private String containerNum1 = BOLId.STRING_INIT;
    private String containerNum2 = BOLId.STRING_INIT;
    private String clearanceFileNo = BOLId.STRING_INIT;
    private String clearanceLtrNo = BOLId.STRING_INIT;
    private String rateRouteNotes = BOLId.STRING_INIT;
    private String charges = BOLId.STRING_INIT;
    private String addressName1 = BOLId.STRING_INIT;
    private String lterm = BOLId.STRING_INIT;
    private String tagsLterm = BOLId.STRING_INIT;
    private String copyBOL = BOLId.STRING_INIT;
    private String stccCode = BOLId.STRING_INIT;
    private String manualInd = BOLId.STRING_INIT;
	private String reIssueMsg = BOLId.STRING_INIT;
/**
 * BOLHeaderData constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLHeaderData() {
	super();
}
/**
* Gets AddressCity.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressCity() {
	return addressCity;
}
/**
* Gets AddressCountry.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressCountry() {
	return addressCountry;
}
/**
* Gets AddressLine1.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressLine1() {
	return addressLine1;
}
/**
* Gets AddressLine2.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressLine2() {
	return addressLine2;
}
/**
* Gets AddressName.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressName() {
	return addressName;
}
/**
* Gets AddressName1.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressName1() {
	return addressName1;
}
/**
* Gets AddressPostal.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressPostal() {
	return addressPostal;
}
/**
* Gets AddressState.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getAddressState() {
	return addressState;
}
/**
* Gets BolNum.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getBolNum() {
	return bolNum;
}
/**
* Gets Building.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getBuilding() {
	return building;
}
/**
* Gets CargoDesc.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCargoDesc() {
	return cargoDesc;
}
/**
* Gets CarOrderNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCarOrderNo() {
	return carOrderNo;
}
/**
* Gets CarrierCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCarrierCode() {
	return carrierCode;
}
/**
* Gets CarrierName.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCarrierName() {
	return carrierName;
}
/**
* Get Charges.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCharges() {
	return charges;
}
/**
* Gets ClearanceFileNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getClearanceFileNo() {
	return clearanceFileNo;
}
/**
* Gets ClearanceLtrNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getClearanceLtrNo() {
	return clearanceLtrNo;
}
/**
* Gets CommittedDate.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCommittedDate() {
	return committedDate;
}
/**
* Gets Consignee.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getConsignee() {
	return consignee;
}
/**
* Gets ContainerNum1.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getContainerNum1() {
	return containerNum1;
}
/**
* Gets ContainerNum2.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getContainerNum2() {
	return containerNum2;
}
/**
* Gets ContractNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getContractNo() {
	return contractNo;
}
/**
* Gets CopyBOL.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getCopyBOL() {
	return copyBOL;
}
/**
* Gets DateShipped.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDateShipped() {
	return dateShipped;
}
/**
* Gets DealerCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDealerCode() {
	return dealerCode;
}
/**
* Gets DeliveryInst.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getDeliveryInst()
{
    StringBuffer delInst = new StringBuffer();
    delInst.append(deliveryInstLine1.trim());
    delInst.append("\n");
    delInst.append(deliveryInstLine2.trim());
    delInst.append("\n");
    delInst.append(deliveryInstLine3.trim());
    delInst.append("\n");
    delInst.append(deliveryInstLine4.trim());
    delInst.append("\n");
    delInst.append(deliveryInstLine5.trim());
	return delInst.toString();
}
/**
* Gets DeliveryInstLine1.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDeliveryInstLine1() {
	return deliveryInstLine1;
}
/**
* Gets DeliveryInstLine2.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDeliveryInstLine2() {
	return deliveryInstLine2;
}
/**
* Gets DeliveryInstLine3.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDeliveryInstLine3() {
	return deliveryInstLine3;
}
/**
* Gets DeliveryInstLine4.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDeliveryInstLine4() {
	return deliveryInstLine4;
}
/**
* Gets DeliveryInstLine5.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDeliveryInstLine5() {
	return deliveryInstLine5;
}
/**
* Gets DestinationCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDestinationCode() {
	return destinationCode;
}
/**
* Gets Dock.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getDock() {
	return dock;
}
/**
* Gets ExportTo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getExportTo() {
	return exportTo;
}
/**
* Gets Factory.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getFactory() {
	return factory;
}
/**
* Gets Freight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getFreight() {
	return freight;
}
/**
* Gets Issue.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getIssue() {
	return issue;
}
/**
* Gets Lterm.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getLterm() {
	return lterm;
}
/**
* Gets LtLind.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getLtLind() {
	return ltLind;
}
/**
* Gets ManualInd.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getManualInd()
{
    return manualInd;
}
/**
* Gets NotesBreakDown31.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getNotesBreakDown31() {
	return notesBreakDown31;
}
/**
* Gets NotesBreakDown80
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getNotesBreakDown80() {
	return notesBreakDown80;
}
/**
* Gets OriginCity.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getOriginCity() {
	return originCity;
}
/**
* Gets OriginCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getOriginCode() {
	return originCode;
}
/**
* Gets OriginState.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getOriginState() {
	return originState;
}
/**
* Gets RateRouteNotes.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getRateRouteNotes() {
	return rateRouteNotes;
}
/**
* Gets ReIssueMsg.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getReIssueMsg()
{
    return reIssueMsg;
}
/**
* Gets SealNo1.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getSealNo1() {
	return sealNo1;
}
/**
* Gets SealNo2.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getSealNo2() {
	return sealNo2;
}
/**
* Gets ShipVia.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getShipVia() {
	return shipVia;
}
/**
* Gets StccCode.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getStccCode() {
	return stccCode;
}
/**
* Gets TagsLterm.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getTagsLterm() {
	return tagsLterm;
}
/**
* Gets TotalWeight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getTotalWeight() {
	return totalWeight;
}
/**
* Gets VehicleBreakDown.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public java.lang.String getVehicleBreakDown() {
	return vehicleBreakDown;
}
/**
 * Sets AddressCity.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressCity java.lang.String
 */
public void setAddressCity(java.lang.String newAddressCity) {
	addressCity = newAddressCity;
}
/**
 * Sets AddressCountry.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressCountry java.lang.String
 */
public void setAddressCountry(java.lang.String newAddressCountry) {
	addressCountry = newAddressCountry;
}
/**
 * Sets AddressLine1.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressLine1 java.lang.String
 */
public void setAddressLine1(java.lang.String newAddressLine1) {
	addressLine1 = newAddressLine1;
}
/**
 * Sets AddressLine2.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressLine2 java.lang.String
 */
public void setAddressLine2(java.lang.String newAddressLine2) {
	addressLine2 = newAddressLine2;
}
/**
 * Sets AddressName.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressName java.lang.String
 */
public void setAddressName(java.lang.String newAddressName) {
	addressName = newAddressName;
}
/**
 * Sets AddressName1.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressName1 java.lang.String
 */
public void setAddressName1(java.lang.String newAddressName1) {
	addressName1 = newAddressName1;
}
/**
 * Sets AddressPostal.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressPostal java.lang.String
 */
public void setAddressPostal(java.lang.String newAddressPostal) {
	addressPostal = newAddressPostal;
}
/**
 * Sets AddressState.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newAddressState java.lang.String
 */
public void setAddressState(java.lang.String newAddressState) {
	addressState = newAddressState;
}
/**
 * Sets BolNum.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newBolNum java.lang.String
 */
public void setBolNum(java.lang.String newBolNum) {
	bolNum = newBolNum;
}
/**
 * Sets Building.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newBuilding java.lang.String
 */
public void setBuilding(java.lang.String newBuilding) {
	building = newBuilding;
}
/**
 * Sets CargoDesc.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCargoDesc java.lang.String
 */
public void setCargoDesc(java.lang.String newCargoDesc) {
	cargoDesc = newCargoDesc;
}
/**
 * Sets CarOrderNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCarOrderNo java.lang.String
 */
public void setCarOrderNo(java.lang.String newCarOrderNo) {
	carOrderNo = newCarOrderNo;
}
/**
 * Sets CarrierCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCarrierCode java.lang.String
 */
public void setCarrierCode(java.lang.String newCarrierCode) {
	carrierCode = newCarrierCode;
}
/**
 * Sets CarrierName.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCarrierName java.lang.String
 */
public void setCarrierName(java.lang.String newCarrierName) {
	carrierName = newCarrierName;
}
/**
 * Sets Charges.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCharges java.lang.String
 */
public void setCharges(java.lang.String newCharges) {
	charges = newCharges;
}
/**
 * Sets ClearanceFileNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newClearanceFileNo java.lang.String
 */
public void setClearanceFileNo(java.lang.String newClearanceFileNo) {
	clearanceFileNo = newClearanceFileNo;
}
/**
 * Sets ClearanceLtrNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newClearanceLtrNo java.lang.String
 */
public void setClearanceLtrNo(java.lang.String newClearanceLtrNo) {
	clearanceLtrNo = newClearanceLtrNo;
}
/**
 * Sets CommittedDate.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCommittedDate java.lang.String
 */
public void setCommittedDate(java.lang.String newCommittedDate) {
	committedDate = newCommittedDate;
}
/**
 * Sets Consignee.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newConsignee java.lang.String
 */
public void setConsignee(java.lang.String newConsignee) {
	consignee = newConsignee;
}
/**
 * Sets ContainerNum1.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newContainerNum1 java.lang.String
 */
public void setContainerNum1(java.lang.String newContainerNum1) {
	containerNum1 = newContainerNum1;
}
/**
 * Sets ContainerNum2.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newContainerNum2 java.lang.String
 */
public void setContainerNum2(java.lang.String newContainerNum2) {
	containerNum2 = newContainerNum2;
}
/**
 * Sets ContractNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newContractNo java.lang.String
 */
public void setContractNo(java.lang.String newContractNo) {
	contractNo = newContractNo;
}
/**
 * Sets CopyBOL.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newCopyBOL java.lang.String
 */
public void setCopyBOL(java.lang.String newCopyBOL) {
	copyBOL = newCopyBOL;
}
/**
 * Sets DateShipped.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDateShipped java.lang.String
 */
public void setDateShipped(java.lang.String newDateShipped) {
	dateShipped = newDateShipped;
}
/**
 * Sets DealerCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDealerCode java.lang.String
 */
public void setDealerCode(java.lang.String newDealerCode) {
	dealerCode = newDealerCode;
}
/**
 * Sets DeliveryInstLine1.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDeliveryInstLine1 java.lang.String
 */
public void setDeliveryInstLine1(java.lang.String newDeliveryInstLine1) {
	deliveryInstLine1 = newDeliveryInstLine1;
}
/**
 * Sets DeliveryInstLine2.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDeliveryInstLine2 java.lang.String
 */
public void setDeliveryInstLine2(java.lang.String newDeliveryInstLine2) {
	deliveryInstLine2 = newDeliveryInstLine2;
}
/**
 * Sets DeliveryInstLine3.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDeliveryInstLine3 java.lang.String
 */
public void setDeliveryInstLine3(java.lang.String newDeliveryInstLine3) {
	deliveryInstLine3 = newDeliveryInstLine3;
}
/**
 * Sets DeliveryInstLine4.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDeliveryInstLine4 java.lang.String
 */
public void setDeliveryInstLine4(java.lang.String newDeliveryInstLine4)
{
    deliveryInstLine4 = newDeliveryInstLine4;
}
/**
 * Sets DeliveryInstLine5.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDeliveryInstLine5 java.lang.String
 */
public void setDeliveryInstLine5(java.lang.String newDeliveryInstLine5) {
	deliveryInstLine5 = newDeliveryInstLine5;
}
/**
 * Sets DestinationCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDestinationCode java.lang.String
 */
public void setDestinationCode(java.lang.String newDestinationCode) {
	destinationCode = newDestinationCode;
}
/**
 * Sets Dock.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newDock java.lang.String
 */
public void setDock(java.lang.String newDock) {
	dock = newDock;
}
/**
 * Sets ExportTo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newExportTo java.lang.String
 */
public void setExportTo(java.lang.String newExportTo) {
	exportTo = newExportTo;
}
/**
 * Sets Factory.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newFactory java.lang.String
 */
public void setFactory(String newFactory) {
	factory = newFactory;
}
/**
 * Sets Freight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newFreight java.lang.String
 */
public void setFreight(java.lang.String newFreight) {
	freight = newFreight;
}
/**
 * Sets Issue.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newIssue java.lang.String
 */
public void setIssue(java.lang.String newIssue) {
	issue = newIssue;
}
/**
 * Sets Lterm.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newLterm java.lang.String
 */
public void setLterm(java.lang.String newLterm) {
	lterm = newLterm;
}
/**
 * Sets LtLind.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newLtLind java.lang.String
 */
public void setLtLind(java.lang.String newLtLind) {
	ltLind = newLtLind;
}
/**
* Sets ManualInd
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param newManualInd java.lang.String
*/
public void setManualInd(String newManualInd)
{
    manualInd = newManualInd;
}
/**
 * Sets NotesBreakDown31
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newNotesBreakDown31 java.lang.String
 */
public void setNotesBreakDown31(java.lang.String newNotesBreakDown31) {
	notesBreakDown31 = newNotesBreakDown31;
}
/**
 * Sets NotesBreakDown80.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newNotesBreakDown80 java.lang.String
 */
public void setNotesBreakDown80(java.lang.String newNotesBreakDown80) {
	notesBreakDown80 = newNotesBreakDown80;
}
/**
 * Sets OriginCity.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newOriginCity java.lang.String
 */
public void setOriginCity(java.lang.String newOriginCity) {
	originCity = newOriginCity;
}
/**
 * Sets OriginCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param one java.lang.String
 */
public void setOriginCode(java.lang.String newOriginCode) {
	originCode = newOriginCode;
}
/**
 * Sets OriginState.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newOriginState java.lang.String
 */
public void setOriginState(java.lang.String newOriginState) {
	originState = newOriginState;
}
/**
 * Sets RateRouteNotes
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newRateRouteNotes java.lang.String
 */
public void setRateRouteNotes(java.lang.String newRateRouteNotes) {
	rateRouteNotes = newRateRouteNotes;
}
/**
* Sets ReIssueMsg.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param newReIssueMsg java.lang.String
*/
public void setReIssueMsg(String newReIssueMsg)
{
    reIssueMsg = newReIssueMsg;
}
/**
 * Sets SealNo1.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newSealNo1 java.lang.String
 */
public void setSealNo1(java.lang.String newSealNo1) {
	sealNo1 = newSealNo1;
}
/**
 * Sets SealNo2.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newSealNo2 java.lang.String
 */
public void setSealNo2(java.lang.String newSealNo2) {
	sealNo2 = newSealNo2;
}
/**
 * Sets ShipVia.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newShipVia java.lang.String
 */
public void setShipVia(java.lang.String newShipVia) {
	shipVia = newShipVia;
}
/**
 * Sets StccCode.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newStccCode java.lang.String
 */
public void setStccCode(java.lang.String newStccCode) {
	stccCode = newStccCode;
}
/**
 * Sets TagsLterm.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newTagsLterm java.lang.String
 */
public void setTagsLterm(java.lang.String newTagsLterm) {
	tagsLterm = newTagsLterm;
}
/**
 * Sets TotalWeight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newTotalWeight java.lang.String
 */
public void setTotalWeight(java.lang.String newTotalWeight) {
	totalWeight = newTotalWeight;
}
/**
 * Sets VehicleBreakDown.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newVehicleBreakDown java.lang.String
 */
public void setVehicleBreakDown(java.lang.String newVehicleBreakDown) {
	vehicleBreakDown = newVehicleBreakDown;
}
}
