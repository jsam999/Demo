package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.bol.util.BOLId;

/**
 * This class is used to create objects to hold
 * BOL Vehicle data
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */

public class BOLVehicleData implements java.io.Serializable {
	private String fieldVehicleName = BOLId.STRING_INIT;
	private int fieldNumItems = 0;
	private double fieldTotalWeight = 0;
	private java.util.Vector fieldItems = new java.util.Vector();
/**
 * BOLVehicleData constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLVehicleData() {
	super();
}
/**
 * Method to add NumItems.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param nm int
 */
public void addNumItems(int nm)
{
    setNumItems(getNumItems() + nm);
}
/**
 * Method to add TotalWeight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param wt long
 */
public void addTotalWeight(long wt) {
	setTotalWeight(getTotalWeight() + wt);
}
/**
* Get Items.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.util.Vector
*/
public java.util.Vector getItems()
{
    return fieldItems;
}
/**
* Gets NumItems.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return int
*/
public int getNumItems()
{
    return fieldNumItems;
}
/**
* Gets TotalWeight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return double
*/
public double getTotalWeight() {
	return fieldTotalWeight;
}
/**
* Gets VehicleName.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getVehicleName()
{
    return fieldVehicleName;
}
/**
 * Sets Items
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param items java.util.Vector
 */
public void setItems(java.util.Vector items) {
	fieldItems = items;
}
/**
 * Sets NumItems.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param numItems int
 */
public void setNumItems(int numItems) {
	fieldNumItems = numItems;
}
/**
 * Sets TotalWeight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param totalWeight double
 */
public void setTotalWeight(double totalWeight) {
	fieldTotalWeight = totalWeight;
}
/**
 * Sets VehicleName.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param vehicleName java.lang.String
 */
public void setVehicleName(String vehicleName) {
	fieldVehicleName = vehicleName;
}
}
