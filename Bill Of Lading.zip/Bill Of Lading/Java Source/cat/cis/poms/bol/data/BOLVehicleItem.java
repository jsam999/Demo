package cat.cis.poms.bol.data;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.bol.util.BOLId;

/**
 * This class is used to create objects to hold
 * BOL Vehicle Item.
 * 
 * @author: Venky, POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */

public class BOLVehicleItem implements java.io.Serializable
{
    private String fieldPackDesc = BOLId.STRING_INIT;
    private String fieldIdNo = BOLId.STRING_INIT;
    private String fieldDescription = BOLId.STRING_INIT;
    private long fieldGrossWeight = 0;
    private long fieldNetWeight = 0;
    private int fieldHeight = 0;
    private int fieldWidth = 0;
    private int fieldLength = 0;
    private String fieldVehName = BOLId.STRING_INIT;
    private String fieldLineNo = BOLId.STRING_INIT;
/**
 * BOLVehicleItem constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLVehicleItem() {
	super();
}
/**
* Gets Description.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getDescription() {
	return fieldDescription;
}
/**
* Gets GrossWeight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public long getGrossWeight() {
	return fieldGrossWeight;
}
/**
* Gets Height.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return int
*/
public int getHeight() {
	return fieldHeight;
}
/**
* Gets IdNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getIdNo() {
	return fieldIdNo;
}
/**
* Gets Length.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return int
*/
public int getLength()
{
    return fieldLength;
}
/**
* Gets LineNo.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getLineNo() {
	return fieldLineNo;
}
/**
* Gets NetWeight.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return long
*/
public long getNetWeight() {
	return fieldNetWeight;
}
/**
* Gets PackDesc.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getPackDesc() {
	return fieldPackDesc;
}
/**
* Gets VehName.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getVehName() {
	return fieldVehName;
}
/**
* Gets Width.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return int
*/
public int getWidth() {
	return fieldWidth;
}
/**
 * Sets Description.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param description java.lang.String
 */
public void setDescription(String description) {
	fieldDescription = description;
}
/**
 * Sets GrossWeight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param grossWeight long
 */
public void setGrossWeight(long grossWeight) {
	fieldGrossWeight = grossWeight;
}
/**
 * Sets Height.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param height int
 */
public void setHeight(int height) {
	fieldHeight = height;
}
/**
 * Sets IdNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param idNo java.lang.String
 */
public void setIdNo(String idNo) {
	fieldIdNo = idNo;
}
/**
 * Sets Length.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param length int
 */
public void setLength(int length) {
	fieldLength = length;
}
/**
 * Sets LineNo.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param lineNo java.lang.String
 */
public void setLineNo(String lineNo) {
	fieldLineNo = lineNo;
}
/**
 * Sets NetWeight.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param netWeight long
 */
public void setNetWeight(long netWeight) {
	fieldNetWeight = netWeight;
}
/**
 * Sets PackDesc.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param packDesc java.lang.String
 */
public void setPackDesc(String packDesc) {
	fieldPackDesc = packDesc;
}
/**
 * Sets VehName.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param vehName java.lang.String
 */
public void setVehName(String vehName) {
	fieldVehName = vehName;
}
/**
 * Sets Width.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param width int
 */
public void setWidth(int width) {
	fieldWidth = width;
}
}
