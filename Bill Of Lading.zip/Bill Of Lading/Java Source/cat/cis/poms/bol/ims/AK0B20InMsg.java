package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: CatBolIMSConnectAK0B20.AK0B20InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B20InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B20InMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B20InMsg.class,150));
		 this.setBytes(new byte[150]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }            
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }      
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }      
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }      
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }      
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }      
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }      
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		 
	*/

   public java.lang.String getACF2__USER__ID__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(7)",false,true);
   }      
   public java.lang.String getBADGE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }      
   public short getLL__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("cat.bol.ims.AK0B20InMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }         
   public java.lang.String[] getMSO__IN()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 5;
		 java.lang.String[] returnArray = new java.lang.String[25];
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 25 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,5,false,false,false,-4,0,"X(05)",false,true);
			returnArray[i0] = element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public java.lang.String getMSO__IN(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 5;
		 int[] dim = {25};
		 int offset = 25 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public java.lang.String getTRAN__CODE__MSG__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }      
   public short getZZ__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__IN",null,getLL__IN());
		 firePropertyChange("ZZ__IN",null,getZZ__IN());
		 firePropertyChange("TRAN__CODE__MSG__IN",null,getTRAN__CODE__MSG__IN());
		 firePropertyChange("BADGE__IN",null,getBADGE__IN());
		 firePropertyChange("ACF2__USER__ID__IN",null,getACF2__USER__ID__IN());
		 firePropertyChange("MSO__IN",null,getMSO__IN());
	  }
   }      
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }      
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setACF2__USER__ID__IN(java.lang.String aACF2__USER__ID__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldACF2__USER__ID__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,18,aACF2__USER__ID__IN,9,0,9,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("ACF2__USER__ID__IN",oldACF2__USER__ID__IN,aACF2__USER__ID__IN);
	  return;
   }      
   public void setBADGE__IN(java.lang.String aBADGE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldBADGE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aBADGE__IN,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  firePropertyChange("BADGE__IN",oldBADGE__IN,aBADGE__IN);
	  return;
   }      
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }      
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,18, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,30, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,35, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,45, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,50, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,55, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,60, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,65, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,70, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,75, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,80, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,85, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,90, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,95, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,100, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,105, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,110, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,115, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,120, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,125, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,130, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,135, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,140, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,145, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  return;
   }      
   public void setLL__IN(short aLL__IN)
	  throws RecordConversionFailureException {
	  short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
	  return;
   }      
   public void setMSO__IN(java.lang.String[] aMSO__IN)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 5;
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 25 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aMSO__IN[i0],9,0,5,false,false,false,-4,0,"X(05)",false,true);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public void setMSO__IN(int index, java.lang.String aMSO__IN)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 5;
		 int[] dim = {25};
		 int offset = 25 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aMSO__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public void setTRAN__CODE__MSG__IN(java.lang.String aTRAN__CODE__MSG__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAN__CODE__MSG__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__MSG__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  firePropertyChange("TRAN__CODE__MSG__IN",oldTRAN__CODE__MSG__IN,aTRAN__CODE__MSG__IN);
	  return;
   }      
   public void setZZ__IN(short aZZ__IN)
	  throws RecordConversionFailureException {
	  short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
	  return;
   }      
}
