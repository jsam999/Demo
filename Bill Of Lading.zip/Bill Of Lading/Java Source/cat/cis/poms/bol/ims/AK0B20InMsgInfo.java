package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B20InMsgInfo.java
// Generated from P:\NEWT1AK0b20.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B20InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B20InMsgInfo_MSO__TABLE__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B20InMsgInfo_MSO__TABLE__IN () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 arraySize[0] = 25;
		 arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(05):DISPLAY")), "MSO__IN", new CobolInitialValueObject(" ", null));
		 addField(arrField);

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B20InMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__MSG__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(5):DISPLAY"), "BADGE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(7):DISPLAY"), "ACF2__USER__ID__IN", new CobolInitialValueObject(" ", null)));

	  addField(new NestedRecordField(new AK0B20InMsgInfo_MSO__TABLE__IN(), "MSO__TABLE__IN"));

   }      
}
