package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B20OutMsgInfo.java
// Generated from C:\9100b20.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B20OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B20OutMsgInfo_VEHICLE__BREAKDOWN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B20OutMsgInfo_VEHICLE__BREAKDOWN () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(03):DISPLAY"), "VEHNUM", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "PACKG__ID__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(06):DISPLAY"), "PACK__DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(14):DISPLAY"), "PACKG__LIST__DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "GROSS__WT__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "NET__WT__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(05):DISPLAY"), "HEIGHT__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(05):DISPLAY"), "WIDTH__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(05):DISPLAY"), "LENGTH__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "DIM__WT__LINE__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B20OutMsgInfo_ERR__MSG__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B20OutMsgInfo_ERR__MSG__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(07):DISPLAY"), "MSO__NO__ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "fill_0", new CobolInitialValueObject(" - ", null)));

		 addField(new Field(new CobolType("X(50):DISPLAY"), "MSO__ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B20OutMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

	  arraySize[0] = 120;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B20OutMsgInfo_VEHICLE__BREAKDOWN()), "VEHICLE__BREAKDOWN");
	  addField(arrField);

	  addField(new NestedRecordField(new AK0B20OutMsgInfo_ERR__MSG__OUT(), "ERR__MSG__OUT"));

   }   
}
