package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN
 * This is a generated file.  Do not edit.
 */

public class AK0B20OutMsg_VEHICLE__BREAKDOWN extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B20OutMsg_VEHICLE__BREAKDOWN()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN.class,65));
		 this.setBytes(new byte[65]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getDIM__WT__LINE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }   
   public java.lang.String getGROSS__WT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,33,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getHEIGHT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,47,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }   
   public java.lang.String getLENGTH__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,57,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }   
   public java.lang.String getNET__WT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getPACK__DESC__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }   
   public java.lang.String getPACKG__ID__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }   
   public java.lang.String getPACKG__LIST__DESC__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,14,false,false,false,-13,0,"X(14)",false,true);
   }   
   public java.lang.String getVEHNUM()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }   
   public java.lang.String getWIDTH__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,52,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("VEHNUM",null,getVEHNUM());
		 firePropertyChange("PACKG__ID__NO__OUT",null,getPACKG__ID__NO__OUT());
		 firePropertyChange("PACK__DESC__OUT",null,getPACK__DESC__OUT());
		 firePropertyChange("PACKG__LIST__DESC__OUT",null,getPACKG__LIST__DESC__OUT());
		 firePropertyChange("GROSS__WT__OUT",null,getGROSS__WT__OUT());
		 firePropertyChange("NET__WT__OUT",null,getNET__WT__OUT());
		 firePropertyChange("HEIGHT__OUT",null,getHEIGHT__OUT());
		 firePropertyChange("WIDTH__OUT",null,getWIDTH__OUT());
		 firePropertyChange("LENGTH__OUT",null,getLENGTH__OUT());
		 firePropertyChange("DIM__WT__LINE__OUT",null,getDIM__WT__LINE__OUT());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setDIM__WT__LINE__OUT(java.lang.String aDIM__WT__LINE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldDIM__WT__LINE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,62,aDIM__WT__LINE__OUT,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  firePropertyChange("DIM__WT__LINE__OUT",oldDIM__WT__LINE__OUT,aDIM__WT__LINE__OUT);
	  return;
   }   
   public void setGROSS__WT__OUT(java.lang.String aGROSS__WT__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldGROSS__WT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,33,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,33,aGROSS__WT__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("GROSS__WT__OUT",oldGROSS__WT__OUT,aGROSS__WT__OUT);
	  return;
   }   
   public void setHEIGHT__OUT(java.lang.String aHEIGHT__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldHEIGHT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,47,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,47,aHEIGHT__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  firePropertyChange("HEIGHT__OUT",oldHEIGHT__OUT,aHEIGHT__OUT);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,3, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,19, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,14,false,false,false,-13,0,"X(14)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,33, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,47, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,52, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,57, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,62, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  return;
   }   
   public void setLENGTH__OUT(java.lang.String aLENGTH__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldLENGTH__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,57,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,57,aLENGTH__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  firePropertyChange("LENGTH__OUT",oldLENGTH__OUT,aLENGTH__OUT);
	  return;
   }   
   public void setNET__WT__OUT(java.lang.String aNET__WT__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldNET__WT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aNET__WT__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("NET__WT__OUT",oldNET__WT__OUT,aNET__WT__OUT);
	  return;
   }   
   public void setPACK__DESC__OUT(java.lang.String aPACK__DESC__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldPACK__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aPACK__DESC__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  firePropertyChange("PACK__DESC__OUT",oldPACK__DESC__OUT,aPACK__DESC__OUT);
	  return;
   }   
   public void setPACKG__ID__NO__OUT(java.lang.String aPACKG__ID__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldPACKG__ID__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,3,aPACKG__ID__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("PACKG__ID__NO__OUT",oldPACKG__ID__NO__OUT,aPACKG__ID__NO__OUT);
	  return;
   }   
   public void setPACKG__LIST__DESC__OUT(java.lang.String aPACKG__LIST__DESC__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldPACKG__LIST__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,14,false,false,false,-13,0,"X(14)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,19,aPACKG__LIST__DESC__OUT,9,0,14,false,false,false,-13,0,"X(14)",false,true);
	  firePropertyChange("PACKG__LIST__DESC__OUT",oldPACKG__LIST__DESC__OUT,aPACKG__LIST__DESC__OUT);
	  return;
   }   
   public void setVEHNUM(java.lang.String aVEHNUM)
	  throws RecordConversionFailureException {
	  java.lang.String oldVEHNUM = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aVEHNUM,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  firePropertyChange("VEHNUM",oldVEHNUM,aVEHNUM);
	  return;
   }   
   public void setWIDTH__OUT(java.lang.String aWIDTH__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldWIDTH__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,52,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,52,aWIDTH__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  firePropertyChange("WIDTH__OUT",oldWIDTH__OUT,aWIDTH__OUT);
	  return;
   }   
}
