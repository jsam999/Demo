package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWNBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B20OutMsg_VEHICLE__BREAKDOWNBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getDIM__WT__LINE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DIM__WT__LINE__OUT", Class.forName(getBeanClassName()), "getDIM__WT__LINE__OUT", "setDIM__WT__LINE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DIM__WT__LINE__OUT");
	  aDescriptor.setDisplayName("DIM__WT__LINE__OUT");
	  aDescriptor.setShortDescription("DIM__WT__LINE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getGROSS__WT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("GROSS__WT__OUT", Class.forName(getBeanClassName()), "getGROSS__WT__OUT", "setGROSS__WT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("GROSS__WT__OUT");
	  aDescriptor.setDisplayName("GROSS__WT__OUT");
	  aDescriptor.setShortDescription("GROSS__WT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHEIGHT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HEIGHT__OUT", Class.forName(getBeanClassName()), "getHEIGHT__OUT", "setHEIGHT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HEIGHT__OUT");
	  aDescriptor.setDisplayName("HEIGHT__OUT");
	  aDescriptor.setShortDescription("HEIGHT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getLENGTH__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LENGTH__OUT", Class.forName(getBeanClassName()), "getLENGTH__OUT", "setLENGTH__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LENGTH__OUT");
	  aDescriptor.setDisplayName("LENGTH__OUT");
	  aDescriptor.setShortDescription("LENGTH__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getNET__WT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("NET__WT__OUT", Class.forName(getBeanClassName()), "getNET__WT__OUT", "setNET__WT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("NET__WT__OUT");
	  aDescriptor.setDisplayName("NET__WT__OUT");
	  aDescriptor.setShortDescription("NET__WT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACK__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACK__DESC__OUT", Class.forName(getBeanClassName()), "getPACK__DESC__OUT", "setPACK__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACK__DESC__OUT");
	  aDescriptor.setDisplayName("PACK__DESC__OUT");
	  aDescriptor.setShortDescription("PACK__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACKG__ID__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACKG__ID__NO__OUT", Class.forName(getBeanClassName()), "getPACKG__ID__NO__OUT", "setPACKG__ID__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACKG__ID__NO__OUT");
	  aDescriptor.setDisplayName("PACKG__ID__NO__OUT");
	  aDescriptor.setShortDescription("PACKG__ID__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACKG__LIST__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACKG__LIST__DESC__OUT", Class.forName(getBeanClassName()), "getPACKG__LIST__DESC__OUT", "setPACKG__LIST__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACKG__LIST__DESC__OUT");
	  aDescriptor.setDisplayName("PACKG__LIST__DESC__OUT");
	  aDescriptor.setShortDescription("PACKG__LIST__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getVEHNUMPropertyDescriptor()
			,getPACKG__ID__NO__OUTPropertyDescriptor()
			,getPACK__DESC__OUTPropertyDescriptor()
			,getPACKG__LIST__DESC__OUTPropertyDescriptor()
			,getGROSS__WT__OUTPropertyDescriptor()
			,getNET__WT__OUTPropertyDescriptor()
			,getHEIGHT__OUTPropertyDescriptor()
			,getWIDTH__OUTPropertyDescriptor()
			,getLENGTH__OUTPropertyDescriptor()
			,getDIM__WT__LINE__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getVEHNUMPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("VEHNUM", Class.forName(getBeanClassName()), "getVEHNUM", "setVEHNUM" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("VEHNUM");
	  aDescriptor.setDisplayName("VEHNUM");
	  aDescriptor.setShortDescription("VEHNUM");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getWIDTH__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("WIDTH__OUT", Class.forName(getBeanClassName()), "getWIDTH__OUT", "setWIDTH__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WIDTH__OUT");
	  aDescriptor.setDisplayName("WIDTH__OUT");
	  aDescriptor.setShortDescription("WIDTH__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
