package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B25InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B25InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.PropertyDescriptor getACF2__USER__ID__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ACF2__USER__ID__IN", Class.forName(getBeanClassName()), "getACF2__USER__ID__IN", "setACF2__USER__ID__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ACF2__USER__ID__IN");
	  aDescriptor.setDisplayName("ACF2__USER__ID__IN");
	  aDescriptor.setShortDescription("ACF2__USER__ID__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getBADGE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BADGE__IN", Class.forName(getBeanClassName()), "getBADGE__IN", "setBADGE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BADGE__IN");
	  aDescriptor.setDisplayName("BADGE__IN");
	  aDescriptor.setShortDescription("BADGE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B25InMsg.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B25InMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B25InMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__IN");
	  aDescriptor.setDisplayName("LL__IN");
	  aDescriptor.setShortDescription("LL__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getMSO__TABLE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("MSO__TABLE__IN", Class.forName(getBeanClassName()), "getMSO__TABLE__IN", "setMSO__TABLE__IN", "getMSO__TABLE__IN", "setMSO__TABLE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MSO__TABLE__IN");
	  aDescriptor.setDisplayName("MSO__TABLE__IN");
	  aDescriptor.setShortDescription("MSO__TABLE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getORD__ENTRY__CLERKPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ORD__ENTRY__CLERK", Class.forName(getBeanClassName()), "getORD__ENTRY__CLERK", "setORD__ENTRY__CLERK" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ORD__ENTRY__CLERK");
	  aDescriptor.setDisplayName("ORD__ENTRY__CLERK");
	  aDescriptor.setShortDescription("ORD__ENTRY__CLERK");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__INPropertyDescriptor()
			,getZZ__INPropertyDescriptor()
			,getTRAN__CODE__MSG__INPropertyDescriptor()
			,getBADGE__INPropertyDescriptor()
			,getACF2__USER__ID__INPropertyDescriptor()
			,getORD__ENTRY__CLERKPropertyDescriptor()
			,getMSO__TABLE__INPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getTRAN__CODE__MSG__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__MSG__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__MSG__IN", "setTRAN__CODE__MSG__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAN__CODE__MSG__IN");
	  aDescriptor.setDisplayName("TRAN__CODE__MSG__IN");
	  aDescriptor.setShortDescription("TRAN__CODE__MSG__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__IN");
	  aDescriptor.setDisplayName("ZZ__IN");
	  aDescriptor.setShortDescription("ZZ__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
