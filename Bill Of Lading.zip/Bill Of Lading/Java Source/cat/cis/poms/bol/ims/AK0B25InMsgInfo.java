package cat.cis.poms.bol.ims;

import com.ibm.ivj.eab.record.cobol.CobolArrayType;
import com.ibm.ivj.eab.record.cobol.CobolDynamicRecordType;
import com.ibm.ivj.eab.record.cobol.CobolInitialValueObject;
import com.ibm.ivj.eab.record.cobol.CobolType;
import com.ibm.record.ArrayField;
import com.ibm.record.Field;
import com.ibm.record.RecordException;

//
//
// FILE NAME: AK0B25InMsgInfo.java
// Generated from C:\9040b25.ccp COBOL source file.
//


/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B25InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B25InMsgInfo_MSO__TABLE__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B25InMsgInfo_MSO__TABLE__IN () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(07):DISPLAY"), "MSO__NO__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "DIM__WT__LINE__NO__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "VEHNUM__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B25InMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__MSG__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(5):DISPLAY"), "BADGE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(7):DISPLAY"), "ACF2__USER__ID__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(03):DISPLAY"), "ORD__ENTRY__CLERK", new CobolInitialValueObject(" ", null)));

	  arraySize[0] = 120;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B25InMsgInfo_MSO__TABLE__IN()), "MSO__TABLE__IN");
	  addField(arrField);

   }   
}
