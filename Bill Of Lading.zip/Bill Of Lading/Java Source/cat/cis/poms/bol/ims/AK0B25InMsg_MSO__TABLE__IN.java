package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B25InMsg_MSO__TABLE__IN
 * This is a generated file.  Do not edit.
 */

public class AK0B25InMsg_MSO__TABLE__IN extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B25InMsg_MSO__TABLE__IN()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B25InMsg_MSO__TABLE__IN.class,13));
		 this.setBytes(new byte[13]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getDIM__WT__LINE__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,7,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }   
   public java.lang.String getMSO__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }   
   public java.lang.String getVEHNUM__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("MSO__NO__IN",null,getMSO__NO__IN());
		 firePropertyChange("DIM__WT__LINE__NO__IN",null,getDIM__WT__LINE__NO__IN());
		 firePropertyChange("VEHNUM__IN",null,getVEHNUM__IN());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setDIM__WT__LINE__NO__IN(java.lang.String aDIM__WT__LINE__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldDIM__WT__LINE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,7,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,7,aDIM__WT__LINE__NO__IN,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  firePropertyChange("DIM__WT__LINE__NO__IN",oldDIM__WT__LINE__NO__IN,aDIM__WT__LINE__NO__IN);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,7, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  return;
   }   
   public void setMSO__NO__IN(java.lang.String aMSO__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldMSO__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aMSO__NO__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  firePropertyChange("MSO__NO__IN",oldMSO__NO__IN,aMSO__NO__IN);
	  return;
   }   
   public void setVEHNUM__IN(java.lang.String aVEHNUM__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldVEHNUM__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aVEHNUM__IN,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  firePropertyChange("VEHNUM__IN",oldVEHNUM__IN,aVEHNUM__IN);
	  return;
   }   
}
