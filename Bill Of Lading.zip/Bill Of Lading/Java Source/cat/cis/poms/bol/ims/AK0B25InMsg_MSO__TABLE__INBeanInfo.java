package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B25InMsg_MSO__TABLE__INBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B25InMsg_MSO__TABLE__INBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B25InMsg_MSO__TABLE__IN.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B25InMsg_MSO__TABLE__IN");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B25InMsg_MSO__TABLE__IN.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getDIM__WT__LINE__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DIM__WT__LINE__NO__IN", Class.forName(getBeanClassName()), "getDIM__WT__LINE__NO__IN", "setDIM__WT__LINE__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DIM__WT__LINE__NO__IN");
	  aDescriptor.setDisplayName("DIM__WT__LINE__NO__IN");
	  aDescriptor.setShortDescription("DIM__WT__LINE__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getMSO__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MSO__NO__IN", Class.forName(getBeanClassName()), "getMSO__NO__IN", "setMSO__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MSO__NO__IN");
	  aDescriptor.setDisplayName("MSO__NO__IN");
	  aDescriptor.setShortDescription("MSO__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getMSO__NO__INPropertyDescriptor()
			,getDIM__WT__LINE__NO__INPropertyDescriptor()
			,getVEHNUM__INPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getVEHNUM__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("VEHNUM__IN", Class.forName(getBeanClassName()), "getVEHNUM__IN", "setVEHNUM__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("VEHNUM__IN");
	  aDescriptor.setDisplayName("VEHNUM__IN");
	  aDescriptor.setShortDescription("VEHNUM__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
