package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B25OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B25OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B25OutMsg.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B25OutMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B25OutMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_0");
	  aDescriptor.setDisplayName("fill_0");
	  aDescriptor.setShortDescription("fill_0");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__OUT");
	  aDescriptor.setDisplayName("LL__OUT");
	  aDescriptor.setShortDescription("LL__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getMSO__ERR__MSG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MSO__ERR__MSG__OUT", Class.forName(getBeanClassName()), "getMSO__ERR__MSG__OUT", "setMSO__ERR__MSG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MSO__ERR__MSG__OUT");
	  aDescriptor.setDisplayName("MSO__ERR__MSG__OUT");
	  aDescriptor.setShortDescription("MSO__ERR__MSG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getMSO__NO__ERR__MSG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MSO__NO__ERR__MSG__OUT", Class.forName(getBeanClassName()), "getMSO__NO__ERR__MSG__OUT", "setMSO__NO__ERR__MSG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MSO__NO__ERR__MSG__OUT");
	  aDescriptor.setDisplayName("MSO__NO__ERR__MSG__OUT");
	  aDescriptor.setShortDescription("MSO__NO__ERR__MSG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__OUTPropertyDescriptor()
			,getZZ__OUTPropertyDescriptor()
			,getMSO__NO__ERR__MSG__OUTPropertyDescriptor()
			,getFill_0PropertyDescriptor()
			,getMSO__ERR__MSG__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__OUT");
	  aDescriptor.setDisplayName("ZZ__OUT");
	  aDescriptor.setShortDescription("ZZ__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
