package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B31InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B31InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B31InMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B31InMsg.class,2170));
         this.setBytes(new byte[2170]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getACCT__DEPT__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2142,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getACCT__DIV__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2147,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }
   public java.lang.String getACCT__EXP__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2152,9,0,4,false,false,false,-3,0,"X(04)",false,true);
   }
   public java.lang.String getACCT__FAC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2140,9,0,2,false,false,false,-1,0,"XX",false,true);
   }
   public java.lang.String getACCT__ORDER__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2156,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getACCT__SEC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2150,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__CITY__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,341,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getADR__COUNTRY__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,383,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,211,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getADR__NM__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,236,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__POSTAL__ZONE__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,373,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getADR__STATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,371,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__TXT__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,271,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__TXT__LN2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,306,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getBADGE__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getBL__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getBL__NO__R__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getCLRN__LTR__FILE__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,98,9,0,15,false,false,false,-14,0,"X(15)",false,true);
   }
   public java.lang.String getCLRN__LTR__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,113,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONSIGNEE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,57,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getCONTAINER__NUMBER__1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,78,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTAINER__NUMBER__2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,88,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTRACT__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,155,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }
   public java.lang.String getDATE__SHIPPED__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,46,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getDEL__INST__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,385,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,415,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN3__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,445,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN4__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,475,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN5__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,505,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDESC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2076,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDESTINATION__CITY__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,123,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getEQUIP__DESC__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,55,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getFAC__BLDG__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }
   public java.lang.String getFAC__BLDG__R__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,36,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }
   public java.lang.String getFRT__CHRG__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2139,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public double getFRT__FLAT__CHRG__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2130,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
   }
   public double getFRT__RATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2121,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
   }
   public java.lang.String getFRT__RATE__UM__ABBR__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2106,9,0,4,false,false,false,-3,0,"X(04)",false,true);
   }
   public java.lang.String getINLAND__FRT__CHRG__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,63,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public short getLL__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public java.lang.String[] getMANUAL__NOTE()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 50;
         java.lang.String[] returnArray = new java.lang.String[30];
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 565 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,50,false,false,false,-49,0,"X(50)",false,true);
            returnArray[i0] = element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getMANUAL__NOTE(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 50;
         int[] dim = {30};
         int offset = 565 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.bol.ims.AK0B31InMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public java.lang.String getMISC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2163,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getORIGIN__CITY__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,129,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getORIGIN__CITY__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,135,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getORIGIN__STATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,153,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getRECORD__TYPE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getREF__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2066,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getROUTE__OR__CARRIER__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,176,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getROUTE__OR__CARRIER__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,181,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getSEAL__NO__1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,64,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getSEAL__NO__2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,71,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String[] getSHORT__CUT__NOTE()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 3;
         java.lang.String[] returnArray = new java.lang.String[10];
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 535 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,3,false,false,false,-2,0,"X(03)",false,true);
            returnArray[i0] = element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSHORT__CUT__NOTE(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 3;
         int[] dim = {10};
         int offset = 535 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSTCC__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,167,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public java.lang.String getTRAN__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public java.lang.String getTRAN__TYPE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2065,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getTRANSP__MODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,53,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public double getUNITS__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2110,8,11,11,false,true,true,-4,0,"9(07)V9(4)",false,false);
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		is increased from 7 to 9.
	*/

   public java.lang.String getUSER__ACF2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
   }
   public short getZZ__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__IN",null,getLL__IN());
         firePropertyChange("ZZ__IN",null,getZZ__IN());
         firePropertyChange("TRAN__CODE__IN",null,getTRAN__CODE__IN());
         firePropertyChange("BADGE__NO__IN",null,getBADGE__NO__IN());
         firePropertyChange("USER__ACF2__IN",null,getUSER__ACF2__IN());
         firePropertyChange("RECORD__TYPE__IN",null,getRECORD__TYPE__IN());
         firePropertyChange("FAC__BLDG__IN",null,getFAC__BLDG__IN());
         firePropertyChange("BL__NO__IN",null,getBL__NO__IN());
         firePropertyChange("FAC__BLDG__R__IN",null,getFAC__BLDG__R__IN());
         firePropertyChange("BL__NO__R__IN",null,getBL__NO__R__IN());
         firePropertyChange("DATE__SHIPPED__IN",null,getDATE__SHIPPED__IN());
         firePropertyChange("TRANSP__MODE__IN",null,getTRANSP__MODE__IN());
         firePropertyChange("EQUIP__DESC__CODE__IN",null,getEQUIP__DESC__CODE__IN());
         firePropertyChange("CONSIGNEE__IN",null,getCONSIGNEE__IN());
         firePropertyChange("INLAND__FRT__CHRG__CODE__IN",null,getINLAND__FRT__CHRG__CODE__IN());
         firePropertyChange("SEAL__NO__1__IN",null,getSEAL__NO__1__IN());
         firePropertyChange("SEAL__NO__2__IN",null,getSEAL__NO__2__IN());
         firePropertyChange("CONTAINER__NUMBER__1__IN",null,getCONTAINER__NUMBER__1__IN());
         firePropertyChange("CONTAINER__NUMBER__2__IN",null,getCONTAINER__NUMBER__2__IN());
         firePropertyChange("CLRN__LTR__FILE__NO__IN",null,getCLRN__LTR__FILE__NO__IN());
         firePropertyChange("CLRN__LTR__NO__IN",null,getCLRN__LTR__NO__IN());
         firePropertyChange("DESTINATION__CITY__CODE__IN",null,getDESTINATION__CITY__CODE__IN());
         firePropertyChange("ORIGIN__CITY__CODE__IN",null,getORIGIN__CITY__CODE__IN());
         firePropertyChange("ORIGIN__CITY__NAME__IN",null,getORIGIN__CITY__NAME__IN());
         firePropertyChange("ORIGIN__STATE__IN",null,getORIGIN__STATE__IN());
         firePropertyChange("CONTRACT__NO__IN",null,getCONTRACT__NO__IN());
         firePropertyChange("STCC__CODE__IN",null,getSTCC__CODE__IN());
         firePropertyChange("ROUTE__OR__CARRIER__CODE__IN",null,getROUTE__OR__CARRIER__CODE__IN());
         firePropertyChange("ROUTE__OR__CARRIER__NAME__IN",null,getROUTE__OR__CARRIER__NAME__IN());
         firePropertyChange("ADR__NAME__IN",null,getADR__NAME__IN());
         firePropertyChange("ADR__NM__LN1__IN",null,getADR__NM__LN1__IN());
         firePropertyChange("ADR__TXT__LN1__IN",null,getADR__TXT__LN1__IN());
         firePropertyChange("ADR__TXT__LN2__IN",null,getADR__TXT__LN2__IN());
         firePropertyChange("ADR__CITY__NAME__IN",null,getADR__CITY__NAME__IN());
         firePropertyChange("ADR__STATE__IN",null,getADR__STATE__IN());
         firePropertyChange("ADR__POSTAL__ZONE__CODE__IN",null,getADR__POSTAL__ZONE__CODE__IN());
         firePropertyChange("ADR__COUNTRY__IN",null,getADR__COUNTRY__IN());
         firePropertyChange("DEL__INST__LN1__IN",null,getDEL__INST__LN1__IN());
         firePropertyChange("DEL__INST__LN2__IN",null,getDEL__INST__LN2__IN());
         firePropertyChange("DEL__INST__LN3__IN",null,getDEL__INST__LN3__IN());
         firePropertyChange("DEL__INST__LN4__IN",null,getDEL__INST__LN4__IN());
         firePropertyChange("DEL__INST__LN5__IN",null,getDEL__INST__LN5__IN());
         firePropertyChange("SHORT__CUT__NOTE",null,getSHORT__CUT__NOTE());
         firePropertyChange("MANUAL__NOTE",null,getMANUAL__NOTE());
         firePropertyChange("TRAN__TYPE__IN",null,getTRAN__TYPE__IN());
         firePropertyChange("REF__NO__IN",null,getREF__NO__IN());
         firePropertyChange("DESC__IN",null,getDESC__IN());
         firePropertyChange("FRT__RATE__UM__ABBR__IN",null,getFRT__RATE__UM__ABBR__IN());
         firePropertyChange("UNITS__IN",null,getUNITS__IN());
         firePropertyChange("FRT__RATE__IN",null,getFRT__RATE__IN());
         firePropertyChange("FRT__FLAT__CHRG__IN",null,getFRT__FLAT__CHRG__IN());
         firePropertyChange("FRT__CHRG__CODE__IN",null,getFRT__CHRG__CODE__IN());
         firePropertyChange("ACCT__FAC__IN",null,getACCT__FAC__IN());
         firePropertyChange("ACCT__DEPT__IN",null,getACCT__DEPT__IN());
         firePropertyChange("ACCT__DIV__IN",null,getACCT__DIV__IN());
         firePropertyChange("ACCT__SEC__IN",null,getACCT__SEC__IN());
         firePropertyChange("ACCT__EXP__IN",null,getACCT__EXP__IN());
         firePropertyChange("ACCT__ORDER__NO__IN",null,getACCT__ORDER__NO__IN());
         firePropertyChange("MISC__IN",null,getMISC__IN());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setACCT__DEPT__IN(java.lang.String aACCT__DEPT__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__DEPT__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2142,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2142,aACCT__DEPT__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("ACCT__DEPT__IN",oldACCT__DEPT__IN,aACCT__DEPT__IN);
      return;
   }
   public void setACCT__DIV__IN(java.lang.String aACCT__DIV__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__DIV__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2147,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2147,aACCT__DIV__IN,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      firePropertyChange("ACCT__DIV__IN",oldACCT__DIV__IN,aACCT__DIV__IN);
      return;
   }
   public void setACCT__EXP__IN(java.lang.String aACCT__EXP__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__EXP__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2152,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2152,aACCT__EXP__IN,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      firePropertyChange("ACCT__EXP__IN",oldACCT__EXP__IN,aACCT__EXP__IN);
      return;
   }
   public void setACCT__FAC__IN(java.lang.String aACCT__FAC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__FAC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2140,9,0,2,false,false,false,-1,0,"XX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2140,aACCT__FAC__IN,9,0,2,false,false,false,-1,0,"XX",false,true);
      firePropertyChange("ACCT__FAC__IN",oldACCT__FAC__IN,aACCT__FAC__IN);
      return;
   }
   public void setACCT__ORDER__NO__IN(java.lang.String aACCT__ORDER__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__ORDER__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2156,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2156,aACCT__ORDER__NO__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("ACCT__ORDER__NO__IN",oldACCT__ORDER__NO__IN,aACCT__ORDER__NO__IN);
      return;
   }
   public void setACCT__SEC__IN(java.lang.String aACCT__SEC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__SEC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2150,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2150,aACCT__SEC__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ACCT__SEC__IN",oldACCT__SEC__IN,aACCT__SEC__IN);
      return;
   }
   public void setADR__CITY__NAME__IN(java.lang.String aADR__CITY__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__CITY__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,341,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,341,aADR__CITY__NAME__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ADR__CITY__NAME__IN",oldADR__CITY__NAME__IN,aADR__CITY__NAME__IN);
      return;
   }
   public void setADR__COUNTRY__IN(java.lang.String aADR__COUNTRY__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__COUNTRY__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,383,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,383,aADR__COUNTRY__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__COUNTRY__IN",oldADR__COUNTRY__IN,aADR__COUNTRY__IN);
      return;
   }
   public void setADR__NAME__IN(java.lang.String aADR__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,211,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,211,aADR__NAME__IN,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("ADR__NAME__IN",oldADR__NAME__IN,aADR__NAME__IN);
      return;
   }
   public void setADR__NM__LN1__IN(java.lang.String aADR__NM__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NM__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,236,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,236,aADR__NM__LN1__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__NM__LN1__IN",oldADR__NM__LN1__IN,aADR__NM__LN1__IN);
      return;
   }
   public void setADR__POSTAL__ZONE__CODE__IN(java.lang.String aADR__POSTAL__ZONE__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__POSTAL__ZONE__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,373,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,373,aADR__POSTAL__ZONE__CODE__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("ADR__POSTAL__ZONE__CODE__IN",oldADR__POSTAL__ZONE__CODE__IN,aADR__POSTAL__ZONE__CODE__IN);
      return;
   }
   public void setADR__STATE__IN(java.lang.String aADR__STATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__STATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,371,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,371,aADR__STATE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__STATE__IN",oldADR__STATE__IN,aADR__STATE__IN);
      return;
   }
   public void setADR__TXT__LN1__IN(java.lang.String aADR__TXT__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,271,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,271,aADR__TXT__LN1__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN1__IN",oldADR__TXT__LN1__IN,aADR__TXT__LN1__IN);
      return;
   }
   public void setADR__TXT__LN2__IN(java.lang.String aADR__TXT__LN2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,306,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,306,aADR__TXT__LN2__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN2__IN",oldADR__TXT__LN2__IN,aADR__TXT__LN2__IN);
      return;
   }
   public void setBADGE__NO__IN(java.lang.String aBADGE__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBADGE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aBADGE__NO__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("BADGE__NO__IN",oldBADGE__NO__IN,aBADGE__NO__IN);
      return;
   }
   public void setBL__NO__IN(java.lang.String aBL__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBL__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,30,aBL__NO__IN,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("BL__NO__IN",oldBL__NO__IN,aBL__NO__IN);
      return;
   }
   public void setBL__NO__R__IN(java.lang.String aBL__NO__R__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBL__NO__R__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aBL__NO__R__IN,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("BL__NO__R__IN",oldBL__NO__R__IN,aBL__NO__R__IN);
      return;
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setCLRN__LTR__FILE__NO__IN(java.lang.String aCLRN__LTR__FILE__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__FILE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,98,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,98,aCLRN__LTR__FILE__NO__IN,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      firePropertyChange("CLRN__LTR__FILE__NO__IN",oldCLRN__LTR__FILE__NO__IN,aCLRN__LTR__FILE__NO__IN);
      return;
   }
   public void setCLRN__LTR__NO__IN(java.lang.String aCLRN__LTR__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,113,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,113,aCLRN__LTR__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CLRN__LTR__NO__IN",oldCLRN__LTR__NO__IN,aCLRN__LTR__NO__IN);
      return;
   }
   public void setCONSIGNEE__IN(java.lang.String aCONSIGNEE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONSIGNEE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,57,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,57,aCONSIGNEE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("CONSIGNEE__IN",oldCONSIGNEE__IN,aCONSIGNEE__IN);
      return;
   }
   public void setCONTAINER__NUMBER__1__IN(java.lang.String aCONTAINER__NUMBER__1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NUMBER__1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,78,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,78,aCONTAINER__NUMBER__1__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NUMBER__1__IN",oldCONTAINER__NUMBER__1__IN,aCONTAINER__NUMBER__1__IN);
      return;
   }
   public void setCONTAINER__NUMBER__2__IN(java.lang.String aCONTAINER__NUMBER__2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NUMBER__2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,88,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,88,aCONTAINER__NUMBER__2__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NUMBER__2__IN",oldCONTAINER__NUMBER__2__IN,aCONTAINER__NUMBER__2__IN);
      return;
   }
   public void setCONTRACT__NO__IN(java.lang.String aCONTRACT__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTRACT__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,155,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,155,aCONTRACT__NO__IN,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      firePropertyChange("CONTRACT__NO__IN",oldCONTRACT__NO__IN,aCONTRACT__NO__IN);
      return;
   }
   public void setDATE__SHIPPED__IN(java.lang.String aDATE__SHIPPED__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDATE__SHIPPED__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,46,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,46,aDATE__SHIPPED__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("DATE__SHIPPED__IN",oldDATE__SHIPPED__IN,aDATE__SHIPPED__IN);
      return;
   }
   public void setDEL__INST__LN1__IN(java.lang.String aDEL__INST__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,385,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,385,aDEL__INST__LN1__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN1__IN",oldDEL__INST__LN1__IN,aDEL__INST__LN1__IN);
      return;
   }
   public void setDEL__INST__LN2__IN(java.lang.String aDEL__INST__LN2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,415,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,415,aDEL__INST__LN2__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN2__IN",oldDEL__INST__LN2__IN,aDEL__INST__LN2__IN);
      return;
   }
   public void setDEL__INST__LN3__IN(java.lang.String aDEL__INST__LN3__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN3__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,445,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,445,aDEL__INST__LN3__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN3__IN",oldDEL__INST__LN3__IN,aDEL__INST__LN3__IN);
      return;
   }
   public void setDEL__INST__LN4__IN(java.lang.String aDEL__INST__LN4__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN4__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,475,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,475,aDEL__INST__LN4__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN4__IN",oldDEL__INST__LN4__IN,aDEL__INST__LN4__IN);
      return;
   }
   public void setDEL__INST__LN5__IN(java.lang.String aDEL__INST__LN5__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN5__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,505,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,505,aDEL__INST__LN5__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN5__IN",oldDEL__INST__LN5__IN,aDEL__INST__LN5__IN);
      return;
   }
   public void setDESC__IN(java.lang.String aDESC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDESC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2076,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2076,aDESC__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DESC__IN",oldDESC__IN,aDESC__IN);
      return;
   }
   public void setDESTINATION__CITY__CODE__IN(java.lang.String aDESTINATION__CITY__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDESTINATION__CITY__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,123,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,123,aDESTINATION__CITY__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("DESTINATION__CITY__CODE__IN",oldDESTINATION__CITY__CODE__IN,aDESTINATION__CITY__CODE__IN);
      return;
   }
   public void setEQUIP__DESC__CODE__IN(java.lang.String aEQUIP__DESC__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldEQUIP__DESC__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,55,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,55,aEQUIP__DESC__CODE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("EQUIP__DESC__CODE__IN",oldEQUIP__DESC__CODE__IN,aEQUIP__DESC__CODE__IN);
      return;
   }
   public void setFAC__BLDG__IN(java.lang.String aFAC__BLDG__IN)
      throws RecordConversionFailureException {
      java.lang.String oldFAC__BLDG__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,26,aFAC__BLDG__IN,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      firePropertyChange("FAC__BLDG__IN",oldFAC__BLDG__IN,aFAC__BLDG__IN);
      return;
   }
   public void setFAC__BLDG__R__IN(java.lang.String aFAC__BLDG__R__IN)
      throws RecordConversionFailureException {
      java.lang.String oldFAC__BLDG__R__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,36,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,36,aFAC__BLDG__R__IN,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      firePropertyChange("FAC__BLDG__R__IN",oldFAC__BLDG__R__IN,aFAC__BLDG__R__IN);
      return;
   }
   public void setFRT__CHRG__CODE__IN(java.lang.String aFRT__CHRG__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldFRT__CHRG__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2139,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2139,aFRT__CHRG__CODE__IN,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("FRT__CHRG__CODE__IN",oldFRT__CHRG__CODE__IN,aFRT__CHRG__CODE__IN);
      return;
   }
   public void setFRT__FLAT__CHRG__IN(double aFRT__FLAT__CHRG__IN)
      throws RecordConversionFailureException {
      double oldFRT__FLAT__CHRG__IN = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2130,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,2130,aFRT__FLAT__CHRG__IN,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
      firePropertyChange("FRT__FLAT__CHRG__IN",oldFRT__FLAT__CHRG__IN,aFRT__FLAT__CHRG__IN);
      return;
   }
   public void setFRT__RATE__IN(double aFRT__RATE__IN)
      throws RecordConversionFailureException {
      double oldFRT__RATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2121,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,2121,aFRT__RATE__IN,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
      firePropertyChange("FRT__RATE__IN",oldFRT__RATE__IN,aFRT__RATE__IN);
      return;
   }
   public void setFRT__RATE__UM__ABBR__IN(java.lang.String aFRT__RATE__UM__ABBR__IN)
      throws RecordConversionFailureException {
      java.lang.String oldFRT__RATE__UM__ABBR__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2106,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2106,aFRT__RATE__UM__ABBR__IN,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      firePropertyChange("FRT__RATE__UM__ABBR__IN",oldFRT__RATE__UM__ABBR__IN,aFRT__RATE__UM__ABBR__IN);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,18, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,26, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,30, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,36, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,46, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,53, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,55, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,57, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,63, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,64, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,71, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,78, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,88, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,98, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,113, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,123, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,129, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,135, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,153, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,155, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,167, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,176, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,181, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,211, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,236, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,271, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,306, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,341, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,371, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,373, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,383, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,385, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,415, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,445, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,475, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,505, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,535, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,538, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,541, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,544, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,547, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,550, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,553, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,556, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,559, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,562, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,565, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,615, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,665, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,715, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,765, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,815, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,865, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,915, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,965, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1015, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1065, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1115, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1165, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1215, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1265, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1315, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1365, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1415, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1465, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1515, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1565, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1615, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1665, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1715, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1765, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1815, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1865, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1915, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1965, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2015, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2065, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2066, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2076, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2106, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2139, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2140, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"XX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2142, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2147, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2150, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2152, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2156, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2163, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      return;
   }
   public void setINLAND__FRT__CHRG__CODE__IN(java.lang.String aINLAND__FRT__CHRG__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldINLAND__FRT__CHRG__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,63,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,63,aINLAND__FRT__CHRG__CODE__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("INLAND__FRT__CHRG__CODE__IN",oldINLAND__FRT__CHRG__CODE__IN,aINLAND__FRT__CHRG__CODE__IN);
      return;
   }
   public void setLL__IN(short aLL__IN)
      throws RecordConversionFailureException {
      short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
      return;
   }
   public void setMANUAL__NOTE(java.lang.String[] aMANUAL__NOTE)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 50;
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 565 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aMANUAL__NOTE[i0],9,0,50,false,false,false,-49,0,"X(50)",false,true);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setMANUAL__NOTE(int index, java.lang.String aMANUAL__NOTE)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 50;
         int[] dim = {30};
         int offset = 565 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aMANUAL__NOTE,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setMISC__IN(java.lang.String aMISC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldMISC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2163,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2163,aMISC__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("MISC__IN",oldMISC__IN,aMISC__IN);
      return;
   }
   public void setORIGIN__CITY__CODE__IN(java.lang.String aORIGIN__CITY__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,129,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,129,aORIGIN__CITY__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("ORIGIN__CITY__CODE__IN",oldORIGIN__CITY__CODE__IN,aORIGIN__CITY__CODE__IN);
      return;
   }
   public void setORIGIN__CITY__NAME__IN(java.lang.String aORIGIN__CITY__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,135,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,135,aORIGIN__CITY__NAME__IN,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("ORIGIN__CITY__NAME__IN",oldORIGIN__CITY__NAME__IN,aORIGIN__CITY__NAME__IN);
      return;
   }
   public void setORIGIN__STATE__IN(java.lang.String aORIGIN__STATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__STATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,153,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,153,aORIGIN__STATE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ORIGIN__STATE__IN",oldORIGIN__STATE__IN,aORIGIN__STATE__IN);
      return;
   }
   public void setRECORD__TYPE__IN(java.lang.String aRECORD__TYPE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldRECORD__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,25,aRECORD__TYPE__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("RECORD__TYPE__IN",oldRECORD__TYPE__IN,aRECORD__TYPE__IN);
      return;
   }
   public void setREF__NO__IN(java.lang.String aREF__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldREF__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2066,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2066,aREF__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("REF__NO__IN",oldREF__NO__IN,aREF__NO__IN);
      return;
   }
   public void setROUTE__OR__CARRIER__CODE__IN(java.lang.String aROUTE__OR__CARRIER__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldROUTE__OR__CARRIER__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,176,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,176,aROUTE__OR__CARRIER__CODE__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("ROUTE__OR__CARRIER__CODE__IN",oldROUTE__OR__CARRIER__CODE__IN,aROUTE__OR__CARRIER__CODE__IN);
      return;
   }
   public void setROUTE__OR__CARRIER__NAME__IN(java.lang.String aROUTE__OR__CARRIER__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldROUTE__OR__CARRIER__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,181,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,181,aROUTE__OR__CARRIER__NAME__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ROUTE__OR__CARRIER__NAME__IN",oldROUTE__OR__CARRIER__NAME__IN,aROUTE__OR__CARRIER__NAME__IN);
      return;
   }
   public void setSEAL__NO__1__IN(java.lang.String aSEAL__NO__1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO__1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,64,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,64,aSEAL__NO__1__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO__1__IN",oldSEAL__NO__1__IN,aSEAL__NO__1__IN);
      return;
   }
   public void setSEAL__NO__2__IN(java.lang.String aSEAL__NO__2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO__2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,71,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,71,aSEAL__NO__2__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO__2__IN",oldSEAL__NO__2__IN,aSEAL__NO__2__IN);
      return;
   }
   public void setSHORT__CUT__NOTE(java.lang.String[] aSHORT__CUT__NOTE)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 3;
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 535 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSHORT__CUT__NOTE[i0],9,0,3,false,false,false,-2,0,"X(03)",false,true);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSHORT__CUT__NOTE(int index, java.lang.String aSHORT__CUT__NOTE)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 3;
         int[] dim = {10};
         int offset = 535 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSHORT__CUT__NOTE,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSTCC__CODE__IN(java.lang.String aSTCC__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSTCC__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,167,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,167,aSTCC__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("STCC__CODE__IN",oldSTCC__CODE__IN,aSTCC__CODE__IN);
      return;
   }
   public void setTRAN__CODE__IN(java.lang.String aTRAN__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("TRAN__CODE__IN",oldTRAN__CODE__IN,aTRAN__CODE__IN);
      return;
   }
   public void setTRAN__TYPE__IN(java.lang.String aTRAN__TYPE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2065,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2065,aTRAN__TYPE__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("TRAN__TYPE__IN",oldTRAN__TYPE__IN,aTRAN__TYPE__IN);
      return;
   }
   public void setTRANSP__MODE__IN(java.lang.String aTRANSP__MODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRANSP__MODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,53,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,53,aTRANSP__MODE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("TRANSP__MODE__IN",oldTRANSP__MODE__IN,aTRANSP__MODE__IN);
      return;
   }
   public void setUNITS__IN(double aUNITS__IN)
      throws RecordConversionFailureException {
      double oldUNITS__IN = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2110,8,11,11,false,true,true,-4,0,"9(07)V9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,2110,aUNITS__IN,8,11,11,false,true,true,-4,0,"9(07)V9(4)",false,false);
      firePropertyChange("UNITS__IN",oldUNITS__IN,aUNITS__IN);
      return;
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setUSER__ACF2__IN(java.lang.String aUSER__ACF2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldUSER__ACF2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,18,aUSER__ACF2__IN,9,0,9,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("USER__ACF2__IN",oldUSER__ACF2__IN,aUSER__ACF2__IN);
      return;
   }
   public void setZZ__IN(short aZZ__IN)
      throws RecordConversionFailureException {
      short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
      return;
   }
}
