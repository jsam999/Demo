package cat.cis.poms.bol.ims;

/**
 * Class: cat.cis.poms.bol.ims.AK0B31InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B31InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.PropertyDescriptor getACCT__DEPT__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__DEPT__IN", Class.forName(getBeanClassName()), "getACCT__DEPT__IN", "setACCT__DEPT__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__DEPT__IN");
      aDescriptor.setDisplayName("ACCT__DEPT__IN");
      aDescriptor.setShortDescription("ACCT__DEPT__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__DIV__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__DIV__IN", Class.forName(getBeanClassName()), "getACCT__DIV__IN", "setACCT__DIV__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__DIV__IN");
      aDescriptor.setDisplayName("ACCT__DIV__IN");
      aDescriptor.setShortDescription("ACCT__DIV__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__EXP__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__EXP__IN", Class.forName(getBeanClassName()), "getACCT__EXP__IN", "setACCT__EXP__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__EXP__IN");
      aDescriptor.setDisplayName("ACCT__EXP__IN");
      aDescriptor.setShortDescription("ACCT__EXP__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__FAC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__FAC__IN", Class.forName(getBeanClassName()), "getACCT__FAC__IN", "setACCT__FAC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__FAC__IN");
      aDescriptor.setDisplayName("ACCT__FAC__IN");
      aDescriptor.setShortDescription("ACCT__FAC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__ORDER__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__ORDER__NO__IN", Class.forName(getBeanClassName()), "getACCT__ORDER__NO__IN", "setACCT__ORDER__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__ORDER__NO__IN");
      aDescriptor.setDisplayName("ACCT__ORDER__NO__IN");
      aDescriptor.setShortDescription("ACCT__ORDER__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__SEC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__SEC__IN", Class.forName(getBeanClassName()), "getACCT__SEC__IN", "setACCT__SEC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__SEC__IN");
      aDescriptor.setDisplayName("ACCT__SEC__IN");
      aDescriptor.setShortDescription("ACCT__SEC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public java.beans.PropertyDescriptor getADR__CITY__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__CITY__NAME__IN", Class.forName(getBeanClassName()), "getADR__CITY__NAME__IN", "setADR__CITY__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__CITY__NAME__IN");
      aDescriptor.setDisplayName("ADR__CITY__NAME__IN");
      aDescriptor.setShortDescription("ADR__CITY__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__COUNTRY__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__COUNTRY__IN", Class.forName(getBeanClassName()), "getADR__COUNTRY__IN", "setADR__COUNTRY__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__COUNTRY__IN");
      aDescriptor.setDisplayName("ADR__COUNTRY__IN");
      aDescriptor.setShortDescription("ADR__COUNTRY__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NAME__IN", Class.forName(getBeanClassName()), "getADR__NAME__IN", "setADR__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NAME__IN");
      aDescriptor.setDisplayName("ADR__NAME__IN");
      aDescriptor.setShortDescription("ADR__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NM__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NM__LN1__IN", Class.forName(getBeanClassName()), "getADR__NM__LN1__IN", "setADR__NM__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NM__LN1__IN");
      aDescriptor.setDisplayName("ADR__NM__LN1__IN");
      aDescriptor.setShortDescription("ADR__NM__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__POSTAL__ZONE__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__POSTAL__ZONE__CODE__IN", Class.forName(getBeanClassName()), "getADR__POSTAL__ZONE__CODE__IN", "setADR__POSTAL__ZONE__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setDisplayName("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setShortDescription("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__STATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__STATE__IN", Class.forName(getBeanClassName()), "getADR__STATE__IN", "setADR__STATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__STATE__IN");
      aDescriptor.setDisplayName("ADR__STATE__IN");
      aDescriptor.setShortDescription("ADR__STATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN1__IN", Class.forName(getBeanClassName()), "getADR__TXT__LN1__IN", "setADR__TXT__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN1__IN");
      aDescriptor.setDisplayName("ADR__TXT__LN1__IN");
      aDescriptor.setShortDescription("ADR__TXT__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN2__IN", Class.forName(getBeanClassName()), "getADR__TXT__LN2__IN", "setADR__TXT__LN2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN2__IN");
      aDescriptor.setDisplayName("ADR__TXT__LN2__IN");
      aDescriptor.setShortDescription("ADR__TXT__LN2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBADGE__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BADGE__NO__IN", Class.forName(getBeanClassName()), "getBADGE__NO__IN", "setBADGE__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BADGE__NO__IN");
      aDescriptor.setDisplayName("BADGE__NO__IN");
      aDescriptor.setShortDescription("BADGE__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.bol.ims.AK0B31InMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.bol.ims.AK0B31InMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B31InMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBL__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BL__NO__IN", Class.forName(getBeanClassName()), "getBL__NO__IN", "setBL__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BL__NO__IN");
      aDescriptor.setDisplayName("BL__NO__IN");
      aDescriptor.setShortDescription("BL__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBL__NO__R__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BL__NO__R__IN", Class.forName(getBeanClassName()), "getBL__NO__R__IN", "setBL__NO__R__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BL__NO__R__IN");
      aDescriptor.setDisplayName("BL__NO__R__IN");
      aDescriptor.setShortDescription("BL__NO__R__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__FILE__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__FILE__NO__IN", Class.forName(getBeanClassName()), "getCLRN__LTR__FILE__NO__IN", "setCLRN__LTR__FILE__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setDisplayName("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setShortDescription("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__NO__IN", Class.forName(getBeanClassName()), "getCLRN__LTR__NO__IN", "setCLRN__LTR__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__NO__IN");
      aDescriptor.setDisplayName("CLRN__LTR__NO__IN");
      aDescriptor.setShortDescription("CLRN__LTR__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONSIGNEE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONSIGNEE__IN", Class.forName(getBeanClassName()), "getCONSIGNEE__IN", "setCONSIGNEE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONSIGNEE__IN");
      aDescriptor.setDisplayName("CONSIGNEE__IN");
      aDescriptor.setShortDescription("CONSIGNEE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NUMBER__1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NUMBER__1__IN", Class.forName(getBeanClassName()), "getCONTAINER__NUMBER__1__IN", "setCONTAINER__NUMBER__1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NUMBER__1__IN");
      aDescriptor.setDisplayName("CONTAINER__NUMBER__1__IN");
      aDescriptor.setShortDescription("CONTAINER__NUMBER__1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NUMBER__2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NUMBER__2__IN", Class.forName(getBeanClassName()), "getCONTAINER__NUMBER__2__IN", "setCONTAINER__NUMBER__2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NUMBER__2__IN");
      aDescriptor.setDisplayName("CONTAINER__NUMBER__2__IN");
      aDescriptor.setShortDescription("CONTAINER__NUMBER__2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTRACT__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTRACT__NO__IN", Class.forName(getBeanClassName()), "getCONTRACT__NO__IN", "setCONTRACT__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTRACT__NO__IN");
      aDescriptor.setDisplayName("CONTRACT__NO__IN");
      aDescriptor.setShortDescription("CONTRACT__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDATE__SHIPPED__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DATE__SHIPPED__IN", Class.forName(getBeanClassName()), "getDATE__SHIPPED__IN", "setDATE__SHIPPED__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DATE__SHIPPED__IN");
      aDescriptor.setDisplayName("DATE__SHIPPED__IN");
      aDescriptor.setShortDescription("DATE__SHIPPED__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN1__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN1__IN", "setDEL__INST__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN1__IN");
      aDescriptor.setDisplayName("DEL__INST__LN1__IN");
      aDescriptor.setShortDescription("DEL__INST__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN2__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN2__IN", "setDEL__INST__LN2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN2__IN");
      aDescriptor.setDisplayName("DEL__INST__LN2__IN");
      aDescriptor.setShortDescription("DEL__INST__LN2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN3__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN3__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN3__IN", "setDEL__INST__LN3__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN3__IN");
      aDescriptor.setDisplayName("DEL__INST__LN3__IN");
      aDescriptor.setShortDescription("DEL__INST__LN3__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN4__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN4__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN4__IN", "setDEL__INST__LN4__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN4__IN");
      aDescriptor.setDisplayName("DEL__INST__LN4__IN");
      aDescriptor.setShortDescription("DEL__INST__LN4__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN5__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN5__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN5__IN", "setDEL__INST__LN5__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN5__IN");
      aDescriptor.setDisplayName("DEL__INST__LN5__IN");
      aDescriptor.setShortDescription("DEL__INST__LN5__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDESC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DESC__IN", Class.forName(getBeanClassName()), "getDESC__IN", "setDESC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DESC__IN");
      aDescriptor.setDisplayName("DESC__IN");
      aDescriptor.setShortDescription("DESC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDESTINATION__CITY__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DESTINATION__CITY__CODE__IN", Class.forName(getBeanClassName()), "getDESTINATION__CITY__CODE__IN", "setDESTINATION__CITY__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DESTINATION__CITY__CODE__IN");
      aDescriptor.setDisplayName("DESTINATION__CITY__CODE__IN");
      aDescriptor.setShortDescription("DESTINATION__CITY__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEQUIP__DESC__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EQUIP__DESC__CODE__IN", Class.forName(getBeanClassName()), "getEQUIP__DESC__CODE__IN", "setEQUIP__DESC__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EQUIP__DESC__CODE__IN");
      aDescriptor.setDisplayName("EQUIP__DESC__CODE__IN");
      aDescriptor.setShortDescription("EQUIP__DESC__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getFAC__BLDG__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FAC__BLDG__IN", Class.forName(getBeanClassName()), "getFAC__BLDG__IN", "setFAC__BLDG__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FAC__BLDG__IN");
      aDescriptor.setDisplayName("FAC__BLDG__IN");
      aDescriptor.setShortDescription("FAC__BLDG__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFAC__BLDG__R__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FAC__BLDG__R__IN", Class.forName(getBeanClassName()), "getFAC__BLDG__R__IN", "setFAC__BLDG__R__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FAC__BLDG__R__IN");
      aDescriptor.setDisplayName("FAC__BLDG__R__IN");
      aDescriptor.setShortDescription("FAC__BLDG__R__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__CHRG__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__CHRG__CODE__IN", Class.forName(getBeanClassName()), "getFRT__CHRG__CODE__IN", "setFRT__CHRG__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__CHRG__CODE__IN");
      aDescriptor.setDisplayName("FRT__CHRG__CODE__IN");
      aDescriptor.setShortDescription("FRT__CHRG__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__FLAT__CHRG__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__FLAT__CHRG__IN", Class.forName(getBeanClassName()), "getFRT__FLAT__CHRG__IN", "setFRT__FLAT__CHRG__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__FLAT__CHRG__IN");
      aDescriptor.setDisplayName("FRT__FLAT__CHRG__IN");
      aDescriptor.setShortDescription("FRT__FLAT__CHRG__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__RATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__IN", Class.forName(getBeanClassName()), "getFRT__RATE__IN", "setFRT__RATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__RATE__IN");
      aDescriptor.setDisplayName("FRT__RATE__IN");
      aDescriptor.setShortDescription("FRT__RATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__RATE__UM__ABBR__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__UM__ABBR__IN", Class.forName(getBeanClassName()), "getFRT__RATE__UM__ABBR__IN", "setFRT__RATE__UM__ABBR__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__RATE__UM__ABBR__IN");
      aDescriptor.setDisplayName("FRT__RATE__UM__ABBR__IN");
      aDescriptor.setShortDescription("FRT__RATE__UM__ABBR__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getINLAND__FRT__CHRG__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("INLAND__FRT__CHRG__CODE__IN", Class.forName(getBeanClassName()), "getINLAND__FRT__CHRG__CODE__IN", "setINLAND__FRT__CHRG__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setDisplayName("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setShortDescription("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__IN");
      aDescriptor.setDisplayName("LL__IN");
      aDescriptor.setShortDescription("LL__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getMANUAL__NOTEPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("MANUAL__NOTE", Class.forName(getBeanClassName()), "getMANUAL__NOTE", "setMANUAL__NOTE", "getMANUAL__NOTE", "setMANUAL__NOTE" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("MANUAL__NOTE");
      aDescriptor.setDisplayName("MANUAL__NOTE");
      aDescriptor.setShortDescription("MANUAL__NOTE");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getMISC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("MISC__IN", Class.forName(getBeanClassName()), "getMISC__IN", "setMISC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("MISC__IN");
      aDescriptor.setDisplayName("MISC__IN");
      aDescriptor.setShortDescription("MISC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__CODE__IN", Class.forName(getBeanClassName()), "getORIGIN__CITY__CODE__IN", "setORIGIN__CITY__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__CODE__IN");
      aDescriptor.setDisplayName("ORIGIN__CITY__CODE__IN");
      aDescriptor.setShortDescription("ORIGIN__CITY__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__NAME__IN", Class.forName(getBeanClassName()), "getORIGIN__CITY__NAME__IN", "setORIGIN__CITY__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__NAME__IN");
      aDescriptor.setDisplayName("ORIGIN__CITY__NAME__IN");
      aDescriptor.setShortDescription("ORIGIN__CITY__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__STATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__STATE__IN", Class.forName(getBeanClassName()), "getORIGIN__STATE__IN", "setORIGIN__STATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__STATE__IN");
      aDescriptor.setDisplayName("ORIGIN__STATE__IN");
      aDescriptor.setShortDescription("ORIGIN__STATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__INPropertyDescriptor()
            ,getZZ__INPropertyDescriptor()
            ,getTRAN__CODE__INPropertyDescriptor()
            ,getBADGE__NO__INPropertyDescriptor()
            ,getUSER__ACF2__INPropertyDescriptor()
            ,getRECORD__TYPE__INPropertyDescriptor()
            ,getFAC__BLDG__INPropertyDescriptor()
            ,getBL__NO__INPropertyDescriptor()
            ,getFAC__BLDG__R__INPropertyDescriptor()
            ,getBL__NO__R__INPropertyDescriptor()
            ,getDATE__SHIPPED__INPropertyDescriptor()
            ,getTRANSP__MODE__INPropertyDescriptor()
            ,getEQUIP__DESC__CODE__INPropertyDescriptor()
            ,getCONSIGNEE__INPropertyDescriptor()
            ,getINLAND__FRT__CHRG__CODE__INPropertyDescriptor()
            ,getSEAL__NO__1__INPropertyDescriptor()
            ,getSEAL__NO__2__INPropertyDescriptor()
            ,getCONTAINER__NUMBER__1__INPropertyDescriptor()
            ,getCONTAINER__NUMBER__2__INPropertyDescriptor()
            ,getCLRN__LTR__FILE__NO__INPropertyDescriptor()
            ,getCLRN__LTR__NO__INPropertyDescriptor()
            ,getDESTINATION__CITY__CODE__INPropertyDescriptor()
            ,getORIGIN__CITY__CODE__INPropertyDescriptor()
            ,getORIGIN__CITY__NAME__INPropertyDescriptor()
            ,getORIGIN__STATE__INPropertyDescriptor()
            ,getCONTRACT__NO__INPropertyDescriptor()
            ,getSTCC__CODE__INPropertyDescriptor()
            ,getROUTE__OR__CARRIER__CODE__INPropertyDescriptor()
            ,getROUTE__OR__CARRIER__NAME__INPropertyDescriptor()
            ,getADR__NAME__INPropertyDescriptor()
            ,getADR__NM__LN1__INPropertyDescriptor()
            ,getADR__TXT__LN1__INPropertyDescriptor()
            ,getADR__TXT__LN2__INPropertyDescriptor()
            ,getADR__CITY__NAME__INPropertyDescriptor()
            ,getADR__STATE__INPropertyDescriptor()
            ,getADR__POSTAL__ZONE__CODE__INPropertyDescriptor()
            ,getADR__COUNTRY__INPropertyDescriptor()
            ,getDEL__INST__LN1__INPropertyDescriptor()
            ,getDEL__INST__LN2__INPropertyDescriptor()
            ,getDEL__INST__LN3__INPropertyDescriptor()
            ,getDEL__INST__LN4__INPropertyDescriptor()
            ,getDEL__INST__LN5__INPropertyDescriptor()
            ,getSHORT__CUT__NOTEPropertyDescriptor()
            ,getMANUAL__NOTEPropertyDescriptor()
            ,getTRAN__TYPE__INPropertyDescriptor()
            ,getREF__NO__INPropertyDescriptor()
            ,getDESC__INPropertyDescriptor()
            ,getFRT__RATE__UM__ABBR__INPropertyDescriptor()
            ,getUNITS__INPropertyDescriptor()
            ,getFRT__RATE__INPropertyDescriptor()
            ,getFRT__FLAT__CHRG__INPropertyDescriptor()
            ,getFRT__CHRG__CODE__INPropertyDescriptor()
            ,getACCT__FAC__INPropertyDescriptor()
            ,getACCT__DEPT__INPropertyDescriptor()
            ,getACCT__DIV__INPropertyDescriptor()
            ,getACCT__SEC__INPropertyDescriptor()
            ,getACCT__EXP__INPropertyDescriptor()
            ,getACCT__ORDER__NO__INPropertyDescriptor()
            ,getMISC__INPropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getRECORD__TYPE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("RECORD__TYPE__IN", Class.forName(getBeanClassName()), "getRECORD__TYPE__IN", "setRECORD__TYPE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("RECORD__TYPE__IN");
      aDescriptor.setDisplayName("RECORD__TYPE__IN");
      aDescriptor.setShortDescription("RECORD__TYPE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getREF__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("REF__NO__IN", Class.forName(getBeanClassName()), "getREF__NO__IN", "setREF__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("REF__NO__IN");
      aDescriptor.setDisplayName("REF__NO__IN");
      aDescriptor.setShortDescription("REF__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getROUTE__OR__CARRIER__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ROUTE__OR__CARRIER__CODE__IN", Class.forName(getBeanClassName()), "getROUTE__OR__CARRIER__CODE__IN", "setROUTE__OR__CARRIER__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ROUTE__OR__CARRIER__CODE__IN");
      aDescriptor.setDisplayName("ROUTE__OR__CARRIER__CODE__IN");
      aDescriptor.setShortDescription("ROUTE__OR__CARRIER__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getROUTE__OR__CARRIER__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ROUTE__OR__CARRIER__NAME__IN", Class.forName(getBeanClassName()), "getROUTE__OR__CARRIER__NAME__IN", "setROUTE__OR__CARRIER__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ROUTE__OR__CARRIER__NAME__IN");
      aDescriptor.setDisplayName("ROUTE__OR__CARRIER__NAME__IN");
      aDescriptor.setShortDescription("ROUTE__OR__CARRIER__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO__1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO__1__IN", Class.forName(getBeanClassName()), "getSEAL__NO__1__IN", "setSEAL__NO__1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO__1__IN");
      aDescriptor.setDisplayName("SEAL__NO__1__IN");
      aDescriptor.setShortDescription("SEAL__NO__1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO__2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO__2__IN", Class.forName(getBeanClassName()), "getSEAL__NO__2__IN", "setSEAL__NO__2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO__2__IN");
      aDescriptor.setDisplayName("SEAL__NO__2__IN");
      aDescriptor.setShortDescription("SEAL__NO__2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHORT__CUT__NOTEPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("SHORT__CUT__NOTE", Class.forName(getBeanClassName()), "getSHORT__CUT__NOTE", "setSHORT__CUT__NOTE", "getSHORT__CUT__NOTE", "setSHORT__CUT__NOTE" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHORT__CUT__NOTE");
      aDescriptor.setDisplayName("SHORT__CUT__NOTE");
      aDescriptor.setShortDescription("SHORT__CUT__NOTE");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTCC__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("STCC__CODE__IN", Class.forName(getBeanClassName()), "getSTCC__CODE__IN", "setSTCC__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STCC__CODE__IN");
      aDescriptor.setDisplayName("STCC__CODE__IN");
      aDescriptor.setShortDescription("STCC__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__IN", "setTRAN__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__CODE__IN");
      aDescriptor.setDisplayName("TRAN__CODE__IN");
      aDescriptor.setShortDescription("TRAN__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__TYPE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__TYPE__IN", Class.forName(getBeanClassName()), "getTRAN__TYPE__IN", "setTRAN__TYPE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__TYPE__IN");
      aDescriptor.setDisplayName("TRAN__TYPE__IN");
      aDescriptor.setShortDescription("TRAN__TYPE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRANSP__MODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRANSP__MODE__IN", Class.forName(getBeanClassName()), "getTRANSP__MODE__IN", "setTRANSP__MODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRANSP__MODE__IN");
      aDescriptor.setDisplayName("TRANSP__MODE__IN");
      aDescriptor.setShortDescription("TRANSP__MODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getUNITS__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("UNITS__IN", Class.forName(getBeanClassName()), "getUNITS__IN", "setUNITS__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("UNITS__IN");
      aDescriptor.setDisplayName("UNITS__IN");
      aDescriptor.setShortDescription("UNITS__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getUSER__ACF2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("USER__ACF2__IN", Class.forName(getBeanClassName()), "getUSER__ACF2__IN", "setUSER__ACF2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("USER__ACF2__IN");
      aDescriptor.setDisplayName("USER__ACF2__IN");
      aDescriptor.setShortDescription("USER__ACF2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__IN");
      aDescriptor.setDisplayName("ZZ__IN");
      aDescriptor.setShortDescription("ZZ__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }
}
