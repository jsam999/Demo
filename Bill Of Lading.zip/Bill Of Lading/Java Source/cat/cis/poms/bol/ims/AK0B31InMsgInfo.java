package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B31InMsgInfo.java
// Generated from C:\tim0b31.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B31InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_LADING__NO__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_LADING__NO__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(4):DISPLAY"), "FAC__BLDG__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(6):DISPLAY"), "BL__NO__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_LADING__NO__R__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_LADING__NO__R__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(4):DISPLAY"), "FAC__BLDG__R__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(6):DISPLAY"), "BL__NO__R__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_ADDRESS__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_ADDRESS__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(25):DISPLAY"), "ADR__NAME__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__NM__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN2__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "ADR__CITY__NAME__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__STATE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "ADR__POSTAL__ZONE__CODE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__COUNTRY__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_DEL__INSTRUCTIONS extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_DEL__INSTRUCTIONS () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN2__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN3__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN4__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN5__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_SHORT__CUT__NOTES__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_SHORT__CUT__NOTES__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 arraySize = new int[1];
		 arraySize[0] = 10;
		 arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(03):DISPLAY")), "SHORT__CUT__NOTE", new CobolInitialValueObject(" ", null));
		 addField(arrField);

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_NOTES__AREA__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_NOTES__AREA__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 arraySize = new int[1];
		 arraySize[0] = 30;
		 arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(50):DISPLAY")), "MANUAL__NOTE", new CobolInitialValueObject(" ", null));
		 addField(arrField);

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_CHARGES__AREA__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_CHARGES__AREA__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(01):DISPLAY"), "TRAN__TYPE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "REF__NO__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DESC__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(04):DISPLAY"), "FRT__RATE__UM__ABBR__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(07)V9(4):DISPLAY"), "UNITS__IN"));

		 addField(new Field(new CobolType("9(5)V9(4):DISPLAY"), "FRT__RATE__IN"));

		 addField(new Field(new CobolType("9(7)V9(2):DISPLAY"), "FRT__FLAT__CHRG__IN"));

		 addField(new Field(new CobolType("X:DISPLAY"), "FRT__CHRG__CODE__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31InMsgInfo_ACCOUNTING__INFO__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31InMsgInfo_ACCOUNTING__INFO__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("XX:DISPLAY"), "ACCT__FAC__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(05):DISPLAY"), "ACCT__DEPT__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "ACCT__DIV__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ACCT__SEC__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(04):DISPLAY"), "ACCT__EXP__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(07):DISPLAY"), "ACCT__ORDER__NO__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(07):DISPLAY"), "MISC__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B31InMsgInfo () throws RecordException
   {
      int[] arraySize = null;
      ArrayField arrField = null;

      addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(05):DISPLAY"), "BADGE__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "USER__ACF2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(01):DISPLAY"), "RECORD__TYPE__IN", new CobolInitialValueObject(" ", null)));

      addField(new NestedRecordField(new AK0B31InMsgInfo_LADING__NO__IN(), "LADING__NO__IN"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_LADING__NO__R__IN(), "LADING__NO__R__IN"));

      addField(new Field(new CobolType("X(07):DISPLAY"), "DATE__SHIPPED__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "TRANSP__MODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "EQUIP__DESC__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "CONSIGNEE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(01):DISPLAY"), "INLAND__FRT__CHRG__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "SEAL__NO__1__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "SEAL__NO__2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CONTAINER__NUMBER__1__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CONTAINER__NUMBER__2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(15):DISPLAY"), "CLRN__LTR__FILE__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CLRN__LTR__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "DESTINATION__CITY__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "ORIGIN__CITY__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(18):DISPLAY"), "ORIGIN__CITY__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "ORIGIN__STATE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(12):DISPLAY"), "CONTRACT__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(09):DISPLAY"), "STCC__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(05):DISPLAY"), "ROUTE__OR__CARRIER__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(30):DISPLAY"), "ROUTE__OR__CARRIER__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new NestedRecordField(new AK0B31InMsgInfo_ADDRESS__IN(), "ADDRESS__IN"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_DEL__INSTRUCTIONS(), "DEL__INSTRUCTIONS"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_SHORT__CUT__NOTES__IN(), "SHORT__CUT__NOTES__IN"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_NOTES__AREA__IN(), "NOTES__AREA__IN"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_CHARGES__AREA__IN(), "CHARGES__AREA__IN"));

      addField(new NestedRecordField(new AK0B31InMsgInfo_ACCOUNTING__INFO__IN(), "ACCOUNTING__INFO__IN"));

   }
}
