package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecord;
import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B31OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B31OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B31OutMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B31OutMsg.class,2838));
         this.setBytes(new byte[2838]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getADR__CITY__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,214,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getADR__COUNTRY__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,256,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getADR__NM__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,109,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__POSTAL__ZONE__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,246,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getADR__STATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,244,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__TXT__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,144,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__TXT__LN2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,179,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getBOL__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public AK0B31OutMsg_CHARGES__AREA__OUT[] getCHARGES__AREA__OUT()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         AK0B31OutMsg_CHARGES__AREA__OUT[] returnArray = new AK0B31OutMsg_CHARGES__AREA__OUT[10];
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 1938 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            CustomRecordType elementRecordType = new CustomRecordType(AK0B31OutMsg_CHARGES__AREA__OUT.class,elementSize);
            CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
            byte[] bytes = new byte[elementSize];
            System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
            element.setBytes (bytes);
            returnArray[i0] = (AK0B31OutMsg_CHARGES__AREA__OUT)element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public AK0B31OutMsg_CHARGES__AREA__OUT getCHARGES__AREA__OUT(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         int offset = 1938 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         CustomRecordType returnRecordType = new CustomRecordType(AK0B31OutMsg_CHARGES__AREA__OUT.class,elementSize);
         CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
         byte[] bytes = new byte[elementSize];
         System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
         returnRecord.setBytes (bytes);
         return ((AK0B31OutMsg_CHARGES__AREA__OUT)returnRecord);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getCITY__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getDEL__INST__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,258,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,288,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN3__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,318,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN4__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,348,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN5__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,378,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDOCK__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getERROR__MSG__ERR__MSG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2788,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }
   public java.lang.String getFAC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getFill_0()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2787,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public double getFRT__CHRG__TOTAL__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2768,8,9,9,false,true,true,-2,0,"9(07)V99",false,false);
   }
   public java.lang.String getISSUE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,38,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getLADING__NO__ERR__MSG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2777,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public short getLL__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.bol.ims.AK0B31OutMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public AK0B31OutMsg_NOTES__BREAKDOWN[] getNOTES__BREAKDOWN()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         AK0B31OutMsg_NOTES__BREAKDOWN[] returnArray = new AK0B31OutMsg_NOTES__BREAKDOWN[30];
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 408 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            CustomRecordType elementRecordType = new CustomRecordType(AK0B31OutMsg_NOTES__BREAKDOWN.class,elementSize);
            CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
            byte[] bytes = new byte[elementSize];
            System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
            element.setBytes (bytes);
            returnArray[i0] = (AK0B31OutMsg_NOTES__BREAKDOWN)element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public AK0B31OutMsg_NOTES__BREAKDOWN getNOTES__BREAKDOWN(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         int offset = 408 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         CustomRecordType returnRecordType = new CustomRecordType(AK0B31OutMsg_NOTES__BREAKDOWN.class,elementSize);
         CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
         byte[] bytes = new byte[elementSize];
         System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
         returnRecord.setBytes (bytes);
         return ((AK0B31OutMsg_NOTES__BREAKDOWN)returnRecord);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getROUTE__OR__CARRIER__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,49,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getROUTE__OR__CARRIER__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,54,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getSTATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getSTCC__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public short getZZ__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__OUT",null,getLL__OUT());
         firePropertyChange("ZZ__OUT",null,getZZ__OUT());
         firePropertyChange("FAC__OUT",null,getFAC__OUT());
         firePropertyChange("DOCK__OUT",null,getDOCK__OUT());
         firePropertyChange("CITY__OUT",null,getCITY__OUT());
         firePropertyChange("STATE__OUT",null,getSTATE__OUT());
         firePropertyChange("BOL__NO__OUT",null,getBOL__NO__OUT());
         firePropertyChange("ISSUE__OUT",null,getISSUE__OUT());
         firePropertyChange("STCC__CODE__OUT",null,getSTCC__CODE__OUT());
         firePropertyChange("ROUTE__OR__CARRIER__CODE__OUT",null,getROUTE__OR__CARRIER__CODE__OUT());
         firePropertyChange("ROUTE__OR__CARRIER__NAME__OUT",null,getROUTE__OR__CARRIER__NAME__OUT());
         firePropertyChange("ADR__NAME__OUT",null,getADR__NAME__OUT());
         firePropertyChange("ADR__NM__LN1__OUT",null,getADR__NM__LN1__OUT());
         firePropertyChange("ADR__TXT__LN1__OUT",null,getADR__TXT__LN1__OUT());
         firePropertyChange("ADR__TXT__LN2__OUT",null,getADR__TXT__LN2__OUT());
         firePropertyChange("ADR__CITY__NAME__OUT",null,getADR__CITY__NAME__OUT());
         firePropertyChange("ADR__STATE__OUT",null,getADR__STATE__OUT());
         firePropertyChange("ADR__POSTAL__ZONE__CODE__OUT",null,getADR__POSTAL__ZONE__CODE__OUT());
         firePropertyChange("ADR__COUNTRY__OUT",null,getADR__COUNTRY__OUT());
         firePropertyChange("DEL__INST__LN1__OUT",null,getDEL__INST__LN1__OUT());
         firePropertyChange("DEL__INST__LN2__OUT",null,getDEL__INST__LN2__OUT());
         firePropertyChange("DEL__INST__LN3__OUT",null,getDEL__INST__LN3__OUT());
         firePropertyChange("DEL__INST__LN4__OUT",null,getDEL__INST__LN4__OUT());
         firePropertyChange("DEL__INST__LN5__OUT",null,getDEL__INST__LN5__OUT());
         firePropertyChange("NOTES__BREAKDOWN",null,getNOTES__BREAKDOWN());
         firePropertyChange("CHARGES__AREA__OUT",null,getCHARGES__AREA__OUT());
         firePropertyChange("FRT__CHRG__TOTAL__OUT",null,getFRT__CHRG__TOTAL__OUT());
         firePropertyChange("LADING__NO__ERR__MSG__OUT",null,getLADING__NO__ERR__MSG__OUT());
         firePropertyChange("fill_0",null,getFill_0());
         firePropertyChange("ERROR__MSG__ERR__MSG__OUT",null,getERROR__MSG__ERR__MSG__OUT());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setADR__CITY__NAME__OUT(java.lang.String aADR__CITY__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__CITY__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,214,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,214,aADR__CITY__NAME__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ADR__CITY__NAME__OUT",oldADR__CITY__NAME__OUT,aADR__CITY__NAME__OUT);
      return;
   }
   public void setADR__COUNTRY__OUT(java.lang.String aADR__COUNTRY__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__COUNTRY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,256,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,256,aADR__COUNTRY__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__COUNTRY__OUT",oldADR__COUNTRY__OUT,aADR__COUNTRY__OUT);
      return;
   }
   public void setADR__NAME__OUT(java.lang.String aADR__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,84,aADR__NAME__OUT,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("ADR__NAME__OUT",oldADR__NAME__OUT,aADR__NAME__OUT);
      return;
   }
   public void setADR__NM__LN1__OUT(java.lang.String aADR__NM__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NM__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,109,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,109,aADR__NM__LN1__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__NM__LN1__OUT",oldADR__NM__LN1__OUT,aADR__NM__LN1__OUT);
      return;
   }
   public void setADR__POSTAL__ZONE__CODE__OUT(java.lang.String aADR__POSTAL__ZONE__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__POSTAL__ZONE__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,246,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,246,aADR__POSTAL__ZONE__CODE__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("ADR__POSTAL__ZONE__CODE__OUT",oldADR__POSTAL__ZONE__CODE__OUT,aADR__POSTAL__ZONE__CODE__OUT);
      return;
   }
   public void setADR__STATE__OUT(java.lang.String aADR__STATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__STATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,244,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,244,aADR__STATE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__STATE__OUT",oldADR__STATE__OUT,aADR__STATE__OUT);
      return;
   }
   public void setADR__TXT__LN1__OUT(java.lang.String aADR__TXT__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,144,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,144,aADR__TXT__LN1__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN1__OUT",oldADR__TXT__LN1__OUT,aADR__TXT__LN1__OUT);
      return;
   }
   public void setADR__TXT__LN2__OUT(java.lang.String aADR__TXT__LN2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,179,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,179,aADR__TXT__LN2__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN2__OUT",oldADR__TXT__LN2__OUT,aADR__TXT__LN2__OUT);
      return;
   }
   public void setBOL__NO__OUT(java.lang.String aBOL__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldBOL__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,28,aBOL__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("BOL__NO__OUT",oldBOL__NO__OUT,aBOL__NO__OUT);
      return;
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setCHARGES__AREA__OUT(AK0B31OutMsg_CHARGES__AREA__OUT[] aCHARGES__AREA__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 1938 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            byte[] recordBytes = getBytes();
            byte[] fieldBytes = aCHARGES__AREA__OUT[i0].getBytes();
            System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
            setBytes(recordBytes);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setCHARGES__AREA__OUT(int index, AK0B31OutMsg_CHARGES__AREA__OUT aCHARGES__AREA__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         int offset = 1938 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         byte[] recordBytes = getBytes();
         byte[] fieldBytes = aCHARGES__AREA__OUT.getBytes();
         System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
         setBytes(recordBytes);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setCITY__OUT(java.lang.String aCITY__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCITY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,8,aCITY__OUT,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("CITY__OUT",oldCITY__OUT,aCITY__OUT);
      return;
   }
   public void setDEL__INST__LN1__OUT(java.lang.String aDEL__INST__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,258,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,258,aDEL__INST__LN1__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN1__OUT",oldDEL__INST__LN1__OUT,aDEL__INST__LN1__OUT);
      return;
   }
   public void setDEL__INST__LN2__OUT(java.lang.String aDEL__INST__LN2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,288,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,288,aDEL__INST__LN2__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN2__OUT",oldDEL__INST__LN2__OUT,aDEL__INST__LN2__OUT);
      return;
   }
   public void setDEL__INST__LN3__OUT(java.lang.String aDEL__INST__LN3__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN3__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,318,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,318,aDEL__INST__LN3__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN3__OUT",oldDEL__INST__LN3__OUT,aDEL__INST__LN3__OUT);
      return;
   }
   public void setDEL__INST__LN4__OUT(java.lang.String aDEL__INST__LN4__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN4__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,348,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,348,aDEL__INST__LN4__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN4__OUT",oldDEL__INST__LN4__OUT,aDEL__INST__LN4__OUT);
      return;
   }
   public void setDEL__INST__LN5__OUT(java.lang.String aDEL__INST__LN5__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN5__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,378,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,378,aDEL__INST__LN5__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN5__OUT",oldDEL__INST__LN5__OUT,aDEL__INST__LN5__OUT);
      return;
   }
   public void setDOCK__OUT(java.lang.String aDOCK__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDOCK__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6,aDOCK__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("DOCK__OUT",oldDOCK__OUT,aDOCK__OUT);
      return;
   }
   public void setERROR__MSG__ERR__MSG__OUT(java.lang.String aERROR__MSG__ERR__MSG__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldERROR__MSG__ERR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2788,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2788,aERROR__MSG__ERR__MSG__OUT,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      firePropertyChange("ERROR__MSG__ERR__MSG__OUT",oldERROR__MSG__ERR__MSG__OUT,aERROR__MSG__ERR__MSG__OUT);
      return;
   }
   public void setFAC__OUT(java.lang.String aFAC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldFAC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aFAC__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("FAC__OUT",oldFAC__OUT,aFAC__OUT);
      return;
   }
   public void setFill_0(java.lang.String aFill_0)
      throws RecordConversionFailureException {
      java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2787,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2787,aFill_0,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("fill_0",oldFill_0,aFill_0);
      return;
   }
   public void setFRT__CHRG__TOTAL__OUT(double aFRT__CHRG__TOTAL__OUT)
      throws RecordConversionFailureException {
      double oldFRT__CHRG__TOTAL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,2768,8,9,9,false,true,true,-2,0,"9(07)V99",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,2768,aFRT__CHRG__TOTAL__OUT,8,9,9,false,true,true,-2,0,"9(07)V99",false,false);
      firePropertyChange("FRT__CHRG__TOTAL__OUT",oldFRT__CHRG__TOTAL__OUT,aFRT__CHRG__TOTAL__OUT);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,8, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,26, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,28, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,38, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,49, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,54, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,84, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,109, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,144, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,179, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,214, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,244, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,246, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,256, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,258, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,288, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,318, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,348, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,378, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2777, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2787, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("-,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2788, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      return;
   }
   public void setISSUE__OUT(java.lang.String aISSUE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldISSUE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,38,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,38,aISSUE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ISSUE__OUT",oldISSUE__OUT,aISSUE__OUT);
      return;
   }
   public void setLADING__NO__ERR__MSG__OUT(java.lang.String aLADING__NO__ERR__MSG__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldLADING__NO__ERR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2777,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2777,aLADING__NO__ERR__MSG__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("LADING__NO__ERR__MSG__OUT",oldLADING__NO__ERR__MSG__OUT,aLADING__NO__ERR__MSG__OUT);
      return;
   }
   public void setLL__OUT(short aLL__OUT)
      throws RecordConversionFailureException {
      short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
      return;
   }
   public void setNOTES__BREAKDOWN(AK0B31OutMsg_NOTES__BREAKDOWN[] aNOTES__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 408 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            byte[] recordBytes = getBytes();
            byte[] fieldBytes = aNOTES__BREAKDOWN[i0].getBytes();
            System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
            setBytes(recordBytes);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setNOTES__BREAKDOWN(int index, AK0B31OutMsg_NOTES__BREAKDOWN aNOTES__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         int offset = 408 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         byte[] recordBytes = getBytes();
         byte[] fieldBytes = aNOTES__BREAKDOWN.getBytes();
         System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
         setBytes(recordBytes);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setROUTE__OR__CARRIER__CODE__OUT(java.lang.String aROUTE__OR__CARRIER__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldROUTE__OR__CARRIER__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,49,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,49,aROUTE__OR__CARRIER__CODE__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("ROUTE__OR__CARRIER__CODE__OUT",oldROUTE__OR__CARRIER__CODE__OUT,aROUTE__OR__CARRIER__CODE__OUT);
      return;
   }
   public void setROUTE__OR__CARRIER__NAME__OUT(java.lang.String aROUTE__OR__CARRIER__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldROUTE__OR__CARRIER__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,54,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,54,aROUTE__OR__CARRIER__NAME__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ROUTE__OR__CARRIER__NAME__OUT",oldROUTE__OR__CARRIER__NAME__OUT,aROUTE__OR__CARRIER__NAME__OUT);
      return;
   }
   public void setSTATE__OUT(java.lang.String aSTATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSTATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,26,aSTATE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("STATE__OUT",oldSTATE__OUT,aSTATE__OUT);
      return;
   }
   public void setSTCC__CODE__OUT(java.lang.String aSTCC__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSTCC__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aSTCC__CODE__OUT,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("STCC__CODE__OUT",oldSTCC__CODE__OUT,aSTCC__CODE__OUT);
      return;
   }
   public void setZZ__OUT(short aZZ__OUT)
      throws RecordConversionFailureException {
      short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
      return;
   }
}
