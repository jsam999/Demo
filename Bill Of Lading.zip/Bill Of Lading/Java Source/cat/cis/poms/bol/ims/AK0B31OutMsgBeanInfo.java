package cat.cis.poms.bol.ims;

/**
 * Class: cat.cis.poms.bol.ims.AK0B31OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B31OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public java.beans.PropertyDescriptor getADR__CITY__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__CITY__NAME__OUT", Class.forName(getBeanClassName()), "getADR__CITY__NAME__OUT", "setADR__CITY__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__CITY__NAME__OUT");
      aDescriptor.setDisplayName("ADR__CITY__NAME__OUT");
      aDescriptor.setShortDescription("ADR__CITY__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__COUNTRY__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__COUNTRY__OUT", Class.forName(getBeanClassName()), "getADR__COUNTRY__OUT", "setADR__COUNTRY__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__COUNTRY__OUT");
      aDescriptor.setDisplayName("ADR__COUNTRY__OUT");
      aDescriptor.setShortDescription("ADR__COUNTRY__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NAME__OUT", Class.forName(getBeanClassName()), "getADR__NAME__OUT", "setADR__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NAME__OUT");
      aDescriptor.setDisplayName("ADR__NAME__OUT");
      aDescriptor.setShortDescription("ADR__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NM__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NM__LN1__OUT", Class.forName(getBeanClassName()), "getADR__NM__LN1__OUT", "setADR__NM__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NM__LN1__OUT");
      aDescriptor.setDisplayName("ADR__NM__LN1__OUT");
      aDescriptor.setShortDescription("ADR__NM__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__POSTAL__ZONE__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__POSTAL__ZONE__CODE__OUT", Class.forName(getBeanClassName()), "getADR__POSTAL__ZONE__CODE__OUT", "setADR__POSTAL__ZONE__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setDisplayName("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setShortDescription("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__STATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__STATE__OUT", Class.forName(getBeanClassName()), "getADR__STATE__OUT", "setADR__STATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__STATE__OUT");
      aDescriptor.setDisplayName("ADR__STATE__OUT");
      aDescriptor.setShortDescription("ADR__STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN1__OUT", Class.forName(getBeanClassName()), "getADR__TXT__LN1__OUT", "setADR__TXT__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN1__OUT");
      aDescriptor.setDisplayName("ADR__TXT__LN1__OUT");
      aDescriptor.setShortDescription("ADR__TXT__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN2__OUT", Class.forName(getBeanClassName()), "getADR__TXT__LN2__OUT", "setADR__TXT__LN2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN2__OUT");
      aDescriptor.setDisplayName("ADR__TXT__LN2__OUT");
      aDescriptor.setShortDescription("ADR__TXT__LN2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.bol.ims.AK0B31OutMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.bol.ims.AK0B31OutMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B31OutMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBOL__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BOL__NO__OUT", Class.forName(getBeanClassName()), "getBOL__NO__OUT", "setBOL__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BOL__NO__OUT");
      aDescriptor.setDisplayName("BOL__NO__OUT");
      aDescriptor.setShortDescription("BOL__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCHARGES__AREA__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("CHARGES__AREA__OUT", Class.forName(getBeanClassName()), "getCHARGES__AREA__OUT", "setCHARGES__AREA__OUT", "getCHARGES__AREA__OUT", "setCHARGES__AREA__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CHARGES__AREA__OUT");
      aDescriptor.setDisplayName("CHARGES__AREA__OUT");
      aDescriptor.setShortDescription("CHARGES__AREA__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCITY__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CITY__OUT", Class.forName(getBeanClassName()), "getCITY__OUT", "setCITY__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CITY__OUT");
      aDescriptor.setDisplayName("CITY__OUT");
      aDescriptor.setShortDescription("CITY__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN1__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN1__OUT", "setDEL__INST__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN1__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN1__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN2__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN2__OUT", "setDEL__INST__LN2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN2__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN2__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN3__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN3__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN3__OUT", "setDEL__INST__LN3__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN3__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN3__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN3__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN4__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN4__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN4__OUT", "setDEL__INST__LN4__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN4__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN4__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN4__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN5__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN5__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN5__OUT", "setDEL__INST__LN5__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN5__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN5__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN5__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDOCK__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DOCK__OUT", Class.forName(getBeanClassName()), "getDOCK__OUT", "setDOCK__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DOCK__OUT");
      aDescriptor.setDisplayName("DOCK__OUT");
      aDescriptor.setShortDescription("DOCK__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getERROR__MSG__ERR__MSG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ERROR__MSG__ERR__MSG__OUT", Class.forName(getBeanClassName()), "getERROR__MSG__ERR__MSG__OUT", "setERROR__MSG__ERR__MSG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ERROR__MSG__ERR__MSG__OUT");
      aDescriptor.setDisplayName("ERROR__MSG__ERR__MSG__OUT");
      aDescriptor.setShortDescription("ERROR__MSG__ERR__MSG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getFAC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FAC__OUT", Class.forName(getBeanClassName()), "getFAC__OUT", "setFAC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FAC__OUT");
      aDescriptor.setDisplayName("FAC__OUT");
      aDescriptor.setShortDescription("FAC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_0");
      aDescriptor.setDisplayName("fill_0");
      aDescriptor.setShortDescription("fill_0");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__CHRG__TOTAL__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__CHRG__TOTAL__OUT", Class.forName(getBeanClassName()), "getFRT__CHRG__TOTAL__OUT", "setFRT__CHRG__TOTAL__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setDisplayName("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setShortDescription("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getISSUE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ISSUE__OUT", Class.forName(getBeanClassName()), "getISSUE__OUT", "setISSUE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ISSUE__OUT");
      aDescriptor.setDisplayName("ISSUE__OUT");
      aDescriptor.setShortDescription("ISSUE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLADING__NO__ERR__MSG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LADING__NO__ERR__MSG__OUT", Class.forName(getBeanClassName()), "getLADING__NO__ERR__MSG__OUT", "setLADING__NO__ERR__MSG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LADING__NO__ERR__MSG__OUT");
      aDescriptor.setDisplayName("LADING__NO__ERR__MSG__OUT");
      aDescriptor.setShortDescription("LADING__NO__ERR__MSG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__OUT");
      aDescriptor.setDisplayName("LL__OUT");
      aDescriptor.setShortDescription("LL__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getNOTES__BREAKDOWNPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("NOTES__BREAKDOWN", Class.forName(getBeanClassName()), "getNOTES__BREAKDOWN", "setNOTES__BREAKDOWN", "getNOTES__BREAKDOWN", "setNOTES__BREAKDOWN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("NOTES__BREAKDOWN");
      aDescriptor.setDisplayName("NOTES__BREAKDOWN");
      aDescriptor.setShortDescription("NOTES__BREAKDOWN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__OUTPropertyDescriptor()
            ,getZZ__OUTPropertyDescriptor()
            ,getFAC__OUTPropertyDescriptor()
            ,getDOCK__OUTPropertyDescriptor()
            ,getCITY__OUTPropertyDescriptor()
            ,getSTATE__OUTPropertyDescriptor()
            ,getBOL__NO__OUTPropertyDescriptor()
            ,getISSUE__OUTPropertyDescriptor()
            ,getSTCC__CODE__OUTPropertyDescriptor()
            ,getROUTE__OR__CARRIER__CODE__OUTPropertyDescriptor()
            ,getROUTE__OR__CARRIER__NAME__OUTPropertyDescriptor()
            ,getADR__NAME__OUTPropertyDescriptor()
            ,getADR__NM__LN1__OUTPropertyDescriptor()
            ,getADR__TXT__LN1__OUTPropertyDescriptor()
            ,getADR__TXT__LN2__OUTPropertyDescriptor()
            ,getADR__CITY__NAME__OUTPropertyDescriptor()
            ,getADR__STATE__OUTPropertyDescriptor()
            ,getADR__POSTAL__ZONE__CODE__OUTPropertyDescriptor()
            ,getADR__COUNTRY__OUTPropertyDescriptor()
            ,getDEL__INST__LN1__OUTPropertyDescriptor()
            ,getDEL__INST__LN2__OUTPropertyDescriptor()
            ,getDEL__INST__LN3__OUTPropertyDescriptor()
            ,getDEL__INST__LN4__OUTPropertyDescriptor()
            ,getDEL__INST__LN5__OUTPropertyDescriptor()
            ,getNOTES__BREAKDOWNPropertyDescriptor()
            ,getCHARGES__AREA__OUTPropertyDescriptor()
            ,getFRT__CHRG__TOTAL__OUTPropertyDescriptor()
            ,getLADING__NO__ERR__MSG__OUTPropertyDescriptor()
            ,getFill_0PropertyDescriptor()
            ,getERROR__MSG__ERR__MSG__OUTPropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getROUTE__OR__CARRIER__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ROUTE__OR__CARRIER__CODE__OUT", Class.forName(getBeanClassName()), "getROUTE__OR__CARRIER__CODE__OUT", "setROUTE__OR__CARRIER__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ROUTE__OR__CARRIER__CODE__OUT");
      aDescriptor.setDisplayName("ROUTE__OR__CARRIER__CODE__OUT");
      aDescriptor.setShortDescription("ROUTE__OR__CARRIER__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getROUTE__OR__CARRIER__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ROUTE__OR__CARRIER__NAME__OUT", Class.forName(getBeanClassName()), "getROUTE__OR__CARRIER__NAME__OUT", "setROUTE__OR__CARRIER__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ROUTE__OR__CARRIER__NAME__OUT");
      aDescriptor.setDisplayName("ROUTE__OR__CARRIER__NAME__OUT");
      aDescriptor.setShortDescription("ROUTE__OR__CARRIER__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("STATE__OUT", Class.forName(getBeanClassName()), "getSTATE__OUT", "setSTATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STATE__OUT");
      aDescriptor.setDisplayName("STATE__OUT");
      aDescriptor.setShortDescription("STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTCC__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("STCC__CODE__OUT", Class.forName(getBeanClassName()), "getSTCC__CODE__OUT", "setSTCC__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STCC__CODE__OUT");
      aDescriptor.setDisplayName("STCC__CODE__OUT");
      aDescriptor.setShortDescription("STCC__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__OUT");
      aDescriptor.setDisplayName("ZZ__OUT");
      aDescriptor.setShortDescription("ZZ__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }
}
