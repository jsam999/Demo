package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B31OutMsgInfo.java
// Generated from C:\tim0b31.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B31OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31OutMsgInfo_ADDRESS__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31OutMsgInfo_ADDRESS__OUT () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(25):DISPLAY"), "ADR__NAME__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__NM__LN1__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN1__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN2__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "ADR__CITY__NAME__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__STATE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "ADR__POSTAL__ZONE__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__COUNTRY__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31OutMsgInfo_DEL__INSTRUCTIONS extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31OutMsgInfo_DEL__INSTRUCTIONS () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN1__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN2__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN3__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN4__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN5__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31OutMsgInfo_NOTES__BREAKDOWN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31OutMsgInfo_NOTES__BREAKDOWN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(01):DISPLAY"), "NOTE__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(50):DISPLAY"), "SHIPPING__NOTES__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31OutMsgInfo_CHARGES__AREA__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31OutMsgInfo_CHARGES__AREA__OUT () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(10):DISPLAY"), "REF__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(04):DISPLAY"), "FRT__RATE__UM__ABBR__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(07)V9(4):DISPLAY"), "UNITS__OUT"));

		 addField(new Field(new CobolType("9(5)V9(4):DISPLAY"), "FRT__RATE__OUT"));

		 addField(new Field(new CobolType("9(7)V9(2):DISPLAY"), "FRT__FLAT__CHRG__OUT"));

		 addField(new Field(new CobolType("X:DISPLAY"), "FRT__CHRG__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(07)V99:DISPLAY"), "FRT__CHRG__OUT"));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B31OutMsgInfo_ERR__MSG__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B31OutMsgInfo_ERR__MSG__OUT () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(10):DISPLAY"), "LADING__NO__ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(01):DISPLAY"), "fill_0", new CobolInitialValueObject("-", null)));

		 addField(new Field(new CobolType("X(50):DISPLAY"), "ERROR__MSG__ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B31OutMsgInfo () throws RecordException
   {
      int[] arraySize = null;
      ArrayField arrField = null;

      addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("X(02):DISPLAY"), "FAC__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "DOCK__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(18):DISPLAY"), "CITY__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "STATE__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "BOL__NO__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "ISSUE__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(09):DISPLAY"), "STCC__CODE__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(05):DISPLAY"), "ROUTE__OR__CARRIER__CODE__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(30):DISPLAY"), "ROUTE__OR__CARRIER__NAME__OUT", new CobolInitialValueObject(" ", null)));

      addField(new NestedRecordField(new AK0B31OutMsgInfo_ADDRESS__OUT(), "ADDRESS__OUT"));

      addField(new NestedRecordField(new AK0B31OutMsgInfo_DEL__INSTRUCTIONS(), "DEL__INSTRUCTIONS"));

      arraySize = new int[1];
      arraySize[0] = 30;
      arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B31OutMsgInfo_NOTES__BREAKDOWN()), "NOTES__BREAKDOWN");
      addField(arrField);

      arraySize = new int[1];
      arraySize[0] = 10;
      arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B31OutMsgInfo_CHARGES__AREA__OUT()), "CHARGES__AREA__OUT");
      addField(arrField);

      addField(new Field(new CobolType("9(07)V99:DISPLAY"), "FRT__CHRG__TOTAL__OUT"));

      addField(new NestedRecordField(new AK0B31OutMsgInfo_ERR__MSG__OUT(), "ERR__MSG__OUT"));

   }
}
