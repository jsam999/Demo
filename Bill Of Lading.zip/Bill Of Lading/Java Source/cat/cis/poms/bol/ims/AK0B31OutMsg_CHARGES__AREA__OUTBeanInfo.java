package cat.cis.poms.bol.ims;

/**
 * Class: cat.cis.poms.bol.ims.AK0B31OutMsg_CHARGES__AREA__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B31OutMsg_CHARGES__AREA__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.bol.ims.AK0B31OutMsg_CHARGES__AREA__OUT.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.bol.ims.AK0B31OutMsg_CHARGES__AREA__OUT");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B31OutMsg_CHARGES__AREA__OUT.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDESC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DESC__OUT", Class.forName(getBeanClassName()), "getDESC__OUT", "setDESC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DESC__OUT");
      aDescriptor.setDisplayName("DESC__OUT");
      aDescriptor.setShortDescription("DESC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getFRT__CHRG__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__CHRG__CODE__OUT", Class.forName(getBeanClassName()), "getFRT__CHRG__CODE__OUT", "setFRT__CHRG__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__CHRG__CODE__OUT");
      aDescriptor.setDisplayName("FRT__CHRG__CODE__OUT");
      aDescriptor.setShortDescription("FRT__CHRG__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__CHRG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__CHRG__OUT", Class.forName(getBeanClassName()), "getFRT__CHRG__OUT", "setFRT__CHRG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__CHRG__OUT");
      aDescriptor.setDisplayName("FRT__CHRG__OUT");
      aDescriptor.setShortDescription("FRT__CHRG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__FLAT__CHRG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__FLAT__CHRG__OUT", Class.forName(getBeanClassName()), "getFRT__FLAT__CHRG__OUT", "setFRT__FLAT__CHRG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__FLAT__CHRG__OUT");
      aDescriptor.setDisplayName("FRT__FLAT__CHRG__OUT");
      aDescriptor.setShortDescription("FRT__FLAT__CHRG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__RATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__OUT", Class.forName(getBeanClassName()), "getFRT__RATE__OUT", "setFRT__RATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__RATE__OUT");
      aDescriptor.setDisplayName("FRT__RATE__OUT");
      aDescriptor.setShortDescription("FRT__RATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__RATE__UM__ABBR__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__UM__ABBR__OUT", Class.forName(getBeanClassName()), "getFRT__RATE__UM__ABBR__OUT", "setFRT__RATE__UM__ABBR__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__RATE__UM__ABBR__OUT");
      aDescriptor.setDisplayName("FRT__RATE__UM__ABBR__OUT");
      aDescriptor.setShortDescription("FRT__RATE__UM__ABBR__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getREF__NO__OUTPropertyDescriptor()
            ,getDESC__OUTPropertyDescriptor()
            ,getFRT__RATE__UM__ABBR__OUTPropertyDescriptor()
            ,getUNITS__OUTPropertyDescriptor()
            ,getFRT__RATE__OUTPropertyDescriptor()
            ,getFRT__FLAT__CHRG__OUTPropertyDescriptor()
            ,getFRT__CHRG__CODE__OUTPropertyDescriptor()
            ,getFRT__CHRG__OUTPropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getREF__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("REF__NO__OUT", Class.forName(getBeanClassName()), "getREF__NO__OUT", "setREF__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("REF__NO__OUT");
      aDescriptor.setDisplayName("REF__NO__OUT");
      aDescriptor.setShortDescription("REF__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getUNITS__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("UNITS__OUT", Class.forName(getBeanClassName()), "getUNITS__OUT", "setUNITS__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("UNITS__OUT");
      aDescriptor.setDisplayName("UNITS__OUT");
      aDescriptor.setShortDescription("UNITS__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }
}
