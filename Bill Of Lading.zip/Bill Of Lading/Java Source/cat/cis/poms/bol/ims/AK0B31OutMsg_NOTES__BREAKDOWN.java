package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B31OutMsg_NOTES__BREAKDOWN
 * This is a generated file.  Do not edit.
 */

public class AK0B31OutMsg_NOTES__BREAKDOWN extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B31OutMsg_NOTES__BREAKDOWN()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B31OutMsg_NOTES__BREAKDOWN.class,51));
         this.setBytes(new byte[51]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getNOTE__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getSHIPPING__NOTES__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("NOTE__CODE__OUT",null,getNOTE__CODE__OUT());
         firePropertyChange("SHIPPING__NOTES__OUT",null,getSHIPPING__NOTES__OUT());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      return;
   }
   public void setNOTE__CODE__OUT(java.lang.String aNOTE__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldNOTE__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aNOTE__CODE__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("NOTE__CODE__OUT",oldNOTE__CODE__OUT,aNOTE__CODE__OUT);
      return;
   }
   public void setSHIPPING__NOTES__OUT(java.lang.String aSHIPPING__NOTES__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSHIPPING__NOTES__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1,aSHIPPING__NOTES__OUT,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      firePropertyChange("SHIPPING__NOTES__OUT",oldSHIPPING__NOTES__OUT,aSHIPPING__NOTES__OUT);
      return;
   }
}
