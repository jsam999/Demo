package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B40InMsgInfo.java
// Generated from C:\t1ak0b40.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B40InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B40InMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(05):DISPLAY"), "BADGE__NO__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(07):DISPLAY"), "USER__ACF2__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(06):DISPLAY"), "ORIGIN__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(06):DISPLAY"), "DEST__CODE__IN", new CobolInitialValueObject(" ", null)));

   }      
}
