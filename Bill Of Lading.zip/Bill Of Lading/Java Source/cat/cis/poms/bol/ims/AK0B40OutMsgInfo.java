package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B40OutMsgInfo.java
// Generated from C:\paul0b40.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B40OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B40OutMsgInfo_DATA__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B40OutMsgInfo_DATA__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X:DISPLAY"), "AUTH__EMER__RTE__IND__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_0", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "IN__OUT__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_1", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "TRAN__TYPE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_2", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "SUPP__DLR__FAC__CD__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_3", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "WT__SEQ__CD__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_4", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(4):DISPLAY"), "TRAILER__ABBR__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_5", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(5):DISPLAY"), "CARRIER__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_6", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "CARRIER__NAME__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_7", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(1):DISPLAY"), "TRANSP__MODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(01):DISPLAY"), "TRL__LD__IND__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(01):DISPLAY"), "CONTR__IND__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(01):DISPLAY"), "LD__WIDE__IND__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X:DISPLAY"), "fill_8", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(8):DISPLAY"), "START__EFF__DATE__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B40OutMsgInfo_ZERO__P__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B40OutMsgInfo_ZERO__P__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(10):DISPLAY"), "ZERO__P__REF__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(40):DISPLAY"), "ZERO__P__DESC__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B40OutMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

	  arraySize[0] = 50;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B40OutMsgInfo_DATA__OUT()), "DATA__OUT");
	  addField(arrField);

	  arraySize[0] = 50;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B40OutMsgInfo_ZERO__P__OUT()), "ZERO__P__OUT");
	  addField(arrField);

	  addField(new Field(new CobolType("X(50):DISPLAY"), "ERROR__MSG__OUT", new CobolInitialValueObject(" ", null)));

   }      
}
