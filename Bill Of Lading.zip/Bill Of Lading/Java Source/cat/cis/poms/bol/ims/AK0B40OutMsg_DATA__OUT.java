package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: CatBolIMSConnectAK0B40.AK0B40OutMsg_DATA__OUT
 * This is a generated file.  Do not edit.
 */

public class AK0B40OutMsg_DATA__OUT extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B40OutMsg_DATA__OUT()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B40OutMsg_DATA__OUT.class,80));
		 this.setBytes(new byte[80]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }            
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }      
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }      
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }      
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }      
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }      
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }      
   public java.lang.String getAUTH__EMER__RTE__IND__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getCARRIER__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }      
   public java.lang.String getCARRIER__NAME__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,31,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }      
   public java.lang.String getCONTR__IND__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,69,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }      
   public java.lang.String getFill_0()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_1()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_2()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,5,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_3()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,16,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_4()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_5()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,24,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_6()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_7()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,66,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getFill_8()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,71,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getIN__OUT__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getLD__WIDE__IND__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,70,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }      
   public java.lang.String getSTART__EFF__DATE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,72,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }      
   public java.lang.String getSUPP__DLR__FAC__CD__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }      
   public java.lang.String getTRAILER__ABBR__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }      
   public java.lang.String getTRAN__TYPE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getTRANSP__MODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,67,9,0,1,false,false,false,0,0,"X(1)",false,true);
   }      
   public java.lang.String getTRL__LD__IND__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,68,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }      
   public java.lang.String getWT__SEQ__CD__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,17,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }      
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("AUTH__EMER__RTE__IND__OUT",null,getAUTH__EMER__RTE__IND__OUT());
		 firePropertyChange("fill_0",null,getFill_0());
		 firePropertyChange("IN__OUT__CODE__OUT",null,getIN__OUT__CODE__OUT());
		 firePropertyChange("fill_1",null,getFill_1());
		 firePropertyChange("TRAN__TYPE__OUT",null,getTRAN__TYPE__OUT());
		 firePropertyChange("fill_2",null,getFill_2());
		 firePropertyChange("SUPP__DLR__FAC__CD__OUT",null,getSUPP__DLR__FAC__CD__OUT());
		 firePropertyChange("fill_3",null,getFill_3());
		 firePropertyChange("WT__SEQ__CD__OUT",null,getWT__SEQ__CD__OUT());
		 firePropertyChange("fill_4",null,getFill_4());
		 firePropertyChange("TRAILER__ABBR__OUT",null,getTRAILER__ABBR__OUT());
		 firePropertyChange("fill_5",null,getFill_5());
		 firePropertyChange("CARRIER__CODE__OUT",null,getCARRIER__CODE__OUT());
		 firePropertyChange("fill_6",null,getFill_6());
		 firePropertyChange("CARRIER__NAME__OUT",null,getCARRIER__NAME__OUT());
		 firePropertyChange("fill_7",null,getFill_7());
		 firePropertyChange("TRANSP__MODE__OUT",null,getTRANSP__MODE__OUT());
		 firePropertyChange("TRL__LD__IND__OUT",null,getTRL__LD__IND__OUT());
		 firePropertyChange("CONTR__IND__OUT",null,getCONTR__IND__OUT());
		 firePropertyChange("LD__WIDE__IND__OUT",null,getLD__WIDE__IND__OUT());
		 firePropertyChange("fill_8",null,getFill_8());
		 firePropertyChange("START__EFF__DATE__OUT",null,getSTART__EFF__DATE__OUT());
	  }
   }      
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }      
   public void setAUTH__EMER__RTE__IND__OUT(java.lang.String aAUTH__EMER__RTE__IND__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldAUTH__EMER__RTE__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aAUTH__EMER__RTE__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("AUTH__EMER__RTE__IND__OUT",oldAUTH__EMER__RTE__IND__OUT,aAUTH__EMER__RTE__IND__OUT);
	  return;
   }      
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }      
   public void setCARRIER__CODE__OUT(java.lang.String aCARRIER__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCARRIER__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,25,aCARRIER__CODE__OUT,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  firePropertyChange("CARRIER__CODE__OUT",oldCARRIER__CODE__OUT,aCARRIER__CODE__OUT);
	  return;
   }      
   public void setCARRIER__NAME__OUT(java.lang.String aCARRIER__NAME__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCARRIER__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,31,9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,31,aCARRIER__NAME__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  firePropertyChange("CARRIER__NAME__OUT",oldCARRIER__NAME__OUT,aCARRIER__NAME__OUT);
	  return;
   }      
   public void setCONTR__IND__OUT(java.lang.String aCONTR__IND__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCONTR__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,69,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,69,aCONTR__IND__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  firePropertyChange("CONTR__IND__OUT",oldCONTR__IND__OUT,aCONTR__IND__OUT);
	  return;
   }      
   public void setFill_0(java.lang.String aFill_0)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1,aFill_0,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_0",oldFill_0,aFill_0);
	  return;
   }      
   public void setFill_1(java.lang.String aFill_1)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_1 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,3,aFill_1,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_1",oldFill_1,aFill_1);
	  return;
   }      
   public void setFill_2(java.lang.String aFill_2)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_2 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,5,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,5,aFill_2,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_2",oldFill_2,aFill_2);
	  return;
   }      
   public void setFill_3(java.lang.String aFill_3)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_3 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,16,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,16,aFill_3,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_3",oldFill_3,aFill_3);
	  return;
   }      
   public void setFill_4(java.lang.String aFill_4)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_4 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,19,aFill_4,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_4",oldFill_4,aFill_4);
	  return;
   }      
   public void setFill_5(java.lang.String aFill_5)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_5 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,24,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,24,aFill_5,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_5",oldFill_5,aFill_5);
	  return;
   }      
   public void setFill_6(java.lang.String aFill_6)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_6 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,30,aFill_6,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_6",oldFill_6,aFill_6);
	  return;
   }      
   public void setFill_7(java.lang.String aFill_7)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_7 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,66,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,66,aFill_7,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_7",oldFill_7,aFill_7);
	  return;
   }      
   public void setFill_8(java.lang.String aFill_8)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_8 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,71,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,71,aFill_8,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("fill_8",oldFill_8,aFill_8);
	  return;
   }      
   public void setIN__OUT__CODE__OUT(java.lang.String aIN__OUT__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldIN__OUT__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,2,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,2,aIN__OUT__CODE__OUT,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("IN__OUT__CODE__OUT",oldIN__OUT__CODE__OUT,aIN__OUT__CODE__OUT);
	  return;
   }      
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,3, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,5, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,16, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,17, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,19, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,20, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,24, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,30, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,31, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,66, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,67, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(1)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,68, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,69, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,70, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,71, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,72, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  return;
   }      
   public void setLD__WIDE__IND__OUT(java.lang.String aLD__WIDE__IND__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldLD__WIDE__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,70,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,70,aLD__WIDE__IND__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  firePropertyChange("LD__WIDE__IND__OUT",oldLD__WIDE__IND__OUT,aLD__WIDE__IND__OUT);
	  return;
   }      
   public void setSTART__EFF__DATE__OUT(java.lang.String aSTART__EFF__DATE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldSTART__EFF__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,72,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,72,aSTART__EFF__DATE__OUT,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("START__EFF__DATE__OUT",oldSTART__EFF__DATE__OUT,aSTART__EFF__DATE__OUT);
	  return;
   }      
   public void setSUPP__DLR__FAC__CD__OUT(java.lang.String aSUPP__DLR__FAC__CD__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldSUPP__DLR__FAC__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6,aSUPP__DLR__FAC__CD__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("SUPP__DLR__FAC__CD__OUT",oldSUPP__DLR__FAC__CD__OUT,aSUPP__DLR__FAC__CD__OUT);
	  return;
   }      
   public void setTRAILER__ABBR__OUT(java.lang.String aTRAILER__ABBR__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAILER__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,20,aTRAILER__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  firePropertyChange("TRAILER__ABBR__OUT",oldTRAILER__ABBR__OUT,aTRAILER__ABBR__OUT);
	  return;
   }      
   public void setTRAN__TYPE__OUT(java.lang.String aTRAN__TYPE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAN__TYPE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__TYPE__OUT,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("TRAN__TYPE__OUT",oldTRAN__TYPE__OUT,aTRAN__TYPE__OUT);
	  return;
   }      
   public void setTRANSP__MODE__OUT(java.lang.String aTRANSP__MODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRANSP__MODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,67,9,0,1,false,false,false,0,0,"X(1)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,67,aTRANSP__MODE__OUT,9,0,1,false,false,false,0,0,"X(1)",false,true);
	  firePropertyChange("TRANSP__MODE__OUT",oldTRANSP__MODE__OUT,aTRANSP__MODE__OUT);
	  return;
   }      
   public void setTRL__LD__IND__OUT(java.lang.String aTRL__LD__IND__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRL__LD__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,68,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,68,aTRL__LD__IND__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
	  firePropertyChange("TRL__LD__IND__OUT",oldTRL__LD__IND__OUT,aTRL__LD__IND__OUT);
	  return;
   }      
   public void setWT__SEQ__CD__OUT(java.lang.String aWT__SEQ__CD__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldWT__SEQ__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,17,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,17,aWT__SEQ__CD__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("WT__SEQ__CD__OUT",oldWT__SEQ__CD__OUT,aWT__SEQ__CD__OUT);
	  return;
   }      
}
