package cat.cis.poms.bol.ims;

/**
 * Class: CatBolIMSConnectAK0B40.AK0B40OutMsg_DATA__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B40OutMsg_DATA__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }      
   public java.beans.PropertyDescriptor getAUTH__EMER__RTE__IND__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("AUTH__EMER__RTE__IND__OUT", Class.forName(getBeanClassName()), "getAUTH__EMER__RTE__IND__OUT", "setAUTH__EMER__RTE__IND__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("AUTH__EMER__RTE__IND__OUT");
	  aDescriptor.setDisplayName("AUTH__EMER__RTE__IND__OUT");
	  aDescriptor.setShortDescription("AUTH__EMER__RTE__IND__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B40OutMsg_DATA__OUT.class);
   }            
   public static java.lang.String getBeanClassName()
   {
	  return("CatBolIMSConnectAK0B40.AK0B40OutMsg_DATA__OUT");
   }      
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B40OutMsg_DATA__OUT.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }            
   public java.beans.PropertyDescriptor getCARRIER__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CARRIER__CODE__OUT", Class.forName(getBeanClassName()), "getCARRIER__CODE__OUT", "setCARRIER__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CARRIER__CODE__OUT");
	  aDescriptor.setDisplayName("CARRIER__CODE__OUT");
	  aDescriptor.setShortDescription("CARRIER__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCARRIER__NAME__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CARRIER__NAME__OUT", Class.forName(getBeanClassName()), "getCARRIER__NAME__OUT", "setCARRIER__NAME__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CARRIER__NAME__OUT");
	  aDescriptor.setDisplayName("CARRIER__NAME__OUT");
	  aDescriptor.setShortDescription("CARRIER__NAME__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCONTR__IND__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CONTR__IND__OUT", Class.forName(getBeanClassName()), "getCONTR__IND__OUT", "setCONTR__IND__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CONTR__IND__OUT");
	  aDescriptor.setDisplayName("CONTR__IND__OUT");
	  aDescriptor.setShortDescription("CONTR__IND__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }      
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_0");
	  aDescriptor.setDisplayName("fill_0");
	  aDescriptor.setShortDescription("fill_0");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_1PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_1", Class.forName(getBeanClassName()), "getFill_1", "setFill_1" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_1");
	  aDescriptor.setDisplayName("fill_1");
	  aDescriptor.setShortDescription("fill_1");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_2PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_2", Class.forName(getBeanClassName()), "getFill_2", "setFill_2" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_2");
	  aDescriptor.setDisplayName("fill_2");
	  aDescriptor.setShortDescription("fill_2");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_3PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_3", Class.forName(getBeanClassName()), "getFill_3", "setFill_3" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_3");
	  aDescriptor.setDisplayName("fill_3");
	  aDescriptor.setShortDescription("fill_3");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_4PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_4", Class.forName(getBeanClassName()), "getFill_4", "setFill_4" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_4");
	  aDescriptor.setDisplayName("fill_4");
	  aDescriptor.setShortDescription("fill_4");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_5PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_5", Class.forName(getBeanClassName()), "getFill_5", "setFill_5" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_5");
	  aDescriptor.setDisplayName("fill_5");
	  aDescriptor.setShortDescription("fill_5");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_6PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_6", Class.forName(getBeanClassName()), "getFill_6", "setFill_6" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_6");
	  aDescriptor.setDisplayName("fill_6");
	  aDescriptor.setShortDescription("fill_6");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_7PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_7", Class.forName(getBeanClassName()), "getFill_7", "setFill_7" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_7");
	  aDescriptor.setDisplayName("fill_7");
	  aDescriptor.setShortDescription("fill_7");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getFill_8PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("fill_8", Class.forName(getBeanClassName()), "getFill_8", "setFill_8" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("fill_8");
	  aDescriptor.setDisplayName("fill_8");
	  aDescriptor.setShortDescription("fill_8");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getIN__OUT__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__OUT__CODE__OUT", Class.forName(getBeanClassName()), "getIN__OUT__CODE__OUT", "setIN__OUT__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__OUT__CODE__OUT");
	  aDescriptor.setDisplayName("IN__OUT__CODE__OUT");
	  aDescriptor.setShortDescription("IN__OUT__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getLD__WIDE__IND__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LD__WIDE__IND__OUT", Class.forName(getBeanClassName()), "getLD__WIDE__IND__OUT", "setLD__WIDE__IND__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LD__WIDE__IND__OUT");
	  aDescriptor.setDisplayName("LD__WIDE__IND__OUT");
	  aDescriptor.setShortDescription("LD__WIDE__IND__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }      
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getAUTH__EMER__RTE__IND__OUTPropertyDescriptor()
			,getFill_0PropertyDescriptor()
			,getIN__OUT__CODE__OUTPropertyDescriptor()
			,getFill_1PropertyDescriptor()
			,getTRAN__TYPE__OUTPropertyDescriptor()
			,getFill_2PropertyDescriptor()
			,getSUPP__DLR__FAC__CD__OUTPropertyDescriptor()
			,getFill_3PropertyDescriptor()
			,getWT__SEQ__CD__OUTPropertyDescriptor()
			,getFill_4PropertyDescriptor()
			,getTRAILER__ABBR__OUTPropertyDescriptor()
			,getFill_5PropertyDescriptor()
			,getCARRIER__CODE__OUTPropertyDescriptor()
			,getFill_6PropertyDescriptor()
			,getCARRIER__NAME__OUTPropertyDescriptor()
			,getFill_7PropertyDescriptor()
			,getTRANSP__MODE__OUTPropertyDescriptor()
			,getTRL__LD__IND__OUTPropertyDescriptor()
			,getCONTR__IND__OUTPropertyDescriptor()
			,getLD__WIDE__IND__OUTPropertyDescriptor()
			,getFill_8PropertyDescriptor()
			,getSTART__EFF__DATE__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }      
   public java.beans.PropertyDescriptor getSTART__EFF__DATE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("START__EFF__DATE__OUT", Class.forName(getBeanClassName()), "getSTART__EFF__DATE__OUT", "setSTART__EFF__DATE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("START__EFF__DATE__OUT");
	  aDescriptor.setDisplayName("START__EFF__DATE__OUT");
	  aDescriptor.setShortDescription("START__EFF__DATE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getSUPP__DLR__FAC__CD__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("SUPP__DLR__FAC__CD__OUT", Class.forName(getBeanClassName()), "getSUPP__DLR__FAC__CD__OUT", "setSUPP__DLR__FAC__CD__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("SUPP__DLR__FAC__CD__OUT");
	  aDescriptor.setDisplayName("SUPP__DLR__FAC__CD__OUT");
	  aDescriptor.setShortDescription("SUPP__DLR__FAC__CD__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRAILER__ABBR__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAILER__ABBR__OUT", Class.forName(getBeanClassName()), "getTRAILER__ABBR__OUT", "setTRAILER__ABBR__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAILER__ABBR__OUT");
	  aDescriptor.setDisplayName("TRAILER__ABBR__OUT");
	  aDescriptor.setShortDescription("TRAILER__ABBR__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRAN__TYPE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAN__TYPE__OUT", Class.forName(getBeanClassName()), "getTRAN__TYPE__OUT", "setTRAN__TYPE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAN__TYPE__OUT");
	  aDescriptor.setDisplayName("TRAN__TYPE__OUT");
	  aDescriptor.setShortDescription("TRAN__TYPE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRANSP__MODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRANSP__MODE__OUT", Class.forName(getBeanClassName()), "getTRANSP__MODE__OUT", "setTRANSP__MODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRANSP__MODE__OUT");
	  aDescriptor.setDisplayName("TRANSP__MODE__OUT");
	  aDescriptor.setShortDescription("TRANSP__MODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRL__LD__IND__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRL__LD__IND__OUT", Class.forName(getBeanClassName()), "getTRL__LD__IND__OUT", "setTRL__LD__IND__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRL__LD__IND__OUT");
	  aDescriptor.setDisplayName("TRL__LD__IND__OUT");
	  aDescriptor.setShortDescription("TRL__LD__IND__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getWT__SEQ__CD__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("WT__SEQ__CD__OUT", Class.forName(getBeanClassName()), "getWT__SEQ__CD__OUT", "setWT__SEQ__CD__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WT__SEQ__CD__OUT");
	  aDescriptor.setDisplayName("WT__SEQ__CD__OUT");
	  aDescriptor.setShortDescription("WT__SEQ__CD__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }      
}
