package cat.cis.poms.bol.ims;

/**
 * Class: CatBolIMSConnectAK0B40.AK0B40OutMsg_ZERO__P__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B40OutMsg_ZERO__P__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }      
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B40OutMsg_ZERO__P__OUT.class);
   }            
   public static java.lang.String getBeanClassName()
   {
	  return("CatBolIMSConnectAK0B40.AK0B40OutMsg_ZERO__P__OUT");
   }      
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B40OutMsg_ZERO__P__OUT.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }            
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }      
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }      
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getZERO__P__REF__NO__OUTPropertyDescriptor()
			,getZERO__P__DESC__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }      
   public java.beans.PropertyDescriptor getZERO__P__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZERO__P__DESC__OUT", Class.forName(getBeanClassName()), "getZERO__P__DESC__OUT", "setZERO__P__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZERO__P__DESC__OUT");
	  aDescriptor.setDisplayName("ZERO__P__DESC__OUT");
	  aDescriptor.setShortDescription("ZERO__P__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getZERO__P__REF__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZERO__P__REF__NO__OUT", Class.forName(getBeanClassName()), "getZERO__P__REF__NO__OUT", "setZERO__P__REF__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZERO__P__REF__NO__OUT");
	  aDescriptor.setDisplayName("ZERO__P__REF__NO__OUT");
	  aDescriptor.setShortDescription("ZERO__P__REF__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }      
}
