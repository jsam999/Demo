package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: CatBolIMSConnectAK0B41.AK0B41InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B41InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B41InMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B41InMsg.class,118));
		 this.setBytes(new byte[118]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }            
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }      
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }      
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }      
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }      
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }      
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }      
   public java.lang.String getAUTH__EMER__RTE__IND__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,49,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getBADGE__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }      
   public java.lang.String getCARRIER__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,69,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }      
   public java.lang.String getCARRIER__NAME__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,83,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }      
   public java.lang.String getCONTR__IND__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,65,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getDEST__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,43,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }      
   public java.lang.String getIN__OUT__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,50,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getLADING__ISSUE__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,35,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }      
   public java.lang.String getLADING__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }      
   public java.lang.String getLD__WIDE__IND__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,66,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public short getLL__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("CatBolIMSConnectAK0B41.AK0B41InMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }      
   public java.lang.String getORIGIN__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,37,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }      
   public java.lang.String getSTART__EFF__DATE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,75,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }      
   public java.lang.String getSUPP__DLR__FAC__CD__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,52,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }      
   public java.lang.String getTRAILER__ABBR__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,67,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }      
   public java.lang.String getTRAN__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }      
   public java.lang.String getTRAN__TYPE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,51,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getTRANSP__MODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,74,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   public java.lang.String getTRL__LD__IND__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,64,9,0,1,false,false,false,0,0,"X",false,true);
   }      
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		is increased from 7 to 9.
	*/

   public java.lang.String getUSER__ACF2__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
   }      
   public java.lang.String getWT__SEQ__CD__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }      
   public short getZZ__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__IN",null,getLL__IN());
		 firePropertyChange("ZZ__IN",null,getZZ__IN());
		 firePropertyChange("TRAN__CODE__IN",null,getTRAN__CODE__IN());
		 firePropertyChange("BADGE__NO__IN",null,getBADGE__NO__IN());
		 firePropertyChange("USER__ACF2__IN",null,getUSER__ACF2__IN());
		 firePropertyChange("LADING__NO__IN",null,getLADING__NO__IN());
		 firePropertyChange("LADING__ISSUE__NO__IN",null,getLADING__ISSUE__NO__IN());
		 firePropertyChange("ORIGIN__CODE__IN",null,getORIGIN__CODE__IN());
		 firePropertyChange("DEST__CODE__IN",null,getDEST__CODE__IN());
		 firePropertyChange("AUTH__EMER__RTE__IND__IN",null,getAUTH__EMER__RTE__IND__IN());
		 firePropertyChange("IN__OUT__CODE__IN",null,getIN__OUT__CODE__IN());
		 firePropertyChange("TRAN__TYPE__IN",null,getTRAN__TYPE__IN());
		 firePropertyChange("SUPP__DLR__FAC__CD__IN",null,getSUPP__DLR__FAC__CD__IN());
		 firePropertyChange("WT__SEQ__CD__IN",null,getWT__SEQ__CD__IN());
		 firePropertyChange("TRL__LD__IND__IN",null,getTRL__LD__IND__IN());
		 firePropertyChange("CONTR__IND__IN",null,getCONTR__IND__IN());
		 firePropertyChange("LD__WIDE__IND__IN",null,getLD__WIDE__IND__IN());
		 firePropertyChange("TRAILER__ABBR__IN",null,getTRAILER__ABBR__IN());
		 firePropertyChange("CARRIER__CODE__IN",null,getCARRIER__CODE__IN());
		 firePropertyChange("TRANSP__MODE__IN",null,getTRANSP__MODE__IN());
		 firePropertyChange("START__EFF__DATE__IN",null,getSTART__EFF__DATE__IN());
		 firePropertyChange("CARRIER__NAME__IN",null,getCARRIER__NAME__IN());
	  }
   }      
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }      
   public void setAUTH__EMER__RTE__IND__IN(java.lang.String aAUTH__EMER__RTE__IND__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldAUTH__EMER__RTE__IND__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,49,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,49,aAUTH__EMER__RTE__IND__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("AUTH__EMER__RTE__IND__IN",oldAUTH__EMER__RTE__IND__IN,aAUTH__EMER__RTE__IND__IN);
	  return;
   }      
   public void setBADGE__NO__IN(java.lang.String aBADGE__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldBADGE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aBADGE__NO__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  firePropertyChange("BADGE__NO__IN",oldBADGE__NO__IN,aBADGE__NO__IN);
	  return;
   }      
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }      
   public void setCARRIER__CODE__IN(java.lang.String aCARRIER__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldCARRIER__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,69,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,69,aCARRIER__CODE__IN,9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  firePropertyChange("CARRIER__CODE__IN",oldCARRIER__CODE__IN,aCARRIER__CODE__IN);
	  return;
   }      
   public void setCARRIER__NAME__IN(java.lang.String aCARRIER__NAME__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldCARRIER__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,83,9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,83,aCARRIER__NAME__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  firePropertyChange("CARRIER__NAME__IN",oldCARRIER__NAME__IN,aCARRIER__NAME__IN);
	  return;
   }      
   public void setCONTR__IND__IN(java.lang.String aCONTR__IND__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldCONTR__IND__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,65,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,65,aCONTR__IND__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("CONTR__IND__IN",oldCONTR__IND__IN,aCONTR__IND__IN);
	  return;
   }      
   public void setDEST__CODE__IN(java.lang.String aDEST__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldDEST__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,43,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,43,aDEST__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  firePropertyChange("DEST__CODE__IN",oldDEST__CODE__IN,aDEST__CODE__IN);
	  return;
   }      
   public void setIN__OUT__CODE__IN(java.lang.String aIN__OUT__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldIN__OUT__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,50,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,50,aIN__OUT__CODE__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("IN__OUT__CODE__IN",oldIN__OUT__CODE__IN,aIN__OUT__CODE__IN);
	  return;
   }      
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,18, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,35, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,37, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,43, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,49, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,50, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,51, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,52, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,62, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,64, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,65, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,66, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,67, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,69, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,74, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,75, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,83, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
	  return;
   }      
   public void setLADING__ISSUE__NO__IN(java.lang.String aLADING__ISSUE__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldLADING__ISSUE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,35,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,35,aLADING__ISSUE__NO__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("LADING__ISSUE__NO__IN",oldLADING__ISSUE__NO__IN,aLADING__ISSUE__NO__IN);
	  return;
   }      
   public void setLADING__NO__IN(java.lang.String aLADING__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldLADING__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,25,aLADING__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("LADING__NO__IN",oldLADING__NO__IN,aLADING__NO__IN);
	  return;
   }      
   public void setLD__WIDE__IND__IN(java.lang.String aLD__WIDE__IND__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldLD__WIDE__IND__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,66,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,66,aLD__WIDE__IND__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("LD__WIDE__IND__IN",oldLD__WIDE__IND__IN,aLD__WIDE__IND__IN);
	  return;
   }      
   public void setLL__IN(short aLL__IN)
	  throws RecordConversionFailureException {
	  short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
	  return;
   }      
   public void setORIGIN__CODE__IN(java.lang.String aORIGIN__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldORIGIN__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,37,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,37,aORIGIN__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
	  firePropertyChange("ORIGIN__CODE__IN",oldORIGIN__CODE__IN,aORIGIN__CODE__IN);
	  return;
   }      
   public void setSTART__EFF__DATE__IN(java.lang.String aSTART__EFF__DATE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldSTART__EFF__DATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,75,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,75,aSTART__EFF__DATE__IN,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("START__EFF__DATE__IN",oldSTART__EFF__DATE__IN,aSTART__EFF__DATE__IN);
	  return;
   }      
   public void setSUPP__DLR__FAC__CD__IN(java.lang.String aSUPP__DLR__FAC__CD__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldSUPP__DLR__FAC__CD__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,52,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,52,aSUPP__DLR__FAC__CD__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("SUPP__DLR__FAC__CD__IN",oldSUPP__DLR__FAC__CD__IN,aSUPP__DLR__FAC__CD__IN);
	  return;
   }      
   public void setTRAILER__ABBR__IN(java.lang.String aTRAILER__ABBR__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAILER__ABBR__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,67,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,67,aTRAILER__ABBR__IN,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  firePropertyChange("TRAILER__ABBR__IN",oldTRAILER__ABBR__IN,aTRAILER__ABBR__IN);
	  return;
   }      
   public void setTRAN__CODE__IN(java.lang.String aTRAN__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAN__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  firePropertyChange("TRAN__CODE__IN",oldTRAN__CODE__IN,aTRAN__CODE__IN);
	  return;
   }      
   public void setTRAN__TYPE__IN(java.lang.String aTRAN__TYPE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAN__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,51,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,51,aTRAN__TYPE__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("TRAN__TYPE__IN",oldTRAN__TYPE__IN,aTRAN__TYPE__IN);
	  return;
   }      
   public void setTRANSP__MODE__IN(java.lang.String aTRANSP__MODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRANSP__MODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,74,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,74,aTRANSP__MODE__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("TRANSP__MODE__IN",oldTRANSP__MODE__IN,aTRANSP__MODE__IN);
	  return;
   }      
   public void setTRL__LD__IND__IN(java.lang.String aTRL__LD__IND__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRL__LD__IND__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,64,9,0,1,false,false,false,0,0,"X",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,64,aTRL__LD__IND__IN,9,0,1,false,false,false,0,0,"X",false,true);
	  firePropertyChange("TRL__LD__IND__IN",oldTRL__LD__IND__IN,aTRL__LD__IND__IN);
	  return;
   }      
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setUSER__ACF2__IN(java.lang.String aUSER__ACF2__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldUSER__ACF2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,18,aUSER__ACF2__IN,9,0,9,false,false,false,-6,0,"X(07)",false,true);
	  firePropertyChange("USER__ACF2__IN",oldUSER__ACF2__IN,aUSER__ACF2__IN);
	  return;
   }      
   public void setWT__SEQ__CD__IN(java.lang.String aWT__SEQ__CD__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldWT__SEQ__CD__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,62,aWT__SEQ__CD__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("WT__SEQ__CD__IN",oldWT__SEQ__CD__IN,aWT__SEQ__CD__IN);
	  return;
   }      
   public void setZZ__IN(short aZZ__IN)
	  throws RecordConversionFailureException {
	  short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
	  return;
   }      
}
