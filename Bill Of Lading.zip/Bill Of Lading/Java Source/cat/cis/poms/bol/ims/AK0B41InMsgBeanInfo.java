package cat.cis.poms.bol.ims;

/**
 * Class: CatBolIMSConnectAK0B41.AK0B41InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B41InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }      
   public java.beans.PropertyDescriptor getAUTH__EMER__RTE__IND__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("AUTH__EMER__RTE__IND__IN", Class.forName(getBeanClassName()), "getAUTH__EMER__RTE__IND__IN", "setAUTH__EMER__RTE__IND__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("AUTH__EMER__RTE__IND__IN");
	  aDescriptor.setDisplayName("AUTH__EMER__RTE__IND__IN");
	  aDescriptor.setShortDescription("AUTH__EMER__RTE__IND__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getBADGE__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BADGE__NO__IN", Class.forName(getBeanClassName()), "getBADGE__NO__IN", "setBADGE__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BADGE__NO__IN");
	  aDescriptor.setDisplayName("BADGE__NO__IN");
	  aDescriptor.setShortDescription("BADGE__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B41InMsg.class);
   }            
   public static java.lang.String getBeanClassName()
   {
	  return("CatBolIMSConnectAK0B41.AK0B41InMsg");
   }      
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B41InMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }            
   public java.beans.PropertyDescriptor getCARRIER__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CARRIER__CODE__IN", Class.forName(getBeanClassName()), "getCARRIER__CODE__IN", "setCARRIER__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CARRIER__CODE__IN");
	  aDescriptor.setDisplayName("CARRIER__CODE__IN");
	  aDescriptor.setShortDescription("CARRIER__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCARRIER__NAME__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CARRIER__NAME__IN", Class.forName(getBeanClassName()), "getCARRIER__NAME__IN", "setCARRIER__NAME__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CARRIER__NAME__IN");
	  aDescriptor.setDisplayName("CARRIER__NAME__IN");
	  aDescriptor.setShortDescription("CARRIER__NAME__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCONTR__IND__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CONTR__IND__IN", Class.forName(getBeanClassName()), "getCONTR__IND__IN", "setCONTR__IND__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CONTR__IND__IN");
	  aDescriptor.setDisplayName("CONTR__IND__IN");
	  aDescriptor.setShortDescription("CONTR__IND__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getDEST__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DEST__CODE__IN", Class.forName(getBeanClassName()), "getDEST__CODE__IN", "setDEST__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DEST__CODE__IN");
	  aDescriptor.setDisplayName("DEST__CODE__IN");
	  aDescriptor.setShortDescription("DEST__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }      
   public java.beans.PropertyDescriptor getIN__OUT__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("IN__OUT__CODE__IN", Class.forName(getBeanClassName()), "getIN__OUT__CODE__IN", "setIN__OUT__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("IN__OUT__CODE__IN");
	  aDescriptor.setDisplayName("IN__OUT__CODE__IN");
	  aDescriptor.setShortDescription("IN__OUT__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getLADING__ISSUE__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LADING__ISSUE__NO__IN", Class.forName(getBeanClassName()), "getLADING__ISSUE__NO__IN", "setLADING__ISSUE__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LADING__ISSUE__NO__IN");
	  aDescriptor.setDisplayName("LADING__ISSUE__NO__IN");
	  aDescriptor.setShortDescription("LADING__ISSUE__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getLADING__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LADING__NO__IN", Class.forName(getBeanClassName()), "getLADING__NO__IN", "setLADING__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LADING__NO__IN");
	  aDescriptor.setDisplayName("LADING__NO__IN");
	  aDescriptor.setShortDescription("LADING__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getLD__WIDE__IND__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LD__WIDE__IND__IN", Class.forName(getBeanClassName()), "getLD__WIDE__IND__IN", "setLD__WIDE__IND__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LD__WIDE__IND__IN");
	  aDescriptor.setDisplayName("LD__WIDE__IND__IN");
	  aDescriptor.setShortDescription("LD__WIDE__IND__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__IN");
	  aDescriptor.setDisplayName("LL__IN");
	  aDescriptor.setShortDescription("LL__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }      
   public java.beans.PropertyDescriptor getORIGIN__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CODE__IN", Class.forName(getBeanClassName()), "getORIGIN__CODE__IN", "setORIGIN__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ORIGIN__CODE__IN");
	  aDescriptor.setDisplayName("ORIGIN__CODE__IN");
	  aDescriptor.setShortDescription("ORIGIN__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__INPropertyDescriptor()
			,getZZ__INPropertyDescriptor()
			,getTRAN__CODE__INPropertyDescriptor()
			,getBADGE__NO__INPropertyDescriptor()
			,getUSER__ACF2__INPropertyDescriptor()
			,getLADING__NO__INPropertyDescriptor()
			,getLADING__ISSUE__NO__INPropertyDescriptor()
			,getORIGIN__CODE__INPropertyDescriptor()
			,getDEST__CODE__INPropertyDescriptor()
			,getAUTH__EMER__RTE__IND__INPropertyDescriptor()
			,getIN__OUT__CODE__INPropertyDescriptor()
			,getTRAN__TYPE__INPropertyDescriptor()
			,getSUPP__DLR__FAC__CD__INPropertyDescriptor()
			,getWT__SEQ__CD__INPropertyDescriptor()
			,getTRL__LD__IND__INPropertyDescriptor()
			,getCONTR__IND__INPropertyDescriptor()
			,getLD__WIDE__IND__INPropertyDescriptor()
			,getTRAILER__ABBR__INPropertyDescriptor()
			,getCARRIER__CODE__INPropertyDescriptor()
			,getTRANSP__MODE__INPropertyDescriptor()
			,getSTART__EFF__DATE__INPropertyDescriptor()
			,getCARRIER__NAME__INPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }      
   public java.beans.PropertyDescriptor getSTART__EFF__DATE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("START__EFF__DATE__IN", Class.forName(getBeanClassName()), "getSTART__EFF__DATE__IN", "setSTART__EFF__DATE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("START__EFF__DATE__IN");
	  aDescriptor.setDisplayName("START__EFF__DATE__IN");
	  aDescriptor.setShortDescription("START__EFF__DATE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getSUPP__DLR__FAC__CD__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("SUPP__DLR__FAC__CD__IN", Class.forName(getBeanClassName()), "getSUPP__DLR__FAC__CD__IN", "setSUPP__DLR__FAC__CD__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("SUPP__DLR__FAC__CD__IN");
	  aDescriptor.setDisplayName("SUPP__DLR__FAC__CD__IN");
	  aDescriptor.setShortDescription("SUPP__DLR__FAC__CD__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRAILER__ABBR__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAILER__ABBR__IN", Class.forName(getBeanClassName()), "getTRAILER__ABBR__IN", "setTRAILER__ABBR__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAILER__ABBR__IN");
	  aDescriptor.setDisplayName("TRAILER__ABBR__IN");
	  aDescriptor.setShortDescription("TRAILER__ABBR__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRAN__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__IN", "setTRAN__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAN__CODE__IN");
	  aDescriptor.setDisplayName("TRAN__CODE__IN");
	  aDescriptor.setShortDescription("TRAN__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRAN__TYPE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAN__TYPE__IN", Class.forName(getBeanClassName()), "getTRAN__TYPE__IN", "setTRAN__TYPE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAN__TYPE__IN");
	  aDescriptor.setDisplayName("TRAN__TYPE__IN");
	  aDescriptor.setShortDescription("TRAN__TYPE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRANSP__MODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRANSP__MODE__IN", Class.forName(getBeanClassName()), "getTRANSP__MODE__IN", "setTRANSP__MODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRANSP__MODE__IN");
	  aDescriptor.setDisplayName("TRANSP__MODE__IN");
	  aDescriptor.setShortDescription("TRANSP__MODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getTRL__LD__IND__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRL__LD__IND__IN", Class.forName(getBeanClassName()), "getTRL__LD__IND__IN", "setTRL__LD__IND__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRL__LD__IND__IN");
	  aDescriptor.setDisplayName("TRL__LD__IND__IN");
	  aDescriptor.setShortDescription("TRL__LD__IND__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getUSER__ACF2__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("USER__ACF2__IN", Class.forName(getBeanClassName()), "getUSER__ACF2__IN", "setUSER__ACF2__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("USER__ACF2__IN");
	  aDescriptor.setDisplayName("USER__ACF2__IN");
	  aDescriptor.setShortDescription("USER__ACF2__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getWT__SEQ__CD__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("WT__SEQ__CD__IN", Class.forName(getBeanClassName()), "getWT__SEQ__CD__IN", "setWT__SEQ__CD__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WT__SEQ__CD__IN");
	  aDescriptor.setDisplayName("WT__SEQ__CD__IN");
	  aDescriptor.setShortDescription("WT__SEQ__CD__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__IN");
	  aDescriptor.setDisplayName("ZZ__IN");
	  aDescriptor.setShortDescription("ZZ__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }      
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }      
}
