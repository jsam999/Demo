package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B41InMsgInfo.java
// Generated from C:\6290b41.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B41InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B41InMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(05):DISPLAY"), "BADGE__NO__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(07):DISPLAY"), "USER__ACF2__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(10):DISPLAY"), "LADING__NO__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "LADING__ISSUE__NO__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(06):DISPLAY"), "ORIGIN__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(06):DISPLAY"), "DEST__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "AUTH__EMER__RTE__IND__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "IN__OUT__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "TRAN__TYPE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(10):DISPLAY"), "SUPP__DLR__FAC__CD__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "WT__SEQ__CD__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "TRL__LD__IND__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "CONTR__IND__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "LD__WIDE__IND__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(2):DISPLAY"), "TRAILER__ABBR__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(5):DISPLAY"), "CARRIER__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X:DISPLAY"), "TRANSP__MODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(8):DISPLAY"), "START__EFF__DATE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(35):DISPLAY"), "CARRIER__NAME__IN", new CobolInitialValueObject(" ", null)));

   }      
}
