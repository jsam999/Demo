package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecord;
import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B41OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B41OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B41OutMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B41OutMsg.class,4991));
		 this.setBytes(new byte[4991]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[] getADDITIONAL__CHARGES__OUT()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 96;
		 AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[] returnArray = new AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[20];
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 1296 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			CustomRecordType elementRecordType = new CustomRecordType(AK0B41OutMsg_ADDITIONAL__CHARGES__OUT.class,elementSize);
			CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
			byte[] bytes = new byte[elementSize];
			System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
			element.setBytes (bytes);
			returnArray[i0] = (AK0B41OutMsg_ADDITIONAL__CHARGES__OUT)element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public AK0B41OutMsg_ADDITIONAL__CHARGES__OUT getADDITIONAL__CHARGES__OUT(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 96;
		 int[] dim = {20};
		 int offset = 1296 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 CustomRecordType returnRecordType = new CustomRecordType(AK0B41OutMsg_ADDITIONAL__CHARGES__OUT.class,elementSize);
		 CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
		 byte[] bytes = new byte[elementSize];
		 System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
		 returnRecord.setBytes (bytes);
		 return ((AK0B41OutMsg_ADDITIONAL__CHARGES__OUT)returnRecord);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public java.lang.String getCONTRACT__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }   
   public java.lang.String getERROR__MSG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4916,9,0,75,false,false,false,-74,0,"X(75)",false,true);
   }   
   public short getLL__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("cat.bol.ims.AK0B41OutMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }   
   public AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[] getRATE__ROUTE__NOTES__OUT()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 85;
		 AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[] returnArray = new AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[20];
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 3216 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			CustomRecordType elementRecordType = new CustomRecordType(AK0B41OutMsg_RATE__ROUTE__NOTES__OUT.class,elementSize);
			CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
			byte[] bytes = new byte[elementSize];
			System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
			element.setBytes (bytes);
			returnArray[i0] = (AK0B41OutMsg_RATE__ROUTE__NOTES__OUT)element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public AK0B41OutMsg_RATE__ROUTE__NOTES__OUT getRATE__ROUTE__NOTES__OUT(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 85;
		 int[] dim = {20};
		 int offset = 3216 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 CustomRecordType returnRecordType = new CustomRecordType(AK0B41OutMsg_RATE__ROUTE__NOTES__OUT.class,elementSize);
		 CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
		 byte[] bytes = new byte[elementSize];
		 System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
		 returnRecord.setBytes (bytes);
		 return ((AK0B41OutMsg_RATE__ROUTE__NOTES__OUT)returnRecord);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public AK0B41OutMsg_WEIGHTS__RATES__OUT[] getWEIGHTS__RATES__OUT()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 64;
		 AK0B41OutMsg_WEIGHTS__RATES__OUT[] returnArray = new AK0B41OutMsg_WEIGHTS__RATES__OUT[20];
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			CustomRecordType elementRecordType = new CustomRecordType(AK0B41OutMsg_WEIGHTS__RATES__OUT.class,elementSize);
			CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
			byte[] bytes = new byte[elementSize];
			System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
			element.setBytes (bytes);
			returnArray[i0] = (AK0B41OutMsg_WEIGHTS__RATES__OUT)element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public AK0B41OutMsg_WEIGHTS__RATES__OUT getWEIGHTS__RATES__OUT(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 64;
		 int[] dim = {20};
		 int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 CustomRecordType returnRecordType = new CustomRecordType(AK0B41OutMsg_WEIGHTS__RATES__OUT.class,elementSize);
		 CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
		 byte[] bytes = new byte[elementSize];
		 System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
		 returnRecord.setBytes (bytes);
		 return ((AK0B41OutMsg_WEIGHTS__RATES__OUT)returnRecord);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public short getZZ__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__OUT",null,getLL__OUT());
		 firePropertyChange("ZZ__OUT",null,getZZ__OUT());
		 firePropertyChange("CONTRACT__NO__OUT",null,getCONTRACT__NO__OUT());
		 firePropertyChange("WEIGHTS__RATES__OUT",null,getWEIGHTS__RATES__OUT());
		 firePropertyChange("ADDITIONAL__CHARGES__OUT",null,getADDITIONAL__CHARGES__OUT());
		 firePropertyChange("RATE__ROUTE__NOTES__OUT",null,getRATE__ROUTE__NOTES__OUT());
		 firePropertyChange("ERROR__MSG__OUT",null,getERROR__MSG__OUT());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setADDITIONAL__CHARGES__OUT(AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[] aADDITIONAL__CHARGES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 96;
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 1296 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			byte[] recordBytes = getBytes();
			byte[] fieldBytes = aADDITIONAL__CHARGES__OUT[i0].getBytes();
			System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
			setBytes(recordBytes);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setADDITIONAL__CHARGES__OUT(int index, AK0B41OutMsg_ADDITIONAL__CHARGES__OUT aADDITIONAL__CHARGES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 96;
		 int[] dim = {20};
		 int offset = 1296 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 byte[] recordBytes = getBytes();
		 byte[] fieldBytes = aADDITIONAL__CHARGES__OUT.getBytes();
		 System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
		 setBytes(recordBytes);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setCONTRACT__NO__OUT(java.lang.String aCONTRACT__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCONTRACT__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aCONTRACT__NO__OUT,9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  firePropertyChange("CONTRACT__NO__OUT",oldCONTRACT__NO__OUT,aCONTRACT__NO__OUT);
	  return;
   }   
   public void setERROR__MSG__OUT(java.lang.String aERROR__MSG__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldERROR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4916,9,0,75,false,false,false,-74,0,"X(75)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4916,aERROR__MSG__OUT,9,0,75,false,false,false,-74,0,"X(75)",false,true);
	  firePropertyChange("ERROR__MSG__OUT",oldERROR__MSG__OUT,aERROR__MSG__OUT);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4916, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,75,false,false,false,-74,0,"X(75)",false,true);
	  return;
   }   
   public void setLL__OUT(short aLL__OUT)
	  throws RecordConversionFailureException {
	  short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
	  return;
   }   
   public void setRATE__ROUTE__NOTES__OUT(AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[] aRATE__ROUTE__NOTES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 85;
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 3216 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			byte[] recordBytes = getBytes();
			byte[] fieldBytes = aRATE__ROUTE__NOTES__OUT[i0].getBytes();
			System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
			setBytes(recordBytes);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setRATE__ROUTE__NOTES__OUT(int index, AK0B41OutMsg_RATE__ROUTE__NOTES__OUT aRATE__ROUTE__NOTES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 85;
		 int[] dim = {20};
		 int offset = 3216 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 byte[] recordBytes = getBytes();
		 byte[] fieldBytes = aRATE__ROUTE__NOTES__OUT.getBytes();
		 System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
		 setBytes(recordBytes);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setWEIGHTS__RATES__OUT(AK0B41OutMsg_WEIGHTS__RATES__OUT[] aWEIGHTS__RATES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 64;
		 int[] dim = {20};
		 for(int i0=0;i0<20;i0++) {
			int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			byte[] recordBytes = getBytes();
			byte[] fieldBytes = aWEIGHTS__RATES__OUT[i0].getBytes();
			System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
			setBytes(recordBytes);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setWEIGHTS__RATES__OUT(int index, AK0B41OutMsg_WEIGHTS__RATES__OUT aWEIGHTS__RATES__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 64;
		 int[] dim = {20};
		 int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 byte[] recordBytes = getBytes();
		 byte[] fieldBytes = aWEIGHTS__RATES__OUT.getBytes();
		 System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
		 setBytes(recordBytes);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setZZ__OUT(short aZZ__OUT)
	  throws RecordConversionFailureException {
	  short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
	  return;
   }   
}
