package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B41OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B41OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.PropertyDescriptor getADDITIONAL__CHARGES__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("ADDITIONAL__CHARGES__OUT", Class.forName(getBeanClassName()), "getADDITIONAL__CHARGES__OUT", "setADDITIONAL__CHARGES__OUT", "getADDITIONAL__CHARGES__OUT", "setADDITIONAL__CHARGES__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADDITIONAL__CHARGES__OUT");
	  aDescriptor.setDisplayName("ADDITIONAL__CHARGES__OUT");
	  aDescriptor.setShortDescription("ADDITIONAL__CHARGES__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B41OutMsg.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B41OutMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B41OutMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCONTRACT__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CONTRACT__NO__OUT", Class.forName(getBeanClassName()), "getCONTRACT__NO__OUT", "setCONTRACT__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CONTRACT__NO__OUT");
	  aDescriptor.setDisplayName("CONTRACT__NO__OUT");
	  aDescriptor.setShortDescription("CONTRACT__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getERROR__MSG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ERROR__MSG__OUT", Class.forName(getBeanClassName()), "getERROR__MSG__OUT", "setERROR__MSG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ERROR__MSG__OUT");
	  aDescriptor.setDisplayName("ERROR__MSG__OUT");
	  aDescriptor.setShortDescription("ERROR__MSG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__OUT");
	  aDescriptor.setDisplayName("LL__OUT");
	  aDescriptor.setShortDescription("LL__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__OUTPropertyDescriptor()
			,getZZ__OUTPropertyDescriptor()
			,getCONTRACT__NO__OUTPropertyDescriptor()
			,getWEIGHTS__RATES__OUTPropertyDescriptor()
			,getADDITIONAL__CHARGES__OUTPropertyDescriptor()
			,getRATE__ROUTE__NOTES__OUTPropertyDescriptor()
			,getERROR__MSG__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getRATE__ROUTE__NOTES__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("RATE__ROUTE__NOTES__OUT", Class.forName(getBeanClassName()), "getRATE__ROUTE__NOTES__OUT", "setRATE__ROUTE__NOTES__OUT", "getRATE__ROUTE__NOTES__OUT", "setRATE__ROUTE__NOTES__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("RATE__ROUTE__NOTES__OUT");
	  aDescriptor.setDisplayName("RATE__ROUTE__NOTES__OUT");
	  aDescriptor.setShortDescription("RATE__ROUTE__NOTES__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getWEIGHTS__RATES__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("WEIGHTS__RATES__OUT", Class.forName(getBeanClassName()), "getWEIGHTS__RATES__OUT", "setWEIGHTS__RATES__OUT", "getWEIGHTS__RATES__OUT", "setWEIGHTS__RATES__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WEIGHTS__RATES__OUT");
	  aDescriptor.setDisplayName("WEIGHTS__RATES__OUT");
	  aDescriptor.setShortDescription("WEIGHTS__RATES__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__OUT");
	  aDescriptor.setDisplayName("ZZ__OUT");
	  aDescriptor.setShortDescription("ZZ__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
