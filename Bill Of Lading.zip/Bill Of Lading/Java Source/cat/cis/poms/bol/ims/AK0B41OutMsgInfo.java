package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B41OutMsgInfo.java
// Generated from C:\9030B41.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B41OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B41OutMsgInfo_WEIGHTS__RATES__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B41OutMsgInfo_WEIGHTS__RATES__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(10):DISPLAY"), "COMM__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "MODEL__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(2):DISPLAY"), "PACK__TYPE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "ATT__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "ARR__REF__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "MINI__WT__LMT__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(7):DISPLAY"), "BRKPT__WT__LMT__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(5)V9(4):DISPLAY"), "FRT__RATE__OUT"));

		 addField(new Field(new CobolType("X(4):DISPLAY"), "FRT__RATE__UM__ABBR__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(4):DISPLAY"), "FRT__UM__ABBR__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B41OutMsgInfo_ADDITIONAL__CHARGES__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B41OutMsgInfo_ADDITIONAL__CHARGES__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(8):DISPLAY"), "END__EFF__DATE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(2):DISPLAY"), "ADDL__CHARGE__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(8):DISPLAY"), "START__EFF__DATE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(6)V9(3):DISPLAY"), "ADL__CHRG__QTY__OUT"));

		 addField(new Field(new CobolType("X(4):DISPLAY"), "QTY__UM__ABBR__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(6)V9(3):DISPLAY"), "ADDL__CHRG__AMT__OUT"));

		 addField(new Field(new CobolType("X(4):DISPLAY"), "ADDL__CHARGE__UM__ABBR__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(6)V9(3):DISPLAY"), "MINI__FRT__CHRG__OUT"));

		 addField(new Field(new CobolType("9(6)V9(3):DISPLAY"), "MAX__FRT__CHRG__OUT"));

		 addField(new Field(new CobolType("X(3):DISPLAY"), "CURRENCY__CODE__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(20):DISPLAY"), "ADDL__CHARGE__DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(2):DISPLAY"), "EXT__APP__CD__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(6)V9(3):DISPLAY"), "TO__QTY__OUT"));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B41OutMsgInfo_RATE__ROUTE__NOTES__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B41OutMsgInfo_RATE__ROUTE__NOTES__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(85):DISPLAY"), "NOTES__DATA__OUT", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B41OutMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(12):DISPLAY"), "CONTRACT__NO__OUT", new CobolInitialValueObject(" ", null)));

	  arraySize[0] = 20;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B41OutMsgInfo_WEIGHTS__RATES__OUT()), "WEIGHTS__RATES__OUT");
	  addField(arrField);

	  arraySize[0] = 20;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B41OutMsgInfo_ADDITIONAL__CHARGES__OUT()), "ADDITIONAL__CHARGES__OUT");
	  addField(arrField);

	  arraySize[0] = 20;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B41OutMsgInfo_RATE__ROUTE__NOTES__OUT()), "RATE__ROUTE__NOTES__OUT");
	  addField(arrField);

	  addField(new Field(new CobolType("X(75):DISPLAY"), "ERROR__MSG__OUT", new CobolInitialValueObject(" ", null)));

   }   
}
