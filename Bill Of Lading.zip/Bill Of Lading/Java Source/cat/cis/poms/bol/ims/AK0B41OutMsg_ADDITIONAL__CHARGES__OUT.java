package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUT
 * This is a generated file.  Do not edit.
 */

public class AK0B41OutMsg_ADDITIONAL__CHARGES__OUT extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B41OutMsg_ADDITIONAL__CHARGES__OUT()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUT.class,96));
		 this.setBytes(new byte[96]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getADDL__CHARGE__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }   
   public java.lang.String getADDL__CHARGE__DESC__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,65,9,0,20,false,false,false,-19,0,"X(20)",false,true);
   }   
   public java.lang.String getADDL__CHARGE__UM__ABBR__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }   
   public double getADDL__CHRG__AMT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,31,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
   }   
   public double getADL__CHRG__QTY__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,18,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
   }   
   public java.lang.String getCURRENCY__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }   
   public java.lang.String getEND__EFF__DATE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }   
   public java.lang.String getEXT__APP__CD__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,85,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }   
   public double getMAX__FRT__CHRG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,53,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
   }   
   public double getMINI__FRT__CHRG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,44,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
   }   
   public java.lang.String getQTY__UM__ABBR__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,27,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }   
   public java.lang.String getSTART__EFF__DATE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,8,false,false,false,-7,0,"X(8)",false,true);
   }   
   public double getTO__QTY__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,87,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("END__EFF__DATE__OUT",null,getEND__EFF__DATE__OUT());
		 firePropertyChange("ADDL__CHARGE__CODE__OUT",null,getADDL__CHARGE__CODE__OUT());
		 firePropertyChange("START__EFF__DATE__OUT",null,getSTART__EFF__DATE__OUT());
		 firePropertyChange("ADL__CHRG__QTY__OUT",null,getADL__CHRG__QTY__OUT());
		 firePropertyChange("QTY__UM__ABBR__OUT",null,getQTY__UM__ABBR__OUT());
		 firePropertyChange("ADDL__CHRG__AMT__OUT",null,getADDL__CHRG__AMT__OUT());
		 firePropertyChange("ADDL__CHARGE__UM__ABBR__OUT",null,getADDL__CHARGE__UM__ABBR__OUT());
		 firePropertyChange("MINI__FRT__CHRG__OUT",null,getMINI__FRT__CHRG__OUT());
		 firePropertyChange("MAX__FRT__CHRG__OUT",null,getMAX__FRT__CHRG__OUT());
		 firePropertyChange("CURRENCY__CODE__OUT",null,getCURRENCY__CODE__OUT());
		 firePropertyChange("ADDL__CHARGE__DESC__OUT",null,getADDL__CHARGE__DESC__OUT());
		 firePropertyChange("EXT__APP__CD__OUT",null,getEXT__APP__CD__OUT());
		 firePropertyChange("TO__QTY__OUT",null,getTO__QTY__OUT());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setADDL__CHARGE__CODE__OUT(java.lang.String aADDL__CHARGE__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldADDL__CHARGE__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,8,aADDL__CHARGE__CODE__OUT,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  firePropertyChange("ADDL__CHARGE__CODE__OUT",oldADDL__CHARGE__CODE__OUT,aADDL__CHARGE__CODE__OUT);
	  return;
   }   
   public void setADDL__CHARGE__DESC__OUT(java.lang.String aADDL__CHARGE__DESC__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldADDL__CHARGE__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,65,9,0,20,false,false,false,-19,0,"X(20)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,65,aADDL__CHARGE__DESC__OUT,9,0,20,false,false,false,-19,0,"X(20)",false,true);
	  firePropertyChange("ADDL__CHARGE__DESC__OUT",oldADDL__CHARGE__DESC__OUT,aADDL__CHARGE__DESC__OUT);
	  return;
   }   
   public void setADDL__CHARGE__UM__ABBR__OUT(java.lang.String aADDL__CHARGE__UM__ABBR__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldADDL__CHARGE__UM__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aADDL__CHARGE__UM__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  firePropertyChange("ADDL__CHARGE__UM__ABBR__OUT",oldADDL__CHARGE__UM__ABBR__OUT,aADDL__CHARGE__UM__ABBR__OUT);
	  return;
   }   
   public void setADDL__CHRG__AMT__OUT(double aADDL__CHRG__AMT__OUT)
	  throws RecordConversionFailureException {
	  double oldADDL__CHRG__AMT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,31,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,31,aADDL__CHRG__AMT__OUT,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  firePropertyChange("ADDL__CHRG__AMT__OUT",oldADDL__CHRG__AMT__OUT,aADDL__CHRG__AMT__OUT);
	  return;
   }   
   public void setADL__CHRG__QTY__OUT(double aADL__CHRG__QTY__OUT)
	  throws RecordConversionFailureException {
	  double oldADL__CHRG__QTY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,18,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,18,aADL__CHRG__QTY__OUT,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  firePropertyChange("ADL__CHRG__QTY__OUT",oldADL__CHRG__QTY__OUT,aADL__CHRG__QTY__OUT);
	  return;
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setCURRENCY__CODE__OUT(java.lang.String aCURRENCY__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCURRENCY__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,62,aCURRENCY__CODE__OUT,9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  firePropertyChange("CURRENCY__CODE__OUT",oldCURRENCY__CODE__OUT,aCURRENCY__CODE__OUT);
	  return;
   }   
   public void setEND__EFF__DATE__OUT(java.lang.String aEND__EFF__DATE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldEND__EFF__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aEND__EFF__DATE__OUT,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("END__EFF__DATE__OUT",oldEND__EFF__DATE__OUT,aEND__EFF__DATE__OUT);
	  return;
   }   
   public void setEXT__APP__CD__OUT(java.lang.String aEXT__APP__CD__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldEXT__APP__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,85,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,85,aEXT__APP__CD__OUT,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  firePropertyChange("EXT__APP__CD__OUT",oldEXT__APP__CD__OUT,aEXT__APP__CD__OUT);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,8, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,27, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,62, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,65, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,20,false,false,false,-19,0,"X(20)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,85, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  return;
   }   
   public void setMAX__FRT__CHRG__OUT(double aMAX__FRT__CHRG__OUT)
	  throws RecordConversionFailureException {
	  double oldMAX__FRT__CHRG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,53,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,53,aMAX__FRT__CHRG__OUT,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  firePropertyChange("MAX__FRT__CHRG__OUT",oldMAX__FRT__CHRG__OUT,aMAX__FRT__CHRG__OUT);
	  return;
   }   
   public void setMINI__FRT__CHRG__OUT(double aMINI__FRT__CHRG__OUT)
	  throws RecordConversionFailureException {
	  double oldMINI__FRT__CHRG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,44,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,44,aMINI__FRT__CHRG__OUT,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  firePropertyChange("MINI__FRT__CHRG__OUT",oldMINI__FRT__CHRG__OUT,aMINI__FRT__CHRG__OUT);
	  return;
   }   
   public void setQTY__UM__ABBR__OUT(java.lang.String aQTY__UM__ABBR__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldQTY__UM__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,27,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,27,aQTY__UM__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  firePropertyChange("QTY__UM__ABBR__OUT",oldQTY__UM__ABBR__OUT,aQTY__UM__ABBR__OUT);
	  return;
   }   
   public void setSTART__EFF__DATE__OUT(java.lang.String aSTART__EFF__DATE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldSTART__EFF__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aSTART__EFF__DATE__OUT,9,0,8,false,false,false,-7,0,"X(8)",false,true);
	  firePropertyChange("START__EFF__DATE__OUT",oldSTART__EFF__DATE__OUT,aSTART__EFF__DATE__OUT);
	  return;
   }   
   public void setTO__QTY__OUT(double aTO__QTY__OUT)
	  throws RecordConversionFailureException {
	  double oldTO__QTY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,87,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,87,aTO__QTY__OUT,8,9,9,false,true,true,-3,0,"9(6)V9(3)",false,false);
	  firePropertyChange("TO__QTY__OUT",oldTO__QTY__OUT,aTO__QTY__OUT);
	  return;
   }   
}
