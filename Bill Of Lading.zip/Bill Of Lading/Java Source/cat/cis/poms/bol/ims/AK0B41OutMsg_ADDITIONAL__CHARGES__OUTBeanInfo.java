package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B41OutMsg_ADDITIONAL__CHARGES__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getADDL__CHARGE__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ADDL__CHARGE__CODE__OUT", Class.forName(getBeanClassName()), "getADDL__CHARGE__CODE__OUT", "setADDL__CHARGE__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADDL__CHARGE__CODE__OUT");
	  aDescriptor.setDisplayName("ADDL__CHARGE__CODE__OUT");
	  aDescriptor.setShortDescription("ADDL__CHARGE__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getADDL__CHARGE__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ADDL__CHARGE__DESC__OUT", Class.forName(getBeanClassName()), "getADDL__CHARGE__DESC__OUT", "setADDL__CHARGE__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADDL__CHARGE__DESC__OUT");
	  aDescriptor.setDisplayName("ADDL__CHARGE__DESC__OUT");
	  aDescriptor.setShortDescription("ADDL__CHARGE__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getADDL__CHARGE__UM__ABBR__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ADDL__CHARGE__UM__ABBR__OUT", Class.forName(getBeanClassName()), "getADDL__CHARGE__UM__ABBR__OUT", "setADDL__CHARGE__UM__ABBR__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADDL__CHARGE__UM__ABBR__OUT");
	  aDescriptor.setDisplayName("ADDL__CHARGE__UM__ABBR__OUT");
	  aDescriptor.setShortDescription("ADDL__CHARGE__UM__ABBR__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getADDL__CHRG__AMT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ADDL__CHRG__AMT__OUT", Class.forName(getBeanClassName()), "getADDL__CHRG__AMT__OUT", "setADDL__CHRG__AMT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADDL__CHRG__AMT__OUT");
	  aDescriptor.setDisplayName("ADDL__CHRG__AMT__OUT");
	  aDescriptor.setShortDescription("ADDL__CHRG__AMT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getADL__CHRG__QTY__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ADL__CHRG__QTY__OUT", Class.forName(getBeanClassName()), "getADL__CHRG__QTY__OUT", "setADL__CHRG__QTY__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ADL__CHRG__QTY__OUT");
	  aDescriptor.setDisplayName("ADL__CHRG__QTY__OUT");
	  aDescriptor.setShortDescription("ADL__CHRG__QTY__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUT.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUT");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B41OutMsg_ADDITIONAL__CHARGES__OUT.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getCURRENCY__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("CURRENCY__CODE__OUT", Class.forName(getBeanClassName()), "getCURRENCY__CODE__OUT", "setCURRENCY__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("CURRENCY__CODE__OUT");
	  aDescriptor.setDisplayName("CURRENCY__CODE__OUT");
	  aDescriptor.setShortDescription("CURRENCY__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getEND__EFF__DATE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("END__EFF__DATE__OUT", Class.forName(getBeanClassName()), "getEND__EFF__DATE__OUT", "setEND__EFF__DATE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("END__EFF__DATE__OUT");
	  aDescriptor.setDisplayName("END__EFF__DATE__OUT");
	  aDescriptor.setShortDescription("END__EFF__DATE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getEXT__APP__CD__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("EXT__APP__CD__OUT", Class.forName(getBeanClassName()), "getEXT__APP__CD__OUT", "setEXT__APP__CD__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("EXT__APP__CD__OUT");
	  aDescriptor.setDisplayName("EXT__APP__CD__OUT");
	  aDescriptor.setShortDescription("EXT__APP__CD__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getMAX__FRT__CHRG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MAX__FRT__CHRG__OUT", Class.forName(getBeanClassName()), "getMAX__FRT__CHRG__OUT", "setMAX__FRT__CHRG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MAX__FRT__CHRG__OUT");
	  aDescriptor.setDisplayName("MAX__FRT__CHRG__OUT");
	  aDescriptor.setShortDescription("MAX__FRT__CHRG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getMINI__FRT__CHRG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MINI__FRT__CHRG__OUT", Class.forName(getBeanClassName()), "getMINI__FRT__CHRG__OUT", "setMINI__FRT__CHRG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MINI__FRT__CHRG__OUT");
	  aDescriptor.setDisplayName("MINI__FRT__CHRG__OUT");
	  aDescriptor.setShortDescription("MINI__FRT__CHRG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getEND__EFF__DATE__OUTPropertyDescriptor()
			,getADDL__CHARGE__CODE__OUTPropertyDescriptor()
			,getSTART__EFF__DATE__OUTPropertyDescriptor()
			,getADL__CHRG__QTY__OUTPropertyDescriptor()
			,getQTY__UM__ABBR__OUTPropertyDescriptor()
			,getADDL__CHRG__AMT__OUTPropertyDescriptor()
			,getADDL__CHARGE__UM__ABBR__OUTPropertyDescriptor()
			,getMINI__FRT__CHRG__OUTPropertyDescriptor()
			,getMAX__FRT__CHRG__OUTPropertyDescriptor()
			,getCURRENCY__CODE__OUTPropertyDescriptor()
			,getADDL__CHARGE__DESC__OUTPropertyDescriptor()
			,getEXT__APP__CD__OUTPropertyDescriptor()
			,getTO__QTY__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getQTY__UM__ABBR__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("QTY__UM__ABBR__OUT", Class.forName(getBeanClassName()), "getQTY__UM__ABBR__OUT", "setQTY__UM__ABBR__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("QTY__UM__ABBR__OUT");
	  aDescriptor.setDisplayName("QTY__UM__ABBR__OUT");
	  aDescriptor.setShortDescription("QTY__UM__ABBR__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getSTART__EFF__DATE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("START__EFF__DATE__OUT", Class.forName(getBeanClassName()), "getSTART__EFF__DATE__OUT", "setSTART__EFF__DATE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("START__EFF__DATE__OUT");
	  aDescriptor.setDisplayName("START__EFF__DATE__OUT");
	  aDescriptor.setShortDescription("START__EFF__DATE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getTO__QTY__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TO__QTY__OUT", Class.forName(getBeanClassName()), "getTO__QTY__OUT", "setTO__QTY__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TO__QTY__OUT");
	  aDescriptor.setDisplayName("TO__QTY__OUT");
	  aDescriptor.setShortDescription("TO__QTY__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
