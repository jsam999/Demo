package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUT
 * This is a generated file.  Do not edit.
 */

public class AK0B41OutMsg_WEIGHTS__RATES__OUT extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B41OutMsg_WEIGHTS__RATES__OUT()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUT.class,64));
		 this.setBytes(new byte[64]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getARR__REF__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getATT__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getBRKPT__WT__LMT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getCOMM__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }   
   public double getFRT__RATE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,47,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
   }   
   public java.lang.String getFRT__RATE__UM__ABBR__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,56,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }   
   public java.lang.String getFRT__UM__ABBR__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,60,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }   
   public java.lang.String getMINI__WT__LMT__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,33,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getMODEL__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,7,false,false,false,-6,0,"X(7)",false,true);
   }   
   public java.lang.String getPACK__TYPE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,17,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("COMM__CODE__OUT",null,getCOMM__CODE__OUT());
		 firePropertyChange("MODEL__NO__OUT",null,getMODEL__NO__OUT());
		 firePropertyChange("PACK__TYPE__OUT",null,getPACK__TYPE__OUT());
		 firePropertyChange("ATT__NO__OUT",null,getATT__NO__OUT());
		 firePropertyChange("ARR__REF__NO__OUT",null,getARR__REF__NO__OUT());
		 firePropertyChange("MINI__WT__LMT__OUT",null,getMINI__WT__LMT__OUT());
		 firePropertyChange("BRKPT__WT__LMT__OUT",null,getBRKPT__WT__LMT__OUT());
		 firePropertyChange("FRT__RATE__OUT",null,getFRT__RATE__OUT());
		 firePropertyChange("FRT__RATE__UM__ABBR__OUT",null,getFRT__RATE__UM__ABBR__OUT());
		 firePropertyChange("FRT__UM__ABBR__OUT",null,getFRT__UM__ABBR__OUT());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setARR__REF__NO__OUT(java.lang.String aARR__REF__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldARR__REF__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,26,aARR__REF__NO__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("ARR__REF__NO__OUT",oldARR__REF__NO__OUT,aARR__REF__NO__OUT);
	  return;
   }   
   public void setATT__NO__OUT(java.lang.String aATT__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldATT__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,19,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,19,aATT__NO__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("ATT__NO__OUT",oldATT__NO__OUT,aATT__NO__OUT);
	  return;
   }   
   public void setBRKPT__WT__LMT__OUT(java.lang.String aBRKPT__WT__LMT__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldBRKPT__WT__LMT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aBRKPT__WT__LMT__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("BRKPT__WT__LMT__OUT",oldBRKPT__WT__LMT__OUT,aBRKPT__WT__LMT__OUT);
	  return;
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setCOMM__CODE__OUT(java.lang.String aCOMM__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldCOMM__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aCOMM__CODE__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("COMM__CODE__OUT",oldCOMM__CODE__OUT,aCOMM__CODE__OUT);
	  return;
   }   
   public void setFRT__RATE__OUT(double aFRT__RATE__OUT)
	  throws RecordConversionFailureException {
	  double oldFRT__RATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,47,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,47,aFRT__RATE__OUT,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
	  firePropertyChange("FRT__RATE__OUT",oldFRT__RATE__OUT,aFRT__RATE__OUT);
	  return;
   }   
   public void setFRT__RATE__UM__ABBR__OUT(java.lang.String aFRT__RATE__UM__ABBR__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldFRT__RATE__UM__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,56,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,56,aFRT__RATE__UM__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  firePropertyChange("FRT__RATE__UM__ABBR__OUT",oldFRT__RATE__UM__ABBR__OUT,aFRT__RATE__UM__ABBR__OUT);
	  return;
   }   
   public void setFRT__UM__ABBR__OUT(java.lang.String aFRT__UM__ABBR__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldFRT__UM__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,60,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,60,aFRT__UM__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  firePropertyChange("FRT__UM__ABBR__OUT",oldFRT__UM__ABBR__OUT,aFRT__UM__ABBR__OUT);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,17, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,19, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,26, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,33, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,56, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,60, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
	  return;
   }   
   public void setMINI__WT__LMT__OUT(java.lang.String aMINI__WT__LMT__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldMINI__WT__LMT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,33,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,33,aMINI__WT__LMT__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("MINI__WT__LMT__OUT",oldMINI__WT__LMT__OUT,aMINI__WT__LMT__OUT);
	  return;
   }   
   public void setMODEL__NO__OUT(java.lang.String aMODEL__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldMODEL__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aMODEL__NO__OUT,9,0,7,false,false,false,-6,0,"X(7)",false,true);
	  firePropertyChange("MODEL__NO__OUT",oldMODEL__NO__OUT,aMODEL__NO__OUT);
	  return;
   }   
   public void setPACK__TYPE__OUT(java.lang.String aPACK__TYPE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldPACK__TYPE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,17,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,17,aPACK__TYPE__OUT,9,0,2,false,false,false,-1,0,"X(2)",false,true);
	  firePropertyChange("PACK__TYPE__OUT",oldPACK__TYPE__OUT,aPACK__TYPE__OUT);
	  return;
   }   
}
