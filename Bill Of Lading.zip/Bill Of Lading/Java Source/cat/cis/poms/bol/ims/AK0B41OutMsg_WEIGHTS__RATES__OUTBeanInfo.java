package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B41OutMsg_WEIGHTS__RATES__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getARR__REF__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ARR__REF__NO__OUT", Class.forName(getBeanClassName()), "getARR__REF__NO__OUT", "setARR__REF__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ARR__REF__NO__OUT");
	  aDescriptor.setDisplayName("ARR__REF__NO__OUT");
	  aDescriptor.setShortDescription("ARR__REF__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getATT__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ATT__NO__OUT", Class.forName(getBeanClassName()), "getATT__NO__OUT", "setATT__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ATT__NO__OUT");
	  aDescriptor.setDisplayName("ATT__NO__OUT");
	  aDescriptor.setShortDescription("ATT__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUT.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUT");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B41OutMsg_WEIGHTS__RATES__OUT.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getBRKPT__WT__LMT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BRKPT__WT__LMT__OUT", Class.forName(getBeanClassName()), "getBRKPT__WT__LMT__OUT", "setBRKPT__WT__LMT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BRKPT__WT__LMT__OUT");
	  aDescriptor.setDisplayName("BRKPT__WT__LMT__OUT");
	  aDescriptor.setShortDescription("BRKPT__WT__LMT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getCOMM__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("COMM__CODE__OUT", Class.forName(getBeanClassName()), "getCOMM__CODE__OUT", "setCOMM__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("COMM__CODE__OUT");
	  aDescriptor.setDisplayName("COMM__CODE__OUT");
	  aDescriptor.setShortDescription("COMM__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getFRT__RATE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__OUT", Class.forName(getBeanClassName()), "getFRT__RATE__OUT", "setFRT__RATE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("FRT__RATE__OUT");
	  aDescriptor.setDisplayName("FRT__RATE__OUT");
	  aDescriptor.setShortDescription("FRT__RATE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getFRT__RATE__UM__ABBR__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("FRT__RATE__UM__ABBR__OUT", Class.forName(getBeanClassName()), "getFRT__RATE__UM__ABBR__OUT", "setFRT__RATE__UM__ABBR__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("FRT__RATE__UM__ABBR__OUT");
	  aDescriptor.setDisplayName("FRT__RATE__UM__ABBR__OUT");
	  aDescriptor.setShortDescription("FRT__RATE__UM__ABBR__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getFRT__UM__ABBR__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("FRT__UM__ABBR__OUT", Class.forName(getBeanClassName()), "getFRT__UM__ABBR__OUT", "setFRT__UM__ABBR__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("FRT__UM__ABBR__OUT");
	  aDescriptor.setDisplayName("FRT__UM__ABBR__OUT");
	  aDescriptor.setShortDescription("FRT__UM__ABBR__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getMINI__WT__LMT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MINI__WT__LMT__OUT", Class.forName(getBeanClassName()), "getMINI__WT__LMT__OUT", "setMINI__WT__LMT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MINI__WT__LMT__OUT");
	  aDescriptor.setDisplayName("MINI__WT__LMT__OUT");
	  aDescriptor.setShortDescription("MINI__WT__LMT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getMODEL__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("MODEL__NO__OUT", Class.forName(getBeanClassName()), "getMODEL__NO__OUT", "setMODEL__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("MODEL__NO__OUT");
	  aDescriptor.setDisplayName("MODEL__NO__OUT");
	  aDescriptor.setShortDescription("MODEL__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACK__TYPE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACK__TYPE__OUT", Class.forName(getBeanClassName()), "getPACK__TYPE__OUT", "setPACK__TYPE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACK__TYPE__OUT");
	  aDescriptor.setDisplayName("PACK__TYPE__OUT");
	  aDescriptor.setShortDescription("PACK__TYPE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getCOMM__CODE__OUTPropertyDescriptor()
			,getMODEL__NO__OUTPropertyDescriptor()
			,getPACK__TYPE__OUTPropertyDescriptor()
			,getATT__NO__OUTPropertyDescriptor()
			,getARR__REF__NO__OUTPropertyDescriptor()
			,getMINI__WT__LMT__OUTPropertyDescriptor()
			,getBRKPT__WT__LMT__OUTPropertyDescriptor()
			,getFRT__RATE__OUTPropertyDescriptor()
			,getFRT__RATE__UM__ABBR__OUTPropertyDescriptor()
			,getFRT__UM__ABBR__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
