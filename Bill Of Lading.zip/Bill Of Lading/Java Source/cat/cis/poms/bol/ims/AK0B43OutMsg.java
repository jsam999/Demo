package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: CatBolIMSConnectAK0B43.AK0B43OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B43OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B43OutMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B43OutMsg.class,314));
		 this.setBytes(new byte[314]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }            
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }      
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }      
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }      
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }      
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }      
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }      
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }      
   public java.lang.String[] getBLS__OUT()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 java.lang.String[] returnArray = new java.lang.String[25];
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 4 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,10,false,false,false,-9,0,"X(10)",false,true);
			returnArray[i0] = element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public java.lang.String getBLS__OUT(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 int offset = 4 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public java.lang.String getFill_0()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,261,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }      
   public short getLL__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("CatBolIMSConnectAK0B43.AK0B43OutMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }      
   public java.lang.String getMSO__ERR__MSG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,264,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }      
   public java.lang.String getMSO__NO__ERR__MSG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,254,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }      
   public short getZZ__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }      
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__OUT",null,getLL__OUT());
		 firePropertyChange("ZZ__OUT",null,getZZ__OUT());
		 firePropertyChange("BLS__OUT",null,getBLS__OUT());
		 firePropertyChange("MSO__NO__ERR__MSG__OUT",null,getMSO__NO__ERR__MSG__OUT());
		 firePropertyChange("fill_0",null,getFill_0());
		 firePropertyChange("MSO__ERR__MSG__OUT",null,getMSO__ERR__MSG__OUT());
	  }
   }      
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }      
   public void setBLS__OUT(java.lang.String[] aBLS__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 4 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aBLS__OUT[i0],9,0,10,false,false,false,-9,0,"X(10)",false,true);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public void setBLS__OUT(int index, java.lang.String aBLS__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 int offset = 4 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aBLS__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }      
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }      
   public void setFill_0(java.lang.String aFill_0)
	  throws RecordConversionFailureException {
	  java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,261,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,261,aFill_0,9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  firePropertyChange("fill_0",oldFill_0,aFill_0);
	  return;
   }      
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,14, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,24, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,34, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,44, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,54, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,64, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,74, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,84, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,94, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,104, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,114, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,124, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,134, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,144, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,154, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,164, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,174, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,184, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,194, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,204, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,214, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,224, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,234, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,244, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,254, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,261, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" - ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,264, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("                                                ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  return;
   }      
   public void setLL__OUT(short aLL__OUT)
	  throws RecordConversionFailureException {
	  short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
	  return;
   }      
   public void setMSO__ERR__MSG__OUT(java.lang.String aMSO__ERR__MSG__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldMSO__ERR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,264,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,264,aMSO__ERR__MSG__OUT,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  firePropertyChange("MSO__ERR__MSG__OUT",oldMSO__ERR__MSG__OUT,aMSO__ERR__MSG__OUT);
	  return;
   }      
   public void setMSO__NO__ERR__MSG__OUT(java.lang.String aMSO__NO__ERR__MSG__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldMSO__NO__ERR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,254,9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,254,aMSO__NO__ERR__MSG__OUT,9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  firePropertyChange("MSO__NO__ERR__MSG__OUT",oldMSO__NO__ERR__MSG__OUT,aMSO__NO__ERR__MSG__OUT);
	  return;
   }      
   public void setZZ__OUT(short aZZ__OUT)
	  throws RecordConversionFailureException {
	  short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
	  return;
   }      
}
