package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B43OutMsgInfo.java
// Generated from C:\706ob43.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B43OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B43OutMsgInfo_BLS__TABLE__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B43OutMsgInfo_BLS__TABLE__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 arraySize[0] = 25;
		 arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(10):DISPLAY")), "BLS__OUT", new CobolInitialValueObject(" ", null));
		 addField(arrField);

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B43OutMsgInfo_ERR__MSG__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B43OutMsgInfo_ERR__MSG__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(07):DISPLAY"), "MSO__NO__ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(03):DISPLAY"), "fill_0", new CobolInitialValueObject(" - ", null)));

		 addField(new Field(new CobolType("X(50):DISPLAY"), "MSO__ERR__MSG__OUT", new CobolInitialValueObject("                                                ", null)));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B43OutMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new NestedRecordField(new AK0B43OutMsgInfo_BLS__TABLE__OUT(), "BLS__TABLE__OUT"));

	  addField(new NestedRecordField(new AK0B43OutMsgInfo_ERR__MSG__OUT(), "ERR__MSG__OUT"));

   }      
}
