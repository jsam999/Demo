package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B46InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B46InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B46InMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B46InMsg.class,816));
         this.setBytes(new byte[816]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getADR__CITY__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,281,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getADR__COUNTRY__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,323,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,151,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getADR__NM__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,176,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__POSTAL__ZONE__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,313,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getADR__STATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,311,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__TXT__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,211,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__TXT__LN2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,246,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getBADGE__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getBLDG__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getBOL__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,32,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCARGO__DESC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,518,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getCARRIER__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,560,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }
   public java.lang.String getCARRIER__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,565,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getCLRN__LTR__FILE__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,113,9,0,15,false,false,false,-14,0,"X(15)",false,true);
   }
   public java.lang.String getCLRN__LTR__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,128,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCOMMITTED__DATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,481,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }
   public java.lang.String getCONSIGNEE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,138,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getCONTAINER__NO1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,58,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTAINER__NO2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,68,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTRACT__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,718,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }
   public java.lang.String getDEL__INST__LN1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,325,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,355,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN3__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,385,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN4__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,415,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN5__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,445,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__TO__LOC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,539,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }
   public java.lang.String getDESTINATION__CITY__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,104,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getDIM__UM__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,749,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public short getDIM__WT__LINE__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,746,8,3,3,false,false,true,-2,0,"9(03)",false,false);
   }
   public java.lang.String getDLR__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,144,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getDOCK__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getEQUIP__TYPE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,111,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getEXP__CARRIER__ABBR__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,632,9,0,15,false,false,false,-14,0,"X(15)",false,true);
   }
   public java.lang.String getEXP__CARRIER__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,626,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getEXPORT__TO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,497,9,0,20,false,false,false,-19,0,"X(20)",false,true);
   }
   public java.lang.String getFAC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getFill_0()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,708,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public int getGROSS__WT__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,768,8,7,7,false,false,true,-6,0,"9(07)",false,false);
   }
   public java.lang.String getHAZARDOUS__REF__CODE1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,812,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,813,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE3__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,814,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE4__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,815,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public int getHEIGHT__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,761,8,5,5,false,false,true,-4,0,"9(05)",false,false);
   }
   public java.lang.String getINLAND__FRT__CHRG__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,150,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getISSUE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,42,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public int getLENGTH__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,751,8,5,5,false,false,true,-4,0,"9(05)",false,false);
   }
   public short getLL__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public java.lang.String getLTL__IND__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,517,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.bol.ims.AK0B46InMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public int getNET__WT__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,775,8,7,7,false,false,true,-6,0,"9(07)",false,false);
   }
   public java.lang.String getORDER__ANALYST__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,536,9,0,3,false,false,false,-2,0,"XXX",false,true);
   }
   public java.lang.String getORIGIN__CITY__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,78,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getORIGIN__CITY__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getORIGIN__STATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,102,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getPACK__DESC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,782,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getPACKG__ID__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,802,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getPACKG__LIST__DESC__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,788,9,0,14,false,false,false,-13,0,"X(14)",false,true);
   }
   public java.lang.String getPIER__AIRPORT__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,647,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getPORT__OF__EXIT__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,595,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getPORT__OF__EXIT__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,601,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public short getQTY__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,743,8,3,3,false,false,true,-2,0,"9(3)",false,false);
   }
   public java.lang.String getRECORD__TYPE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getSAILING__DATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,702,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getSEAL__NO1__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,44,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getSEAL__NO2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,51,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getSHIP__VIA__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,110,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getSHIPPED__DATE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,489,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }
   public java.lang.String getSTCC__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,730,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public java.lang.String[] getSTOPOVER__LOC__IN()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         java.lang.String[] returnArray = new java.lang.String[4];
         int[] dim = {4};
         for(int i0=0;i0<4;i0++) {
            int offset = 544 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,4,false,false,false,-3,0,"X(4)",false,true);
            returnArray[i0] = element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSTOPOVER__LOC__IN(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         int offset = 544 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getTOTAL__WEIGHT__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,475,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getTRAN__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public java.lang.String getTRAN__TYPE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,739,9,0,1,false,false,false,0,0,"X(1)",false,true);
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		is increased from 7 to 9.
	*/

   public java.lang.String getUSER__ACF2__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getVEH__NO__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,740,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }
   public java.lang.String getVESSEL__NAME__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,677,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public int getWIDTH__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,756,8,5,5,false,false,true,-4,0,"9(05)",false,false);
   }
   public java.lang.String getWT__UM__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,766,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public short getZZ__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__IN",null,getLL__IN());
         firePropertyChange("ZZ__IN",null,getZZ__IN());
         firePropertyChange("TRAN__CODE__IN",null,getTRAN__CODE__IN());
         firePropertyChange("BADGE__NO__IN",null,getBADGE__NO__IN());
         firePropertyChange("USER__ACF2__IN",null,getUSER__ACF2__IN());
         firePropertyChange("RECORD__TYPE__IN",null,getRECORD__TYPE__IN());
         firePropertyChange("FAC__IN",null,getFAC__IN());
         firePropertyChange("BLDG__IN",null,getBLDG__IN());
         firePropertyChange("DOCK__IN",null,getDOCK__IN());
         firePropertyChange("BOL__NO__IN",null,getBOL__NO__IN());
         firePropertyChange("ISSUE__IN",null,getISSUE__IN());
         firePropertyChange("SEAL__NO1__IN",null,getSEAL__NO1__IN());
         firePropertyChange("SEAL__NO2__IN",null,getSEAL__NO2__IN());
         firePropertyChange("CONTAINER__NO1__IN",null,getCONTAINER__NO1__IN());
         firePropertyChange("CONTAINER__NO2__IN",null,getCONTAINER__NO2__IN());
         firePropertyChange("ORIGIN__CITY__CODE__IN",null,getORIGIN__CITY__CODE__IN());
         firePropertyChange("ORIGIN__CITY__NAME__IN",null,getORIGIN__CITY__NAME__IN());
         firePropertyChange("ORIGIN__STATE__IN",null,getORIGIN__STATE__IN());
         firePropertyChange("DESTINATION__CITY__CODE__IN",null,getDESTINATION__CITY__CODE__IN());
         firePropertyChange("SHIP__VIA__IN",null,getSHIP__VIA__IN());
         firePropertyChange("EQUIP__TYPE__IN",null,getEQUIP__TYPE__IN());
         firePropertyChange("CLRN__LTR__FILE__NO__IN",null,getCLRN__LTR__FILE__NO__IN());
         firePropertyChange("CLRN__LTR__NO__IN",null,getCLRN__LTR__NO__IN());
         firePropertyChange("CONSIGNEE__IN",null,getCONSIGNEE__IN());
         firePropertyChange("DLR__CODE__IN",null,getDLR__CODE__IN());
         firePropertyChange("INLAND__FRT__CHRG__CODE__IN",null,getINLAND__FRT__CHRG__CODE__IN());
         firePropertyChange("ADR__NAME__IN",null,getADR__NAME__IN());
         firePropertyChange("ADR__NM__LN1__IN",null,getADR__NM__LN1__IN());
         firePropertyChange("ADR__TXT__LN1__IN",null,getADR__TXT__LN1__IN());
         firePropertyChange("ADR__TXT__LN2__IN",null,getADR__TXT__LN2__IN());
         firePropertyChange("ADR__CITY__NAME__IN",null,getADR__CITY__NAME__IN());
         firePropertyChange("ADR__STATE__IN",null,getADR__STATE__IN());
         firePropertyChange("ADR__POSTAL__ZONE__CODE__IN",null,getADR__POSTAL__ZONE__CODE__IN());
         firePropertyChange("ADR__COUNTRY__IN",null,getADR__COUNTRY__IN());
         firePropertyChange("DEL__INST__LN1__IN",null,getDEL__INST__LN1__IN());
         firePropertyChange("DEL__INST__LN2__IN",null,getDEL__INST__LN2__IN());
         firePropertyChange("DEL__INST__LN3__IN",null,getDEL__INST__LN3__IN());
         firePropertyChange("DEL__INST__LN4__IN",null,getDEL__INST__LN4__IN());
         firePropertyChange("DEL__INST__LN5__IN",null,getDEL__INST__LN5__IN());
         firePropertyChange("TOTAL__WEIGHT__IN",null,getTOTAL__WEIGHT__IN());
         firePropertyChange("COMMITTED__DATE__IN",null,getCOMMITTED__DATE__IN());
         firePropertyChange("SHIPPED__DATE__IN",null,getSHIPPED__DATE__IN());
         firePropertyChange("EXPORT__TO__IN",null,getEXPORT__TO__IN());
         firePropertyChange("LTL__IND__IN",null,getLTL__IND__IN());
         firePropertyChange("CARGO__DESC__IN",null,getCARGO__DESC__IN());
         firePropertyChange("ORDER__ANALYST__IN",null,getORDER__ANALYST__IN());
         firePropertyChange("DEL__TO__LOC__IN",null,getDEL__TO__LOC__IN());
         firePropertyChange("STOPOVER__LOC__IN",null,getSTOPOVER__LOC__IN());
         firePropertyChange("CARRIER__CODE__IN",null,getCARRIER__CODE__IN());
         firePropertyChange("CARRIER__NAME__IN",null,getCARRIER__NAME__IN());
         firePropertyChange("PORT__OF__EXIT__CODE__IN",null,getPORT__OF__EXIT__CODE__IN());
         firePropertyChange("PORT__OF__EXIT__NAME__IN",null,getPORT__OF__EXIT__NAME__IN());
         firePropertyChange("EXP__CARRIER__CODE__IN",null,getEXP__CARRIER__CODE__IN());
         firePropertyChange("EXP__CARRIER__ABBR__NAME__IN",null,getEXP__CARRIER__ABBR__NAME__IN());
         firePropertyChange("PIER__AIRPORT__NAME__IN",null,getPIER__AIRPORT__NAME__IN());
         firePropertyChange("VESSEL__NAME__IN",null,getVESSEL__NAME__IN());
         firePropertyChange("SAILING__DATE__IN",null,getSAILING__DATE__IN());
         firePropertyChange("fill_0",null,getFill_0());
         firePropertyChange("CONTRACT__NO__IN",null,getCONTRACT__NO__IN());
         firePropertyChange("STCC__CODE__IN",null,getSTCC__CODE__IN());
         firePropertyChange("TRAN__TYPE__IN",null,getTRAN__TYPE__IN());
         firePropertyChange("VEH__NO__IN",null,getVEH__NO__IN());
         firePropertyChange("QTY__IN",null,getQTY__IN());
         firePropertyChange("DIM__WT__LINE__NO__IN",null,getDIM__WT__LINE__NO__IN());
         firePropertyChange("DIM__UM__IN",null,getDIM__UM__IN());
         firePropertyChange("LENGTH__IN",null,getLENGTH__IN());
         firePropertyChange("WIDTH__IN",null,getWIDTH__IN());
         firePropertyChange("HEIGHT__IN",null,getHEIGHT__IN());
         firePropertyChange("WT__UM__IN",null,getWT__UM__IN());
         firePropertyChange("GROSS__WT__IN",null,getGROSS__WT__IN());
         firePropertyChange("NET__WT__IN",null,getNET__WT__IN());
         firePropertyChange("PACK__DESC__IN",null,getPACK__DESC__IN());
         firePropertyChange("PACKG__LIST__DESC__IN",null,getPACKG__LIST__DESC__IN());
         firePropertyChange("PACKG__ID__IN",null,getPACKG__ID__IN());
         firePropertyChange("HAZARDOUS__REF__CODE1__IN",null,getHAZARDOUS__REF__CODE1__IN());
         firePropertyChange("HAZARDOUS__REF__CODE2__IN",null,getHAZARDOUS__REF__CODE2__IN());
         firePropertyChange("HAZARDOUS__REF__CODE3__IN",null,getHAZARDOUS__REF__CODE3__IN());
         firePropertyChange("HAZARDOUS__REF__CODE4__IN",null,getHAZARDOUS__REF__CODE4__IN());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setADR__CITY__NAME__IN(java.lang.String aADR__CITY__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__CITY__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,281,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,281,aADR__CITY__NAME__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ADR__CITY__NAME__IN",oldADR__CITY__NAME__IN,aADR__CITY__NAME__IN);
      return;
   }
   public void setADR__COUNTRY__IN(java.lang.String aADR__COUNTRY__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__COUNTRY__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,323,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,323,aADR__COUNTRY__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__COUNTRY__IN",oldADR__COUNTRY__IN,aADR__COUNTRY__IN);
      return;
   }
   public void setADR__NAME__IN(java.lang.String aADR__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,151,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,151,aADR__NAME__IN,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("ADR__NAME__IN",oldADR__NAME__IN,aADR__NAME__IN);
      return;
   }
   public void setADR__NM__LN1__IN(java.lang.String aADR__NM__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NM__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,176,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,176,aADR__NM__LN1__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__NM__LN1__IN",oldADR__NM__LN1__IN,aADR__NM__LN1__IN);
      return;
   }
   public void setADR__POSTAL__ZONE__CODE__IN(java.lang.String aADR__POSTAL__ZONE__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__POSTAL__ZONE__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,313,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,313,aADR__POSTAL__ZONE__CODE__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("ADR__POSTAL__ZONE__CODE__IN",oldADR__POSTAL__ZONE__CODE__IN,aADR__POSTAL__ZONE__CODE__IN);
      return;
   }
   public void setADR__STATE__IN(java.lang.String aADR__STATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__STATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,311,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,311,aADR__STATE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__STATE__IN",oldADR__STATE__IN,aADR__STATE__IN);
      return;
   }
   public void setADR__TXT__LN1__IN(java.lang.String aADR__TXT__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,211,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,211,aADR__TXT__LN1__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN1__IN",oldADR__TXT__LN1__IN,aADR__TXT__LN1__IN);
      return;
   }
   public void setADR__TXT__LN2__IN(java.lang.String aADR__TXT__LN2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,246,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,246,aADR__TXT__LN2__IN,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN2__IN",oldADR__TXT__LN2__IN,aADR__TXT__LN2__IN);
      return;
   }
   public void setBADGE__NO__IN(java.lang.String aBADGE__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBADGE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aBADGE__NO__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("BADGE__NO__IN",oldBADGE__NO__IN,aBADGE__NO__IN);
      return;
   }
   public void setBLDG__IN(java.lang.String aBLDG__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBLDG__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,28,aBLDG__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("BLDG__IN",oldBLDG__IN,aBLDG__IN);
      return;
   }
   public void setBOL__NO__IN(java.lang.String aBOL__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldBOL__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,32,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,32,aBOL__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("BOL__NO__IN",oldBOL__NO__IN,aBOL__NO__IN);
      return;
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setCARGO__DESC__IN(java.lang.String aCARGO__DESC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCARGO__DESC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,518,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,518,aCARGO__DESC__IN,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("CARGO__DESC__IN",oldCARGO__DESC__IN,aCARGO__DESC__IN);
      return;
   }
   public void setCARRIER__CODE__IN(java.lang.String aCARRIER__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCARRIER__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,560,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,560,aCARRIER__CODE__IN,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      firePropertyChange("CARRIER__CODE__IN",oldCARRIER__CODE__IN,aCARRIER__CODE__IN);
      return;
   }
   public void setCARRIER__NAME__IN(java.lang.String aCARRIER__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCARRIER__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,565,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,565,aCARRIER__NAME__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("CARRIER__NAME__IN",oldCARRIER__NAME__IN,aCARRIER__NAME__IN);
      return;
   }
   public void setCLRN__LTR__FILE__NO__IN(java.lang.String aCLRN__LTR__FILE__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__FILE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,113,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,113,aCLRN__LTR__FILE__NO__IN,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      firePropertyChange("CLRN__LTR__FILE__NO__IN",oldCLRN__LTR__FILE__NO__IN,aCLRN__LTR__FILE__NO__IN);
      return;
   }
   public void setCLRN__LTR__NO__IN(java.lang.String aCLRN__LTR__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,128,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,128,aCLRN__LTR__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CLRN__LTR__NO__IN",oldCLRN__LTR__NO__IN,aCLRN__LTR__NO__IN);
      return;
   }
   public void setCOMMITTED__DATE__IN(java.lang.String aCOMMITTED__DATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCOMMITTED__DATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,481,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,481,aCOMMITTED__DATE__IN,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      firePropertyChange("COMMITTED__DATE__IN",oldCOMMITTED__DATE__IN,aCOMMITTED__DATE__IN);
      return;
   }
   public void setCONSIGNEE__IN(java.lang.String aCONSIGNEE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONSIGNEE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,138,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,138,aCONSIGNEE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("CONSIGNEE__IN",oldCONSIGNEE__IN,aCONSIGNEE__IN);
      return;
   }
   public void setCONTAINER__NO1__IN(java.lang.String aCONTAINER__NO1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NO1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,58,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,58,aCONTAINER__NO1__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NO1__IN",oldCONTAINER__NO1__IN,aCONTAINER__NO1__IN);
      return;
   }
   public void setCONTAINER__NO2__IN(java.lang.String aCONTAINER__NO2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NO2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,68,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,68,aCONTAINER__NO2__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NO2__IN",oldCONTAINER__NO2__IN,aCONTAINER__NO2__IN);
      return;
   }
   public void setCONTRACT__NO__IN(java.lang.String aCONTRACT__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldCONTRACT__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,718,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,718,aCONTRACT__NO__IN,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      firePropertyChange("CONTRACT__NO__IN",oldCONTRACT__NO__IN,aCONTRACT__NO__IN);
      return;
   }
   public void setDEL__INST__LN1__IN(java.lang.String aDEL__INST__LN1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,325,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,325,aDEL__INST__LN1__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN1__IN",oldDEL__INST__LN1__IN,aDEL__INST__LN1__IN);
      return;
   }
   public void setDEL__INST__LN2__IN(java.lang.String aDEL__INST__LN2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,355,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,355,aDEL__INST__LN2__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN2__IN",oldDEL__INST__LN2__IN,aDEL__INST__LN2__IN);
      return;
   }
   public void setDEL__INST__LN3__IN(java.lang.String aDEL__INST__LN3__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN3__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,385,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,385,aDEL__INST__LN3__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN3__IN",oldDEL__INST__LN3__IN,aDEL__INST__LN3__IN);
      return;
   }
   public void setDEL__INST__LN4__IN(java.lang.String aDEL__INST__LN4__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN4__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,415,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,415,aDEL__INST__LN4__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN4__IN",oldDEL__INST__LN4__IN,aDEL__INST__LN4__IN);
      return;
   }
   public void setDEL__INST__LN5__IN(java.lang.String aDEL__INST__LN5__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN5__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,445,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,445,aDEL__INST__LN5__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN5__IN",oldDEL__INST__LN5__IN,aDEL__INST__LN5__IN);
      return;
   }
   public void setDEL__TO__LOC__IN(java.lang.String aDEL__TO__LOC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__TO__LOC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,539,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,539,aDEL__TO__LOC__IN,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      firePropertyChange("DEL__TO__LOC__IN",oldDEL__TO__LOC__IN,aDEL__TO__LOC__IN);
      return;
   }
   public void setDESTINATION__CITY__CODE__IN(java.lang.String aDESTINATION__CITY__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDESTINATION__CITY__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,104,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,104,aDESTINATION__CITY__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("DESTINATION__CITY__CODE__IN",oldDESTINATION__CITY__CODE__IN,aDESTINATION__CITY__CODE__IN);
      return;
   }
   public void setDIM__UM__IN(java.lang.String aDIM__UM__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDIM__UM__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,749,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,749,aDIM__UM__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("DIM__UM__IN",oldDIM__UM__IN,aDIM__UM__IN);
      return;
   }
   public void setDIM__WT__LINE__NO__IN(short aDIM__WT__LINE__NO__IN)
      throws RecordConversionFailureException {
      short oldDIM__WT__LINE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,746,8,3,3,false,false,true,-2,0,"9(03)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,746,aDIM__WT__LINE__NO__IN,8,3,3,false,false,true,-2,0,"9(03)",false,false);
      firePropertyChange("DIM__WT__LINE__NO__IN",oldDIM__WT__LINE__NO__IN,aDIM__WT__LINE__NO__IN);
      return;
   }
   public void setDLR__CODE__IN(java.lang.String aDLR__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDLR__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,144,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,144,aDLR__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("DLR__CODE__IN",oldDLR__CODE__IN,aDLR__CODE__IN);
      return;
   }
   public void setDOCK__IN(java.lang.String aDOCK__IN)
      throws RecordConversionFailureException {
      java.lang.String oldDOCK__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,30,aDOCK__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("DOCK__IN",oldDOCK__IN,aDOCK__IN);
      return;
   }
   public void setEQUIP__TYPE__IN(java.lang.String aEQUIP__TYPE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldEQUIP__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,111,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,111,aEQUIP__TYPE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("EQUIP__TYPE__IN",oldEQUIP__TYPE__IN,aEQUIP__TYPE__IN);
      return;
   }
   public void setEXP__CARRIER__ABBR__NAME__IN(java.lang.String aEXP__CARRIER__ABBR__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldEXP__CARRIER__ABBR__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,632,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,632,aEXP__CARRIER__ABBR__NAME__IN,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      firePropertyChange("EXP__CARRIER__ABBR__NAME__IN",oldEXP__CARRIER__ABBR__NAME__IN,aEXP__CARRIER__ABBR__NAME__IN);
      return;
   }
   public void setEXP__CARRIER__CODE__IN(java.lang.String aEXP__CARRIER__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldEXP__CARRIER__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,626,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,626,aEXP__CARRIER__CODE__IN,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("EXP__CARRIER__CODE__IN",oldEXP__CARRIER__CODE__IN,aEXP__CARRIER__CODE__IN);
      return;
   }
   public void setEXPORT__TO__IN(java.lang.String aEXPORT__TO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldEXPORT__TO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,497,9,0,20,false,false,false,-19,0,"X(20)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,497,aEXPORT__TO__IN,9,0,20,false,false,false,-19,0,"X(20)",false,true);
      firePropertyChange("EXPORT__TO__IN",oldEXPORT__TO__IN,aEXPORT__TO__IN);
      return;
   }
   public void setFAC__IN(java.lang.String aFAC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldFAC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,26,aFAC__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("FAC__IN",oldFAC__IN,aFAC__IN);
      return;
   }
   public void setFill_0(java.lang.String aFill_0)
      throws RecordConversionFailureException {
      java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,708,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,708,aFill_0,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("fill_0",oldFill_0,aFill_0);
      return;
   }
   public void setGROSS__WT__IN(int aGROSS__WT__IN)
      throws RecordConversionFailureException {
      int oldGROSS__WT__IN = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,768,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,768,aGROSS__WT__IN,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      firePropertyChange("GROSS__WT__IN",oldGROSS__WT__IN,aGROSS__WT__IN);
      return;
   }
   public void setHAZARDOUS__REF__CODE1__IN(java.lang.String aHAZARDOUS__REF__CODE1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,812,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,812,aHAZARDOUS__REF__CODE1__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE1__IN",oldHAZARDOUS__REF__CODE1__IN,aHAZARDOUS__REF__CODE1__IN);
      return;
   }
   public void setHAZARDOUS__REF__CODE2__IN(java.lang.String aHAZARDOUS__REF__CODE2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,813,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,813,aHAZARDOUS__REF__CODE2__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE2__IN",oldHAZARDOUS__REF__CODE2__IN,aHAZARDOUS__REF__CODE2__IN);
      return;
   }
   public void setHAZARDOUS__REF__CODE3__IN(java.lang.String aHAZARDOUS__REF__CODE3__IN)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE3__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,814,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,814,aHAZARDOUS__REF__CODE3__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE3__IN",oldHAZARDOUS__REF__CODE3__IN,aHAZARDOUS__REF__CODE3__IN);
      return;
   }
   public void setHAZARDOUS__REF__CODE4__IN(java.lang.String aHAZARDOUS__REF__CODE4__IN)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE4__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,815,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,815,aHAZARDOUS__REF__CODE4__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE4__IN",oldHAZARDOUS__REF__CODE4__IN,aHAZARDOUS__REF__CODE4__IN);
      return;
   }
   public void setHEIGHT__IN(int aHEIGHT__IN)
      throws RecordConversionFailureException {
      int oldHEIGHT__IN = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,761,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,761,aHEIGHT__IN,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      firePropertyChange("HEIGHT__IN",oldHEIGHT__IN,aHEIGHT__IN);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,18, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,26, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,28, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,30, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,32, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,42, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,44, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,51, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,58, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,68, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,78, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,84, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,102, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,104, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,110, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,111, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,113, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,128, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,138, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,144, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,150, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,151, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,176, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,211, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,246, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,281, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,311, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,313, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,323, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,325, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,355, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,385, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,415, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,445, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,475, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,481, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,489, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,497, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,20,false,false,false,-19,0,"X(20)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,517, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,518, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,536, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"XXX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,539, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,544, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,548, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,552, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,556, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,560, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,565, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,595, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,601, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,626, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,632, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,647, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,677, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,702, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,708, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,718, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,730, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,739, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(1)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,740, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,749, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,766, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,782, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,788, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,14,false,false,false,-13,0,"X(14)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,802, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,812, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,813, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,814, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,815, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      return;
   }
   public void setINLAND__FRT__CHRG__CODE__IN(java.lang.String aINLAND__FRT__CHRG__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldINLAND__FRT__CHRG__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,150,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,150,aINLAND__FRT__CHRG__CODE__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("INLAND__FRT__CHRG__CODE__IN",oldINLAND__FRT__CHRG__CODE__IN,aINLAND__FRT__CHRG__CODE__IN);
      return;
   }
   public void setISSUE__IN(java.lang.String aISSUE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldISSUE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,42,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,42,aISSUE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ISSUE__IN",oldISSUE__IN,aISSUE__IN);
      return;
   }
   public void setLENGTH__IN(int aLENGTH__IN)
      throws RecordConversionFailureException {
      int oldLENGTH__IN = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,751,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,751,aLENGTH__IN,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      firePropertyChange("LENGTH__IN",oldLENGTH__IN,aLENGTH__IN);
      return;
   }
   public void setLL__IN(short aLL__IN)
      throws RecordConversionFailureException {
      short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
      return;
   }
   public void setLTL__IND__IN(java.lang.String aLTL__IND__IN)
      throws RecordConversionFailureException {
      java.lang.String oldLTL__IND__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,517,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,517,aLTL__IND__IN,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("LTL__IND__IN",oldLTL__IND__IN,aLTL__IND__IN);
      return;
   }
   public void setNET__WT__IN(int aNET__WT__IN)
      throws RecordConversionFailureException {
      int oldNET__WT__IN = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,775,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,775,aNET__WT__IN,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      firePropertyChange("NET__WT__IN",oldNET__WT__IN,aNET__WT__IN);
      return;
   }
   public void setORDER__ANALYST__IN(java.lang.String aORDER__ANALYST__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORDER__ANALYST__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,536,9,0,3,false,false,false,-2,0,"XXX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,536,aORDER__ANALYST__IN,9,0,3,false,false,false,-2,0,"XXX",false,true);
      firePropertyChange("ORDER__ANALYST__IN",oldORDER__ANALYST__IN,aORDER__ANALYST__IN);
      return;
   }
   public void setORIGIN__CITY__CODE__IN(java.lang.String aORIGIN__CITY__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,78,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,78,aORIGIN__CITY__CODE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("ORIGIN__CITY__CODE__IN",oldORIGIN__CITY__CODE__IN,aORIGIN__CITY__CODE__IN);
      return;
   }
   public void setORIGIN__CITY__NAME__IN(java.lang.String aORIGIN__CITY__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,84,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,84,aORIGIN__CITY__NAME__IN,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("ORIGIN__CITY__NAME__IN",oldORIGIN__CITY__NAME__IN,aORIGIN__CITY__NAME__IN);
      return;
   }
   public void setORIGIN__STATE__IN(java.lang.String aORIGIN__STATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__STATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,102,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,102,aORIGIN__STATE__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ORIGIN__STATE__IN",oldORIGIN__STATE__IN,aORIGIN__STATE__IN);
      return;
   }
   public void setPACK__DESC__IN(java.lang.String aPACK__DESC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPACK__DESC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,782,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,782,aPACK__DESC__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("PACK__DESC__IN",oldPACK__DESC__IN,aPACK__DESC__IN);
      return;
   }
   public void setPACKG__ID__IN(java.lang.String aPACKG__ID__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPACKG__ID__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,802,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,802,aPACKG__ID__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("PACKG__ID__IN",oldPACKG__ID__IN,aPACKG__ID__IN);
      return;
   }
   public void setPACKG__LIST__DESC__IN(java.lang.String aPACKG__LIST__DESC__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPACKG__LIST__DESC__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,788,9,0,14,false,false,false,-13,0,"X(14)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,788,aPACKG__LIST__DESC__IN,9,0,14,false,false,false,-13,0,"X(14)",false,true);
      firePropertyChange("PACKG__LIST__DESC__IN",oldPACKG__LIST__DESC__IN,aPACKG__LIST__DESC__IN);
      return;
   }
   public void setPIER__AIRPORT__NAME__IN(java.lang.String aPIER__AIRPORT__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPIER__AIRPORT__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,647,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,647,aPIER__AIRPORT__NAME__IN,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("PIER__AIRPORT__NAME__IN",oldPIER__AIRPORT__NAME__IN,aPIER__AIRPORT__NAME__IN);
      return;
   }
   public void setPORT__OF__EXIT__CODE__IN(java.lang.String aPORT__OF__EXIT__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPORT__OF__EXIT__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,595,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,595,aPORT__OF__EXIT__CODE__IN,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("PORT__OF__EXIT__CODE__IN",oldPORT__OF__EXIT__CODE__IN,aPORT__OF__EXIT__CODE__IN);
      return;
   }
   public void setPORT__OF__EXIT__NAME__IN(java.lang.String aPORT__OF__EXIT__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldPORT__OF__EXIT__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,601,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,601,aPORT__OF__EXIT__NAME__IN,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("PORT__OF__EXIT__NAME__IN",oldPORT__OF__EXIT__NAME__IN,aPORT__OF__EXIT__NAME__IN);
      return;
   }
   public void setQTY__IN(short aQTY__IN)
      throws RecordConversionFailureException {
      short oldQTY__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,743,8,3,3,false,false,true,-2,0,"9(3)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,743,aQTY__IN,8,3,3,false,false,true,-2,0,"9(3)",false,false);
      firePropertyChange("QTY__IN",oldQTY__IN,aQTY__IN);
      return;
   }
   public void setRECORD__TYPE__IN(java.lang.String aRECORD__TYPE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldRECORD__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,25,aRECORD__TYPE__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("RECORD__TYPE__IN",oldRECORD__TYPE__IN,aRECORD__TYPE__IN);
      return;
   }
   public void setSAILING__DATE__IN(java.lang.String aSAILING__DATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSAILING__DATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,702,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,702,aSAILING__DATE__IN,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("SAILING__DATE__IN",oldSAILING__DATE__IN,aSAILING__DATE__IN);
      return;
   }
   public void setSEAL__NO1__IN(java.lang.String aSEAL__NO1__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO1__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,44,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,44,aSEAL__NO1__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO1__IN",oldSEAL__NO1__IN,aSEAL__NO1__IN);
      return;
   }
   public void setSEAL__NO2__IN(java.lang.String aSEAL__NO2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,51,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,51,aSEAL__NO2__IN,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO2__IN",oldSEAL__NO2__IN,aSEAL__NO2__IN);
      return;
   }
   public void setSHIP__VIA__IN(java.lang.String aSHIP__VIA__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSHIP__VIA__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,110,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,110,aSHIP__VIA__IN,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("SHIP__VIA__IN",oldSHIP__VIA__IN,aSHIP__VIA__IN);
      return;
   }
   public void setSHIPPED__DATE__IN(java.lang.String aSHIPPED__DATE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSHIPPED__DATE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,489,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,489,aSHIPPED__DATE__IN,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      firePropertyChange("SHIPPED__DATE__IN",oldSHIPPED__DATE__IN,aSHIPPED__DATE__IN);
      return;
   }
   public void setSTCC__CODE__IN(java.lang.String aSTCC__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSTCC__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,730,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,730,aSTCC__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("STCC__CODE__IN",oldSTCC__CODE__IN,aSTCC__CODE__IN);
      return;
   }
   public void setSTOPOVER__LOC__IN(java.lang.String[] aSTOPOVER__LOC__IN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         for(int i0=0;i0<4;i0++) {
            int offset = 544 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSTOPOVER__LOC__IN[i0],9,0,4,false,false,false,-3,0,"X(4)",false,true);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSTOPOVER__LOC__IN(int index, java.lang.String aSTOPOVER__LOC__IN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         int offset = 544 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSTOPOVER__LOC__IN,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setTOTAL__WEIGHT__IN(java.lang.String aTOTAL__WEIGHT__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTOTAL__WEIGHT__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,475,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,475,aTOTAL__WEIGHT__IN,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("TOTAL__WEIGHT__IN",oldTOTAL__WEIGHT__IN,aTOTAL__WEIGHT__IN);
      return;
   }
   public void setTRAN__CODE__IN(java.lang.String aTRAN__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("TRAN__CODE__IN",oldTRAN__CODE__IN,aTRAN__CODE__IN);
      return;
   }
   public void setTRAN__TYPE__IN(java.lang.String aTRAN__TYPE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__TYPE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,739,9,0,1,false,false,false,0,0,"X(1)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,739,aTRAN__TYPE__IN,9,0,1,false,false,false,0,0,"X(1)",false,true);
      firePropertyChange("TRAN__TYPE__IN",oldTRAN__TYPE__IN,aTRAN__TYPE__IN);
      return;
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setUSER__ACF2__IN(java.lang.String aUSER__ACF2__IN)
      throws RecordConversionFailureException {
      java.lang.String oldUSER__ACF2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,18,aUSER__ACF2__IN,9,0,9,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("USER__ACF2__IN",oldUSER__ACF2__IN,aUSER__ACF2__IN);
      return;
   }
   public void setVEH__NO__IN(java.lang.String aVEH__NO__IN)
      throws RecordConversionFailureException {
      java.lang.String oldVEH__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,740,9,0,3,false,false,false,-2,0,"X(3)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,740,aVEH__NO__IN,9,0,3,false,false,false,-2,0,"X(3)",false,true);
      firePropertyChange("VEH__NO__IN",oldVEH__NO__IN,aVEH__NO__IN);
      return;
   }
   public void setVESSEL__NAME__IN(java.lang.String aVESSEL__NAME__IN)
      throws RecordConversionFailureException {
      java.lang.String oldVESSEL__NAME__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,677,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,677,aVESSEL__NAME__IN,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("VESSEL__NAME__IN",oldVESSEL__NAME__IN,aVESSEL__NAME__IN);
      return;
   }
   public void setWIDTH__IN(int aWIDTH__IN)
      throws RecordConversionFailureException {
      int oldWIDTH__IN = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,756,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,756,aWIDTH__IN,8,5,5,false,false,true,-4,0,"9(05)",false,false);
      firePropertyChange("WIDTH__IN",oldWIDTH__IN,aWIDTH__IN);
      return;
   }
   public void setWT__UM__IN(java.lang.String aWT__UM__IN)
      throws RecordConversionFailureException {
      java.lang.String oldWT__UM__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,766,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,766,aWT__UM__IN,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("WT__UM__IN",oldWT__UM__IN,aWT__UM__IN);
      return;
   }
   public void setZZ__IN(short aZZ__IN)
      throws RecordConversionFailureException {
      short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
      return;
   }
}
