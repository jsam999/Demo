package cat.cis.poms.bol.ims;

/**
 * Class: cat.cis.poms.bol.ims.AK0B46InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B46InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public java.beans.PropertyDescriptor getADR__CITY__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__CITY__NAME__IN", Class.forName(getBeanClassName()), "getADR__CITY__NAME__IN", "setADR__CITY__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__CITY__NAME__IN");
      aDescriptor.setDisplayName("ADR__CITY__NAME__IN");
      aDescriptor.setShortDescription("ADR__CITY__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__COUNTRY__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__COUNTRY__IN", Class.forName(getBeanClassName()), "getADR__COUNTRY__IN", "setADR__COUNTRY__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__COUNTRY__IN");
      aDescriptor.setDisplayName("ADR__COUNTRY__IN");
      aDescriptor.setShortDescription("ADR__COUNTRY__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NAME__IN", Class.forName(getBeanClassName()), "getADR__NAME__IN", "setADR__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NAME__IN");
      aDescriptor.setDisplayName("ADR__NAME__IN");
      aDescriptor.setShortDescription("ADR__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NM__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NM__LN1__IN", Class.forName(getBeanClassName()), "getADR__NM__LN1__IN", "setADR__NM__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NM__LN1__IN");
      aDescriptor.setDisplayName("ADR__NM__LN1__IN");
      aDescriptor.setShortDescription("ADR__NM__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__POSTAL__ZONE__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__POSTAL__ZONE__CODE__IN", Class.forName(getBeanClassName()), "getADR__POSTAL__ZONE__CODE__IN", "setADR__POSTAL__ZONE__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setDisplayName("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setShortDescription("ADR__POSTAL__ZONE__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__STATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__STATE__IN", Class.forName(getBeanClassName()), "getADR__STATE__IN", "setADR__STATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__STATE__IN");
      aDescriptor.setDisplayName("ADR__STATE__IN");
      aDescriptor.setShortDescription("ADR__STATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN1__IN", Class.forName(getBeanClassName()), "getADR__TXT__LN1__IN", "setADR__TXT__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN1__IN");
      aDescriptor.setDisplayName("ADR__TXT__LN1__IN");
      aDescriptor.setShortDescription("ADR__TXT__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN2__IN", Class.forName(getBeanClassName()), "getADR__TXT__LN2__IN", "setADR__TXT__LN2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN2__IN");
      aDescriptor.setDisplayName("ADR__TXT__LN2__IN");
      aDescriptor.setShortDescription("ADR__TXT__LN2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBADGE__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BADGE__NO__IN", Class.forName(getBeanClassName()), "getBADGE__NO__IN", "setBADGE__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BADGE__NO__IN");
      aDescriptor.setDisplayName("BADGE__NO__IN");
      aDescriptor.setShortDescription("BADGE__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.bol.ims.AK0B46InMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.bol.ims.AK0B46InMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B46InMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBLDG__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BLDG__IN", Class.forName(getBeanClassName()), "getBLDG__IN", "setBLDG__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BLDG__IN");
      aDescriptor.setDisplayName("BLDG__IN");
      aDescriptor.setShortDescription("BLDG__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBOL__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BOL__NO__IN", Class.forName(getBeanClassName()), "getBOL__NO__IN", "setBOL__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BOL__NO__IN");
      aDescriptor.setDisplayName("BOL__NO__IN");
      aDescriptor.setShortDescription("BOL__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARGO__DESC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARGO__DESC__IN", Class.forName(getBeanClassName()), "getCARGO__DESC__IN", "setCARGO__DESC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARGO__DESC__IN");
      aDescriptor.setDisplayName("CARGO__DESC__IN");
      aDescriptor.setShortDescription("CARGO__DESC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARRIER__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARRIER__CODE__IN", Class.forName(getBeanClassName()), "getCARRIER__CODE__IN", "setCARRIER__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARRIER__CODE__IN");
      aDescriptor.setDisplayName("CARRIER__CODE__IN");
      aDescriptor.setShortDescription("CARRIER__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARRIER__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARRIER__NAME__IN", Class.forName(getBeanClassName()), "getCARRIER__NAME__IN", "setCARRIER__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARRIER__NAME__IN");
      aDescriptor.setDisplayName("CARRIER__NAME__IN");
      aDescriptor.setShortDescription("CARRIER__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__FILE__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__FILE__NO__IN", Class.forName(getBeanClassName()), "getCLRN__LTR__FILE__NO__IN", "setCLRN__LTR__FILE__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setDisplayName("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setShortDescription("CLRN__LTR__FILE__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__NO__IN", Class.forName(getBeanClassName()), "getCLRN__LTR__NO__IN", "setCLRN__LTR__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__NO__IN");
      aDescriptor.setDisplayName("CLRN__LTR__NO__IN");
      aDescriptor.setShortDescription("CLRN__LTR__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCOMMITTED__DATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("COMMITTED__DATE__IN", Class.forName(getBeanClassName()), "getCOMMITTED__DATE__IN", "setCOMMITTED__DATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("COMMITTED__DATE__IN");
      aDescriptor.setDisplayName("COMMITTED__DATE__IN");
      aDescriptor.setShortDescription("COMMITTED__DATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONSIGNEE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONSIGNEE__IN", Class.forName(getBeanClassName()), "getCONSIGNEE__IN", "setCONSIGNEE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONSIGNEE__IN");
      aDescriptor.setDisplayName("CONSIGNEE__IN");
      aDescriptor.setShortDescription("CONSIGNEE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NO1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NO1__IN", Class.forName(getBeanClassName()), "getCONTAINER__NO1__IN", "setCONTAINER__NO1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NO1__IN");
      aDescriptor.setDisplayName("CONTAINER__NO1__IN");
      aDescriptor.setShortDescription("CONTAINER__NO1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NO2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NO2__IN", Class.forName(getBeanClassName()), "getCONTAINER__NO2__IN", "setCONTAINER__NO2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NO2__IN");
      aDescriptor.setDisplayName("CONTAINER__NO2__IN");
      aDescriptor.setShortDescription("CONTAINER__NO2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTRACT__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTRACT__NO__IN", Class.forName(getBeanClassName()), "getCONTRACT__NO__IN", "setCONTRACT__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTRACT__NO__IN");
      aDescriptor.setDisplayName("CONTRACT__NO__IN");
      aDescriptor.setShortDescription("CONTRACT__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN1__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN1__IN", "setDEL__INST__LN1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN1__IN");
      aDescriptor.setDisplayName("DEL__INST__LN1__IN");
      aDescriptor.setShortDescription("DEL__INST__LN1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN2__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN2__IN", "setDEL__INST__LN2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN2__IN");
      aDescriptor.setDisplayName("DEL__INST__LN2__IN");
      aDescriptor.setShortDescription("DEL__INST__LN2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN3__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN3__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN3__IN", "setDEL__INST__LN3__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN3__IN");
      aDescriptor.setDisplayName("DEL__INST__LN3__IN");
      aDescriptor.setShortDescription("DEL__INST__LN3__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN4__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN4__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN4__IN", "setDEL__INST__LN4__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN4__IN");
      aDescriptor.setDisplayName("DEL__INST__LN4__IN");
      aDescriptor.setShortDescription("DEL__INST__LN4__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN5__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN5__IN", Class.forName(getBeanClassName()), "getDEL__INST__LN5__IN", "setDEL__INST__LN5__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN5__IN");
      aDescriptor.setDisplayName("DEL__INST__LN5__IN");
      aDescriptor.setShortDescription("DEL__INST__LN5__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__TO__LOC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__TO__LOC__IN", Class.forName(getBeanClassName()), "getDEL__TO__LOC__IN", "setDEL__TO__LOC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__TO__LOC__IN");
      aDescriptor.setDisplayName("DEL__TO__LOC__IN");
      aDescriptor.setShortDescription("DEL__TO__LOC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDESTINATION__CITY__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DESTINATION__CITY__CODE__IN", Class.forName(getBeanClassName()), "getDESTINATION__CITY__CODE__IN", "setDESTINATION__CITY__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DESTINATION__CITY__CODE__IN");
      aDescriptor.setDisplayName("DESTINATION__CITY__CODE__IN");
      aDescriptor.setShortDescription("DESTINATION__CITY__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDIM__UM__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DIM__UM__IN", Class.forName(getBeanClassName()), "getDIM__UM__IN", "setDIM__UM__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DIM__UM__IN");
      aDescriptor.setDisplayName("DIM__UM__IN");
      aDescriptor.setShortDescription("DIM__UM__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDIM__WT__LINE__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DIM__WT__LINE__NO__IN", Class.forName(getBeanClassName()), "getDIM__WT__LINE__NO__IN", "setDIM__WT__LINE__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DIM__WT__LINE__NO__IN");
      aDescriptor.setDisplayName("DIM__WT__LINE__NO__IN");
      aDescriptor.setShortDescription("DIM__WT__LINE__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDLR__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DLR__CODE__IN", Class.forName(getBeanClassName()), "getDLR__CODE__IN", "setDLR__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DLR__CODE__IN");
      aDescriptor.setDisplayName("DLR__CODE__IN");
      aDescriptor.setShortDescription("DLR__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDOCK__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DOCK__IN", Class.forName(getBeanClassName()), "getDOCK__IN", "setDOCK__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DOCK__IN");
      aDescriptor.setDisplayName("DOCK__IN");
      aDescriptor.setShortDescription("DOCK__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEQUIP__TYPE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EQUIP__TYPE__IN", Class.forName(getBeanClassName()), "getEQUIP__TYPE__IN", "setEQUIP__TYPE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EQUIP__TYPE__IN");
      aDescriptor.setDisplayName("EQUIP__TYPE__IN");
      aDescriptor.setShortDescription("EQUIP__TYPE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getEXP__CARRIER__ABBR__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXP__CARRIER__ABBR__NAME__IN", Class.forName(getBeanClassName()), "getEXP__CARRIER__ABBR__NAME__IN", "setEXP__CARRIER__ABBR__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXP__CARRIER__ABBR__NAME__IN");
      aDescriptor.setDisplayName("EXP__CARRIER__ABBR__NAME__IN");
      aDescriptor.setShortDescription("EXP__CARRIER__ABBR__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEXP__CARRIER__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXP__CARRIER__CODE__IN", Class.forName(getBeanClassName()), "getEXP__CARRIER__CODE__IN", "setEXP__CARRIER__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXP__CARRIER__CODE__IN");
      aDescriptor.setDisplayName("EXP__CARRIER__CODE__IN");
      aDescriptor.setShortDescription("EXP__CARRIER__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEXPORT__TO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXPORT__TO__IN", Class.forName(getBeanClassName()), "getEXPORT__TO__IN", "setEXPORT__TO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXPORT__TO__IN");
      aDescriptor.setDisplayName("EXPORT__TO__IN");
      aDescriptor.setShortDescription("EXPORT__TO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFAC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FAC__IN", Class.forName(getBeanClassName()), "getFAC__IN", "setFAC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FAC__IN");
      aDescriptor.setDisplayName("FAC__IN");
      aDescriptor.setShortDescription("FAC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_0");
      aDescriptor.setDisplayName("fill_0");
      aDescriptor.setShortDescription("fill_0");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getGROSS__WT__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("GROSS__WT__IN", Class.forName(getBeanClassName()), "getGROSS__WT__IN", "setGROSS__WT__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("GROSS__WT__IN");
      aDescriptor.setDisplayName("GROSS__WT__IN");
      aDescriptor.setShortDescription("GROSS__WT__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE1__IN", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE1__IN", "setHAZARDOUS__REF__CODE1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("HAZARDOUS__REF__CODE1__IN");
      aDescriptor.setDisplayName("HAZARDOUS__REF__CODE1__IN");
      aDescriptor.setShortDescription("HAZARDOUS__REF__CODE1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE2__IN", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE2__IN", "setHAZARDOUS__REF__CODE2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("HAZARDOUS__REF__CODE2__IN");
      aDescriptor.setDisplayName("HAZARDOUS__REF__CODE2__IN");
      aDescriptor.setShortDescription("HAZARDOUS__REF__CODE2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE3__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE3__IN", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE3__IN", "setHAZARDOUS__REF__CODE3__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("HAZARDOUS__REF__CODE3__IN");
      aDescriptor.setDisplayName("HAZARDOUS__REF__CODE3__IN");
      aDescriptor.setShortDescription("HAZARDOUS__REF__CODE3__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE4__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE4__IN", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE4__IN", "setHAZARDOUS__REF__CODE4__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("HAZARDOUS__REF__CODE4__IN");
      aDescriptor.setDisplayName("HAZARDOUS__REF__CODE4__IN");
      aDescriptor.setShortDescription("HAZARDOUS__REF__CODE4__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getHEIGHT__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("HEIGHT__IN", Class.forName(getBeanClassName()), "getHEIGHT__IN", "setHEIGHT__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("HEIGHT__IN");
      aDescriptor.setDisplayName("HEIGHT__IN");
      aDescriptor.setShortDescription("HEIGHT__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getINLAND__FRT__CHRG__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("INLAND__FRT__CHRG__CODE__IN", Class.forName(getBeanClassName()), "getINLAND__FRT__CHRG__CODE__IN", "setINLAND__FRT__CHRG__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setDisplayName("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setShortDescription("INLAND__FRT__CHRG__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getISSUE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ISSUE__IN", Class.forName(getBeanClassName()), "getISSUE__IN", "setISSUE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ISSUE__IN");
      aDescriptor.setDisplayName("ISSUE__IN");
      aDescriptor.setShortDescription("ISSUE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLENGTH__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LENGTH__IN", Class.forName(getBeanClassName()), "getLENGTH__IN", "setLENGTH__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LENGTH__IN");
      aDescriptor.setDisplayName("LENGTH__IN");
      aDescriptor.setShortDescription("LENGTH__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__IN");
      aDescriptor.setDisplayName("LL__IN");
      aDescriptor.setShortDescription("LL__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLTL__IND__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LTL__IND__IN", Class.forName(getBeanClassName()), "getLTL__IND__IN", "setLTL__IND__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LTL__IND__IN");
      aDescriptor.setDisplayName("LTL__IND__IN");
      aDescriptor.setShortDescription("LTL__IND__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getNET__WT__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("NET__WT__IN", Class.forName(getBeanClassName()), "getNET__WT__IN", "setNET__WT__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("NET__WT__IN");
      aDescriptor.setDisplayName("NET__WT__IN");
      aDescriptor.setShortDescription("NET__WT__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORDER__ANALYST__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORDER__ANALYST__IN", Class.forName(getBeanClassName()), "getORDER__ANALYST__IN", "setORDER__ANALYST__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORDER__ANALYST__IN");
      aDescriptor.setDisplayName("ORDER__ANALYST__IN");
      aDescriptor.setShortDescription("ORDER__ANALYST__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__CODE__IN", Class.forName(getBeanClassName()), "getORIGIN__CITY__CODE__IN", "setORIGIN__CITY__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__CODE__IN");
      aDescriptor.setDisplayName("ORIGIN__CITY__CODE__IN");
      aDescriptor.setShortDescription("ORIGIN__CITY__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__NAME__IN", Class.forName(getBeanClassName()), "getORIGIN__CITY__NAME__IN", "setORIGIN__CITY__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__NAME__IN");
      aDescriptor.setDisplayName("ORIGIN__CITY__NAME__IN");
      aDescriptor.setShortDescription("ORIGIN__CITY__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__STATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__STATE__IN", Class.forName(getBeanClassName()), "getORIGIN__STATE__IN", "setORIGIN__STATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__STATE__IN");
      aDescriptor.setDisplayName("ORIGIN__STATE__IN");
      aDescriptor.setShortDescription("ORIGIN__STATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPACK__DESC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PACK__DESC__IN", Class.forName(getBeanClassName()), "getPACK__DESC__IN", "setPACK__DESC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PACK__DESC__IN");
      aDescriptor.setDisplayName("PACK__DESC__IN");
      aDescriptor.setShortDescription("PACK__DESC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPACKG__ID__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PACKG__ID__IN", Class.forName(getBeanClassName()), "getPACKG__ID__IN", "setPACKG__ID__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PACKG__ID__IN");
      aDescriptor.setDisplayName("PACKG__ID__IN");
      aDescriptor.setShortDescription("PACKG__ID__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPACKG__LIST__DESC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PACKG__LIST__DESC__IN", Class.forName(getBeanClassName()), "getPACKG__LIST__DESC__IN", "setPACKG__LIST__DESC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PACKG__LIST__DESC__IN");
      aDescriptor.setDisplayName("PACKG__LIST__DESC__IN");
      aDescriptor.setShortDescription("PACKG__LIST__DESC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPIER__AIRPORT__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PIER__AIRPORT__NAME__IN", Class.forName(getBeanClassName()), "getPIER__AIRPORT__NAME__IN", "setPIER__AIRPORT__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PIER__AIRPORT__NAME__IN");
      aDescriptor.setDisplayName("PIER__AIRPORT__NAME__IN");
      aDescriptor.setShortDescription("PIER__AIRPORT__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPORT__OF__EXIT__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PORT__OF__EXIT__CODE__IN", Class.forName(getBeanClassName()), "getPORT__OF__EXIT__CODE__IN", "setPORT__OF__EXIT__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PORT__OF__EXIT__CODE__IN");
      aDescriptor.setDisplayName("PORT__OF__EXIT__CODE__IN");
      aDescriptor.setShortDescription("PORT__OF__EXIT__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPORT__OF__EXIT__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PORT__OF__EXIT__NAME__IN", Class.forName(getBeanClassName()), "getPORT__OF__EXIT__NAME__IN", "setPORT__OF__EXIT__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PORT__OF__EXIT__NAME__IN");
      aDescriptor.setDisplayName("PORT__OF__EXIT__NAME__IN");
      aDescriptor.setShortDescription("PORT__OF__EXIT__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__INPropertyDescriptor()
            ,getZZ__INPropertyDescriptor()
            ,getTRAN__CODE__INPropertyDescriptor()
            ,getBADGE__NO__INPropertyDescriptor()
            ,getUSER__ACF2__INPropertyDescriptor()
            ,getRECORD__TYPE__INPropertyDescriptor()
            ,getFAC__INPropertyDescriptor()
            ,getBLDG__INPropertyDescriptor()
            ,getDOCK__INPropertyDescriptor()
            ,getBOL__NO__INPropertyDescriptor()
            ,getISSUE__INPropertyDescriptor()
            ,getSEAL__NO1__INPropertyDescriptor()
            ,getSEAL__NO2__INPropertyDescriptor()
            ,getCONTAINER__NO1__INPropertyDescriptor()
            ,getCONTAINER__NO2__INPropertyDescriptor()
            ,getORIGIN__CITY__CODE__INPropertyDescriptor()
            ,getORIGIN__CITY__NAME__INPropertyDescriptor()
            ,getORIGIN__STATE__INPropertyDescriptor()
            ,getDESTINATION__CITY__CODE__INPropertyDescriptor()
            ,getSHIP__VIA__INPropertyDescriptor()
            ,getEQUIP__TYPE__INPropertyDescriptor()
            ,getCLRN__LTR__FILE__NO__INPropertyDescriptor()
            ,getCLRN__LTR__NO__INPropertyDescriptor()
            ,getCONSIGNEE__INPropertyDescriptor()
            ,getDLR__CODE__INPropertyDescriptor()
            ,getINLAND__FRT__CHRG__CODE__INPropertyDescriptor()
            ,getADR__NAME__INPropertyDescriptor()
            ,getADR__NM__LN1__INPropertyDescriptor()
            ,getADR__TXT__LN1__INPropertyDescriptor()
            ,getADR__TXT__LN2__INPropertyDescriptor()
            ,getADR__CITY__NAME__INPropertyDescriptor()
            ,getADR__STATE__INPropertyDescriptor()
            ,getADR__POSTAL__ZONE__CODE__INPropertyDescriptor()
            ,getADR__COUNTRY__INPropertyDescriptor()
            ,getDEL__INST__LN1__INPropertyDescriptor()
            ,getDEL__INST__LN2__INPropertyDescriptor()
            ,getDEL__INST__LN3__INPropertyDescriptor()
            ,getDEL__INST__LN4__INPropertyDescriptor()
            ,getDEL__INST__LN5__INPropertyDescriptor()
            ,getTOTAL__WEIGHT__INPropertyDescriptor()
            ,getCOMMITTED__DATE__INPropertyDescriptor()
            ,getSHIPPED__DATE__INPropertyDescriptor()
            ,getEXPORT__TO__INPropertyDescriptor()
            ,getLTL__IND__INPropertyDescriptor()
            ,getCARGO__DESC__INPropertyDescriptor()
            ,getORDER__ANALYST__INPropertyDescriptor()
            ,getDEL__TO__LOC__INPropertyDescriptor()
            ,getSTOPOVER__LOC__INPropertyDescriptor()
            ,getCARRIER__CODE__INPropertyDescriptor()
            ,getCARRIER__NAME__INPropertyDescriptor()
            ,getPORT__OF__EXIT__CODE__INPropertyDescriptor()
            ,getPORT__OF__EXIT__NAME__INPropertyDescriptor()
            ,getEXP__CARRIER__CODE__INPropertyDescriptor()
            ,getEXP__CARRIER__ABBR__NAME__INPropertyDescriptor()
            ,getPIER__AIRPORT__NAME__INPropertyDescriptor()
            ,getVESSEL__NAME__INPropertyDescriptor()
            ,getSAILING__DATE__INPropertyDescriptor()
            ,getFill_0PropertyDescriptor()
            ,getCONTRACT__NO__INPropertyDescriptor()
            ,getSTCC__CODE__INPropertyDescriptor()
            ,getTRAN__TYPE__INPropertyDescriptor()
            ,getVEH__NO__INPropertyDescriptor()
            ,getQTY__INPropertyDescriptor()
            ,getDIM__WT__LINE__NO__INPropertyDescriptor()
            ,getDIM__UM__INPropertyDescriptor()
            ,getLENGTH__INPropertyDescriptor()
            ,getWIDTH__INPropertyDescriptor()
            ,getHEIGHT__INPropertyDescriptor()
            ,getWT__UM__INPropertyDescriptor()
            ,getGROSS__WT__INPropertyDescriptor()
            ,getNET__WT__INPropertyDescriptor()
            ,getPACK__DESC__INPropertyDescriptor()
            ,getPACKG__LIST__DESC__INPropertyDescriptor()
            ,getPACKG__ID__INPropertyDescriptor()
            ,getHAZARDOUS__REF__CODE1__INPropertyDescriptor()
            ,getHAZARDOUS__REF__CODE2__INPropertyDescriptor()
            ,getHAZARDOUS__REF__CODE3__INPropertyDescriptor()
            ,getHAZARDOUS__REF__CODE4__INPropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getQTY__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("QTY__IN", Class.forName(getBeanClassName()), "getQTY__IN", "setQTY__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("QTY__IN");
      aDescriptor.setDisplayName("QTY__IN");
      aDescriptor.setShortDescription("QTY__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getRECORD__TYPE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("RECORD__TYPE__IN", Class.forName(getBeanClassName()), "getRECORD__TYPE__IN", "setRECORD__TYPE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("RECORD__TYPE__IN");
      aDescriptor.setDisplayName("RECORD__TYPE__IN");
      aDescriptor.setShortDescription("RECORD__TYPE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSAILING__DATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SAILING__DATE__IN", Class.forName(getBeanClassName()), "getSAILING__DATE__IN", "setSAILING__DATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SAILING__DATE__IN");
      aDescriptor.setDisplayName("SAILING__DATE__IN");
      aDescriptor.setShortDescription("SAILING__DATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO1__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO1__IN", Class.forName(getBeanClassName()), "getSEAL__NO1__IN", "setSEAL__NO1__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO1__IN");
      aDescriptor.setDisplayName("SEAL__NO1__IN");
      aDescriptor.setShortDescription("SEAL__NO1__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO2__IN", Class.forName(getBeanClassName()), "getSEAL__NO2__IN", "setSEAL__NO2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO2__IN");
      aDescriptor.setDisplayName("SEAL__NO2__IN");
      aDescriptor.setShortDescription("SEAL__NO2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIP__VIA__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SHIP__VIA__IN", Class.forName(getBeanClassName()), "getSHIP__VIA__IN", "setSHIP__VIA__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIP__VIA__IN");
      aDescriptor.setDisplayName("SHIP__VIA__IN");
      aDescriptor.setShortDescription("SHIP__VIA__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIPPED__DATE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SHIPPED__DATE__IN", Class.forName(getBeanClassName()), "getSHIPPED__DATE__IN", "setSHIPPED__DATE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIPPED__DATE__IN");
      aDescriptor.setDisplayName("SHIPPED__DATE__IN");
      aDescriptor.setShortDescription("SHIPPED__DATE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTCC__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("STCC__CODE__IN", Class.forName(getBeanClassName()), "getSTCC__CODE__IN", "setSTCC__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STCC__CODE__IN");
      aDescriptor.setDisplayName("STCC__CODE__IN");
      aDescriptor.setShortDescription("STCC__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTOPOVER__LOC__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("STOPOVER__LOC__IN", Class.forName(getBeanClassName()), "getSTOPOVER__LOC__IN", "setSTOPOVER__LOC__IN", "getSTOPOVER__LOC__IN", "setSTOPOVER__LOC__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STOPOVER__LOC__IN");
      aDescriptor.setDisplayName("STOPOVER__LOC__IN");
      aDescriptor.setShortDescription("STOPOVER__LOC__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTOTAL__WEIGHT__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TOTAL__WEIGHT__IN", Class.forName(getBeanClassName()), "getTOTAL__WEIGHT__IN", "setTOTAL__WEIGHT__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TOTAL__WEIGHT__IN");
      aDescriptor.setDisplayName("TOTAL__WEIGHT__IN");
      aDescriptor.setShortDescription("TOTAL__WEIGHT__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__IN", "setTRAN__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__CODE__IN");
      aDescriptor.setDisplayName("TRAN__CODE__IN");
      aDescriptor.setShortDescription("TRAN__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__TYPE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__TYPE__IN", Class.forName(getBeanClassName()), "getTRAN__TYPE__IN", "setTRAN__TYPE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__TYPE__IN");
      aDescriptor.setDisplayName("TRAN__TYPE__IN");
      aDescriptor.setShortDescription("TRAN__TYPE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getUSER__ACF2__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("USER__ACF2__IN", Class.forName(getBeanClassName()), "getUSER__ACF2__IN", "setUSER__ACF2__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("USER__ACF2__IN");
      aDescriptor.setDisplayName("USER__ACF2__IN");
      aDescriptor.setShortDescription("USER__ACF2__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getVEH__NO__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("VEH__NO__IN", Class.forName(getBeanClassName()), "getVEH__NO__IN", "setVEH__NO__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("VEH__NO__IN");
      aDescriptor.setDisplayName("VEH__NO__IN");
      aDescriptor.setShortDescription("VEH__NO__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getVESSEL__NAME__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("VESSEL__NAME__IN", Class.forName(getBeanClassName()), "getVESSEL__NAME__IN", "setVESSEL__NAME__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("VESSEL__NAME__IN");
      aDescriptor.setDisplayName("VESSEL__NAME__IN");
      aDescriptor.setShortDescription("VESSEL__NAME__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getWIDTH__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("WIDTH__IN", Class.forName(getBeanClassName()), "getWIDTH__IN", "setWIDTH__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("WIDTH__IN");
      aDescriptor.setDisplayName("WIDTH__IN");
      aDescriptor.setShortDescription("WIDTH__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getWT__UM__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("WT__UM__IN", Class.forName(getBeanClassName()), "getWT__UM__IN", "setWT__UM__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("WT__UM__IN");
      aDescriptor.setDisplayName("WT__UM__IN");
      aDescriptor.setShortDescription("WT__UM__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__IN");
      aDescriptor.setDisplayName("ZZ__IN");
      aDescriptor.setShortDescription("ZZ__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }
}
