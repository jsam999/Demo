package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B46InMsgInfo.java
// Generated from C:\t1ak0b46.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B46InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B46InMsgInfo_ADDRESS__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B46InMsgInfo_ADDRESS__IN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(25):DISPLAY"), "ADR__NAME__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__NM__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(35):DISPLAY"), "ADR__TXT__LN2__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "ADR__CITY__NAME__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__STATE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "ADR__POSTAL__ZONE__CODE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "ADR__COUNTRY__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B46InMsgInfo_DEL__INSTRUCTIONS extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B46InMsgInfo_DEL__INSTRUCTIONS () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN1__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN2__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN3__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN4__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(30):DISPLAY"), "DEL__INST__LN5__IN", new CobolInitialValueObject(" ", null)));

	  }
   }
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B46InMsgInfo_VEHICLE__BREAKDOWN extends CobolDynamicRecordType
   {
	  /**
	  *  This class defines a shared dynamic record type definition.
	  */
	  public class AK0B46InMsgInfo_VEHICLE__BREAKDOWN_HAZARDOUS__REF__CODES__IN extends CobolDynamicRecordType
	  {
		 /**
		 *  This ctor defines the record type (its content).
		 */
		 public AK0B46InMsgInfo_VEHICLE__BREAKDOWN_HAZARDOUS__REF__CODES__IN () throws RecordException
		 {
			int[] arraySize = null;
			ArrayField arrField = null;

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE1__IN", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE2__IN", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE3__IN", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE4__IN", new CobolInitialValueObject(" ", null)));

		 }
	  }
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B46InMsgInfo_VEHICLE__BREAKDOWN () throws RecordException
	  {
		 int[] arraySize = null;
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(1):DISPLAY"), "TRAN__TYPE__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(3):DISPLAY"), "VEH__NO__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(3):DISPLAY"), "QTY__IN"));

		 addField(new Field(new CobolType("9(03):DISPLAY"), "DIM__WT__LINE__NO__IN"));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "DIM__UM__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "LENGTH__IN"));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "WIDTH__IN"));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "HEIGHT__IN"));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "WT__UM__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(07):DISPLAY"), "GROSS__WT__IN"));

		 addField(new Field(new CobolType("9(07):DISPLAY"), "NET__WT__IN"));

		 addField(new Field(new CobolType("X(06):DISPLAY"), "PACK__DESC__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(14):DISPLAY"), "PACKG__LIST__DESC__IN", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "PACKG__ID__IN", new CobolInitialValueObject(" ", null)));

		 addField(new NestedRecordField(new AK0B46InMsgInfo_VEHICLE__BREAKDOWN_HAZARDOUS__REF__CODES__IN(), "HAZARDOUS__REF__CODES__IN"));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B46InMsgInfo () throws RecordException
   {
      int[] arraySize = null;
      ArrayField arrField = null;

      addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(05):DISPLAY"), "BADGE__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "USER__ACF2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(01):DISPLAY"), "RECORD__TYPE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "FAC__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "BLDG__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "DOCK__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "BOL__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "ISSUE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "SEAL__NO1__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(07):DISPLAY"), "SEAL__NO2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CONTAINER__NO1__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CONTAINER__NO2__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "ORIGIN__CITY__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(18):DISPLAY"), "ORIGIN__CITY__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "ORIGIN__STATE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "DESTINATION__CITY__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(01):DISPLAY"), "SHIP__VIA__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(02):DISPLAY"), "EQUIP__TYPE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(15):DISPLAY"), "CLRN__LTR__FILE__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "CLRN__LTR__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "CONSIGNEE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "DLR__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(01):DISPLAY"), "INLAND__FRT__CHRG__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new NestedRecordField(new AK0B46InMsgInfo_ADDRESS__IN(), "ADDRESS__IN"));

      addField(new NestedRecordField(new AK0B46InMsgInfo_DEL__INSTRUCTIONS(), "DEL__INSTRUCTIONS"));

      addField(new Field(new CobolType("X(6):DISPLAY"), "TOTAL__WEIGHT__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(08):DISPLAY"), "COMMITTED__DATE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(08):DISPLAY"), "SHIPPED__DATE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(20):DISPLAY"), "EXPORT__TO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X:DISPLAY"), "LTL__IND__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(18):DISPLAY"), "CARGO__DESC__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("XXX:DISPLAY"), "ORDER__ANALYST__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(5):DISPLAY"), "DEL__TO__LOC__IN", new CobolInitialValueObject(" ", null)));

      arraySize = new int[1];
      arraySize[0] = 4;
      arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(4):DISPLAY")), "STOPOVER__LOC__IN", new CobolInitialValueObject(" ", null));
      addField(arrField);

      addField(new Field(new CobolType("X(5):DISPLAY"), "CARRIER__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(30):DISPLAY"), "CARRIER__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(6):DISPLAY"), "PORT__OF__EXIT__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(25):DISPLAY"), "PORT__OF__EXIT__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(6):DISPLAY"), "EXP__CARRIER__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(15):DISPLAY"), "EXP__CARRIER__ABBR__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(30):DISPLAY"), "PIER__AIRPORT__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(25):DISPLAY"), "VESSEL__NAME__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(06):DISPLAY"), "SAILING__DATE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(10):DISPLAY"), "fill_0", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(12):DISPLAY"), "CONTRACT__NO__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(09):DISPLAY"), "STCC__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new NestedRecordField(new AK0B46InMsgInfo_VEHICLE__BREAKDOWN(), "VEHICLE__BREAKDOWN"));

   }
}
