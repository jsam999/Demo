package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecord;
import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B46OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B46OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B46OutMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B46OutMsg.class,3881));
		 this.setBytes(new byte[3881]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getBLDG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }   
   public java.lang.String getBOL__NO__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }   
   public java.lang.String getDOCK__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }   
   public java.lang.String getERROR__MSG__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3831,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }   
   public java.lang.String getFAC__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }   
   public java.lang.String getISSUE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }   
   public short getLL__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("cat.bol.ims.AK0B46OutMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }   
   public java.lang.String getSTCC__CODE__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }   
   public AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[] getVEHICLE__BREAKDOWN__OUT()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 76;
		 AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[] returnArray = new AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[50];
		 int[] dim = {50};
		 for(int i0=0;i0<50;i0++) {
			int offset = 31 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			CustomRecordType elementRecordType = new CustomRecordType(AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT.class,elementSize);
			CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
			byte[] bytes = new byte[elementSize];
			System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
			element.setBytes (bytes);
			returnArray[i0] = (AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT)element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT getVEHICLE__BREAKDOWN__OUT(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 76;
		 int[] dim = {50};
		 int offset = 31 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 CustomRecordType returnRecordType = new CustomRecordType(AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT.class,elementSize);
		 CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
		 byte[] bytes = new byte[elementSize];
		 System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
		 returnRecord.setBytes (bytes);
		 return ((AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT)returnRecord);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public short getZZ__OUT()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__OUT",null,getLL__OUT());
		 firePropertyChange("ZZ__OUT",null,getZZ__OUT());
		 firePropertyChange("FAC__OUT",null,getFAC__OUT());
		 firePropertyChange("BLDG__OUT",null,getBLDG__OUT());
		 firePropertyChange("DOCK__OUT",null,getDOCK__OUT());
		 firePropertyChange("BOL__NO__OUT",null,getBOL__NO__OUT());
		 firePropertyChange("ISSUE__OUT",null,getISSUE__OUT());
		 firePropertyChange("STCC__CODE__OUT",null,getSTCC__CODE__OUT());
		 firePropertyChange("VEHICLE__BREAKDOWN__OUT",null,getVEHICLE__BREAKDOWN__OUT());
		 firePropertyChange("ERROR__MSG__OUT",null,getERROR__MSG__OUT());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setBLDG__OUT(java.lang.String aBLDG__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldBLDG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6,aBLDG__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("BLDG__OUT",oldBLDG__OUT,aBLDG__OUT);
	  return;
   }   
   public void setBOL__NO__OUT(java.lang.String aBOL__NO__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldBOL__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aBOL__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  firePropertyChange("BOL__NO__OUT",oldBOL__NO__OUT,aBOL__NO__OUT);
	  return;
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setDOCK__OUT(java.lang.String aDOCK__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldDOCK__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,8,aDOCK__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("DOCK__OUT",oldDOCK__OUT,aDOCK__OUT);
	  return;
   }   
   public void setERROR__MSG__OUT(java.lang.String aERROR__MSG__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldERROR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,3831,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,3831,aERROR__MSG__OUT,9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  firePropertyChange("ERROR__MSG__OUT",oldERROR__MSG__OUT,aERROR__MSG__OUT);
	  return;
   }   
   public void setFAC__OUT(java.lang.String aFAC__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldFAC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aFAC__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("FAC__OUT",oldFAC__OUT,aFAC__OUT);
	  return;
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,8, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,20, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,22, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,3831, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
	  return;
   }   
   public void setISSUE__OUT(java.lang.String aISSUE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldISSUE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,20,aISSUE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
	  firePropertyChange("ISSUE__OUT",oldISSUE__OUT,aISSUE__OUT);
	  return;
   }   
   public void setLL__OUT(short aLL__OUT)
	  throws RecordConversionFailureException {
	  short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
	  return;
   }   
   public void setSTCC__CODE__OUT(java.lang.String aSTCC__CODE__OUT)
	  throws RecordConversionFailureException {
	  java.lang.String oldSTCC__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,22,aSTCC__CODE__OUT,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  firePropertyChange("STCC__CODE__OUT",oldSTCC__CODE__OUT,aSTCC__CODE__OUT);
	  return;
   }   
   public void setVEHICLE__BREAKDOWN__OUT(AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[] aVEHICLE__BREAKDOWN__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 76;
		 int[] dim = {50};
		 for(int i0=0;i0<50;i0++) {
			int offset = 31 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			byte[] recordBytes = getBytes();
			byte[] fieldBytes = aVEHICLE__BREAKDOWN__OUT[i0].getBytes();
			System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
			setBytes(recordBytes);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setVEHICLE__BREAKDOWN__OUT(int index, AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT aVEHICLE__BREAKDOWN__OUT)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 76;
		 int[] dim = {50};
		 int offset = 31 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 byte[] recordBytes = getBytes();
		 byte[] fieldBytes = aVEHICLE__BREAKDOWN__OUT.getBytes();
		 System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
		 setBytes(recordBytes);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setZZ__OUT(short aZZ__OUT)
	  throws RecordConversionFailureException {
	  short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
	  return;
   }   
}
