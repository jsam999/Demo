package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B46OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B46OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B46OutMsg.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B46OutMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B46OutMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getBLDG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BLDG__OUT", Class.forName(getBeanClassName()), "getBLDG__OUT", "setBLDG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BLDG__OUT");
	  aDescriptor.setDisplayName("BLDG__OUT");
	  aDescriptor.setShortDescription("BLDG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getBOL__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BOL__NO__OUT", Class.forName(getBeanClassName()), "getBOL__NO__OUT", "setBOL__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BOL__NO__OUT");
	  aDescriptor.setDisplayName("BOL__NO__OUT");
	  aDescriptor.setShortDescription("BOL__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getDOCK__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DOCK__OUT", Class.forName(getBeanClassName()), "getDOCK__OUT", "setDOCK__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DOCK__OUT");
	  aDescriptor.setDisplayName("DOCK__OUT");
	  aDescriptor.setShortDescription("DOCK__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getERROR__MSG__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ERROR__MSG__OUT", Class.forName(getBeanClassName()), "getERROR__MSG__OUT", "setERROR__MSG__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ERROR__MSG__OUT");
	  aDescriptor.setDisplayName("ERROR__MSG__OUT");
	  aDescriptor.setShortDescription("ERROR__MSG__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getFAC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("FAC__OUT", Class.forName(getBeanClassName()), "getFAC__OUT", "setFAC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("FAC__OUT");
	  aDescriptor.setDisplayName("FAC__OUT");
	  aDescriptor.setShortDescription("FAC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getISSUE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ISSUE__OUT", Class.forName(getBeanClassName()), "getISSUE__OUT", "setISSUE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ISSUE__OUT");
	  aDescriptor.setDisplayName("ISSUE__OUT");
	  aDescriptor.setShortDescription("ISSUE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__OUT");
	  aDescriptor.setDisplayName("LL__OUT");
	  aDescriptor.setShortDescription("LL__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__OUTPropertyDescriptor()
			,getZZ__OUTPropertyDescriptor()
			,getFAC__OUTPropertyDescriptor()
			,getBLDG__OUTPropertyDescriptor()
			,getDOCK__OUTPropertyDescriptor()
			,getBOL__NO__OUTPropertyDescriptor()
			,getISSUE__OUTPropertyDescriptor()
			,getSTCC__CODE__OUTPropertyDescriptor()
			,getVEHICLE__BREAKDOWN__OUTPropertyDescriptor()
			,getERROR__MSG__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getSTCC__CODE__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("STCC__CODE__OUT", Class.forName(getBeanClassName()), "getSTCC__CODE__OUT", "setSTCC__CODE__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("STCC__CODE__OUT");
	  aDescriptor.setDisplayName("STCC__CODE__OUT");
	  aDescriptor.setShortDescription("STCC__CODE__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getVEHICLE__BREAKDOWN__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("VEHICLE__BREAKDOWN__OUT", Class.forName(getBeanClassName()), "getVEHICLE__BREAKDOWN__OUT", "setVEHICLE__BREAKDOWN__OUT", "getVEHICLE__BREAKDOWN__OUT", "setVEHICLE__BREAKDOWN__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("VEHICLE__BREAKDOWN__OUT");
	  aDescriptor.setDisplayName("VEHICLE__BREAKDOWN__OUT");
	  aDescriptor.setShortDescription("VEHICLE__BREAKDOWN__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__OUT");
	  aDescriptor.setDisplayName("ZZ__OUT");
	  aDescriptor.setShortDescription("ZZ__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
