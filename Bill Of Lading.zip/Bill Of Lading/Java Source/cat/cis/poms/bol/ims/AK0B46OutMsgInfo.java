package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B46OutMsgInfo.java
// Generated from C:\9030b46.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B46OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT extends CobolDynamicRecordType
   {
	  /**
	  *  This class defines a shared dynamic record type definition.
	  */
	  public class AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT_HAZARDOUS__REF__CODES__OUT extends CobolDynamicRecordType
	  {
		 /**
		 *  This ctor defines the record type (its content).
		 */
		 public AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT_HAZARDOUS__REF__CODES__OUT () throws RecordException
		 {
			int[] arraySize = new int[1];
			ArrayField arrField = null;

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE1__OUT", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE2__OUT", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE3__OUT", new CobolInitialValueObject(" ", null)));

			addField(new Field(new CobolType("X(01):DISPLAY"), "HAZARDOUS__REF__CODE4__OUT", new CobolInitialValueObject(" ", null)));

		 }
	  }
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 addField(new Field(new CobolType("X(3):DISPLAY"), "VEH__NO__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(3):DISPLAY"), "QTY__OUT"));

		 addField(new Field(new CobolType("9(03):DISPLAY"), "DIM__WT__LINE__NO__OUT"));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "DIM__UM__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "LENGTH__OUT"));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "WIDTH__OUT"));

		 addField(new Field(new CobolType("9(05):DISPLAY"), "HEIGHT__OUT"));

		 addField(new Field(new CobolType("X(02):DISPLAY"), "WT__UM__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("9(07):DISPLAY"), "GROSS__WT__OUT"));

		 addField(new Field(new CobolType("9(07):DISPLAY"), "NET__WT__OUT"));

		 addField(new Field(new CobolType("X(06):DISPLAY"), "PACK__DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(14):DISPLAY"), "PACKG__LIST__DESC__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new Field(new CobolType("X(10):DISPLAY"), "PACKG__ID__OUT", new CobolInitialValueObject(" ", null)));

		 addField(new NestedRecordField(new AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT_HAZARDOUS__REF__CODES__OUT(), "HAZARDOUS__REF__CODES__OUT"));

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B46OutMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "FAC__OUT", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "BLDG__OUT", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "DOCK__OUT", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(10):DISPLAY"), "BOL__NO__OUT", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(02):DISPLAY"), "ISSUE__OUT", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "STCC__CODE__OUT", new CobolInitialValueObject(" ", null)));

	  arraySize[0] = 50;
	  arrField = new ArrayField(new CobolArrayType(arraySize, new AK0B46OutMsgInfo_VEHICLE__BREAKDOWN__OUT()), "VEHICLE__BREAKDOWN__OUT");
	  addField(arrField);

	  addField(new Field(new CobolType("X(50):DISPLAY"), "ERROR__MSG__OUT", new CobolInitialValueObject(" ", null)));

   }   
}
