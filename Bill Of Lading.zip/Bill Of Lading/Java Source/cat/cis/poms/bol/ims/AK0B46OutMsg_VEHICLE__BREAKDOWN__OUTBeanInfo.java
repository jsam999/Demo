package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B46OutMsg_VEHICLE__BREAKDOWN__OUTBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B46OutMsg_VEHICLE__BREAKDOWN__OUTBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.PropertyDescriptor getDIM__UM__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DIM__UM__OUT", Class.forName(getBeanClassName()), "getDIM__UM__OUT", "setDIM__UM__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DIM__UM__OUT");
	  aDescriptor.setDisplayName("DIM__UM__OUT");
	  aDescriptor.setShortDescription("DIM__UM__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getDIM__WT__LINE__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("DIM__WT__LINE__NO__OUT", Class.forName(getBeanClassName()), "getDIM__WT__LINE__NO__OUT", "setDIM__WT__LINE__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("DIM__WT__LINE__NO__OUT");
	  aDescriptor.setDisplayName("DIM__WT__LINE__NO__OUT");
	  aDescriptor.setShortDescription("DIM__WT__LINE__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getGROSS__WT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("GROSS__WT__OUT", Class.forName(getBeanClassName()), "getGROSS__WT__OUT", "setGROSS__WT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("GROSS__WT__OUT");
	  aDescriptor.setDisplayName("GROSS__WT__OUT");
	  aDescriptor.setShortDescription("GROSS__WT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE1__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE1__OUT", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE1__OUT", "setHAZARDOUS__REF__CODE1__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HAZARDOUS__REF__CODE1__OUT");
	  aDescriptor.setDisplayName("HAZARDOUS__REF__CODE1__OUT");
	  aDescriptor.setShortDescription("HAZARDOUS__REF__CODE1__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE2__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE2__OUT", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE2__OUT", "setHAZARDOUS__REF__CODE2__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HAZARDOUS__REF__CODE2__OUT");
	  aDescriptor.setDisplayName("HAZARDOUS__REF__CODE2__OUT");
	  aDescriptor.setShortDescription("HAZARDOUS__REF__CODE2__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE3__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE3__OUT", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE3__OUT", "setHAZARDOUS__REF__CODE3__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HAZARDOUS__REF__CODE3__OUT");
	  aDescriptor.setDisplayName("HAZARDOUS__REF__CODE3__OUT");
	  aDescriptor.setShortDescription("HAZARDOUS__REF__CODE3__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHAZARDOUS__REF__CODE4__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HAZARDOUS__REF__CODE4__OUT", Class.forName(getBeanClassName()), "getHAZARDOUS__REF__CODE4__OUT", "setHAZARDOUS__REF__CODE4__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HAZARDOUS__REF__CODE4__OUT");
	  aDescriptor.setDisplayName("HAZARDOUS__REF__CODE4__OUT");
	  aDescriptor.setShortDescription("HAZARDOUS__REF__CODE4__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getHEIGHT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("HEIGHT__OUT", Class.forName(getBeanClassName()), "getHEIGHT__OUT", "setHEIGHT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("HEIGHT__OUT");
	  aDescriptor.setDisplayName("HEIGHT__OUT");
	  aDescriptor.setShortDescription("HEIGHT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getLENGTH__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LENGTH__OUT", Class.forName(getBeanClassName()), "getLENGTH__OUT", "setLENGTH__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LENGTH__OUT");
	  aDescriptor.setDisplayName("LENGTH__OUT");
	  aDescriptor.setShortDescription("LENGTH__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getNET__WT__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("NET__WT__OUT", Class.forName(getBeanClassName()), "getNET__WT__OUT", "setNET__WT__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("NET__WT__OUT");
	  aDescriptor.setDisplayName("NET__WT__OUT");
	  aDescriptor.setShortDescription("NET__WT__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACK__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACK__DESC__OUT", Class.forName(getBeanClassName()), "getPACK__DESC__OUT", "setPACK__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACK__DESC__OUT");
	  aDescriptor.setDisplayName("PACK__DESC__OUT");
	  aDescriptor.setShortDescription("PACK__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACKG__ID__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACKG__ID__OUT", Class.forName(getBeanClassName()), "getPACKG__ID__OUT", "setPACKG__ID__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACKG__ID__OUT");
	  aDescriptor.setDisplayName("PACKG__ID__OUT");
	  aDescriptor.setShortDescription("PACKG__ID__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getPACKG__LIST__DESC__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PACKG__LIST__DESC__OUT", Class.forName(getBeanClassName()), "getPACKG__LIST__DESC__OUT", "setPACKG__LIST__DESC__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PACKG__LIST__DESC__OUT");
	  aDescriptor.setDisplayName("PACKG__LIST__DESC__OUT");
	  aDescriptor.setShortDescription("PACKG__LIST__DESC__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getVEH__NO__OUTPropertyDescriptor()
			,getQTY__OUTPropertyDescriptor()
			,getDIM__WT__LINE__NO__OUTPropertyDescriptor()
			,getDIM__UM__OUTPropertyDescriptor()
			,getLENGTH__OUTPropertyDescriptor()
			,getWIDTH__OUTPropertyDescriptor()
			,getHEIGHT__OUTPropertyDescriptor()
			,getWT__UM__OUTPropertyDescriptor()
			,getGROSS__WT__OUTPropertyDescriptor()
			,getNET__WT__OUTPropertyDescriptor()
			,getPACK__DESC__OUTPropertyDescriptor()
			,getPACKG__LIST__DESC__OUTPropertyDescriptor()
			,getPACKG__ID__OUTPropertyDescriptor()
			,getHAZARDOUS__REF__CODE1__OUTPropertyDescriptor()
			,getHAZARDOUS__REF__CODE2__OUTPropertyDescriptor()
			,getHAZARDOUS__REF__CODE3__OUTPropertyDescriptor()
			,getHAZARDOUS__REF__CODE4__OUTPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getQTY__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("QTY__OUT", Class.forName(getBeanClassName()), "getQTY__OUT", "setQTY__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("QTY__OUT");
	  aDescriptor.setDisplayName("QTY__OUT");
	  aDescriptor.setShortDescription("QTY__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getVEH__NO__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("VEH__NO__OUT", Class.forName(getBeanClassName()), "getVEH__NO__OUT", "setVEH__NO__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("VEH__NO__OUT");
	  aDescriptor.setDisplayName("VEH__NO__OUT");
	  aDescriptor.setShortDescription("VEH__NO__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getWIDTH__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("WIDTH__OUT", Class.forName(getBeanClassName()), "getWIDTH__OUT", "setWIDTH__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WIDTH__OUT");
	  aDescriptor.setDisplayName("WIDTH__OUT");
	  aDescriptor.setShortDescription("WIDTH__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getWT__UM__OUTPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("WT__UM__OUT", Class.forName(getBeanClassName()), "getWT__UM__OUT", "setWT__UM__OUT" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("WT__UM__OUT");
	  aDescriptor.setDisplayName("WT__UM__OUT");
	  aDescriptor.setShortDescription("WT__UM__OUT");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
