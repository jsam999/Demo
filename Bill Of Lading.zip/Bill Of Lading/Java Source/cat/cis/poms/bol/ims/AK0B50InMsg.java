package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.bol.ims.AK0B50InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B50InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B50InMsg()
	  throws RecordException
   {
	  try {
		 com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		 attrs.setFloatingPointFormat((int)0);
		 attrs.setEndian((int)0);
		 attrs.setRemoteIntEndian((int)0);
		 attrs.setCodePage((java.lang.String)"037");
		 attrs.setMachine((int)0);
		 this.setRecordAttributes(attrs);
		 this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B50InMsg.class,283));
		 this.setBytes(new byte[283]);
		 this.setInitialValues();
		 this.enableNotification();
	  } catch (Exception e) {
		 throw new RecordException(e.getMessage());
	  }
   }      
   public void addPropertyChangeListener(PropertyChangeListener x) {
	  listeners.addPropertyChangeListener( x );
   }   
   public void disableNotification()
   {
	  super.disableNotification();
	  notifyWhenContentsUpdated = false;
	  return;
   }   
   public void enableNotification()
   {
	  super.enableNotification();
	  notifyWhenContentsUpdated = true;
	  return;
   }   
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
	  listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
	  listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
	  listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
	  listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
	  listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
	  listeners.firePropertyChange( prop, oldObj, newObj);
   }   
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }   
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
	  listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }   
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
	  listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }   
   public java.lang.String getBADGE__NO__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }   
   public java.lang.String[] getLADING__NO__IN()
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 java.lang.String[] returnArray = new java.lang.String[25];
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 33 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,10,false,false,false,-9,0,"X(10)",false,true);
			returnArray[i0] = element;
		 }
		 return returnArray;
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public java.lang.String getLADING__NO__IN(int index)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 int offset = 33 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public short getLL__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public static Class getMetadataClass() {
	  try {
		 return Class.forName("cat.bol.ims.AK0B50InMsgInfo");
	  } catch (ClassNotFoundException e) {
		 return null;
	  }
   }   
   public java.lang.String getPRINTER__LTERM1()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }   
   public java.lang.String getTRAN__CODE__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }   
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		is increased from 7 to 9.
	*/

   public java.lang.String getUSER__ACF2__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
   }   
   public short getZZ__IN()
	  throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }   
   public void notifyAllVars()
	  throws RecordConversionFailureException
   {
	  if (notifyWhenContentsUpdated) {
		 firePropertyChange("LL__IN",null,getLL__IN());
		 firePropertyChange("ZZ__IN",null,getZZ__IN());
		 firePropertyChange("TRAN__CODE__IN",null,getTRAN__CODE__IN());
		 firePropertyChange("BADGE__NO__IN",null,getBADGE__NO__IN());
		 firePropertyChange("USER__ACF2__IN",null,getUSER__ACF2__IN());
		 firePropertyChange("PRINTER__LTERM1",null,getPRINTER__LTERM1());
		 firePropertyChange("LADING__NO__IN",null,getLADING__NO__IN());
	  }
   }   
   public void removePropertyChangeListener(PropertyChangeListener x) {
	  listeners.removePropertyChangeListener( x );
   }   
   public void setBADGE__NO__IN(java.lang.String aBADGE__NO__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldBADGE__NO__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aBADGE__NO__IN,9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  firePropertyChange("BADGE__NO__IN",oldBADGE__NO__IN,aBADGE__NO__IN);
	  return;
   }   
   public void setBytes(byte[] contents)
   {
	  super.setBytes(contents);
	  notifyAllVars();
   }   
   public void setInitialValues() throws
	  RecordConversionFailureException,
	  RecordConversionUnsupportedException
   {
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,18, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,25, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,33, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,43, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,53, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,63, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,73, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,83, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,93, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,103, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,113, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,123, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,133, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,143, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,153, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,163, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,173, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,183, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,193, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,203, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,213, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,223, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,233, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,243, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,253, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,263, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,273, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  return;
   }   
   public void setLADING__NO__IN(java.lang.String[] aLADING__NO__IN)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 for(int i0=0;i0<25;i0++) {
			int offset = 33 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
			com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aLADING__NO__IN[i0],9,0,10,false,false,false,-9,0,"X(10)",false,true);
		 }
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setLADING__NO__IN(int index, java.lang.String aLADING__NO__IN)
	  throws RecordConversionFailureException {
	  try
	  {
		 int elementSize = 10;
		 int[] dim = {25};
		 int offset = 33 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
		 com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aLADING__NO__IN,9,0,10,false,false,false,-9,0,"X(10)",false,true);
	  }
	  catch (Exception exc)
	  {
		 throw new RecordConversionFailureException();
	  }
   }   
   public void setLL__IN(short aLL__IN)
	  throws RecordConversionFailureException {
	  short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
	  return;
   }   
   public void setPRINTER__LTERM1(java.lang.String aPRINTER__LTERM1)
	  throws RecordConversionFailureException {
	  java.lang.String oldPRINTER__LTERM1 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,25,9,0,8,false,false,false,-7,0,"X(08)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,25,aPRINTER__LTERM1,9,0,8,false,false,false,-7,0,"X(08)",false,true);
	  firePropertyChange("PRINTER__LTERM1",oldPRINTER__LTERM1,aPRINTER__LTERM1);
	  return;
   }   
   public void setTRAN__CODE__IN(java.lang.String aTRAN__CODE__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldTRAN__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
	  firePropertyChange("TRAN__CODE__IN",oldTRAN__CODE__IN,aTRAN__CODE__IN);
	  return;
   }   
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setUSER__ACF2__IN(java.lang.String aUSER__ACF2__IN)
	  throws RecordConversionFailureException {
	  java.lang.String oldUSER__ACF2__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,18,9,0,9,false,false,false,-6,0,"X(07)",false,true);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,18,aUSER__ACF2__IN,9,0,9,false,false,false,-6,0,"X(07)",false,true);
	  firePropertyChange("USER__ACF2__IN",oldUSER__ACF2__IN,aUSER__ACF2__IN);
	  return;
   }   
   public void setZZ__IN(short aZZ__IN)
	  throws RecordConversionFailureException {
	  short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	  firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
	  return;
   }   
}
