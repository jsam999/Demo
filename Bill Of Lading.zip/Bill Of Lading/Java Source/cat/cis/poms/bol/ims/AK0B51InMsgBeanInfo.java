package cat.cis.poms.bol.ims;

/**
 * Class: cat.bol.ims.AK0B51InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B51InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
	  java.lang.Class superClass;
	  java.beans.BeanInfo superBeanInfo = null;

	  try {
		 superClass = getBeanDescriptor().getBeanClass().getSuperclass();
	  } catch (java.lang.Throwable exception) {
		 return null;
	  }

	  try {
		 superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
	  } catch (java.beans.IntrospectionException ie) {}

	  if (superBeanInfo != null) {
		 java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
		 ret[0] = superBeanInfo;
		 return ret;
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getBADGE__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("BADGE__NO__IN", Class.forName(getBeanClassName()), "getBADGE__NO__IN", "setBADGE__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("BADGE__NO__IN");
	  aDescriptor.setDisplayName("BADGE__NO__IN");
	  aDescriptor.setShortDescription("BADGE__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public static java.lang.Class getBeanClass()
   {
	  return(cat.cis.poms.bol.ims.AK0B51InMsg.class);
   }      
   public static java.lang.String getBeanClassName()
   {
	  return("cat.bol.ims.AK0B51InMsg");
   }   
   public java.beans.BeanDescriptor getBeanDescriptor() {
	  java.beans.BeanDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B51InMsg.class);
	  } catch (Throwable exception) {
	  };
	  return aDescriptor;
   }      
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getLADING__NO__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.IndexedPropertyDescriptor("LADING__NO__IN", Class.forName(getBeanClassName()), "getLADING__NO__IN", "setLADING__NO__IN", "getLADING__NO__IN", "setLADING__NO__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LADING__NO__IN");
	  aDescriptor.setDisplayName("LADING__NO__IN");
	  aDescriptor.setShortDescription("LADING__NO__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("LL__IN");
	  aDescriptor.setDisplayName("LL__IN");
	  aDescriptor.setShortDescription("LL__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
	  return null;
   }   
   public java.beans.PropertyDescriptor getPRINTER__LTERM1PropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("PRINTER__LTERM1", Class.forName(getBeanClassName()), "getPRINTER__LTERM1", "setPRINTER__LTERM1" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("PRINTER__LTERM1");
	  aDescriptor.setDisplayName("PRINTER__LTERM1");
	  aDescriptor.setShortDescription("PRINTER__LTERM1");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
	  try {
		 java.beans.PropertyDescriptor aDescriptorList[] = {
			getLL__INPropertyDescriptor()
			,getZZ__INPropertyDescriptor()
			,getTRAN__CODE__INPropertyDescriptor()
			,getBADGE__NO__INPropertyDescriptor()
			,getUSER__ACF2__INPropertyDescriptor()
			,getPRINTER__LTERM1PropertyDescriptor()
			,getLADING__NO__INPropertyDescriptor()
		 };
		 return aDescriptorList;
	  } catch (java.lang.Throwable exception) {
		 handleException(exception);
	  }
	  return null;
   }   
   public java.beans.PropertyDescriptor getTRAN__CODE__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__IN", "setTRAN__CODE__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("TRAN__CODE__IN");
	  aDescriptor.setDisplayName("TRAN__CODE__IN");
	  aDescriptor.setShortDescription("TRAN__CODE__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getUSER__ACF2__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("USER__ACF2__IN", Class.forName(getBeanClassName()), "getUSER__ACF2__IN", "setUSER__ACF2__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("USER__ACF2__IN");
	  aDescriptor.setDisplayName("USER__ACF2__IN");
	  aDescriptor.setShortDescription("USER__ACF2__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
	  throws java.beans.IntrospectionException
   {
	  java.beans.PropertyDescriptor aDescriptor = null;
	  try {
		 aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
	  } catch (java.lang.ClassNotFoundException exception) {
		 handleException(exception);
	  }

	  aDescriptor.setBound(true);
	  aDescriptor.setName("ZZ__IN");
	  aDescriptor.setDisplayName("ZZ__IN");
	  aDescriptor.setShortDescription("ZZ__IN");
	  aDescriptor.setHidden(false);
	  aDescriptor.setExpert(false);
	  return aDescriptor;
   }   
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }   
}
