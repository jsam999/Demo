package cat.cis.poms.bol.ims;

//
//
// FILE NAME: AK0B51InMsgInfo.java
// Generated from C:\9070b51.ccp COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B51InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This class defines a shared dynamic record type definition.
   */
   public class AK0B51InMsgInfo_LADING__NO__TABLE__IN extends CobolDynamicRecordType
   {
	  /**
	  *  This ctor defines the record type (its content).
	  */
	  public AK0B51InMsgInfo_LADING__NO__TABLE__IN () throws RecordException
	  {
		 int[] arraySize = new int[1];
		 ArrayField arrField = null;

		 arraySize[0] = 25;
		 arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(10):DISPLAY")), "LADING__NO__IN", new CobolInitialValueObject(" ", null));
		 addField(arrField);

	  }
   }
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B51InMsgInfo () throws RecordException
   {
	  int[] arraySize = new int[1];
	  ArrayField arrField = null;

	  addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

	  addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(05):DISPLAY"), "BADGE__NO__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(07):DISPLAY"), "USER__ACF2__IN", new CobolInitialValueObject(" ", null)));

	  addField(new Field(new CobolType("X(08):DISPLAY"), "PRINTER__LTERM1", new CobolInitialValueObject(" ", null)));

	  addField(new NestedRecordField(new AK0B51InMsgInfo_LADING__NO__TABLE__IN(), "LADING__NO__TABLE__IN"));

   }   
}
