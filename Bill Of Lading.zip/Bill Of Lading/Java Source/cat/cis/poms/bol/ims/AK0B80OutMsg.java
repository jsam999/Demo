package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecord;
import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B80OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B80OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B80OutMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B80OutMsg.class,7003));
         this.setBytes(new byte[7003]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getACCT__DEPT__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,131,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getACCT__DIV__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,136,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }
   public java.lang.String getACCT__EXP__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,141,9,0,4,false,false,false,-3,0,"X(04)",false,true);
   }
   public java.lang.String getACCT__FAC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,129,9,0,2,false,false,false,-1,0,"XX",false,true);
   }
   public java.lang.String getACCT__ORDER__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,145,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getACCT__SEC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,139,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__CITY__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,289,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getADR__COUNTRY__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,331,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,159,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getADR__NM__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,184,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__POSTAL__ZONE__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,321,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getADR__STATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,319,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getADR__TXT__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,219,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getADR__TXT__LN2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,254,9,0,35,false,false,false,-34,0,"X(35)",false,true);
   }
   public java.lang.String getAUTH__EMER__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1605,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getBLDG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getBOL__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCARGO__DESC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,526,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getCARRIER__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,568,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }
   public java.lang.String getCARRIER__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,573,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getCLRN__LTR__FILE__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,91,9,0,15,false,false,false,-14,0,"X(15)",false,true);
   }
   public java.lang.String getCLRN__LTR__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,106,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCOMMITTED__DATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,489,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }
   public java.lang.String getCOMPANY__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1603,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }
   public java.lang.String getCONSIGNEE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,116,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getCONTAINER__NO1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,36,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTAINER__NO2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,46,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getCONTR__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1619,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getCONTRACT__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,726,9,0,12,false,false,false,-11,0,"X(12)",false,true);
   }
   public java.lang.String getDEL__INST__LN1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,333,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,363,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN3__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,393,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN4__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,423,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__INST__LN5__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,453,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getDEL__TO__LOC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,547,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }
   public java.lang.String getDEST__CITY__STATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1592,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getDESTINATION__CITY__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,82,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getDLR__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,122,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getDOCK__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getEQUIP__TYPE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,89,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getERROR__MSG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6953,9,0,50,false,false,false,-49,0,"X(50)",false,true);
   }
   public java.lang.String getEXP__CARRIER__ABBR__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,640,9,0,15,false,false,false,-14,0,"X(15)",false,true);
   }
   public java.lang.String getEXP__CARRIER__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,634,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getEXPORT__TO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,505,9,0,20,false,false,false,-19,0,"X(20)",false,true);
   }
   public java.lang.String getFAC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getFill_0()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,719,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public double getFRT__CHRG__TOTAL__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,1577,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
   }
   public java.lang.String getINLAND__FRT__CHRG__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,128,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getISSUE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getLD__WIDE__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1620,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public short getLL__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public java.lang.String getLTL__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,525,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getMANUAL__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,717,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.bol.ims.AK0B80OutMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public java.lang.String getMISC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,152,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public AK0B80OutMsg_NOTES__BREAKDOWN[] getNOTES__BREAKDOWN()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         AK0B80OutMsg_NOTES__BREAKDOWN[] returnArray = new AK0B80OutMsg_NOTES__BREAKDOWN[30];
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 5423 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            CustomRecordType elementRecordType = new CustomRecordType(AK0B80OutMsg_NOTES__BREAKDOWN.class,elementSize);
            CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
            byte[] bytes = new byte[elementSize];
            System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
            element.setBytes (bytes);
            returnArray[i0] = (AK0B80OutMsg_NOTES__BREAKDOWN)element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public AK0B80OutMsg_NOTES__BREAKDOWN getNOTES__BREAKDOWN(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         int offset = 5423 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         CustomRecordType returnRecordType = new CustomRecordType(AK0B80OutMsg_NOTES__BREAKDOWN.class,elementSize);
         CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
         byte[] bytes = new byte[elementSize];
         System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
         returnRecord.setBytes (bytes);
         return ((AK0B80OutMsg_NOTES__BREAKDOWN)returnRecord);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getORDER__ANALYST__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,544,9,0,3,false,false,false,-2,0,"XXX",false,true);
   }
   public java.lang.String getORIGIN__CITY__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,56,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getORIGIN__CITY__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,18,false,false,false,-17,0,"X(18)",false,true);
   }
   public java.lang.String getORIGIN__CITY__STATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1586,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getORIGIN__STATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,80,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getPIER__AIRPORT__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,655,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getPORT__OF__EXIT__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,603,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getPORT__OF__EXIT__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,609,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getPRINT__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,716,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getSAILING__DATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,710,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getSEAL__NO1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getSEAL__NO2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,29,9,0,7,false,false,false,-6,0,"X(07)",false,true);
   }
   public java.lang.String getSHIP__IND__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,718,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getSHIP__VIA__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,88,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getSHIPPED__DATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,497,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }
   public AK0B80OutMsg_SHIPPING__CHARGES[] getSHIPPING__CHARGES()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         AK0B80OutMsg_SHIPPING__CHARGES[] returnArray = new AK0B80OutMsg_SHIPPING__CHARGES[10];
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 747 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            CustomRecordType elementRecordType = new CustomRecordType(AK0B80OutMsg_SHIPPING__CHARGES.class,elementSize);
            CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
            byte[] bytes = new byte[elementSize];
            System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
            element.setBytes (bytes);
            returnArray[i0] = (AK0B80OutMsg_SHIPPING__CHARGES)element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public AK0B80OutMsg_SHIPPING__CHARGES getSHIPPING__CHARGES(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         int offset = 747 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         CustomRecordType returnRecordType = new CustomRecordType(AK0B80OutMsg_SHIPPING__CHARGES.class,elementSize);
         CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
         byte[] bytes = new byte[elementSize];
         System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
         returnRecord.setBytes (bytes);
         return ((AK0B80OutMsg_SHIPPING__CHARGES)returnRecord);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSTCC__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,738,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public java.lang.String[] getSTOPOVER__LOC__OUT()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         java.lang.String[] returnArray = new java.lang.String[4];
         int[] dim = {4};
         for(int i0=0;i0<4;i0++) {
            int offset = 552 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,4,false,false,false,-3,0,"X(4)",false,true);
            returnArray[i0] = element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSTOPOVER__LOC__OUT(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         int offset = 552 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getSUPP__DLR__FAC__CD__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1607,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getTOTAL__WEIGHT__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,483,9,0,6,false,false,false,-5,0,"X(6)",false,true);
   }
   public java.lang.String getTRAILER__ABBR__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1621,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getTRAN__TYPE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1606,9,0,1,false,false,false,0,0,"X",false,true);
   }
   public java.lang.String getTRANSP__MILES__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1598,9,0,5,false,false,false,-4,0,"X(5)",false,true);
   }
   public AK0B80OutMsg_VEHICLE__BREAKDOWN[] getVEHICLE__BREAKDOWN()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 76;
         AK0B80OutMsg_VEHICLE__BREAKDOWN[] returnArray = new AK0B80OutMsg_VEHICLE__BREAKDOWN[50];
         int[] dim = {50};
         for(int i0=0;i0<50;i0++) {
            int offset = 1623 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            CustomRecordType elementRecordType = new CustomRecordType(AK0B80OutMsg_VEHICLE__BREAKDOWN.class,elementSize);
            CustomRecord element = (CustomRecord) elementRecordType.newRecord(getRecordAttributes(),0,0);
            byte[] bytes = new byte[elementSize];
            System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
            element.setBytes (bytes);
            returnArray[i0] = (AK0B80OutMsg_VEHICLE__BREAKDOWN)element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public AK0B80OutMsg_VEHICLE__BREAKDOWN getVEHICLE__BREAKDOWN(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 76;
         int[] dim = {50};
         int offset = 1623 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         CustomRecordType returnRecordType = new CustomRecordType(AK0B80OutMsg_VEHICLE__BREAKDOWN.class,elementSize);
         CustomRecord returnRecord = (CustomRecord) returnRecordType.newRecord(getRecordAttributes(),0,0);
         byte[] bytes = new byte[elementSize];
         System.arraycopy (getBytes(), offset, bytes, 0, elementSize);
         returnRecord.setBytes (bytes);
         return ((AK0B80OutMsg_VEHICLE__BREAKDOWN)returnRecord);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getVESSEL__NAME__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,685,9,0,25,false,false,false,-24,0,"X(25)",false,true);
   }
   public java.lang.String getWT__SEQ__CD__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1617,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }
   public short getZZ__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__OUT",null,getLL__OUT());
         firePropertyChange("ZZ__OUT",null,getZZ__OUT());
         firePropertyChange("FAC__OUT",null,getFAC__OUT());
         firePropertyChange("BLDG__OUT",null,getBLDG__OUT());
         firePropertyChange("DOCK__OUT",null,getDOCK__OUT());
         firePropertyChange("BOL__NO__OUT",null,getBOL__NO__OUT());
         firePropertyChange("ISSUE__OUT",null,getISSUE__OUT());
         firePropertyChange("SEAL__NO1__OUT",null,getSEAL__NO1__OUT());
         firePropertyChange("SEAL__NO2__OUT",null,getSEAL__NO2__OUT());
         firePropertyChange("CONTAINER__NO1__OUT",null,getCONTAINER__NO1__OUT());
         firePropertyChange("CONTAINER__NO2__OUT",null,getCONTAINER__NO2__OUT());
         firePropertyChange("ORIGIN__CITY__CODE__OUT",null,getORIGIN__CITY__CODE__OUT());
         firePropertyChange("ORIGIN__CITY__NAME__OUT",null,getORIGIN__CITY__NAME__OUT());
         firePropertyChange("ORIGIN__STATE__OUT",null,getORIGIN__STATE__OUT());
         firePropertyChange("DESTINATION__CITY__CODE__OUT",null,getDESTINATION__CITY__CODE__OUT());
         firePropertyChange("SHIP__VIA__OUT",null,getSHIP__VIA__OUT());
         firePropertyChange("EQUIP__TYPE__OUT",null,getEQUIP__TYPE__OUT());
         firePropertyChange("CLRN__LTR__FILE__NO__OUT",null,getCLRN__LTR__FILE__NO__OUT());
         firePropertyChange("CLRN__LTR__NO__OUT",null,getCLRN__LTR__NO__OUT());
         firePropertyChange("CONSIGNEE__OUT",null,getCONSIGNEE__OUT());
         firePropertyChange("DLR__CODE__OUT",null,getDLR__CODE__OUT());
         firePropertyChange("INLAND__FRT__CHRG__CODE__OUT",null,getINLAND__FRT__CHRG__CODE__OUT());
         firePropertyChange("ACCT__FAC__OUT",null,getACCT__FAC__OUT());
         firePropertyChange("ACCT__DEPT__OUT",null,getACCT__DEPT__OUT());
         firePropertyChange("ACCT__DIV__OUT",null,getACCT__DIV__OUT());
         firePropertyChange("ACCT__SEC__OUT",null,getACCT__SEC__OUT());
         firePropertyChange("ACCT__EXP__OUT",null,getACCT__EXP__OUT());
         firePropertyChange("ACCT__ORDER__NO__OUT",null,getACCT__ORDER__NO__OUT());
         firePropertyChange("MISC__OUT",null,getMISC__OUT());
         firePropertyChange("ADR__NAME__OUT",null,getADR__NAME__OUT());
         firePropertyChange("ADR__NM__LN1__OUT",null,getADR__NM__LN1__OUT());
         firePropertyChange("ADR__TXT__LN1__OUT",null,getADR__TXT__LN1__OUT());
         firePropertyChange("ADR__TXT__LN2__OUT",null,getADR__TXT__LN2__OUT());
         firePropertyChange("ADR__CITY__NAME__OUT",null,getADR__CITY__NAME__OUT());
         firePropertyChange("ADR__STATE__OUT",null,getADR__STATE__OUT());
         firePropertyChange("ADR__POSTAL__ZONE__CODE__OUT",null,getADR__POSTAL__ZONE__CODE__OUT());
         firePropertyChange("ADR__COUNTRY__OUT",null,getADR__COUNTRY__OUT());
         firePropertyChange("DEL__INST__LN1__OUT",null,getDEL__INST__LN1__OUT());
         firePropertyChange("DEL__INST__LN2__OUT",null,getDEL__INST__LN2__OUT());
         firePropertyChange("DEL__INST__LN3__OUT",null,getDEL__INST__LN3__OUT());
         firePropertyChange("DEL__INST__LN4__OUT",null,getDEL__INST__LN4__OUT());
         firePropertyChange("DEL__INST__LN5__OUT",null,getDEL__INST__LN5__OUT());
         firePropertyChange("TOTAL__WEIGHT__OUT",null,getTOTAL__WEIGHT__OUT());
         firePropertyChange("COMMITTED__DATE__OUT",null,getCOMMITTED__DATE__OUT());
         firePropertyChange("SHIPPED__DATE__OUT",null,getSHIPPED__DATE__OUT());
         firePropertyChange("EXPORT__TO__OUT",null,getEXPORT__TO__OUT());
         firePropertyChange("LTL__IND__OUT",null,getLTL__IND__OUT());
         firePropertyChange("CARGO__DESC__OUT",null,getCARGO__DESC__OUT());
         firePropertyChange("ORDER__ANALYST__OUT",null,getORDER__ANALYST__OUT());
         firePropertyChange("DEL__TO__LOC__OUT",null,getDEL__TO__LOC__OUT());
         firePropertyChange("STOPOVER__LOC__OUT",null,getSTOPOVER__LOC__OUT());
         firePropertyChange("CARRIER__CODE__OUT",null,getCARRIER__CODE__OUT());
         firePropertyChange("CARRIER__NAME__OUT",null,getCARRIER__NAME__OUT());
         firePropertyChange("PORT__OF__EXIT__CODE__OUT",null,getPORT__OF__EXIT__CODE__OUT());
         firePropertyChange("PORT__OF__EXIT__NAME__OUT",null,getPORT__OF__EXIT__NAME__OUT());
         firePropertyChange("EXP__CARRIER__CODE__OUT",null,getEXP__CARRIER__CODE__OUT());
         firePropertyChange("EXP__CARRIER__ABBR__NAME__OUT",null,getEXP__CARRIER__ABBR__NAME__OUT());
         firePropertyChange("PIER__AIRPORT__NAME__OUT",null,getPIER__AIRPORT__NAME__OUT());
         firePropertyChange("VESSEL__NAME__OUT",null,getVESSEL__NAME__OUT());
         firePropertyChange("SAILING__DATE__OUT",null,getSAILING__DATE__OUT());
         firePropertyChange("PRINT__IND__OUT",null,getPRINT__IND__OUT());
         firePropertyChange("MANUAL__IND__OUT",null,getMANUAL__IND__OUT());
         firePropertyChange("SHIP__IND__OUT",null,getSHIP__IND__OUT());
         firePropertyChange("fill_0",null,getFill_0());
         firePropertyChange("CONTRACT__NO__OUT",null,getCONTRACT__NO__OUT());
         firePropertyChange("STCC__CODE__OUT",null,getSTCC__CODE__OUT());
         firePropertyChange("SHIPPING__CHARGES",null,getSHIPPING__CHARGES());
         firePropertyChange("FRT__CHRG__TOTAL__OUT",null,getFRT__CHRG__TOTAL__OUT());
         firePropertyChange("ORIGIN__CITY__STATE__OUT",null,getORIGIN__CITY__STATE__OUT());
         firePropertyChange("DEST__CITY__STATE__OUT",null,getDEST__CITY__STATE__OUT());
         firePropertyChange("TRANSP__MILES__OUT",null,getTRANSP__MILES__OUT());
         firePropertyChange("COMPANY__CODE__OUT",null,getCOMPANY__CODE__OUT());
         firePropertyChange("AUTH__EMER__IND__OUT",null,getAUTH__EMER__IND__OUT());
         firePropertyChange("TRAN__TYPE__OUT",null,getTRAN__TYPE__OUT());
         firePropertyChange("SUPP__DLR__FAC__CD__OUT",null,getSUPP__DLR__FAC__CD__OUT());
         firePropertyChange("WT__SEQ__CD__OUT",null,getWT__SEQ__CD__OUT());
         firePropertyChange("CONTR__IND__OUT",null,getCONTR__IND__OUT());
         firePropertyChange("LD__WIDE__IND__OUT",null,getLD__WIDE__IND__OUT());
         firePropertyChange("TRAILER__ABBR__OUT",null,getTRAILER__ABBR__OUT());
         firePropertyChange("VEHICLE__BREAKDOWN",null,getVEHICLE__BREAKDOWN());
         firePropertyChange("NOTES__BREAKDOWN",null,getNOTES__BREAKDOWN());
         firePropertyChange("ERROR__MSG__OUT",null,getERROR__MSG__OUT());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setACCT__DEPT__OUT(java.lang.String aACCT__DEPT__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__DEPT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,131,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,131,aACCT__DEPT__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("ACCT__DEPT__OUT",oldACCT__DEPT__OUT,aACCT__DEPT__OUT);
      return;
   }
   public void setACCT__DIV__OUT(java.lang.String aACCT__DIV__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__DIV__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,136,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,136,aACCT__DIV__OUT,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      firePropertyChange("ACCT__DIV__OUT",oldACCT__DIV__OUT,aACCT__DIV__OUT);
      return;
   }
   public void setACCT__EXP__OUT(java.lang.String aACCT__EXP__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__EXP__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,141,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,141,aACCT__EXP__OUT,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      firePropertyChange("ACCT__EXP__OUT",oldACCT__EXP__OUT,aACCT__EXP__OUT);
      return;
   }
   public void setACCT__FAC__OUT(java.lang.String aACCT__FAC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__FAC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,129,9,0,2,false,false,false,-1,0,"XX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,129,aACCT__FAC__OUT,9,0,2,false,false,false,-1,0,"XX",false,true);
      firePropertyChange("ACCT__FAC__OUT",oldACCT__FAC__OUT,aACCT__FAC__OUT);
      return;
   }
   public void setACCT__ORDER__NO__OUT(java.lang.String aACCT__ORDER__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__ORDER__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,145,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,145,aACCT__ORDER__NO__OUT,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("ACCT__ORDER__NO__OUT",oldACCT__ORDER__NO__OUT,aACCT__ORDER__NO__OUT);
      return;
   }
   public void setACCT__SEC__OUT(java.lang.String aACCT__SEC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldACCT__SEC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,139,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,139,aACCT__SEC__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ACCT__SEC__OUT",oldACCT__SEC__OUT,aACCT__SEC__OUT);
      return;
   }
   public void setADR__CITY__NAME__OUT(java.lang.String aADR__CITY__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__CITY__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,289,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,289,aADR__CITY__NAME__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("ADR__CITY__NAME__OUT",oldADR__CITY__NAME__OUT,aADR__CITY__NAME__OUT);
      return;
   }
   public void setADR__COUNTRY__OUT(java.lang.String aADR__COUNTRY__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__COUNTRY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,331,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,331,aADR__COUNTRY__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__COUNTRY__OUT",oldADR__COUNTRY__OUT,aADR__COUNTRY__OUT);
      return;
   }
   public void setADR__NAME__OUT(java.lang.String aADR__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,159,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,159,aADR__NAME__OUT,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("ADR__NAME__OUT",oldADR__NAME__OUT,aADR__NAME__OUT);
      return;
   }
   public void setADR__NM__LN1__OUT(java.lang.String aADR__NM__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__NM__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,184,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,184,aADR__NM__LN1__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__NM__LN1__OUT",oldADR__NM__LN1__OUT,aADR__NM__LN1__OUT);
      return;
   }
   public void setADR__POSTAL__ZONE__CODE__OUT(java.lang.String aADR__POSTAL__ZONE__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__POSTAL__ZONE__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,321,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,321,aADR__POSTAL__ZONE__CODE__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("ADR__POSTAL__ZONE__CODE__OUT",oldADR__POSTAL__ZONE__CODE__OUT,aADR__POSTAL__ZONE__CODE__OUT);
      return;
   }
   public void setADR__STATE__OUT(java.lang.String aADR__STATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__STATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,319,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,319,aADR__STATE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ADR__STATE__OUT",oldADR__STATE__OUT,aADR__STATE__OUT);
      return;
   }
   public void setADR__TXT__LN1__OUT(java.lang.String aADR__TXT__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,219,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,219,aADR__TXT__LN1__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN1__OUT",oldADR__TXT__LN1__OUT,aADR__TXT__LN1__OUT);
      return;
   }
   public void setADR__TXT__LN2__OUT(java.lang.String aADR__TXT__LN2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldADR__TXT__LN2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,254,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,254,aADR__TXT__LN2__OUT,9,0,35,false,false,false,-34,0,"X(35)",false,true);
      firePropertyChange("ADR__TXT__LN2__OUT",oldADR__TXT__LN2__OUT,aADR__TXT__LN2__OUT);
      return;
   }
   public void setAUTH__EMER__IND__OUT(java.lang.String aAUTH__EMER__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldAUTH__EMER__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1605,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1605,aAUTH__EMER__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("AUTH__EMER__IND__OUT",oldAUTH__EMER__IND__OUT,aAUTH__EMER__IND__OUT);
      return;
   }
   public void setBLDG__OUT(java.lang.String aBLDG__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldBLDG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6,aBLDG__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("BLDG__OUT",oldBLDG__OUT,aBLDG__OUT);
      return;
   }
   public void setBOL__NO__OUT(java.lang.String aBOL__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldBOL__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aBOL__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("BOL__NO__OUT",oldBOL__NO__OUT,aBOL__NO__OUT);
      return;
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setCARGO__DESC__OUT(java.lang.String aCARGO__DESC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCARGO__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,526,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,526,aCARGO__DESC__OUT,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("CARGO__DESC__OUT",oldCARGO__DESC__OUT,aCARGO__DESC__OUT);
      return;
   }
   public void setCARRIER__CODE__OUT(java.lang.String aCARRIER__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCARRIER__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,568,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,568,aCARRIER__CODE__OUT,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      firePropertyChange("CARRIER__CODE__OUT",oldCARRIER__CODE__OUT,aCARRIER__CODE__OUT);
      return;
   }
   public void setCARRIER__NAME__OUT(java.lang.String aCARRIER__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCARRIER__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,573,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,573,aCARRIER__NAME__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("CARRIER__NAME__OUT",oldCARRIER__NAME__OUT,aCARRIER__NAME__OUT);
      return;
   }
   public void setCLRN__LTR__FILE__NO__OUT(java.lang.String aCLRN__LTR__FILE__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__FILE__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,91,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,91,aCLRN__LTR__FILE__NO__OUT,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      firePropertyChange("CLRN__LTR__FILE__NO__OUT",oldCLRN__LTR__FILE__NO__OUT,aCLRN__LTR__FILE__NO__OUT);
      return;
   }
   public void setCLRN__LTR__NO__OUT(java.lang.String aCLRN__LTR__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCLRN__LTR__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,106,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,106,aCLRN__LTR__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CLRN__LTR__NO__OUT",oldCLRN__LTR__NO__OUT,aCLRN__LTR__NO__OUT);
      return;
   }
   public void setCOMMITTED__DATE__OUT(java.lang.String aCOMMITTED__DATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCOMMITTED__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,489,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,489,aCOMMITTED__DATE__OUT,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      firePropertyChange("COMMITTED__DATE__OUT",oldCOMMITTED__DATE__OUT,aCOMMITTED__DATE__OUT);
      return;
   }
   public void setCOMPANY__CODE__OUT(java.lang.String aCOMPANY__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCOMPANY__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1603,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1603,aCOMPANY__CODE__OUT,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      firePropertyChange("COMPANY__CODE__OUT",oldCOMPANY__CODE__OUT,aCOMPANY__CODE__OUT);
      return;
   }
   public void setCONSIGNEE__OUT(java.lang.String aCONSIGNEE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCONSIGNEE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,116,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,116,aCONSIGNEE__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("CONSIGNEE__OUT",oldCONSIGNEE__OUT,aCONSIGNEE__OUT);
      return;
   }
   public void setCONTAINER__NO1__OUT(java.lang.String aCONTAINER__NO1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NO1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,36,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,36,aCONTAINER__NO1__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NO1__OUT",oldCONTAINER__NO1__OUT,aCONTAINER__NO1__OUT);
      return;
   }
   public void setCONTAINER__NO2__OUT(java.lang.String aCONTAINER__NO2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCONTAINER__NO2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,46,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,46,aCONTAINER__NO2__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("CONTAINER__NO2__OUT",oldCONTAINER__NO2__OUT,aCONTAINER__NO2__OUT);
      return;
   }
   public void setCONTR__IND__OUT(java.lang.String aCONTR__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCONTR__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1619,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1619,aCONTR__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("CONTR__IND__OUT",oldCONTR__IND__OUT,aCONTR__IND__OUT);
      return;
   }
   public void setCONTRACT__NO__OUT(java.lang.String aCONTRACT__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldCONTRACT__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,726,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,726,aCONTRACT__NO__OUT,9,0,12,false,false,false,-11,0,"X(12)",false,true);
      firePropertyChange("CONTRACT__NO__OUT",oldCONTRACT__NO__OUT,aCONTRACT__NO__OUT);
      return;
   }
   public void setDEL__INST__LN1__OUT(java.lang.String aDEL__INST__LN1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,333,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,333,aDEL__INST__LN1__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN1__OUT",oldDEL__INST__LN1__OUT,aDEL__INST__LN1__OUT);
      return;
   }
   public void setDEL__INST__LN2__OUT(java.lang.String aDEL__INST__LN2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,363,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,363,aDEL__INST__LN2__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN2__OUT",oldDEL__INST__LN2__OUT,aDEL__INST__LN2__OUT);
      return;
   }
   public void setDEL__INST__LN3__OUT(java.lang.String aDEL__INST__LN3__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN3__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,393,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,393,aDEL__INST__LN3__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN3__OUT",oldDEL__INST__LN3__OUT,aDEL__INST__LN3__OUT);
      return;
   }
   public void setDEL__INST__LN4__OUT(java.lang.String aDEL__INST__LN4__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN4__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,423,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,423,aDEL__INST__LN4__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN4__OUT",oldDEL__INST__LN4__OUT,aDEL__INST__LN4__OUT);
      return;
   }
   public void setDEL__INST__LN5__OUT(java.lang.String aDEL__INST__LN5__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__INST__LN5__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,453,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,453,aDEL__INST__LN5__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DEL__INST__LN5__OUT",oldDEL__INST__LN5__OUT,aDEL__INST__LN5__OUT);
      return;
   }
   public void setDEL__TO__LOC__OUT(java.lang.String aDEL__TO__LOC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEL__TO__LOC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,547,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,547,aDEL__TO__LOC__OUT,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      firePropertyChange("DEL__TO__LOC__OUT",oldDEL__TO__LOC__OUT,aDEL__TO__LOC__OUT);
      return;
   }
   public void setDEST__CITY__STATE__OUT(java.lang.String aDEST__CITY__STATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDEST__CITY__STATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1592,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1592,aDEST__CITY__STATE__OUT,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("DEST__CITY__STATE__OUT",oldDEST__CITY__STATE__OUT,aDEST__CITY__STATE__OUT);
      return;
   }
   public void setDESTINATION__CITY__CODE__OUT(java.lang.String aDESTINATION__CITY__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDESTINATION__CITY__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,82,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,82,aDESTINATION__CITY__CODE__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("DESTINATION__CITY__CODE__OUT",oldDESTINATION__CITY__CODE__OUT,aDESTINATION__CITY__CODE__OUT);
      return;
   }
   public void setDLR__CODE__OUT(java.lang.String aDLR__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDLR__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,122,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,122,aDLR__CODE__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("DLR__CODE__OUT",oldDLR__CODE__OUT,aDLR__CODE__OUT);
      return;
   }
   public void setDOCK__OUT(java.lang.String aDOCK__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDOCK__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,8,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,8,aDOCK__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("DOCK__OUT",oldDOCK__OUT,aDOCK__OUT);
      return;
   }
   public void setEQUIP__TYPE__OUT(java.lang.String aEQUIP__TYPE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldEQUIP__TYPE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,89,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,89,aEQUIP__TYPE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("EQUIP__TYPE__OUT",oldEQUIP__TYPE__OUT,aEQUIP__TYPE__OUT);
      return;
   }
   public void setERROR__MSG__OUT(java.lang.String aERROR__MSG__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldERROR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6953,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6953,aERROR__MSG__OUT,9,0,50,false,false,false,-49,0,"X(50)",false,true);
      firePropertyChange("ERROR__MSG__OUT",oldERROR__MSG__OUT,aERROR__MSG__OUT);
      return;
   }
   public void setEXP__CARRIER__ABBR__NAME__OUT(java.lang.String aEXP__CARRIER__ABBR__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldEXP__CARRIER__ABBR__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,640,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,640,aEXP__CARRIER__ABBR__NAME__OUT,9,0,15,false,false,false,-14,0,"X(15)",false,true);
      firePropertyChange("EXP__CARRIER__ABBR__NAME__OUT",oldEXP__CARRIER__ABBR__NAME__OUT,aEXP__CARRIER__ABBR__NAME__OUT);
      return;
   }
   public void setEXP__CARRIER__CODE__OUT(java.lang.String aEXP__CARRIER__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldEXP__CARRIER__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,634,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,634,aEXP__CARRIER__CODE__OUT,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("EXP__CARRIER__CODE__OUT",oldEXP__CARRIER__CODE__OUT,aEXP__CARRIER__CODE__OUT);
      return;
   }
   public void setEXPORT__TO__OUT(java.lang.String aEXPORT__TO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldEXPORT__TO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,505,9,0,20,false,false,false,-19,0,"X(20)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,505,aEXPORT__TO__OUT,9,0,20,false,false,false,-19,0,"X(20)",false,true);
      firePropertyChange("EXPORT__TO__OUT",oldEXPORT__TO__OUT,aEXPORT__TO__OUT);
      return;
   }
   public void setFAC__OUT(java.lang.String aFAC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldFAC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aFAC__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("FAC__OUT",oldFAC__OUT,aFAC__OUT);
      return;
   }
   public void setFill_0(java.lang.String aFill_0)
      throws RecordConversionFailureException {
      java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,719,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,719,aFill_0,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("fill_0",oldFill_0,aFill_0);
      return;
   }
   public void setFRT__CHRG__TOTAL__OUT(double aFRT__CHRG__TOTAL__OUT)
      throws RecordConversionFailureException {
      double oldFRT__CHRG__TOTAL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,1577,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,1577,aFRT__CHRG__TOTAL__OUT,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
      firePropertyChange("FRT__CHRG__TOTAL__OUT",oldFRT__CHRG__TOTAL__OUT,aFRT__CHRG__TOTAL__OUT);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,8, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,20, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,22, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,29, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,36, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,46, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,56, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,62, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,80, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,82, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,88, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,89, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,91, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,106, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,116, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,122, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,128, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,129, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"XX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,131, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,136, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,139, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,141, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,145, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,152, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,159, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,184, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,219, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,254, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,35,false,false,false,-34,0,"X(35)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,289, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,319, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,321, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,331, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,333, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,363, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,393, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,423, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,453, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,483, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,489, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,497, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,505, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,20,false,false,false,-19,0,"X(20)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,525, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,526, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,544, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"XXX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,547, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,552, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,556, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,560, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,564, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,568, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,573, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,603, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,609, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,634, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,640, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,15,false,false,false,-14,0,"X(15)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,655, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,685, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,710, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,716, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,717, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,718, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,719, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,726, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,12,false,false,false,-11,0,"X(12)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,738, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1586, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1592, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1598, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1603, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1605, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1606, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1607, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1617, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1619, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1620, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,1621, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6953, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,50,false,false,false,-49,0,"X(50)",false,true);
      return;
   }
   public void setINLAND__FRT__CHRG__CODE__OUT(java.lang.String aINLAND__FRT__CHRG__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldINLAND__FRT__CHRG__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,128,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,128,aINLAND__FRT__CHRG__CODE__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("INLAND__FRT__CHRG__CODE__OUT",oldINLAND__FRT__CHRG__CODE__OUT,aINLAND__FRT__CHRG__CODE__OUT);
      return;
   }
   public void setISSUE__OUT(java.lang.String aISSUE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldISSUE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,20,aISSUE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ISSUE__OUT",oldISSUE__OUT,aISSUE__OUT);
      return;
   }
   public void setLD__WIDE__IND__OUT(java.lang.String aLD__WIDE__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldLD__WIDE__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1620,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1620,aLD__WIDE__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("LD__WIDE__IND__OUT",oldLD__WIDE__IND__OUT,aLD__WIDE__IND__OUT);
      return;
   }
   public void setLL__OUT(short aLL__OUT)
      throws RecordConversionFailureException {
      short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
      return;
   }
   public void setLTL__IND__OUT(java.lang.String aLTL__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldLTL__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,525,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,525,aLTL__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("LTL__IND__OUT",oldLTL__IND__OUT,aLTL__IND__OUT);
      return;
   }
   public void setMANUAL__IND__OUT(java.lang.String aMANUAL__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldMANUAL__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,717,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,717,aMANUAL__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("MANUAL__IND__OUT",oldMANUAL__IND__OUT,aMANUAL__IND__OUT);
      return;
   }
   public void setMISC__OUT(java.lang.String aMISC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldMISC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,152,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,152,aMISC__OUT,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("MISC__OUT",oldMISC__OUT,aMISC__OUT);
      return;
   }
   public void setNOTES__BREAKDOWN(AK0B80OutMsg_NOTES__BREAKDOWN[] aNOTES__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         for(int i0=0;i0<30;i0++) {
            int offset = 5423 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            byte[] recordBytes = getBytes();
            byte[] fieldBytes = aNOTES__BREAKDOWN[i0].getBytes();
            System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
            setBytes(recordBytes);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setNOTES__BREAKDOWN(int index, AK0B80OutMsg_NOTES__BREAKDOWN aNOTES__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 51;
         int[] dim = {30};
         int offset = 5423 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         byte[] recordBytes = getBytes();
         byte[] fieldBytes = aNOTES__BREAKDOWN.getBytes();
         System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
         setBytes(recordBytes);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setORDER__ANALYST__OUT(java.lang.String aORDER__ANALYST__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldORDER__ANALYST__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,544,9,0,3,false,false,false,-2,0,"XXX",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,544,aORDER__ANALYST__OUT,9,0,3,false,false,false,-2,0,"XXX",false,true);
      firePropertyChange("ORDER__ANALYST__OUT",oldORDER__ANALYST__OUT,aORDER__ANALYST__OUT);
      return;
   }
   public void setORIGIN__CITY__CODE__OUT(java.lang.String aORIGIN__CITY__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,56,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,56,aORIGIN__CITY__CODE__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("ORIGIN__CITY__CODE__OUT",oldORIGIN__CITY__CODE__OUT,aORIGIN__CITY__CODE__OUT);
      return;
   }
   public void setORIGIN__CITY__NAME__OUT(java.lang.String aORIGIN__CITY__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,62,aORIGIN__CITY__NAME__OUT,9,0,18,false,false,false,-17,0,"X(18)",false,true);
      firePropertyChange("ORIGIN__CITY__NAME__OUT",oldORIGIN__CITY__NAME__OUT,aORIGIN__CITY__NAME__OUT);
      return;
   }
   public void setORIGIN__CITY__STATE__OUT(java.lang.String aORIGIN__CITY__STATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__CITY__STATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1586,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1586,aORIGIN__CITY__STATE__OUT,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("ORIGIN__CITY__STATE__OUT",oldORIGIN__CITY__STATE__OUT,aORIGIN__CITY__STATE__OUT);
      return;
   }
   public void setORIGIN__STATE__OUT(java.lang.String aORIGIN__STATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldORIGIN__STATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,80,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,80,aORIGIN__STATE__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("ORIGIN__STATE__OUT",oldORIGIN__STATE__OUT,aORIGIN__STATE__OUT);
      return;
   }
   public void setPIER__AIRPORT__NAME__OUT(java.lang.String aPIER__AIRPORT__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPIER__AIRPORT__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,655,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,655,aPIER__AIRPORT__NAME__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("PIER__AIRPORT__NAME__OUT",oldPIER__AIRPORT__NAME__OUT,aPIER__AIRPORT__NAME__OUT);
      return;
   }
   public void setPORT__OF__EXIT__CODE__OUT(java.lang.String aPORT__OF__EXIT__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPORT__OF__EXIT__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,603,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,603,aPORT__OF__EXIT__CODE__OUT,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("PORT__OF__EXIT__CODE__OUT",oldPORT__OF__EXIT__CODE__OUT,aPORT__OF__EXIT__CODE__OUT);
      return;
   }
   public void setPORT__OF__EXIT__NAME__OUT(java.lang.String aPORT__OF__EXIT__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPORT__OF__EXIT__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,609,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,609,aPORT__OF__EXIT__NAME__OUT,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("PORT__OF__EXIT__NAME__OUT",oldPORT__OF__EXIT__NAME__OUT,aPORT__OF__EXIT__NAME__OUT);
      return;
   }
   public void setPRINT__IND__OUT(java.lang.String aPRINT__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPRINT__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,716,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,716,aPRINT__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("PRINT__IND__OUT",oldPRINT__IND__OUT,aPRINT__IND__OUT);
      return;
   }
   public void setSAILING__DATE__OUT(java.lang.String aSAILING__DATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSAILING__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,710,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,710,aSAILING__DATE__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("SAILING__DATE__OUT",oldSAILING__DATE__OUT,aSAILING__DATE__OUT);
      return;
   }
   public void setSEAL__NO1__OUT(java.lang.String aSEAL__NO1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,22,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,22,aSEAL__NO1__OUT,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO1__OUT",oldSEAL__NO1__OUT,aSEAL__NO1__OUT);
      return;
   }
   public void setSEAL__NO2__OUT(java.lang.String aSEAL__NO2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSEAL__NO2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,29,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,29,aSEAL__NO2__OUT,9,0,7,false,false,false,-6,0,"X(07)",false,true);
      firePropertyChange("SEAL__NO2__OUT",oldSEAL__NO2__OUT,aSEAL__NO2__OUT);
      return;
   }
   public void setSHIP__IND__OUT(java.lang.String aSHIP__IND__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSHIP__IND__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,718,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,718,aSHIP__IND__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("SHIP__IND__OUT",oldSHIP__IND__OUT,aSHIP__IND__OUT);
      return;
   }
   public void setSHIP__VIA__OUT(java.lang.String aSHIP__VIA__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSHIP__VIA__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,88,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,88,aSHIP__VIA__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("SHIP__VIA__OUT",oldSHIP__VIA__OUT,aSHIP__VIA__OUT);
      return;
   }
   public void setSHIPPED__DATE__OUT(java.lang.String aSHIPPED__DATE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSHIPPED__DATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,497,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,497,aSHIPPED__DATE__OUT,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      firePropertyChange("SHIPPED__DATE__OUT",oldSHIPPED__DATE__OUT,aSHIPPED__DATE__OUT);
      return;
   }
   public void setSHIPPING__CHARGES(AK0B80OutMsg_SHIPPING__CHARGES[] aSHIPPING__CHARGES)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         for(int i0=0;i0<10;i0++) {
            int offset = 747 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            byte[] recordBytes = getBytes();
            byte[] fieldBytes = aSHIPPING__CHARGES[i0].getBytes();
            System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
            setBytes(recordBytes);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSHIPPING__CHARGES(int index, AK0B80OutMsg_SHIPPING__CHARGES aSHIPPING__CHARGES)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 83;
         int[] dim = {10};
         int offset = 747 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         byte[] recordBytes = getBytes();
         byte[] fieldBytes = aSHIPPING__CHARGES.getBytes();
         System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
         setBytes(recordBytes);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSTCC__CODE__OUT(java.lang.String aSTCC__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSTCC__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,738,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,738,aSTCC__CODE__OUT,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("STCC__CODE__OUT",oldSTCC__CODE__OUT,aSTCC__CODE__OUT);
      return;
   }
   public void setSTOPOVER__LOC__OUT(java.lang.String[] aSTOPOVER__LOC__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         for(int i0=0;i0<4;i0++) {
            int offset = 552 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSTOPOVER__LOC__OUT[i0],9,0,4,false,false,false,-3,0,"X(4)",false,true);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSTOPOVER__LOC__OUT(int index, java.lang.String aSTOPOVER__LOC__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 4;
         int[] dim = {4};
         int offset = 552 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aSTOPOVER__LOC__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setSUPP__DLR__FAC__CD__OUT(java.lang.String aSUPP__DLR__FAC__CD__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldSUPP__DLR__FAC__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1607,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1607,aSUPP__DLR__FAC__CD__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("SUPP__DLR__FAC__CD__OUT",oldSUPP__DLR__FAC__CD__OUT,aSUPP__DLR__FAC__CD__OUT);
      return;
   }
   public void setTOTAL__WEIGHT__OUT(java.lang.String aTOTAL__WEIGHT__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldTOTAL__WEIGHT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,483,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,483,aTOTAL__WEIGHT__OUT,9,0,6,false,false,false,-5,0,"X(6)",false,true);
      firePropertyChange("TOTAL__WEIGHT__OUT",oldTOTAL__WEIGHT__OUT,aTOTAL__WEIGHT__OUT);
      return;
   }
   public void setTRAILER__ABBR__OUT(java.lang.String aTRAILER__ABBR__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldTRAILER__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1621,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1621,aTRAILER__ABBR__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("TRAILER__ABBR__OUT",oldTRAILER__ABBR__OUT,aTRAILER__ABBR__OUT);
      return;
   }
   public void setTRAN__TYPE__OUT(java.lang.String aTRAN__TYPE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__TYPE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1606,9,0,1,false,false,false,0,0,"X",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1606,aTRAN__TYPE__OUT,9,0,1,false,false,false,0,0,"X",false,true);
      firePropertyChange("TRAN__TYPE__OUT",oldTRAN__TYPE__OUT,aTRAN__TYPE__OUT);
      return;
   }
   public void setTRANSP__MILES__OUT(java.lang.String aTRANSP__MILES__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldTRANSP__MILES__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1598,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1598,aTRANSP__MILES__OUT,9,0,5,false,false,false,-4,0,"X(5)",false,true);
      firePropertyChange("TRANSP__MILES__OUT",oldTRANSP__MILES__OUT,aTRANSP__MILES__OUT);
      return;
   }
   public void setVEHICLE__BREAKDOWN(AK0B80OutMsg_VEHICLE__BREAKDOWN[] aVEHICLE__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 76;
         int[] dim = {50};
         for(int i0=0;i0<50;i0++) {
            int offset = 1623 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            byte[] recordBytes = getBytes();
            byte[] fieldBytes = aVEHICLE__BREAKDOWN[i0].getBytes();
            System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
            setBytes(recordBytes);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setVEHICLE__BREAKDOWN(int index, AK0B80OutMsg_VEHICLE__BREAKDOWN aVEHICLE__BREAKDOWN)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 76;
         int[] dim = {50};
         int offset = 1623 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         byte[] recordBytes = getBytes();
         byte[] fieldBytes = aVEHICLE__BREAKDOWN.getBytes();
         System.arraycopy(fieldBytes,0,recordBytes,offset,fieldBytes.length);
         setBytes(recordBytes);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setVESSEL__NAME__OUT(java.lang.String aVESSEL__NAME__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldVESSEL__NAME__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,685,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,685,aVESSEL__NAME__OUT,9,0,25,false,false,false,-24,0,"X(25)",false,true);
      firePropertyChange("VESSEL__NAME__OUT",oldVESSEL__NAME__OUT,aVESSEL__NAME__OUT);
      return;
   }
   public void setWT__SEQ__CD__OUT(java.lang.String aWT__SEQ__CD__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldWT__SEQ__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,1617,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,1617,aWT__SEQ__CD__OUT,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      firePropertyChange("WT__SEQ__CD__OUT",oldWT__SEQ__CD__OUT,aWT__SEQ__CD__OUT);
      return;
   }
   public void setZZ__OUT(short aZZ__OUT)
      throws RecordConversionFailureException {
      short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
      return;
   }
}
