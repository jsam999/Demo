package cat.cis.poms.bol.ims;

/**
 * Class: cat.cis.poms.bol.ims.AK0B80OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B80OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.PropertyDescriptor getACCT__DEPT__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__DEPT__OUT", Class.forName(getBeanClassName()), "getACCT__DEPT__OUT", "setACCT__DEPT__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__DEPT__OUT");
      aDescriptor.setDisplayName("ACCT__DEPT__OUT");
      aDescriptor.setShortDescription("ACCT__DEPT__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__DIV__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__DIV__OUT", Class.forName(getBeanClassName()), "getACCT__DIV__OUT", "setACCT__DIV__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__DIV__OUT");
      aDescriptor.setDisplayName("ACCT__DIV__OUT");
      aDescriptor.setShortDescription("ACCT__DIV__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__EXP__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__EXP__OUT", Class.forName(getBeanClassName()), "getACCT__EXP__OUT", "setACCT__EXP__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__EXP__OUT");
      aDescriptor.setDisplayName("ACCT__EXP__OUT");
      aDescriptor.setShortDescription("ACCT__EXP__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__FAC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__FAC__OUT", Class.forName(getBeanClassName()), "getACCT__FAC__OUT", "setACCT__FAC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__FAC__OUT");
      aDescriptor.setDisplayName("ACCT__FAC__OUT");
      aDescriptor.setShortDescription("ACCT__FAC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__ORDER__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__ORDER__NO__OUT", Class.forName(getBeanClassName()), "getACCT__ORDER__NO__OUT", "setACCT__ORDER__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__ORDER__NO__OUT");
      aDescriptor.setDisplayName("ACCT__ORDER__NO__OUT");
      aDescriptor.setShortDescription("ACCT__ORDER__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getACCT__SEC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACCT__SEC__OUT", Class.forName(getBeanClassName()), "getACCT__SEC__OUT", "setACCT__SEC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACCT__SEC__OUT");
      aDescriptor.setDisplayName("ACCT__SEC__OUT");
      aDescriptor.setShortDescription("ACCT__SEC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public java.beans.PropertyDescriptor getADR__CITY__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__CITY__NAME__OUT", Class.forName(getBeanClassName()), "getADR__CITY__NAME__OUT", "setADR__CITY__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__CITY__NAME__OUT");
      aDescriptor.setDisplayName("ADR__CITY__NAME__OUT");
      aDescriptor.setShortDescription("ADR__CITY__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__COUNTRY__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__COUNTRY__OUT", Class.forName(getBeanClassName()), "getADR__COUNTRY__OUT", "setADR__COUNTRY__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__COUNTRY__OUT");
      aDescriptor.setDisplayName("ADR__COUNTRY__OUT");
      aDescriptor.setShortDescription("ADR__COUNTRY__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NAME__OUT", Class.forName(getBeanClassName()), "getADR__NAME__OUT", "setADR__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NAME__OUT");
      aDescriptor.setDisplayName("ADR__NAME__OUT");
      aDescriptor.setShortDescription("ADR__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__NM__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__NM__LN1__OUT", Class.forName(getBeanClassName()), "getADR__NM__LN1__OUT", "setADR__NM__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__NM__LN1__OUT");
      aDescriptor.setDisplayName("ADR__NM__LN1__OUT");
      aDescriptor.setShortDescription("ADR__NM__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__POSTAL__ZONE__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__POSTAL__ZONE__CODE__OUT", Class.forName(getBeanClassName()), "getADR__POSTAL__ZONE__CODE__OUT", "setADR__POSTAL__ZONE__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setDisplayName("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setShortDescription("ADR__POSTAL__ZONE__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__STATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__STATE__OUT", Class.forName(getBeanClassName()), "getADR__STATE__OUT", "setADR__STATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__STATE__OUT");
      aDescriptor.setDisplayName("ADR__STATE__OUT");
      aDescriptor.setShortDescription("ADR__STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN1__OUT", Class.forName(getBeanClassName()), "getADR__TXT__LN1__OUT", "setADR__TXT__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN1__OUT");
      aDescriptor.setDisplayName("ADR__TXT__LN1__OUT");
      aDescriptor.setShortDescription("ADR__TXT__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getADR__TXT__LN2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ADR__TXT__LN2__OUT", Class.forName(getBeanClassName()), "getADR__TXT__LN2__OUT", "setADR__TXT__LN2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ADR__TXT__LN2__OUT");
      aDescriptor.setDisplayName("ADR__TXT__LN2__OUT");
      aDescriptor.setShortDescription("ADR__TXT__LN2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getAUTH__EMER__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("AUTH__EMER__IND__OUT", Class.forName(getBeanClassName()), "getAUTH__EMER__IND__OUT", "setAUTH__EMER__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("AUTH__EMER__IND__OUT");
      aDescriptor.setDisplayName("AUTH__EMER__IND__OUT");
      aDescriptor.setShortDescription("AUTH__EMER__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.bol.ims.AK0B80OutMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.bol.ims.AK0B80OutMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.bol.ims.AK0B80OutMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBLDG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BLDG__OUT", Class.forName(getBeanClassName()), "getBLDG__OUT", "setBLDG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BLDG__OUT");
      aDescriptor.setDisplayName("BLDG__OUT");
      aDescriptor.setShortDescription("BLDG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getBOL__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("BOL__NO__OUT", Class.forName(getBeanClassName()), "getBOL__NO__OUT", "setBOL__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("BOL__NO__OUT");
      aDescriptor.setDisplayName("BOL__NO__OUT");
      aDescriptor.setShortDescription("BOL__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARGO__DESC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARGO__DESC__OUT", Class.forName(getBeanClassName()), "getCARGO__DESC__OUT", "setCARGO__DESC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARGO__DESC__OUT");
      aDescriptor.setDisplayName("CARGO__DESC__OUT");
      aDescriptor.setShortDescription("CARGO__DESC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARRIER__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARRIER__CODE__OUT", Class.forName(getBeanClassName()), "getCARRIER__CODE__OUT", "setCARRIER__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARRIER__CODE__OUT");
      aDescriptor.setDisplayName("CARRIER__CODE__OUT");
      aDescriptor.setShortDescription("CARRIER__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCARRIER__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CARRIER__NAME__OUT", Class.forName(getBeanClassName()), "getCARRIER__NAME__OUT", "setCARRIER__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CARRIER__NAME__OUT");
      aDescriptor.setDisplayName("CARRIER__NAME__OUT");
      aDescriptor.setShortDescription("CARRIER__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__FILE__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__FILE__NO__OUT", Class.forName(getBeanClassName()), "getCLRN__LTR__FILE__NO__OUT", "setCLRN__LTR__FILE__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__FILE__NO__OUT");
      aDescriptor.setDisplayName("CLRN__LTR__FILE__NO__OUT");
      aDescriptor.setShortDescription("CLRN__LTR__FILE__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCLRN__LTR__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CLRN__LTR__NO__OUT", Class.forName(getBeanClassName()), "getCLRN__LTR__NO__OUT", "setCLRN__LTR__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CLRN__LTR__NO__OUT");
      aDescriptor.setDisplayName("CLRN__LTR__NO__OUT");
      aDescriptor.setShortDescription("CLRN__LTR__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCOMMITTED__DATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("COMMITTED__DATE__OUT", Class.forName(getBeanClassName()), "getCOMMITTED__DATE__OUT", "setCOMMITTED__DATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("COMMITTED__DATE__OUT");
      aDescriptor.setDisplayName("COMMITTED__DATE__OUT");
      aDescriptor.setShortDescription("COMMITTED__DATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCOMPANY__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("COMPANY__CODE__OUT", Class.forName(getBeanClassName()), "getCOMPANY__CODE__OUT", "setCOMPANY__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("COMPANY__CODE__OUT");
      aDescriptor.setDisplayName("COMPANY__CODE__OUT");
      aDescriptor.setShortDescription("COMPANY__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONSIGNEE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONSIGNEE__OUT", Class.forName(getBeanClassName()), "getCONSIGNEE__OUT", "setCONSIGNEE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONSIGNEE__OUT");
      aDescriptor.setDisplayName("CONSIGNEE__OUT");
      aDescriptor.setShortDescription("CONSIGNEE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NO1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NO1__OUT", Class.forName(getBeanClassName()), "getCONTAINER__NO1__OUT", "setCONTAINER__NO1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NO1__OUT");
      aDescriptor.setDisplayName("CONTAINER__NO1__OUT");
      aDescriptor.setShortDescription("CONTAINER__NO1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTAINER__NO2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTAINER__NO2__OUT", Class.forName(getBeanClassName()), "getCONTAINER__NO2__OUT", "setCONTAINER__NO2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTAINER__NO2__OUT");
      aDescriptor.setDisplayName("CONTAINER__NO2__OUT");
      aDescriptor.setShortDescription("CONTAINER__NO2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTR__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTR__IND__OUT", Class.forName(getBeanClassName()), "getCONTR__IND__OUT", "setCONTR__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTR__IND__OUT");
      aDescriptor.setDisplayName("CONTR__IND__OUT");
      aDescriptor.setShortDescription("CONTR__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getCONTRACT__NO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("CONTRACT__NO__OUT", Class.forName(getBeanClassName()), "getCONTRACT__NO__OUT", "setCONTRACT__NO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("CONTRACT__NO__OUT");
      aDescriptor.setDisplayName("CONTRACT__NO__OUT");
      aDescriptor.setShortDescription("CONTRACT__NO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN1__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN1__OUT", "setDEL__INST__LN1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN1__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN1__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN2__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN2__OUT", "setDEL__INST__LN2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN2__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN2__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN3__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN3__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN3__OUT", "setDEL__INST__LN3__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN3__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN3__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN3__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN4__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN4__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN4__OUT", "setDEL__INST__LN4__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN4__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN4__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN4__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__INST__LN5__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__INST__LN5__OUT", Class.forName(getBeanClassName()), "getDEL__INST__LN5__OUT", "setDEL__INST__LN5__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__INST__LN5__OUT");
      aDescriptor.setDisplayName("DEL__INST__LN5__OUT");
      aDescriptor.setShortDescription("DEL__INST__LN5__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEL__TO__LOC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEL__TO__LOC__OUT", Class.forName(getBeanClassName()), "getDEL__TO__LOC__OUT", "setDEL__TO__LOC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEL__TO__LOC__OUT");
      aDescriptor.setDisplayName("DEL__TO__LOC__OUT");
      aDescriptor.setShortDescription("DEL__TO__LOC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDEST__CITY__STATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DEST__CITY__STATE__OUT", Class.forName(getBeanClassName()), "getDEST__CITY__STATE__OUT", "setDEST__CITY__STATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DEST__CITY__STATE__OUT");
      aDescriptor.setDisplayName("DEST__CITY__STATE__OUT");
      aDescriptor.setShortDescription("DEST__CITY__STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDESTINATION__CITY__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DESTINATION__CITY__CODE__OUT", Class.forName(getBeanClassName()), "getDESTINATION__CITY__CODE__OUT", "setDESTINATION__CITY__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DESTINATION__CITY__CODE__OUT");
      aDescriptor.setDisplayName("DESTINATION__CITY__CODE__OUT");
      aDescriptor.setShortDescription("DESTINATION__CITY__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDLR__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DLR__CODE__OUT", Class.forName(getBeanClassName()), "getDLR__CODE__OUT", "setDLR__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DLR__CODE__OUT");
      aDescriptor.setDisplayName("DLR__CODE__OUT");
      aDescriptor.setShortDescription("DLR__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getDOCK__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("DOCK__OUT", Class.forName(getBeanClassName()), "getDOCK__OUT", "setDOCK__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("DOCK__OUT");
      aDescriptor.setDisplayName("DOCK__OUT");
      aDescriptor.setShortDescription("DOCK__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEQUIP__TYPE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EQUIP__TYPE__OUT", Class.forName(getBeanClassName()), "getEQUIP__TYPE__OUT", "setEQUIP__TYPE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EQUIP__TYPE__OUT");
      aDescriptor.setDisplayName("EQUIP__TYPE__OUT");
      aDescriptor.setShortDescription("EQUIP__TYPE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getERROR__MSG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ERROR__MSG__OUT", Class.forName(getBeanClassName()), "getERROR__MSG__OUT", "setERROR__MSG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ERROR__MSG__OUT");
      aDescriptor.setDisplayName("ERROR__MSG__OUT");
      aDescriptor.setShortDescription("ERROR__MSG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getEXP__CARRIER__ABBR__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXP__CARRIER__ABBR__NAME__OUT", Class.forName(getBeanClassName()), "getEXP__CARRIER__ABBR__NAME__OUT", "setEXP__CARRIER__ABBR__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXP__CARRIER__ABBR__NAME__OUT");
      aDescriptor.setDisplayName("EXP__CARRIER__ABBR__NAME__OUT");
      aDescriptor.setShortDescription("EXP__CARRIER__ABBR__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEXP__CARRIER__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXP__CARRIER__CODE__OUT", Class.forName(getBeanClassName()), "getEXP__CARRIER__CODE__OUT", "setEXP__CARRIER__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXP__CARRIER__CODE__OUT");
      aDescriptor.setDisplayName("EXP__CARRIER__CODE__OUT");
      aDescriptor.setShortDescription("EXP__CARRIER__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getEXPORT__TO__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("EXPORT__TO__OUT", Class.forName(getBeanClassName()), "getEXPORT__TO__OUT", "setEXPORT__TO__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("EXPORT__TO__OUT");
      aDescriptor.setDisplayName("EXPORT__TO__OUT");
      aDescriptor.setShortDescription("EXPORT__TO__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFAC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FAC__OUT", Class.forName(getBeanClassName()), "getFAC__OUT", "setFAC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FAC__OUT");
      aDescriptor.setDisplayName("FAC__OUT");
      aDescriptor.setShortDescription("FAC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_0");
      aDescriptor.setDisplayName("fill_0");
      aDescriptor.setShortDescription("fill_0");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFRT__CHRG__TOTAL__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FRT__CHRG__TOTAL__OUT", Class.forName(getBeanClassName()), "getFRT__CHRG__TOTAL__OUT", "setFRT__CHRG__TOTAL__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setDisplayName("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setShortDescription("FRT__CHRG__TOTAL__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getINLAND__FRT__CHRG__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("INLAND__FRT__CHRG__CODE__OUT", Class.forName(getBeanClassName()), "getINLAND__FRT__CHRG__CODE__OUT", "setINLAND__FRT__CHRG__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("INLAND__FRT__CHRG__CODE__OUT");
      aDescriptor.setDisplayName("INLAND__FRT__CHRG__CODE__OUT");
      aDescriptor.setShortDescription("INLAND__FRT__CHRG__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getISSUE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ISSUE__OUT", Class.forName(getBeanClassName()), "getISSUE__OUT", "setISSUE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ISSUE__OUT");
      aDescriptor.setDisplayName("ISSUE__OUT");
      aDescriptor.setShortDescription("ISSUE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLD__WIDE__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LD__WIDE__IND__OUT", Class.forName(getBeanClassName()), "getLD__WIDE__IND__OUT", "setLD__WIDE__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LD__WIDE__IND__OUT");
      aDescriptor.setDisplayName("LD__WIDE__IND__OUT");
      aDescriptor.setShortDescription("LD__WIDE__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__OUT");
      aDescriptor.setDisplayName("LL__OUT");
      aDescriptor.setShortDescription("LL__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLTL__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LTL__IND__OUT", Class.forName(getBeanClassName()), "getLTL__IND__OUT", "setLTL__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LTL__IND__OUT");
      aDescriptor.setDisplayName("LTL__IND__OUT");
      aDescriptor.setShortDescription("LTL__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getMANUAL__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("MANUAL__IND__OUT", Class.forName(getBeanClassName()), "getMANUAL__IND__OUT", "setMANUAL__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("MANUAL__IND__OUT");
      aDescriptor.setDisplayName("MANUAL__IND__OUT");
      aDescriptor.setShortDescription("MANUAL__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getMISC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("MISC__OUT", Class.forName(getBeanClassName()), "getMISC__OUT", "setMISC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("MISC__OUT");
      aDescriptor.setDisplayName("MISC__OUT");
      aDescriptor.setShortDescription("MISC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getNOTES__BREAKDOWNPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("NOTES__BREAKDOWN", Class.forName(getBeanClassName()), "getNOTES__BREAKDOWN", "setNOTES__BREAKDOWN", "getNOTES__BREAKDOWN", "setNOTES__BREAKDOWN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("NOTES__BREAKDOWN");
      aDescriptor.setDisplayName("NOTES__BREAKDOWN");
      aDescriptor.setShortDescription("NOTES__BREAKDOWN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORDER__ANALYST__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORDER__ANALYST__OUT", Class.forName(getBeanClassName()), "getORDER__ANALYST__OUT", "setORDER__ANALYST__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORDER__ANALYST__OUT");
      aDescriptor.setDisplayName("ORDER__ANALYST__OUT");
      aDescriptor.setShortDescription("ORDER__ANALYST__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__CODE__OUT", Class.forName(getBeanClassName()), "getORIGIN__CITY__CODE__OUT", "setORIGIN__CITY__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__CODE__OUT");
      aDescriptor.setDisplayName("ORIGIN__CITY__CODE__OUT");
      aDescriptor.setShortDescription("ORIGIN__CITY__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__NAME__OUT", Class.forName(getBeanClassName()), "getORIGIN__CITY__NAME__OUT", "setORIGIN__CITY__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__NAME__OUT");
      aDescriptor.setDisplayName("ORIGIN__CITY__NAME__OUT");
      aDescriptor.setShortDescription("ORIGIN__CITY__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__CITY__STATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__CITY__STATE__OUT", Class.forName(getBeanClassName()), "getORIGIN__CITY__STATE__OUT", "setORIGIN__CITY__STATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__CITY__STATE__OUT");
      aDescriptor.setDisplayName("ORIGIN__CITY__STATE__OUT");
      aDescriptor.setShortDescription("ORIGIN__CITY__STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getORIGIN__STATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ORIGIN__STATE__OUT", Class.forName(getBeanClassName()), "getORIGIN__STATE__OUT", "setORIGIN__STATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ORIGIN__STATE__OUT");
      aDescriptor.setDisplayName("ORIGIN__STATE__OUT");
      aDescriptor.setShortDescription("ORIGIN__STATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPIER__AIRPORT__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PIER__AIRPORT__NAME__OUT", Class.forName(getBeanClassName()), "getPIER__AIRPORT__NAME__OUT", "setPIER__AIRPORT__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PIER__AIRPORT__NAME__OUT");
      aDescriptor.setDisplayName("PIER__AIRPORT__NAME__OUT");
      aDescriptor.setShortDescription("PIER__AIRPORT__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPORT__OF__EXIT__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PORT__OF__EXIT__CODE__OUT", Class.forName(getBeanClassName()), "getPORT__OF__EXIT__CODE__OUT", "setPORT__OF__EXIT__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PORT__OF__EXIT__CODE__OUT");
      aDescriptor.setDisplayName("PORT__OF__EXIT__CODE__OUT");
      aDescriptor.setShortDescription("PORT__OF__EXIT__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPORT__OF__EXIT__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PORT__OF__EXIT__NAME__OUT", Class.forName(getBeanClassName()), "getPORT__OF__EXIT__NAME__OUT", "setPORT__OF__EXIT__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PORT__OF__EXIT__NAME__OUT");
      aDescriptor.setDisplayName("PORT__OF__EXIT__NAME__OUT");
      aDescriptor.setShortDescription("PORT__OF__EXIT__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getPRINT__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("PRINT__IND__OUT", Class.forName(getBeanClassName()), "getPRINT__IND__OUT", "setPRINT__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("PRINT__IND__OUT");
      aDescriptor.setDisplayName("PRINT__IND__OUT");
      aDescriptor.setShortDescription("PRINT__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__OUTPropertyDescriptor()
            ,getZZ__OUTPropertyDescriptor()
            ,getFAC__OUTPropertyDescriptor()
            ,getBLDG__OUTPropertyDescriptor()
            ,getDOCK__OUTPropertyDescriptor()
            ,getBOL__NO__OUTPropertyDescriptor()
            ,getISSUE__OUTPropertyDescriptor()
            ,getSEAL__NO1__OUTPropertyDescriptor()
            ,getSEAL__NO2__OUTPropertyDescriptor()
            ,getCONTAINER__NO1__OUTPropertyDescriptor()
            ,getCONTAINER__NO2__OUTPropertyDescriptor()
            ,getORIGIN__CITY__CODE__OUTPropertyDescriptor()
            ,getORIGIN__CITY__NAME__OUTPropertyDescriptor()
            ,getORIGIN__STATE__OUTPropertyDescriptor()
            ,getDESTINATION__CITY__CODE__OUTPropertyDescriptor()
            ,getSHIP__VIA__OUTPropertyDescriptor()
            ,getEQUIP__TYPE__OUTPropertyDescriptor()
            ,getCLRN__LTR__FILE__NO__OUTPropertyDescriptor()
            ,getCLRN__LTR__NO__OUTPropertyDescriptor()
            ,getCONSIGNEE__OUTPropertyDescriptor()
            ,getDLR__CODE__OUTPropertyDescriptor()
            ,getINLAND__FRT__CHRG__CODE__OUTPropertyDescriptor()
            ,getACCT__FAC__OUTPropertyDescriptor()
            ,getACCT__DEPT__OUTPropertyDescriptor()
            ,getACCT__DIV__OUTPropertyDescriptor()
            ,getACCT__SEC__OUTPropertyDescriptor()
            ,getACCT__EXP__OUTPropertyDescriptor()
            ,getACCT__ORDER__NO__OUTPropertyDescriptor()
            ,getMISC__OUTPropertyDescriptor()
            ,getADR__NAME__OUTPropertyDescriptor()
            ,getADR__NM__LN1__OUTPropertyDescriptor()
            ,getADR__TXT__LN1__OUTPropertyDescriptor()
            ,getADR__TXT__LN2__OUTPropertyDescriptor()
            ,getADR__CITY__NAME__OUTPropertyDescriptor()
            ,getADR__STATE__OUTPropertyDescriptor()
            ,getADR__POSTAL__ZONE__CODE__OUTPropertyDescriptor()
            ,getADR__COUNTRY__OUTPropertyDescriptor()
            ,getDEL__INST__LN1__OUTPropertyDescriptor()
            ,getDEL__INST__LN2__OUTPropertyDescriptor()
            ,getDEL__INST__LN3__OUTPropertyDescriptor()
            ,getDEL__INST__LN4__OUTPropertyDescriptor()
            ,getDEL__INST__LN5__OUTPropertyDescriptor()
            ,getTOTAL__WEIGHT__OUTPropertyDescriptor()
            ,getCOMMITTED__DATE__OUTPropertyDescriptor()
            ,getSHIPPED__DATE__OUTPropertyDescriptor()
            ,getEXPORT__TO__OUTPropertyDescriptor()
            ,getLTL__IND__OUTPropertyDescriptor()
            ,getCARGO__DESC__OUTPropertyDescriptor()
            ,getORDER__ANALYST__OUTPropertyDescriptor()
            ,getDEL__TO__LOC__OUTPropertyDescriptor()
            ,getSTOPOVER__LOC__OUTPropertyDescriptor()
            ,getCARRIER__CODE__OUTPropertyDescriptor()
            ,getCARRIER__NAME__OUTPropertyDescriptor()
            ,getPORT__OF__EXIT__CODE__OUTPropertyDescriptor()
            ,getPORT__OF__EXIT__NAME__OUTPropertyDescriptor()
            ,getEXP__CARRIER__CODE__OUTPropertyDescriptor()
            ,getEXP__CARRIER__ABBR__NAME__OUTPropertyDescriptor()
            ,getPIER__AIRPORT__NAME__OUTPropertyDescriptor()
            ,getVESSEL__NAME__OUTPropertyDescriptor()
            ,getSAILING__DATE__OUTPropertyDescriptor()
            ,getPRINT__IND__OUTPropertyDescriptor()
            ,getMANUAL__IND__OUTPropertyDescriptor()
            ,getSHIP__IND__OUTPropertyDescriptor()
            ,getFill_0PropertyDescriptor()
            ,getCONTRACT__NO__OUTPropertyDescriptor()
            ,getSTCC__CODE__OUTPropertyDescriptor()
            ,getSHIPPING__CHARGESPropertyDescriptor()
            ,getFRT__CHRG__TOTAL__OUTPropertyDescriptor()
            ,getORIGIN__CITY__STATE__OUTPropertyDescriptor()
            ,getDEST__CITY__STATE__OUTPropertyDescriptor()
            ,getTRANSP__MILES__OUTPropertyDescriptor()
            ,getCOMPANY__CODE__OUTPropertyDescriptor()
            ,getAUTH__EMER__IND__OUTPropertyDescriptor()
            ,getTRAN__TYPE__OUTPropertyDescriptor()
            ,getSUPP__DLR__FAC__CD__OUTPropertyDescriptor()
            ,getWT__SEQ__CD__OUTPropertyDescriptor()
            ,getCONTR__IND__OUTPropertyDescriptor()
            ,getLD__WIDE__IND__OUTPropertyDescriptor()
            ,getTRAILER__ABBR__OUTPropertyDescriptor()
            ,getVEHICLE__BREAKDOWNPropertyDescriptor()
            ,getNOTES__BREAKDOWNPropertyDescriptor()
            ,getERROR__MSG__OUTPropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getSAILING__DATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SAILING__DATE__OUT", Class.forName(getBeanClassName()), "getSAILING__DATE__OUT", "setSAILING__DATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SAILING__DATE__OUT");
      aDescriptor.setDisplayName("SAILING__DATE__OUT");
      aDescriptor.setShortDescription("SAILING__DATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO1__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO1__OUT", Class.forName(getBeanClassName()), "getSEAL__NO1__OUT", "setSEAL__NO1__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO1__OUT");
      aDescriptor.setDisplayName("SEAL__NO1__OUT");
      aDescriptor.setShortDescription("SEAL__NO1__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSEAL__NO2__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SEAL__NO2__OUT", Class.forName(getBeanClassName()), "getSEAL__NO2__OUT", "setSEAL__NO2__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SEAL__NO2__OUT");
      aDescriptor.setDisplayName("SEAL__NO2__OUT");
      aDescriptor.setShortDescription("SEAL__NO2__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIP__IND__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SHIP__IND__OUT", Class.forName(getBeanClassName()), "getSHIP__IND__OUT", "setSHIP__IND__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIP__IND__OUT");
      aDescriptor.setDisplayName("SHIP__IND__OUT");
      aDescriptor.setShortDescription("SHIP__IND__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIP__VIA__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SHIP__VIA__OUT", Class.forName(getBeanClassName()), "getSHIP__VIA__OUT", "setSHIP__VIA__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIP__VIA__OUT");
      aDescriptor.setDisplayName("SHIP__VIA__OUT");
      aDescriptor.setShortDescription("SHIP__VIA__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIPPED__DATE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SHIPPED__DATE__OUT", Class.forName(getBeanClassName()), "getSHIPPED__DATE__OUT", "setSHIPPED__DATE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIPPED__DATE__OUT");
      aDescriptor.setDisplayName("SHIPPED__DATE__OUT");
      aDescriptor.setShortDescription("SHIPPED__DATE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSHIPPING__CHARGESPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("SHIPPING__CHARGES", Class.forName(getBeanClassName()), "getSHIPPING__CHARGES", "setSHIPPING__CHARGES", "getSHIPPING__CHARGES", "setSHIPPING__CHARGES" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SHIPPING__CHARGES");
      aDescriptor.setDisplayName("SHIPPING__CHARGES");
      aDescriptor.setShortDescription("SHIPPING__CHARGES");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTCC__CODE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("STCC__CODE__OUT", Class.forName(getBeanClassName()), "getSTCC__CODE__OUT", "setSTCC__CODE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STCC__CODE__OUT");
      aDescriptor.setDisplayName("STCC__CODE__OUT");
      aDescriptor.setShortDescription("STCC__CODE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSTOPOVER__LOC__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("STOPOVER__LOC__OUT", Class.forName(getBeanClassName()), "getSTOPOVER__LOC__OUT", "setSTOPOVER__LOC__OUT", "getSTOPOVER__LOC__OUT", "setSTOPOVER__LOC__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("STOPOVER__LOC__OUT");
      aDescriptor.setDisplayName("STOPOVER__LOC__OUT");
      aDescriptor.setShortDescription("STOPOVER__LOC__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getSUPP__DLR__FAC__CD__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SUPP__DLR__FAC__CD__OUT", Class.forName(getBeanClassName()), "getSUPP__DLR__FAC__CD__OUT", "setSUPP__DLR__FAC__CD__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SUPP__DLR__FAC__CD__OUT");
      aDescriptor.setDisplayName("SUPP__DLR__FAC__CD__OUT");
      aDescriptor.setShortDescription("SUPP__DLR__FAC__CD__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTOTAL__WEIGHT__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TOTAL__WEIGHT__OUT", Class.forName(getBeanClassName()), "getTOTAL__WEIGHT__OUT", "setTOTAL__WEIGHT__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TOTAL__WEIGHT__OUT");
      aDescriptor.setDisplayName("TOTAL__WEIGHT__OUT");
      aDescriptor.setShortDescription("TOTAL__WEIGHT__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAILER__ABBR__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAILER__ABBR__OUT", Class.forName(getBeanClassName()), "getTRAILER__ABBR__OUT", "setTRAILER__ABBR__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAILER__ABBR__OUT");
      aDescriptor.setDisplayName("TRAILER__ABBR__OUT");
      aDescriptor.setShortDescription("TRAILER__ABBR__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__TYPE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__TYPE__OUT", Class.forName(getBeanClassName()), "getTRAN__TYPE__OUT", "setTRAN__TYPE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__TYPE__OUT");
      aDescriptor.setDisplayName("TRAN__TYPE__OUT");
      aDescriptor.setShortDescription("TRAN__TYPE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRANSP__MILES__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRANSP__MILES__OUT", Class.forName(getBeanClassName()), "getTRANSP__MILES__OUT", "setTRANSP__MILES__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRANSP__MILES__OUT");
      aDescriptor.setDisplayName("TRANSP__MILES__OUT");
      aDescriptor.setShortDescription("TRANSP__MILES__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getVEHICLE__BREAKDOWNPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("VEHICLE__BREAKDOWN", Class.forName(getBeanClassName()), "getVEHICLE__BREAKDOWN", "setVEHICLE__BREAKDOWN", "getVEHICLE__BREAKDOWN", "setVEHICLE__BREAKDOWN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("VEHICLE__BREAKDOWN");
      aDescriptor.setDisplayName("VEHICLE__BREAKDOWN");
      aDescriptor.setShortDescription("VEHICLE__BREAKDOWN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getVESSEL__NAME__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("VESSEL__NAME__OUT", Class.forName(getBeanClassName()), "getVESSEL__NAME__OUT", "setVESSEL__NAME__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("VESSEL__NAME__OUT");
      aDescriptor.setDisplayName("VESSEL__NAME__OUT");
      aDescriptor.setShortDescription("VESSEL__NAME__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getWT__SEQ__CD__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("WT__SEQ__CD__OUT", Class.forName(getBeanClassName()), "getWT__SEQ__CD__OUT", "setWT__SEQ__CD__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("WT__SEQ__CD__OUT");
      aDescriptor.setDisplayName("WT__SEQ__CD__OUT");
      aDescriptor.setShortDescription("WT__SEQ__CD__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__OUT");
      aDescriptor.setDisplayName("ZZ__OUT");
      aDescriptor.setShortDescription("ZZ__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	 // System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	 // exception.printStackTrace(System.out);
   }
}
