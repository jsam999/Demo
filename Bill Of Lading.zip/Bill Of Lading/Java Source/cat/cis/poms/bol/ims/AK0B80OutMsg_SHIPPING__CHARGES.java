package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B80OutMsg_SHIPPING__CHARGES
 * This is a generated file.  Do not edit.
 */

public class AK0B80OutMsg_SHIPPING__CHARGES extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B80OutMsg_SHIPPING__CHARGES()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B80OutMsg_SHIPPING__CHARGES.class,83));
         this.setBytes(new byte[83]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getDESC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,30,false,false,false,-29,0,"X(30)",false,true);
   }
   public java.lang.String getFRT__CHRG__CODE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,73,9,0,1,false,false,false,0,0,"X(1)",false,true);
   }
   public double getFRT__CHRG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,74,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
   }
   public double getFRT__FLAT__CHRG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,64,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
   }
   public double getFRT__RATE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,55,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
   }
   public java.lang.String getFRT__RATE__UM__ABBR__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,4,false,false,false,-3,0,"X(4)",false,true);
   }
   public java.lang.String getREF__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public double getUNITS__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,44,8,11,11,false,true,true,-4,0,"9(7)V9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("REF__NO__OUT",null,getREF__NO__OUT());
         firePropertyChange("DESC__OUT",null,getDESC__OUT());
         firePropertyChange("FRT__RATE__UM__ABBR__OUT",null,getFRT__RATE__UM__ABBR__OUT());
         firePropertyChange("UNITS__OUT",null,getUNITS__OUT());
         firePropertyChange("FRT__RATE__OUT",null,getFRT__RATE__OUT());
         firePropertyChange("FRT__FLAT__CHRG__OUT",null,getFRT__FLAT__CHRG__OUT());
         firePropertyChange("FRT__CHRG__CODE__OUT",null,getFRT__CHRG__CODE__OUT());
         firePropertyChange("FRT__CHRG__OUT",null,getFRT__CHRG__OUT());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setDESC__OUT(java.lang.String aDESC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,10,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,10,aDESC__OUT,9,0,30,false,false,false,-29,0,"X(30)",false,true);
      firePropertyChange("DESC__OUT",oldDESC__OUT,aDESC__OUT);
      return;
   }
   public void setFRT__CHRG__CODE__OUT(java.lang.String aFRT__CHRG__CODE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldFRT__CHRG__CODE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,73,9,0,1,false,false,false,0,0,"X(1)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,73,aFRT__CHRG__CODE__OUT,9,0,1,false,false,false,0,0,"X(1)",false,true);
      firePropertyChange("FRT__CHRG__CODE__OUT",oldFRT__CHRG__CODE__OUT,aFRT__CHRG__CODE__OUT);
      return;
   }
   public void setFRT__CHRG__OUT(double aFRT__CHRG__OUT)
      throws RecordConversionFailureException {
      double oldFRT__CHRG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,74,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,74,aFRT__CHRG__OUT,8,9,9,false,true,true,-2,0,"9(7)V99",false,false);
      firePropertyChange("FRT__CHRG__OUT",oldFRT__CHRG__OUT,aFRT__CHRG__OUT);
      return;
   }
   public void setFRT__FLAT__CHRG__OUT(double aFRT__FLAT__CHRG__OUT)
      throws RecordConversionFailureException {
      double oldFRT__FLAT__CHRG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,64,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,64,aFRT__FLAT__CHRG__OUT,8,9,9,false,true,true,-2,0,"9(7)V9(2)",false,false);
      firePropertyChange("FRT__FLAT__CHRG__OUT",oldFRT__FLAT__CHRG__OUT,aFRT__FLAT__CHRG__OUT);
      return;
   }
   public void setFRT__RATE__OUT(double aFRT__RATE__OUT)
      throws RecordConversionFailureException {
      double oldFRT__RATE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,55,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,55,aFRT__RATE__OUT,8,9,9,false,true,true,-4,0,"9(5)V9(4)",false,false);
      firePropertyChange("FRT__RATE__OUT",oldFRT__RATE__OUT,aFRT__RATE__OUT);
      return;
   }
   public void setFRT__RATE__UM__ABBR__OUT(java.lang.String aFRT__RATE__UM__ABBR__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldFRT__RATE__UM__ABBR__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,40,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,40,aFRT__RATE__UM__ABBR__OUT,9,0,4,false,false,false,-3,0,"X(4)",false,true);
      firePropertyChange("FRT__RATE__UM__ABBR__OUT",oldFRT__RATE__UM__ABBR__OUT,aFRT__RATE__UM__ABBR__OUT);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,10, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,30,false,false,false,-29,0,"X(30)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,40, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(4)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,73, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(1)",false,true);
      return;
   }
   public void setREF__NO__OUT(java.lang.String aREF__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldREF__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aREF__NO__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("REF__NO__OUT",oldREF__NO__OUT,aREF__NO__OUT);
      return;
   }
   public void setUNITS__OUT(double aUNITS__OUT)
      throws RecordConversionFailureException {
      double oldUNITS__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toDouble(this,44,8,11,11,false,true,true,-4,0,"9(7)V9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromDouble(this,44,aUNITS__OUT,8,11,11,false,true,true,-4,0,"9(7)V9(4)",false,false);
      firePropertyChange("UNITS__OUT",oldUNITS__OUT,aUNITS__OUT);
      return;
   }
}
