package cat.cis.poms.bol.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.bol.ims.AK0B80OutMsg_VEHICLE__BREAKDOWN
 * This is a generated file.  Do not edit.
 */

public class AK0B80OutMsg_VEHICLE__BREAKDOWN extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B80OutMsg_VEHICLE__BREAKDOWN()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.bol.ims.AK0B80OutMsg_VEHICLE__BREAKDOWN.class,76));
         this.setBytes(new byte[76]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String getDIM__UM__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,9,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public java.lang.String getDIM__WT__LINE__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }
   public int getGROSS__WT__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,28,8,7,7,false,false,true,-6,0,"9(07)",false,false);
   }
   public java.lang.String getHAZARDOUS__REF__CODE1__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,72,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE2__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,73,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE3__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,74,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHAZARDOUS__REF__CODE4__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,75,9,0,1,false,false,false,0,0,"X(01)",false,true);
   }
   public java.lang.String getHEIGHT__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,21,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getLENGTH__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,11,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public int getNET__WT__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,35,8,7,7,false,false,true,-6,0,"9(07)",false,false);
   }
   public java.lang.String getPACK__DESC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,42,9,0,6,false,false,false,-5,0,"X(06)",false,true);
   }
   public java.lang.String getPACKG__ID__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,10,false,false,false,-9,0,"X(10)",false,true);
   }
   public java.lang.String getPACKG__LIST__DESC__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,48,9,0,14,false,false,false,-13,0,"X(14)",false,true);
   }
   public short getQTY__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,3,8,3,3,false,false,true,-2,0,"9(3)",false,false);
   }
   public java.lang.String getVEH__NO__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,3,false,false,false,-2,0,"X(3)",false,true);
   }
   public java.lang.String getWIDTH__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,16,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getWT__UM__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("VEH__NO__OUT",null,getVEH__NO__OUT());
         firePropertyChange("QTY__OUT",null,getQTY__OUT());
         firePropertyChange("DIM__WT__LINE__NO__OUT",null,getDIM__WT__LINE__NO__OUT());
         firePropertyChange("DIM__UM__OUT",null,getDIM__UM__OUT());
         firePropertyChange("LENGTH__OUT",null,getLENGTH__OUT());
         firePropertyChange("WIDTH__OUT",null,getWIDTH__OUT());
         firePropertyChange("HEIGHT__OUT",null,getHEIGHT__OUT());
         firePropertyChange("WT__UM__OUT",null,getWT__UM__OUT());
         firePropertyChange("GROSS__WT__OUT",null,getGROSS__WT__OUT());
         firePropertyChange("NET__WT__OUT",null,getNET__WT__OUT());
         firePropertyChange("PACK__DESC__OUT",null,getPACK__DESC__OUT());
         firePropertyChange("PACKG__LIST__DESC__OUT",null,getPACKG__LIST__DESC__OUT());
         firePropertyChange("PACKG__ID__OUT",null,getPACKG__ID__OUT());
         firePropertyChange("HAZARDOUS__REF__CODE1__OUT",null,getHAZARDOUS__REF__CODE1__OUT());
         firePropertyChange("HAZARDOUS__REF__CODE2__OUT",null,getHAZARDOUS__REF__CODE2__OUT());
         firePropertyChange("HAZARDOUS__REF__CODE3__OUT",null,getHAZARDOUS__REF__CODE3__OUT());
         firePropertyChange("HAZARDOUS__REF__CODE4__OUT",null,getHAZARDOUS__REF__CODE4__OUT());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setDIM__UM__OUT(java.lang.String aDIM__UM__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDIM__UM__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,9,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,9,aDIM__UM__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("DIM__UM__OUT",oldDIM__UM__OUT,aDIM__UM__OUT);
      return;
   }
   public void setDIM__WT__LINE__NO__OUT(java.lang.String aDIM__WT__LINE__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldDIM__WT__LINE__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,6,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,6,aDIM__WT__LINE__NO__OUT,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      firePropertyChange("DIM__WT__LINE__NO__OUT",oldDIM__WT__LINE__NO__OUT,aDIM__WT__LINE__NO__OUT);
      return;
   }
   public void setGROSS__WT__OUT(int aGROSS__WT__OUT)
      throws RecordConversionFailureException {
      int oldGROSS__WT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,28,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,28,aGROSS__WT__OUT,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      firePropertyChange("GROSS__WT__OUT",oldGROSS__WT__OUT,aGROSS__WT__OUT);
      return;
   }
   public void setHAZARDOUS__REF__CODE1__OUT(java.lang.String aHAZARDOUS__REF__CODE1__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE1__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,72,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,72,aHAZARDOUS__REF__CODE1__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE1__OUT",oldHAZARDOUS__REF__CODE1__OUT,aHAZARDOUS__REF__CODE1__OUT);
      return;
   }
   public void setHAZARDOUS__REF__CODE2__OUT(java.lang.String aHAZARDOUS__REF__CODE2__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE2__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,73,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,73,aHAZARDOUS__REF__CODE2__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE2__OUT",oldHAZARDOUS__REF__CODE2__OUT,aHAZARDOUS__REF__CODE2__OUT);
      return;
   }
   public void setHAZARDOUS__REF__CODE3__OUT(java.lang.String aHAZARDOUS__REF__CODE3__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE3__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,74,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,74,aHAZARDOUS__REF__CODE3__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE3__OUT",oldHAZARDOUS__REF__CODE3__OUT,aHAZARDOUS__REF__CODE3__OUT);
      return;
   }
   public void setHAZARDOUS__REF__CODE4__OUT(java.lang.String aHAZARDOUS__REF__CODE4__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldHAZARDOUS__REF__CODE4__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,75,9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,75,aHAZARDOUS__REF__CODE4__OUT,9,0,1,false,false,false,0,0,"X(01)",false,true);
      firePropertyChange("HAZARDOUS__REF__CODE4__OUT",oldHAZARDOUS__REF__CODE4__OUT,aHAZARDOUS__REF__CODE4__OUT);
      return;
   }
   public void setHEIGHT__OUT(java.lang.String aHEIGHT__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldHEIGHT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,21,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,21,aHEIGHT__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("HEIGHT__OUT",oldHEIGHT__OUT,aHEIGHT__OUT);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(3)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,6, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,9, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,11, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,16, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,21, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,26, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,42, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,48, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,14,false,false,false,-13,0,"X(14)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,62, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,72, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,73, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,74, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,75, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,1,false,false,false,0,0,"X(01)",false,true);
      return;
   }
   public void setLENGTH__OUT(java.lang.String aLENGTH__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldLENGTH__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,11,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,11,aLENGTH__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("LENGTH__OUT",oldLENGTH__OUT,aLENGTH__OUT);
      return;
   }
   public void setNET__WT__OUT(int aNET__WT__OUT)
      throws RecordConversionFailureException {
      int oldNET__WT__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toInt(this,35,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromInt(this,35,aNET__WT__OUT,8,7,7,false,false,true,-6,0,"9(07)",false,false);
      firePropertyChange("NET__WT__OUT",oldNET__WT__OUT,aNET__WT__OUT);
      return;
   }
   public void setPACK__DESC__OUT(java.lang.String aPACK__DESC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPACK__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,42,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,42,aPACK__DESC__OUT,9,0,6,false,false,false,-5,0,"X(06)",false,true);
      firePropertyChange("PACK__DESC__OUT",oldPACK__DESC__OUT,aPACK__DESC__OUT);
      return;
   }
   public void setPACKG__ID__OUT(java.lang.String aPACKG__ID__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPACKG__ID__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,62,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,62,aPACKG__ID__OUT,9,0,10,false,false,false,-9,0,"X(10)",false,true);
      firePropertyChange("PACKG__ID__OUT",oldPACKG__ID__OUT,aPACKG__ID__OUT);
      return;
   }
   public void setPACKG__LIST__DESC__OUT(java.lang.String aPACKG__LIST__DESC__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldPACKG__LIST__DESC__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,48,9,0,14,false,false,false,-13,0,"X(14)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,48,aPACKG__LIST__DESC__OUT,9,0,14,false,false,false,-13,0,"X(14)",false,true);
      firePropertyChange("PACKG__LIST__DESC__OUT",oldPACKG__LIST__DESC__OUT,aPACKG__LIST__DESC__OUT);
      return;
   }
   public void setQTY__OUT(short aQTY__OUT)
      throws RecordConversionFailureException {
      short oldQTY__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,3,8,3,3,false,false,true,-2,0,"9(3)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,3,aQTY__OUT,8,3,3,false,false,true,-2,0,"9(3)",false,false);
      firePropertyChange("QTY__OUT",oldQTY__OUT,aQTY__OUT);
      return;
   }
   public void setVEH__NO__OUT(java.lang.String aVEH__NO__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldVEH__NO__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,0,9,0,3,false,false,false,-2,0,"X(3)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,0,aVEH__NO__OUT,9,0,3,false,false,false,-2,0,"X(3)",false,true);
      firePropertyChange("VEH__NO__OUT",oldVEH__NO__OUT,aVEH__NO__OUT);
      return;
   }
   public void setWIDTH__OUT(java.lang.String aWIDTH__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldWIDTH__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,16,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,16,aWIDTH__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("WIDTH__OUT",oldWIDTH__OUT,aWIDTH__OUT);
      return;
   }
   public void setWT__UM__OUT(java.lang.String aWT__UM__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldWT__UM__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,26,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,26,aWT__UM__OUT,9,0,2,false,false,false,-1,0,"X(02)",false,true);
      firePropertyChange("WT__UM__OUT",oldWT__UM__OUT,aWT__UM__OUT);
      return;
   }
}
