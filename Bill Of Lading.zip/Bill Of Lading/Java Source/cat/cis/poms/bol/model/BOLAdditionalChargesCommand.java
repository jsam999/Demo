package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 


import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.data.BOLAdditionalChargesData;
import cat.cis.poms.bol.data.BOLChargeData;
import cat.cis.poms.bol.data.BOLHeaderData;
import cat.cis.poms.bol.ims.AK0B31InMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg_CHARGES__AREA__OUT;
import cat.cis.poms.bol.ims.AK0B40InMsg;
import cat.cis.poms.bol.ims.AK0B40OutMsg;
import cat.cis.poms.bol.ims.AK0B40OutMsg_DATA__OUT;
import cat.cis.poms.bol.ims.AK0B40OutMsg_ZERO__P__OUT;
import cat.cis.poms.bol.ims.AK0B80OutMsg_SHIPPING__CHARGES;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSUserInfo;

import com.ibm.connector.imstoc.DFSMsg;

/**
 * This command class handles the request for the View
 * BOL Additional Charges and redirects
 * to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLAdditionalChargesCommand extends BOLBaseCommand
{

/**
 * BOLAdditionalChargesCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLAdditionalChargesCommand() {
	super();
}
/**
 * Method to add reference no's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void add(
    HttpServletRequest req,
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{

    BOLHeaderData input = (BOLHeaderData) getSessionValue(req, "HEADER");
    params.put("HEADER", input);
    addReferenceNos(params, userInfo);
    setSessionValue(req, "NOTES_BREAKDOWN31", params.get("NOTES_BREAKDOWN31"));
    removeSessionValue(req, "NOTES_BREAKDOWN80");
    setSessionValue(req, "HEADER", params.get("HEADER"));
    setSessionValue(req, "CHARGES_TABLE", params.get("CHARGES_TABLE"));

    //init
    removeSessionValue(req, "OP_REF_NO");
    removeSessionValue(req, "OP_DESC");

}
/**
 * Method to add reference no's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void addReferenceNos(Hashtable params, COPPSUserInfo userInfo)
    throws BOLException
{

    try
        {
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
        String LadingNo = header.getBolNum();
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);
        String RefNo = "";
        String DescIn = "";

        String Units = "";

        String Rate = "";

        String FlatCharge = "";

        String ChargeCode = "";
        String TranType = "A";
        RefNo = (String) params.get("REF_NO");
        DescIn = (String) params.get("DESC");

        Units = (String) params.get("UNITS");
        if (Units.equals(""))
            {
            Units = "0";
        }
        Rate = (String) params.get("RATE");
        if (Rate.equals(""))
            {
            Rate = "0";
        }
        FlatCharge = (String) params.get("FLAT_CHARGE");
        if (FlatCharge.equals(""))
            {
            FlatCharge = "0";
        }
        ChargeCode = (String) params.get("CHARGE_CODE");

        //	(this.getSession()).putValue("sessionClearanceLtrNo", (this.getRequest()).getParameterValues(ClearanceLtrNo));

        double UnitsIn = Double.valueOf(Units).doubleValue();
        double RateIn = Double.valueOf(Rate).doubleValue();
        double FlatChargeIn = Double.valueOf(FlatCharge).doubleValue();

        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("C");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        inMsg.setTRAN__TYPE__IN(TranType);
        inMsg.setREF__NO__IN(RefNo);
        inMsg.setDESC__IN(DescIn);
        //inMsg.setFRT__RATE__UM__ABBR__IN();
        inMsg.setUNITS__IN(UnitsIn);
        inMsg.setFRT__RATE__IN(RateIn);
        inMsg.setFRT__FLAT__CHRG__IN(FlatChargeIn);
        inMsg.setFRT__CHRG__CODE__IN(ChargeCode);

        Object bean = null;

        try
            {

            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {

                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                formatChargeData(params, out);
                //(this.getSession()).removeValue("sessionNotesBreakdown80");

            }

            else if (output.length() != 0)
                {
                throw new BOLException(out.getERROR__MSG__ERR__MSG__OUT());
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
        }

    }
    catch (BOLException e)
        {
        e.setTranxID("AK010B31 ");
        e.setMethod("addReferenceNos");
        throw e;

    }

    return;
}
/**
 * Method to delete reference no's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void delete(
    HttpServletRequest req,
    Hashtable params,
    COPPSUserInfo userInfo
   )
    throws Exception
{
    BOLHeaderData input = (BOLHeaderData) getSessionValue(req, "HEADER");
    params.put("HEADER", input);
    Vector chargesTable = (Vector) getSessionValue(req, "CHARGES_TABLE");
    params.put("CHARGES_TABLE", chargesTable);
    deleteReferenceNos(params, userInfo);
    setSessionValue(req, "NOTES_BREAKDOWN31", params.get("NOTES_BREAKDOWN31"));
    removeSessionValue(req, "NOTES_BREAKDOWN80");
    setSessionValue(req, "HEADER", params.get("HEADER"));
    setSessionValue(req, "CHARGES_TABLE", params.get("CHARGES_TABLE"));

    //init
    removeSessionValue(req, "OP_REF_NO");
    removeSessionValue(req, "OP_DESC");
}
/**
 * Method to delete reference no's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void deleteReferenceNos(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{

    try
        {
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLHeaderData header = (BOLHeaderData)params.get("HEADER");
        String LadingNo = header.getBolNum();
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);
        String deleteItem = (String) params.get("DELETE_SELECTION");
        int itemNo = Integer.parseInt(deleteItem);
        Vector chargesTable = (Vector) params.get("CHARGES_TABLE");
        String RefNo = "";
        String DescIn = "";
        if (chargesTable != null)
            {
            BOLChargeData data = (BOLChargeData) chargesTable.elementAt(itemNo);
            RefNo = data.getRefNo();
            DescIn = data.getDescription();
        }
        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("C");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        inMsg.setTRAN__TYPE__IN("D");
        inMsg.setREF__NO__IN(RefNo);
        inMsg.setDESC__IN(DescIn);

        String desc = "";

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }
        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;

            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {
                //need to see this later
                //(this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT); 
                header.setIssue(out.getISSUE__OUT());
                formatChargeData(params, out);
                //(this.getSession()).removeValue("sessionNotesBreakdown80");

            }

            else if (output.length() != 0)
                {
                throw new BOLException(out.getERROR__MSG__ERR__MSG__OUT());
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
	        e.setTranxID("AK010B31 ");
	        e.setMethod("deleteReferenceNos");
        throw e;
    }

    return;
}
/**
 * Method to format additional charges
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param arr java.lang.Object
 */
/* Modified 17-July-2007 by Shibu Pillai 
Commented this flow to stop calling the tran AK010B41.*/
/*
private void formatAdditionalCharges(Hashtable params, Object[] arr)
{

    AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[] e = (AK0B41OutMsg_ADDITIONAL__CHARGES__OUT[]) arr;
    String[] chargesArray = new String[180];
    for (int n = 0; n < 180; n++)
        {
        chargesArray[n] = "";
    }
        
    int l = 0;
    String desc = null;
    for (int n = 0; n < 20; n++)
        {
        desc = e[n].getADDL__CHARGE__CODE__OUT().trim();
        if (desc.length() > 0)
            {

            chargesArray[l] =
                "CODE:" + "_______________" + e[n].getADDL__CHARGE__CODE__OUT().trim();
            l++;

            chargesArray[l] =
                "START DATE:" + "_________" + e[n].getSTART__EFF__DATE__OUT().trim();
            l++;

            chargesArray[l] =
                "CURRENCY:" + "___________" + e[n].getCURRENCY__CODE__OUT().trim();
            l++;

            chargesArray[l] =
                "S,AMOUNT & UM:"
                    + "______"
                    + e[n].getADDL__CHRG__AMT__OUT()
                    + "__"
                    + e[n].getADDL__CHARGE__UM__ABBR__OUT().trim();
            l++;

            chargesArray[l] = "FROM QTY & UM:" + "______";
            l++;

            chargesArray[l] = "TO QTY:" + "______________" + e[n].getTO__QTY__OUT();
            l++;

            chargesArray[l] =
                "NOTATION:" + "____________" + e[n].getADDL__CHARGE__DESC__OUT().trim();
            l++;

            chargesArray[l] =
                "BASE:" + "________________" + e[n].getADDL__CHARGE__UM__ABBR__OUT().trim();
            l++;

            chargesArray[l] =
                "MIN & MAX:"
                    + "___________"
                    + e[n].getMINI__FRT__CHRG__OUT()
                    + "______"
                    + e[n].getMAX__FRT__CHRG__OUT();

        }
        else
            {
            chargesArray[l] = "";
        }
        l++;
    }

    params.put("CHARGES", chargesArray);

    return;
}
*/
/**
 * Method to format charge data
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param chargeData cat.cis.poms.bol.ims.AK0B31OutMsg
 */
private void formatChargeData(Hashtable params, AK0B31OutMsg chargeData)
{
    String desc = "";

    AK0B31OutMsg_CHARGES__AREA__OUT[] a =
        (AK0B31OutMsg_CHARGES__AREA__OUT[]) chargeData.getCHARGES__AREA__OUT();
    int numItems = 0;
    for (int i = 0; i < 50; i++)
        {
        desc = a[i].getREF__NO__OUT().trim();
        if (desc.length() > 0)
            {
            ++numItems;
        }
        else
            {
            break;
        }
    }

    Vector chargesList = new Vector();
    BOLChargeData data = null;

    for (int i = 0; i < numItems; i++)
        {

        data = new BOLChargeData();
        data.setRefNo(a[i].getREF__NO__OUT().trim());
        data.setDescription(a[i].getDESC__OUT().trim());
        data.setUnits(String.valueOf(a[i].getUNITS__OUT()));
        data.setRate(String.valueOf(a[i].getFRT__RATE__OUT()));
        data.setFlatCharges(String.valueOf(a[i].getFRT__FLAT__CHRG__OUT()));
        data.setChargeCode(a[i].getFRT__CHRG__CODE__OUT());
        data.setTotal(String.valueOf(a[i].getFRT__CHRG__OUT()));
        chargesList.add(data);
    }

    data = new BOLChargeData();
    data.setTotalFlag(true);
    data.setDescription("TOTAL CHARGES");
    double tot = chargeData.getFRT__CHRG__TOTAL__OUT();
    data.setTotal(String.valueOf(tot));
    chargesList.add(data);

    params.put("CHARGES_TABLE", chargesList);

    params.put("NOTES_BREAKDOWN31", chargeData.getNOTES__BREAKDOWN());
    //have to remove NOTES_BREAKDOWN80

}
/**
 * Method to format rate routes
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param arr java.lang.Object
 */
/* Modified 17-July-2007 by Shibu Pillai 
Commented this flow to stop calling the tran AK010B41.*/
/*
private void formatRateRoutes(
    Hashtable params, Object[] arr)
{
    AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[] d =
        (AK0B41OutMsg_RATE__ROUTE__NOTES__OUT[])arr;
    String[] notesArray = new String[20];

    for (int n = 0; n < 20; n++)
        {
         notesArray[n] = d[n].getNOTES__DATA__OUT().trim();
    }
 	 params.put("RATE_ROUTES", notesArray);
     return;
}
*/
/**
 * Method to format rates
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param arr java.lang.Object
 */
/* Modified 17-July-2007 by Shibu Pillai 
Commented this flow to stop calling the tran AK010B41.*/
/*
private void formatRates(Hashtable params, Object[] arr)
{
AK0B41OutMsg_WEIGHTS__RATES__OUT[] c = (AK0B41OutMsg_WEIGHTS__RATES__OUT[])arr;
    // retrieve the traffic selection list
     
    StringBuffer desc = new StringBuffer("");
	
    String[] ratesArray = new String[20];
    int r = 0;
    for (int n = 0; n < 20; n++)
        {
	        desc.setLength(0);
        if (n == 0)
            {
            desc.append("QTY/");
            desc.append("");
            desc.append(c[n].getFRT__UM__ABBR__OUT().trim());
            desc.append("____");
            desc.append("BRKPT/");
            desc.append("");
            desc.append("Var");
            desc.append("____");
            desc.append("RATE/");
            desc.append("");
            desc.append(c[n].getFRT__RATE__UM__ABBR__OUT().trim());
            desc.append("____");
            desc.append("MODEL");
            ratesArray[n] = desc.toString();
        }
        else
            {
            desc.append(c[r].getMINI__WT__LMT__OUT().trim());
            if (desc.toString().equals(""))
                {
                ratesArray[n] = desc.toString();
            }
            else
                {

                desc.append("___________________");
                desc.append(c[r].getFRT__RATE__OUT());
                desc.append("_______");
                desc.append(c[r].getMODEL__NO__OUT().trim());
                ratesArray[n] = desc.toString();
            }
            r++;
        }

    }
 	params.put("RATES", ratesArray);
    return;
}
*/
/**
 * Method to format shipping charges
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 */
private void formatShippingCharges(Hashtable params)
{

    String refNo = "";

    Object[] charges = (Object[])params.get("SHIPPING_CHARGES");
    if(charges == null)
    {
	    return;
    }
    AK0B80OutMsg_SHIPPING__CHARGES[] a = null;
    if(charges[0] instanceof AK0B80OutMsg_SHIPPING__CHARGES)
    {
	    a = (AK0B80OutMsg_SHIPPING__CHARGES[])charges;
  
    }
    //AK0B80OutMsg_SHIPPING__CHARGES a[] = (AK0B80OutMsg_SHIPPING__CHARGES[]) params.get("SHIPPING_CHARGES");
    
    int numItems = 0;
    for (int i = 0; i < 10; i++)
        {
        refNo = a[i].getREF__NO__OUT().trim();
        if (refNo.length() > 0)
            {
            ++numItems;
        }
        else
            {
            break;
        }
    }

    
     
    Vector chargesList = new Vector();
    BOLChargeData data = null;
    
    for (int i = 0; i < numItems; i++)
        {
        
		data = new BOLChargeData();
		
        data.setRefNo(a[i].getREF__NO__OUT().trim());
		data.setDescription(a[i].getDESC__OUT().trim());
        data.setUnits(String.valueOf(a[i].getUNITS__OUT()));
        data.setRate(String.valueOf(a[i].getFRT__RATE__OUT()));
        data.setFlatCharges(String.valueOf(a[i].getFRT__FLAT__CHRG__OUT()));
        data.setChargeCode(a[i].getFRT__CHRG__CODE__OUT());
		data.setTotal(String.valueOf(a[i].getFRT__CHRG__OUT()));
		chargesList.add(data);
    }

    data = new BOLChargeData();
    data.setTotalFlag(true);
    data.setDescription("TOTAL CHARGES");
    double tot = ((Double)params.get("SHIPPING_CHARGES_TOTAL")).doubleValue();
    data.setTotal(String.valueOf(tot));
	chargesList.add(data);
    
    params.put("CHARGES_TABLE", chargesList);
    return;
}
/**
 * Method to format zerop
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param arr java.lang.Object
 */
private void formatZerop(Hashtable params, Object[] arr)
{

    StringBuffer zeropItem = new StringBuffer();

    Vector newList = new Vector();

    AK0B40OutMsg_ZERO__P__OUT[] p = (AK0B40OutMsg_ZERO__P__OUT[]) arr;
    for (int n = 0; n < 50; n++)
        {
        zeropItem.setLength(0);
        zeropItem.append(p[n].getZERO__P__REF__NO__OUT().trim());
        zeropItem.append("_______");
        zeropItem.append(p[n].getZERO__P__DESC__OUT().trim());
        newList.addElement(zeropItem.toString());
    }

    params.put("ZEROP_FMT_LIST", newList);
    params.put("ZEROP", p);
    return;
}
/**
 * Method to retrieve traffic data
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void open(
    HttpServletRequest req,
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{

    BOLHeaderData input = (BOLHeaderData) getSessionValue(req, "HEADER");

    Object[] shippingCharges = (Object[]) getSessionValue(req, "SHIPPING_CHARGES");
    Double shippingChargesTotal =
        (Double) getSessionValue(req, "SHIPPING_CHARGES_TOTAL");

    params.put("HEADER", input);
    if (shippingCharges != null)
        {
        params.put("SHIPPING_CHARGES", shippingCharges);
    }
    if (shippingChargesTotal != null)
        {
        params.put("SHIPPING_CHARGES_TOTAL", shippingChargesTotal);
    }
    retrieveTrafficData(params, userInfo);
    setSessionValue(req, "TRAFFIC_ROUTE_OBJS", params.get("TRAFFIC_ROUTE_OBJS"));
    setSessionValue(req, "ZEROP_FMT_LIST", params.get("ZEROP_FMT_LIST"));
    setSessionValue(req, "ZEROP", params.get("ZEROP"));
    setSessionValue(req, "CHARGES_TABLE", params.get("CHARGES_TABLE"));
    //init
    removeSessionValue(req, "RATE_ROUTES");
    removeSessionValue(req, "CHARGES");
    removeSessionValue(req, "RATES");
    removeSessionValue(req, "OP_REF_NO");
    removeSessionValue(req, "OP_DESC");

}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log =
        BOLUtil.getInstance().getLog("BOLAddCharges", "performTask()", cwsId);

    try
        {
        //getting the user parameters for the request
        COPPSUserInfo userInfo = getUserInfo(req, log);
        Hashtable params = acquireParameters(req);

        String action = (String) params.get(BOLId.ACTION);
        String screen = (String) params.get(BOLId.CURRENT_SCREEN_ID);
        String url = BOLUrl.MAIN_FRAME;
        String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_ADD_CHARGES);

        if (screen != null && screen.compareTo("3") != 0)
            {
            int id = Integer.parseInt(screen);
            url = BOLId.urlArr[id];
        }
        else if (action.compareTo("OPEN") == 0)
            {
            open(req, params, userInfo);
        }
/* Modified 17-July-2007 by Shibu Pillai 
 Commented this flow to stop calling the tran AK010B41.*/
/*
        else if (action.compareTo("TRAFFIC") == 0)
            {
            traffic(req, params, userInfo);
        }
*/        
        else if (action.compareTo("ZEROP") == 0)
            {
            zerop(req, params);
        }
        else if (action.compareTo("ADD") == 0)
            {
            add(req, params, userInfo);
        }
        else if (action.compareTo("DELETE") == 0)
            {
            delete(req, params, userInfo);
        }
        setSessionValue(req, BOLId.CURRENT_SCREEN_ID, BOLId.ADD_CHARGES);
        setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);
        setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
        redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
			log.logFatal(e.getErrorDetails(),e);
			throw e;
    }
}
/**
 * Method to retrieve traffic data
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void retrieveTrafficData(
    Hashtable params,
    COPPSUserInfo userInfo) throws Exception
{
	retrieveTrafficList(params, userInfo);
	formatShippingCharges(params);
}
/**
 * Method to retrieve traffic list
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void retrieveTrafficList(
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{
    try
        {

        // load up BOL header bean
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
		BOLHeaderData header = (BOLHeaderData)params.get("HEADER");
        String originCode = header.getOriginCode();
        String destinationCode = header.getDestinationCode();

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B40InMsg inMsg = new AK0B40InMsg();
        AK0B40OutMsg outMsg = new AK0B40OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 37);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B40 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setORIGIN__CODE__IN(originCode);
        inMsg.setDEST__CODE__IN(destinationCode);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B40OutMsg)
            {
            AK0B40OutMsg out = (AK0B40OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getERROR__MSG__OUT();
            output = output.trim();


            formatZerop(params, out.getZERO__P__OUT());
           
			
            if (output.length() == 0)
                {

                String desc = null;
                Vector trafficList = new Vector();
                AK0B40OutMsg_DATA__OUT[] trafficItems =
                    (AK0B40OutMsg_DATA__OUT[]) out.getDATA__OUT();
                int numItems = trafficItems.length;
                BOLAdditionalChargesData dataObj = null;
                for (int i = 0; i < numItems; i++)
                    {
                    desc = trafficItems[i].getCARRIER__CODE__OUT().trim();

                    if (desc.length() > 0)
                        { // assumption empty string represents end of list
                        dataObj = new BOLAdditionalChargesData();

                        // populate traffic route data object
                        dataObj.setAuthEmerRteInd(
                            trafficItems[i].getAUTH__EMER__RTE__IND__OUT().trim());
                        dataObj.setInOutCode(trafficItems[i].getIN__OUT__CODE__OUT().trim());
                        dataObj.setTranTypeOut(trafficItems[i].getTRAN__TYPE__OUT().trim());
                        dataObj.setSuppDlrFacCd(trafficItems[i].getSUPP__DLR__FAC__CD__OUT().trim());
                        dataObj.setWtSeqCd(trafficItems[i].getWT__SEQ__CD__OUT().trim());
                        dataObj.setTrailerAbbr(trafficItems[i].getTRAILER__ABBR__OUT().trim());
                        dataObj.setCarrierCode(trafficItems[i].getCARRIER__CODE__OUT().trim());
                        dataObj.setCarrierName(trafficItems[i].getCARRIER__NAME__OUT().trim());
                        dataObj.setTranspMode(trafficItems[i].getTRANSP__MODE__OUT().trim());
                        dataObj.setTrlLdInd(trafficItems[i].getTRL__LD__IND__OUT().trim());
                        dataObj.setContrInd(trafficItems[i].getCONTR__IND__OUT().trim());
                        dataObj.setLdWideInd(trafficItems[i].getLD__WIDE__IND__OUT().trim());
                        dataObj.setStartEffDate(trafficItems[i].getSTART__EFF__DATE__OUT().trim());
                        // add the object to storage vector
                        trafficList.addElement(dataObj);
                    }
                    else
                        { // at the end, bail out
                        break;
                    }
                }

                params.put("TRAFFIC_ROUTE_OBJS", trafficList);
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
        }

    }
    catch (BOLException e)
        {
	       e.setTranxID("AK010B40 ");
	       e.setMethod("retrieveTrafficList");
        throw e;
    }
    return; // your library books on time
}
/**
 * Method to select OP Number
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
private void selectOPNumber(Hashtable params, String selItem)
{

    //int n = getBOLAdditionalChargesFormData1().getOPListSelectionIndex();
    AK0B40OutMsg_ZERO__P__OUT[] p =
        (AK0B40OutMsg_ZERO__P__OUT[]) params.get("ZEROP");
    Vector zeropList = (Vector) params.get("ZEROP_FMT_LIST");
    String txt = null;
    for (int i = 0; i < 50; i++)
        {

        txt = (String) zeropList.elementAt(i);

        if (txt.compareTo(selItem) == 0)
            {
            params.put("OP_REF_NO", p[i].getZERO__P__REF__NO__OUT().trim());
            params.put("OP_DESC", p[i].getZERO__P__DESC__OUT().trim());
            break;
        }
    }
    return;
}
/**
 * Method to select traffic data
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
/* Modified 17-July-2007 by Shibu Pillai 
Commented this flow to stop calling the tran AK010B41.*/
/*
private void traffic(
    HttpServletRequest req,
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{
    BOLHeaderData input = (BOLHeaderData) getSessionValue(req, "HEADER");
    Vector trafficList = (Vector) getSessionValue(req, "TRAFFIC_ROUTE_OBJS");

    params.put("HEADER", input);
    params.put("TRAFFIC_ROUTE_OBJS", trafficList);
    String items = (String) params.get("TrafficSelection");
    trafficData(params, userInfo, items);
    setSessionValue(req, "RATE_ROUTES", params.get("RATE_ROUTES"));
    setSessionValue(req, "CHARGES", params.get("CHARGES"));
    setSessionValue(req, "RATES", params.get("RATES"));
    //init
    removeSessionValue(req, "OP_REF_NO");
    removeSessionValue(req, "OP_DESC");
}
*/
/**
 * Method to retrieve traffic data
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @param items java.lang.String
 * @exception java.lang.Exception
 */
/* Modified 17-July-2007 by Shibu Pillai 
Commented this flow to stop calling the tran AK010B41.*/
/*
private void trafficData(Hashtable params, COPPSUserInfo userInfo, String items) throws Exception
{
    
    try
        {

        
        Calendar c = Calendar.getInstance();
        int cyear = c.get(Calendar.YEAR);
        int cmonth = c.get(Calendar.MONTH) + 1;
        String smonth = "";
        if (cmonth < 10)
            {
            smonth = "0" + Integer.toString(cmonth);
        }
        else
            {
            smonth = Integer.toString(cmonth);
        }
        int cdate = c.get(Calendar.DATE);
        String sdate = "";
        if (cdate < 10)
            {
            sdate = "0" + Integer.toString(cdate);
        }
        else
            {
            sdate = Integer.toString(cdate);
        }
       

        //tim.getDate();

        String LadingNo = "";
        String LadingIssueNo = "";
        String OriginCode = "";
        String DestCode = "";
        String AuthEmer = "";
        String InOut = "";
        String TranType = "";
        String SuppDlr = "";
        String WtSeq = "";
        String TrlLd = "";
        String ContrInd = "";
        String LdWide = "";
        String TrailerAbbr = "";
        String CarrierCode = "";
        String TranspMode = "";
        String StartEff = "";
        String CarrierName = "";

        

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLHeaderData header = (BOLHeaderData)params.get("HEADER");
        LadingNo = header.getBolNum();
        LadingIssueNo = header.getIssue();
        OriginCode = header.getOriginCode();
        DestCode = header.getDestinationCode();
        int index = 0;

        
        Vector trafficList =
            (Vector) params.get("TRAFFIC_ROUTE_OBJS");

         
         BOLAdditionalChargesData dataObj = null;

        
            {
            index = Integer.parseInt(items);
            dataObj =
                (BOLAdditionalChargesData) trafficList.elementAt(index);
            AuthEmer = dataObj.getAuthEmerRteInd();
            InOut = dataObj.getInOutCode();
            TranType = dataObj.getTranTypeOut();
            SuppDlr = dataObj.getSuppDlrFacCd();
            WtSeq = dataObj.getWtSeqCd();
            TrlLd = dataObj.getTrlLdInd();
            ContrInd = dataObj.getContrInd();
            LdWide = dataObj.getLdWideInd();
            TrailerAbbr = dataObj.getTrailerAbbr();
            CarrierCode = dataObj.getCarrierCode();
            TranspMode = dataObj.getTranspMode();
            CarrierName = dataObj.getCarrierName();
            StartEff = dataObj.getStartEffDate();
            
        }
         // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B41InMsg inMsg = new AK0B41InMsg();
        AK0B41OutMsg outMsg = new AK0B41OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 118);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B41 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setLADING__NO__IN(LadingNo);
        inMsg.setLADING__ISSUE__NO__IN(LadingIssueNo);
        inMsg.setORIGIN__CODE__IN(OriginCode);
        inMsg.setDEST__CODE__IN(DestCode);
        inMsg.setAUTH__EMER__RTE__IND__IN(AuthEmer);
        inMsg.setIN__OUT__CODE__IN(InOut);
        inMsg.setTRAN__TYPE__IN(TranType);
        inMsg.setSUPP__DLR__FAC__CD__IN(SuppDlr);
        inMsg.setWT__SEQ__CD__IN(WtSeq);
        inMsg.setTRL__LD__IND__IN(TrlLd);
        inMsg.setCONTR__IND__IN(ContrInd);
        inMsg.setLD__WIDE__IND__IN(LdWide);
        inMsg.setTRAILER__ABBR__IN(TrailerAbbr);
        inMsg.setCARRIER__CODE__IN(CarrierCode);
        inMsg.setTRANSP__MODE__IN(TranspMode);
        inMsg.setSTART__EFF__DATE__IN(StartEff);
        inMsg.setCARRIER__NAME__IN(CarrierName);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

	            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B41OutMsg)
            {
            AK0B41OutMsg out = (AK0B41OutMsg) bean;
           
            output = out.getERROR__MSG__OUT();
            output = output.trim();

            

            if (output.length() == 0)
                {
	             header.setContractNo(out.getCONTRACT__NO__OUT());
	             header.setCarrierCode(CarrierCode);
	             header.setCarrierName(CarrierName);
                formatRates(params, out.getWEIGHTS__RATES__OUT());
                formatAdditionalCharges(params, out.getADDITIONAL__CHARGES__OUT());
                formatRateRoutes(params,out.getRATE__ROUTE__NOTES__OUT());
            }

            else if (output.length() != 0)
                {
                throw new BOLException(output);
            }

        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        } 
         
    }
    catch (BOLException e)
        {
	        e.setTranxID("AK010B41 ");
	        e.setMethod("trafficData");
         throw e;
    }

    return;  
}
*/
/**
 * Method to select OPNumber
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @exception java.lang.Exception
 */
private void zerop(
    HttpServletRequest req,
    Hashtable params)
    throws Exception
{

    Object anzerop = (Object) getSessionValue(req, "ZEROP");
    Object zeropList = (Object) getSessionValue(req, "ZEROP_FMT_LIST");
    
    params.put("ZEROP", anzerop);
    params.put("ZEROP_FMT_LIST", zeropList);
    String zeropItem = (String) params.get("OPList");
    selectOPNumber(params, zeropItem);
    setSessionValue(req, "OP_REF_NO", params.get("OP_REF_NO"));
    setSessionValue(req, "OP_DESC", params.get("OP_DESC"));

}
}
