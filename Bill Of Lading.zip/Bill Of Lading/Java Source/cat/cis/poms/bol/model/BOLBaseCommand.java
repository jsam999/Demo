/**
****************************************************************
Date           : 12/28/2012
Reason         : Changed for Websphere to Tomcat Migration
****************************************************************
**/
package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 


import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.com.servlet.ComFunctions;
import cat.cis.poms.com.util.POMSUtil;
import cat.cis.poms.copps.model.COPPSSecurity;
import cat.cis.poms.copps.model.COPPSUserInfo;

/**
 * This is an abstract command implementing
 * common functions used by all commands 
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 
public abstract class BOLBaseCommand
{
/**
 * BOLBaseCommand default constructor.
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLBaseCommand() {
	super();
}
/**
 * This method takes all parameters from the request and
 * puts them into a hashtable to return
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @return java.util.Hashtable
 * @throws BOLException if exception occurs.
 */

/* Changed for Websphere to Tomcat Migration for CAT Migration Project � STARTS */
public Hashtable acquireParameters(HttpServletRequest req) throws BOLException
{
	/*Hashtable params = new Hashtable();
	Enumeration enum = req.getParameterNames();
	if (enum != null)
	{
		String name = null;
		String[] value = null;
		
		while (enum.hasMoreElements())
		{
			 name = (String) enum.nextElement();
			 value = req.getParameterValues(name);
			 // WAS 6 Migration - Validate input values.
			 if(!POMSUtil.validate(name, value)) {
			 	throw new BOLException("Invalid entry for " + name);
			 }
			// if there is only one value for an element, the value is
			// extracted and added to the Hashtable.
			if (value != null && value.length == 1)
			{
				params.put(name, value[0]);
			}
			// if there is more than one value for an element,
			// the value is extracted and added to the Hashtable.
			else
				if (value != null && value.length > 1)
				{
					params.put(name, value);
				}
		}
	}
	return params;*/
	Hashtable params = new Hashtable();
	Enumeration enumerate = req.getParameterNames();
	if (enumerate != null)
	{
		String name = null;
		String[] value = null;
		
		while (enumerate.hasMoreElements())
		{
			 name = (String) enumerate.nextElement();
			 value = req.getParameterValues(name);
			 // WAS 6 Migration - Validate input values.
			 if(!POMSUtil.validate(name, value)) {
			 	throw new BOLException("Invalid entry for " + name);
			 }
			// if there is only one value for an element, the value is
			// extracted and added to the Hashtable.
			if (value != null && value.length == 1)
			{
				params.put(name, value[0]);
			}
			// if there is more than one value for an element,
			// the value is extracted and added to the Hashtable.
			else
				if (value != null && value.length > 1)
				{
					params.put(name, value);
				}
		}
	}
	return params;
}
/* Changed for Websphere to Tomcat Migration for CAT Migration Project � ENDS */
/**
 * This method creates a new ComLog Object and returns.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param methodName java.lang.String
 * @return cat.cis.poms.log.ComLog
 */
public ComLog getLog(String methodName) throws Exception
{
	ComLog log = new ComLog("common", "BOLBaseCommand", methodName, "COMMON");
	return log;
}
/**
 * Gets the session value
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param key java.lang.String
 * @return java.lang.Object
 */
public Object getSessionValue(HttpServletRequest req, String key) {
	return req.getSession().getAttribute(key);
	 
}
/**
 * This method is to get the User ID from session cache
 * or from CWS cookie
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @return java.lang.String
 */
public String getUserId(HttpServletRequest req) throws Exception
{
	ComLog log = getLog("getUserId");
	String userId = ComFunctions.getRemoteUser(req, log);
	return userId;
}
/**
* This method is to get the User Info from session cache
* or from the database
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param req javax.servlet.HttpServletRequest
* @param log cat.cis.poms.com.log.ComLog
* @return cat.cis.poms.copps.model.COPPSUserInfo
*/
public COPPSUserInfo getUserInfo(HttpServletRequest req, ComLog log)
    throws Exception
{
    COPPSUserInfo userInfo = (COPPSUserInfo) getSessionValue(req, "SECURITY");
    if (userInfo == null)
        {
        COPPSSecurity coppsSecurity = new COPPSSecurity(log);
        userInfo = coppsSecurity.getUserInfo();
        setSessionValue(req, "SECURITY", userInfo);
    }
    return userInfo;
}
/**
 * Abstract method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
 public abstract void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception;
/**
 * Method used to forward JSP's/Servlet's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 * @param url java.lang.String
 */
protected void redirect(HttpServletRequest req, HttpServletResponse res, ServletContext context,String url) throws Exception
{
	RequestDispatcher rd = context.getRequestDispatcher(ComFunctions.formatURL(url));
	rd.forward(req, res);
}
/**
 * Method used to remove session value
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param key java.lang.String
 */
public void removeSessionValue(HttpServletRequest req, String key) {
	req.getSession().removeAttribute(key);
	 
}
/**
 * Sets the session value.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param key java.lang.String
 * @param obj java.lang.Object
 */
public void  setSessionValue(HttpServletRequest req, String key, Object obj) {
	req.getSession().setAttribute(key, obj);
}
}
