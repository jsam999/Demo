package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.copps.model.COPPSUserInfo;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import com.ibm.connector.imstoc.DFSMsg;


import cat.cis.poms.bol.ims.AK0B30InMsg;
import cat.cis.poms.bol.ims.AK0B30OutMsg;

/**
 * This command class handles the request for the View
 * BOL Build and redirects to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLBuildCommand extends BOLBaseCommand
{
/**
 * BOLBuildCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLBuildCommand() {
	super();
}
/**
 * Add entered consolidation
 * number into the selection list
 *
 * @param newOrder java.lang.String new MSO number to add
 * @param curOrders java.lang.String current list of entered numbers from session wrapper
 * @return lang.util.Vector
 * @exception java.lang.Exception
 */
public Vector addMSO(String newOrder, Vector curOrders)
    throws Exception {

    // determine if a value was entered
    if (newOrder == null) {
        throw new Exception("Please provide an MSO to add");
    }

    // determine if there are any current orders
    if (curOrders == null) {

        curOrders = new java.util.Vector();
    }

    newOrder = newOrder.trim();

    if (newOrder.length() == 5) {
        // add the new element to the session data
        curOrders.addElement(newOrder);

    } else {
        throw new Exception("Invalid MSO number provided");
    }

    return curOrders;
}
/**
 * Method to build BOL for the selected MSO numbers.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param currOrders java.util.Vector
 * @param userinfo cat.cis.poms.copps.model.COPPSUserInfo
 * @param log java.lang.String
 * @return java.util.Hashtable
 * @exception java.lang.Exception
 */
public Hashtable buildBOL(Vector currOrders, COPPSUserInfo userinfo, ComLog log) throws Exception{

	Hashtable table = new Hashtable();
    try {
        

        if ((currOrders == null) || (currOrders.size() < 1)) {
            throw new Exception("Please enter MSO(s) to consolidate");
        }

        String logonid = userinfo.getAcf2Id();
        String badge = userinfo.getBadge();
        String[] ordersList = new String[currOrders.size()];
        int numOrders = currOrders.size();
        for (int i = 0; i < numOrders; i++) {
            ordersList[i] = (String) currOrders.elementAt(i);
        }

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B30InMsg inMsg = new AK0B30InMsg();
        AK0B30OutMsg outMsg = new AK0B30OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 150);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B30 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        for (int c = 0; c < ordersList.length; c++)
        {
            inMsg.setMSO__NO__IN(c, ordersList[c]);
        }
        Object bean = null;

        try {
            bean = ims.callIMS(inMsg);
        } catch (Exception e) {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B30OutMsg) {
            AK0B30OutMsg out = (AK0B30OutMsg) bean;
            
            output = out.getMSO__ERR__MSG__OUT();
            output = output.trim();
            
            if (output.length() == 0) {

             	String[] msos = out.getMSOS__OUT();
             	String[] bols = out.getBLS__OUT();
				table.put("MSO_LIST", msos);
				table.put("BOL_LIST", bols);
				
            } else
                if (output.length() != 0) {
	                throw new BOLException(output);
                   
                }
           
        }

        if (bean instanceof DFSMsg) {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            log.logFatal(output, new Exception(output));
            throw new BOLException(output);
            

        }
    } catch (BOLException e) {
	    e.setTranxID("AK010B30 ");
	    e.setMethod("buildBOL");
         throw e;
         
    }

    return table;
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log = BOLUtil.getInstance().getLog("BOLBuild", "performTask()", cwsId);
    try
        {
         //getting the user parameters for the request

        COPPSUserInfo userInfo = getUserInfo(req, log);
        Hashtable params = acquireParameters(req);

        String action = (String) params.get(BOLId.ACTION);

        String url = BOLUrl.MAIN_FRAME;
        String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);

        if (action != null)
            {

            if (action.compareTo("OPEN") == 0)
                {
                //do nothing
                removeSessionValue(req, "MSO_LIST");
            }
            else if (action.compareTo("ADD") == 0)
                {
                String mso = (String) params.get("MSO");
                Vector msoList = (Vector) getSessionValue(req, "MSO_LIST");
                msoList = addMSO(mso, msoList);
                setSessionValue(req, "MSO_LIST", msoList);
            }
            else if (action.compareTo("REMOVE") == 0)
                {
                Object mso = (Object) params.get("MSO_LIST");
                Vector msoList = (Vector) getSessionValue(req, "MSO_LIST");
                msoList = removeMSO(mso, msoList);
                setSessionValue(req, "MSO_LIST", msoList);
            }
            else if (action.compareTo("REMOVE_ALL") == 0)
                {
                setSessionValue(req, "MSO_LIST", new Vector());
            }
            else if (action.compareTo("ASSIGN_BOL_NOS") == 0)
                {
                screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_SELECTION);

                Vector msoList = (Vector) getSessionValue(req, "MSO_LIST");
                Hashtable table = buildBOL(msoList, userInfo, log);
                setSessionValue(req, "MSO_LIST", table.get("MSO_LIST"));
                setSessionValue(req, "BOL_LIST", table.get("BOL_LIST"));
            }
            else if (action.compareTo("CLOSE") == 0)
                {

                screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);

            }
            else if (action.compareTo("BUILD") == 0)
                {
                url = BOLUrl.EDIT_SERVLET;
            }
            else if (action.compareTo("VECH_ASSIGN") == 0)
                {
                req.getParameterValues("ACTION")[0] = "OPEN";
                url = BOLUrl.VECH_ASSIGN_SERVLET;
            }
        }
        setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
        redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to remove MSO number's from the selected MSO list.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param mso java.lang.Object This can be either a String or String[]
 * @param curList java.util.Vector selected MSO list
 * @return java.util.Vector BOL list after removal of MSO's
 */
public Vector removeMSO(Object mso, java.util.Vector curList) {

    // don't waste the time if there is nothing in the list
    if (curList == null) {
        return null;
    }

    if (mso == null) {
        return null;
    }
    
    String selItem = "";
    String[] msoList = null;
    if (mso instanceof String) {
        msoList = new String[1];
        msoList[0] = (String) mso;
    } else {
        msoList = (String[]) mso;
    }
    // determine number of items in list
    int numItems = curList.size();

    //loop through list to determine which one to delete

    String txt = null;
    for (int y = 0; y < msoList.length; y++) {
	    selItem = msoList[y];
        for (int i = 0; i < numItems; i++) {
            // retrieve element from current list
            txt = (java.lang.String) curList.elementAt(i);
            // string matches is all we have 8^(
            if (txt.compareTo(selItem) == 0) {
                curList.removeElementAt(i);
                // nailed it, now update session data

                break;
            }
        }
    }

    return curList;
}
}
