package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */


import java.util.Hashtable;
import java.util.Vector;
import java.util.StringTokenizer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLString;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.copps.model.COPPSUserInfo;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import com.ibm.connector.imstoc.DFSMsg;

import cat.cis.poms.bol.data.BOLDetailsData;
import cat.cis.poms.bol.data.BOLHeaderData;


import cat.cis.poms.bol.ims.AK0B31InMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg;
import cat.cis.poms.bol.ims.AK0B80OutMsg_VEHICLE__BREAKDOWN;
import cat.cis.poms.bol.ims.AK0B80OutMsg_NOTES__BREAKDOWN;
import cat.cis.poms.bol.ims.AK0B31OutMsg_NOTES__BREAKDOWN;

/**
 * This command class handles the request for the View
 * BOL Details and redirects to appropriate JSP's.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLDetailsCommand extends BOLBaseCommand
{
/**
 * BOLDetailsCommand default constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLDetailsCommand() {
	super();
}
/**
 * Method to save BOL details.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void apply(
    HttpServletRequest req,
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{

     
    BOLHeaderData input = (BOLHeaderData) getSessionValue(req, "HEADER");
    params.put("HEADER", input);
    saveDetails(params, userInfo);
    setSessionValue(req, "NOTES_BREAKDOWN31", params.get("NOTES_BREAKDOWN31"));
    removeSessionValue(req, "DETAIL_NOTES");
    setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));

}
/**
 * Method to retrieve BOL details.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void open(
    HttpServletRequest req,
    Hashtable params)
    throws Exception
{

    Object[] notes80 = (Object[]) getSessionValue(req, "NOTES_BREAKDOWN80");

    if (notes80 != null)
        {
        params.put("NOTES_BREAKDOWN80", notes80);
    }

    Object[] notes31 = (Object[]) getSessionValue(req, "NOTES_BREAKDOWN31");
    if (notes31 != null)
        {
        params.put("NOTES_BREAKDOWN31", notes31);
    }
        
    Object[] vehicleBreakdown =
        (Object[]) getSessionValue(req, "VEHICLE_BREAKDOWN80");

    if (vehicleBreakdown != null)
        {
        params.put("VEHICLE_BREAKDOWN80", vehicleBreakdown);
    }

     
    retrieveDetails(params);
    setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));
    setSessionValue(req, "DETAIL_TABLE", params.get("DETAIL_TABLE"));

}
/**
 * Method to execute the request from the View
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res, ServletContext context) throws Exception
{
	//getting the CWSID
	String cwsId = getUserId(req);
	ComLog log = BOLUtil.getInstance().getLog("BOLDetails", "performTask()", cwsId);
	try
	{
		
	
	//getting the user parameters for the request


	COPPSUserInfo userInfo = getUserInfo(req, log);
	Hashtable params = acquireParameters(req);
	
	String action = (String) params.get(BOLId.ACTION);
	String screen = (String) params.get(BOLId.CURRENT_SCREEN_ID);
	String url = BOLUrl.MAIN_FRAME;
	String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_DETAILS);
	if (screen != null)
	{
		if (screen.compareTo("1") != 0)
		{
			int id = Integer.parseInt(screen);
            url = BOLId.urlArr[id];
		}
		else
			if (action.compareTo("OPEN") == 0)
			{
				open(req,params);
			}
			else if(action.compareTo("APPLY") == 0)
			{
				apply(req,params, userInfo);
			}
	}
	setSessionValue(req, BOLId.CURRENT_SCREEN_ID, BOLId.DETAILS);
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
	redirect(req, res, context,url);
	 }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to process BOL detail Notes.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param obj java.lang.Object
 * @return java.lang.String
 */
public String processNotes(Object[] obj)
{

    AK0B31OutMsg_NOTES__BREAKDOWN[] c = (AK0B31OutMsg_NOTES__BREAKDOWN[]) obj;

    String desc = "";
    String code = "";
    int numProgramNotes = 0;
    int numManual = 0;
      for (int n = 0; n < 30; n++)
        {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
            {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                {
	                ++numProgramNotes;
                     
                }
                else
                {
                    ++numManual;
                }
            }
            else
            {
                ++numManual;
                 
            }
        }
     

     int numNotes = numProgramNotes + numManual;
    
StringBuffer manual = new StringBuffer("");
        for (int n = 0; n < numNotes; n++)
        {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
            {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.compareTo("P") != 0)
                { 
                    if (manual.toString().compareTo("") == 0)
                        {
                        manual.append(desc);
                    }
                    else
                        {
	                        manual.append("\n");
	                        manual.append(desc);
                       
                    }
                }
            }
        }
    
    return manual.toString();
}
/**
 * Method to retrieve BOL details.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 */
public void retrieveDetails(Hashtable params)
{

    AK0B80OutMsg_VEHICLE__BREAKDOWN[] a =
        (AK0B80OutMsg_VEHICLE__BREAKDOWN[]) params.get("VEHICLE_BREAKDOWN80");

    String desc = null;
    String code = null;
    StringBuffer manual = new StringBuffer("");
    int numDescs = 0;
    int numNotes = 0;
    int numProgramNotes = 0;

    int numTotal = 0;
    int numManual = 0;
    
    if (a != null)
        {
        for (int i = 0; i < 50; i++)
            {
            desc = a[i].getPACKG__LIST__DESC__OUT().trim();
            if (desc.length() > 0)
                {
                ++numDescs;
            }
            else
                {
                break;
            }
        }
    }
    AK0B80OutMsg_NOTES__BREAKDOWN[] c =
        (AK0B80OutMsg_NOTES__BREAKDOWN[]) params.get("NOTES_BREAKDOWN80");
    AK0B31OutMsg_NOTES__BREAKDOWN[] b =
        (AK0B31OutMsg_NOTES__BREAKDOWN[]) params.get("NOTES_BREAKDOWN31");

    //determine which format to use
    if (c == null && b != null)
        {
        for (int n = 0; n < 30; n++)
            {
            desc = b[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = b[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
                    ++numProgramNotes;

                }
                else
                    {
                    ++numManual;
                }
            }
            else
                {
                ++numManual;
            }

        }

    }
    else if(c != null)
        {
        for (int n = 0; n < 30; n++)
            {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
                    ++numProgramNotes;

                }
                else
                    {
                    ++numManual;
                }
            }
            else
                {
                ++numManual;

            }
        }
    }

    numNotes = numProgramNotes + numManual;
    numTotal = numProgramNotes + numDescs;
    String test = "4040404";
    String test2 = "40404";
    String test3 = "404";
    Vector detailsTable = new Vector();
    BOLDetailsData data = null;
    StringBuffer descBuffer = null;
    BOLString bolS = null;
    String e = null;
    for (int i = 0; i < numDescs; i++)
        {
        data = new BOLDetailsData();
        e = String.valueOf(a[i].getQTY__OUT());
        if (e.equals(test3))
            {
            e = "";
        }
        bolS = new BOLString(e);
        data.setQty(bolS.stripLeadingZeroesReturnSpace());

        data.setUnits(a[i].getPACK__DESC__OUT().trim());

        descBuffer = new StringBuffer(a[i].getPACKG__ID__OUT().trim());
        descBuffer.append("     ");
        descBuffer.append(a[i].getPACKG__LIST__DESC__OUT().trim());
        descBuffer.append(" ");
        descBuffer.append(a[i].getHAZARDOUS__REF__CODE1__OUT().trim());
        descBuffer.append(" ");
        descBuffer.append(a[i].getHAZARDOUS__REF__CODE2__OUT().trim());
        descBuffer.append(" ");
        descBuffer.append(a[i].getHAZARDOUS__REF__CODE3__OUT().trim());
        descBuffer.append(" ");
        descBuffer.append(a[i].getHAZARDOUS__REF__CODE4__OUT().trim());

        data.setDesc(descBuffer.toString());

        e = String.valueOf(a[i].getHEIGHT__OUT()).toString();
        if (e.equals(test2))
            {
            e = "";
        }
        bolS = new BOLString(e);
        data.setHeight(bolS.stripLeadingZeroesReturnSpace());

        e = String.valueOf(a[i].getWIDTH__OUT()).toString();
        if (e.equals(test2))
            {
            e = "";
        }
        bolS = new BOLString(e);
        data.setWidth(bolS.stripLeadingZeroesReturnSpace());

        e = String.valueOf(a[i].getLENGTH__OUT()).toString();
        if (e.equals(test2))
            {
            e = "";
        }
        bolS = new BOLString(e);
        data.setLength(bolS.stripLeadingZeroesReturnSpace());

        e = String.valueOf(a[i].getGROSS__WT__OUT()).toString();
        if (e.equals(test))
            {
            e = "";
        }
        bolS = new BOLString(e);

        data.setWeight(bolS.stripLeadingZeroesReturnSpace());
        detailsTable.add(data);

    }

    int i = numDescs;
    if (c == null)
        {

        for (int n = 0; n < numNotes; n++)
            {
            desc = b[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = b[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
                    data = new BOLDetailsData();
                    data.setDesc(b[n].getSHIPPING__NOTES__OUT().trim());
                    i++;
                    detailsTable.add(data);
                }
                else
                    {
                    if (manual.toString().compareTo("") ==0)
                        {
                        manual.append(desc);
                    }
                    else
                        {
                        manual.append("\n");
                        manual.append(desc);
                    }
                    i++;
                }
            }

        }
    }
    else
        {

        for (int n = 0; n < numNotes; n++)
            {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
                    data = new BOLDetailsData();
                    data.setDesc(c[n].getSHIPPING__NOTES__OUT().trim());
                    i++;
                    detailsTable.add(data);
                }
                else
                    {
                    if (manual.toString().compareTo("") == 0)
                        {
                        manual.append(desc);
                    }
                    else
                        {
	                    manual.append("\n");
	                    manual.append(desc);
                        
                    }
                    i++;
                }
            }
        }
    }

    params.put("DETAIL_NOTES", manual.toString());
    params.put("DETAIL_TABLE", detailsTable);
    return;
}
/**
 * Method to save BOL details.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void saveDetails(
    Hashtable params,
    COPPSUserInfo userInfo) throws Exception
{

    try
        {

        String userNotes = "";
        String note = "";
        
        String LadingNo = "";
       
         String ClearanceFileNo = "";
        String ClearanceLtrNo = "";
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        userNotes = (String) params.get("BOL_DTL_NOTES");
        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");

        LadingNo = header.getBolNum();
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);

       
        

        

        ClearanceFileNo = header.getClearanceFileNo();
        if (ClearanceFileNo == null)
            {
            ClearanceFileNo = "";
        }

        ClearanceLtrNo = header.getClearanceLtrNo();
        if (ClearanceLtrNo == null)
            {
            ClearanceLtrNo = "";
        }

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("N");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        ;
        inMsg.setCLRN__LTR__FILE__NO__IN(ClearanceFileNo);
        inMsg.setCLRN__LTR__NO__IN(ClearanceLtrNo);
        
        StringTokenizer token =
            new StringTokenizer(userNotes, "\n");
        int n = 0;
        while (token.hasMoreTokens())
            {
            note = token.nextToken();
            inMsg.setMANUAL__NOTE(n, note);

            
            n++;
        }
        inMsg.setSHORT__CUT__NOTE(0, (String) params.get("SCNOTE0"));
        inMsg.setSHORT__CUT__NOTE(1, (String) params.get("SCNOTE1"));
        inMsg.setSHORT__CUT__NOTE(2, (String) params.get("SCNOTE2"));
        inMsg.setSHORT__CUT__NOTE(3, (String) params.get("SCNOTE3"));
        inMsg.setSHORT__CUT__NOTE(4, (String) params.get("SCNOTE4"));
        inMsg.setSHORT__CUT__NOTE(5, (String) params.get("SCNOTE5"));
        inMsg.setSHORT__CUT__NOTE(6, (String) params.get("SCNOTE6"));
        inMsg.setSHORT__CUT__NOTE(7, (String) params.get("SCNOTE7"));
        inMsg.setSHORT__CUT__NOTE(8, (String) params.get("SCNOTE8"));
        inMsg.setSHORT__CUT__NOTE(9, (String) params.get("SCNOTE9"));
		Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
            
            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();
            

            if (output.length() == 0)
                {

                // (this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                params.put("NOTES_BREAKDOWN31",out.getNOTES__BREAKDOWN());//should remove NOTES_BREAKDOWN80
            	String manual = processNotes(out.getNOTES__BREAKDOWN());
            	params.put("DETAIL_NOTES", manual);
            }

            else if (output.length() != 0)
                {
                throw new BOLException( "received err in 'ApplyBtnPressed in BOLDetailsGui'" + output);
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException( "received err in 'ApplyBtnPressed in BOLDetailsGui'" + output);

        }

    }
    catch (BOLException e)
        {
		e.setMethod("saveDetails");
		e.setTranxID("AK010B31 ");
        throw e;
    }
    return;
}
}
