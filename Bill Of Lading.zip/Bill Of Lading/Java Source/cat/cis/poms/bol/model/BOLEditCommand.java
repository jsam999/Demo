package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Hashtable;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.data.BOLHeaderData;
import cat.cis.poms.bol.ims.AK0B43InMsg;
import cat.cis.poms.bol.ims.AK0B43OutMsg;
import cat.cis.poms.bol.ims.AK0B46InMsg;
import cat.cis.poms.bol.ims.AK0B46OutMsg;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSUserInfo;

import com.ibm.connector.imstoc.DFSMsg;

/**
 * This command class handles the request for the View
 * BOL Update/Inquiry/Manual Build and redirects to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */


public class BOLEditCommand extends BOLBaseCommand
{
/**
 * BOLEditCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLEditCommand() {
	super();
}
/**
 * Method to manual build BOL.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param container java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void buildBOL(Hashtable container, COPPSUserInfo userInfo)
    throws Exception
{
    try
        {

        String Fac = null;
        String Bldg = null;

        // load up BOL header bean
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();

        Fac = (String) container.get("FAC");
        Fac = Fac.toUpperCase();
        if (Fac == null)
            {
            Fac = "  ";
        }
        else
            {
            Fac = Fac.toUpperCase();
        }
        Bldg = (String) container.get("BLDG");
        if (Bldg == null)
            {
            Bldg = "  ";
        }
        else
            {
            Bldg = Bldg.toUpperCase();
        }

        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();
        AK0B46InMsg inMsg = new AK0B46InMsg();
        AK0B46OutMsg outMsg = new AK0B46OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 816);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B46 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("B");
        inMsg.setFAC__IN(Fac);
        inMsg.setBLDG__IN(pad(Bldg, 2));

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B46OutMsg)
            {
            AK0B46OutMsg out = (AK0B46OutMsg) bean;

            output = out.getERROR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {
                BOLHeaderData data = new BOLHeaderData();
                data.setBolNum(out.getBOL__NO__OUT());
                data.setFactory(out.getFAC__OUT());
                data.setDock(out.getDOCK__OUT());
                data.setBuilding(out.getBLDG__OUT());
                data.setIssue(out.getISSUE__OUT());
                data.setManualInd("M");
                container.put("HEADER", data);
            }

            else if (output.length() != 0)
                {

                throw new BOLException(output);
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
		e.setTranxID("AK010B46 ");
		e.setMethod("buildBOL");
        throw e;
    }

    return;
}
/**
 * Method to pad string with spaces.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param one java.lang.String String to be padded
 * @param l int no of spaces to be padded
 * @return java.lang.String padded string
 */
public String pad(String s, int l) {
		StringBuffer str = new StringBuffer(s);
		int ol = s.length();
		for (int c=ol;c<l;c++)
		{
			//s += " ";
			str.append(" ");
		}
		//System.out.println("str.toSt  >>> "+str.toString());
		return str.toString();	
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log = BOLUtil.getInstance().getLog("BOLEdit", "performTask()", cwsId);
    try
    {
    //getting the user parameters for the request

    COPPSUserInfo userInfo = getUserInfo(req, log);
    //getting the user parameters for the request

    Hashtable params = acquireParameters(req);

    String action = (String) params.get(BOLId.ACTION);
    

    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_EDIT);

    if (action != null)
        {
        if (action.compareTo("OPEN_INQUIRY") == 0)
            {
            setSessionValue(req, BOLId.EDIT_MODE, "INQUIRY");

        }
        else if (action.compareTo("OPEN_UPDATE") == 0)
            {
            setSessionValue(req, BOLId.EDIT_MODE, "UPDATE");

        }
        else if (action.compareTo("OPEN_MANUAL_BUILD") == 0)
            {
            screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_MANUAL_BUILD);
            removeSessionValue(req, "BOL_LIST");
        }
        else if (action.compareTo("XREF") == 0)
            {
			xrefButtonPressed(params, userInfo);
            String[] bols = (String[]) params.get("BOL_LIST");
            setSessionValue(req, "BOL_LIST", bols);
            setSessionValue(req, "MSO", (String) params.get("MSO"));
            setSessionValue(req, "ACTION", "XREF"); //important, used in jsp
        }
        else if (
            action.compareTo("INQUIRY") == 0
                || action.compareTo("UPDATE") == 0
                || action.compareTo("BUILD") == 0)
            {
            String bol = (String) params.get("BOL_NO");

            if (bol == null || bol.compareTo("") == 0)
                {
                bol = (String) params.get("BOL_LIST");
            }
            else
                {
                removeSessionValue(req, "BOL_LIST");
            }
            setSessionValue(req, "BOL_SELECTED", bol);
            req.getParameterValues("ACTION")[0] = "OPEN";
            url = BOLUrl.HEADER_SERVLET + "?SCREEN_ID=0";

            setSessionValue(req, BOLId.EDIT_MODE, action);

        }
        else if (action.compareTo("MANUAL_BUILD") == 0)
            {
            removeSessionValue(req, "HEADER");
			params.put("FAC", params.get("FAC"));
            params.put("BLDG", params.get("BLDG"));
            buildBOL(params, userInfo);
            BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
            setSessionValue(req, "HEADER", header);
            setSessionValue(req, "BOL_SELECTED", header.getBolNum());
            req.getParameterValues("ACTION")[0] = "DO_NOTHING";
            url = BOLUrl.HEADER_SERVLET + "?SCREEN_ID=0";
			removeSessionValue(req, "SHIPPING_CHARGES");
            removeSessionValue(req, "SHIPPING_CHARGES_TOTAL");
            removeSessionValue(req, "VEHICLE_BREAKDOWN80");
            removeSessionValue(req, "NOTES_BREAKDOWN80");
            removeSessionValue(req, "FOOTER");
            setSessionValue(req, BOLId.EDIT_MODE, "MANUAL_BUILD");

        }
        else if (action.compareTo("CLOSE") == 0)
            {
            screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);

        }

    }

    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to retrieve the BOL numbers for MSO
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param parmas java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void xrefButtonPressed(Hashtable params, COPPSUserInfo userinfo) throws Exception
{
 	String mso = (String)params.get("MSO");
	try
        {
        
       	String logonid = userinfo.getLogonId();
        String badge = userinfo.getBadge();
		
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B43InMsg inMsg = new AK0B43InMsg();
        AK0B43OutMsg outMsg = new AK0B43OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 30);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B43 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setMSO__NO__IN(mso);
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            
	            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B43OutMsg)
            {
            AK0B43OutMsg out = (AK0B43OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getMSO__ERR__MSG__OUT();
            output = output.trim();
            
            if (output.length() == 0)
                {
                //(this.getSession()).putValue("sessionBLSXref", out.getBLS__OUT());
                //java.lang.String b[] = (String[]) this.getSession().getValue("sessionBLSXref");
                String[] b = out.getBLS__OUT();
                String[] BLSArray = new java.lang.String[25];

                String bol = null;

                for (int n = 0; n < 25; n++)
                    {
                    bol = "";
                    bol = b[n];
                    BLSArray[n] = bol;
                    
                }
				
                
                params.put("BOL_LIST", BLSArray);
                params.put("MSO", mso);

            }

            else if (output.length() != 0)
                {
	                throw new BOLException(output);
                
            }
           
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
           

        }
    }
    catch (BOLException e)
        {
	       e.setMethod("xrefButtonPressed");
	       e.setTranxID("AK010B43 ");
        throw e;
    }

    return;
}
}
