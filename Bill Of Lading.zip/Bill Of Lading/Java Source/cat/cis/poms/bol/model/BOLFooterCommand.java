package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Hashtable;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.data.BOLFooterData;
import cat.cis.poms.bol.data.BOLHeaderData;
import cat.cis.poms.bol.ims.AK0B31InMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSUserInfo;

import com.ibm.connector.imstoc.DFSMsg;

/**
 * This command class handles the request for the View
 * BOL Footer and redirects to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLFooterCommand extends BOLBaseCommand
{
/**
 * BOLFooterCommand default constructor.
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLFooterCommand() {
	super();
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log =
        BOLUtil.getInstance().getLog("TDSController", "performTask()", cwsId);
    try
    {
	   
    //getting the user parameters for the request

    COPPSUserInfo userInfo = getUserInfo(req, log);
    Hashtable params = acquireParameters(req);

    String action = (String) params.get(BOLId.ACTION);
    String screen = (String) params.get(BOLId.CURRENT_SCREEN_ID);
    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_FOOTER);
    if (screen != null)
        {
        if (screen.compareTo("2") != 0)
            {
            int id = Integer.parseInt(screen);
            url = BOLId.urlArr[id];
        }
        else if (action.compareTo("OPEN") == 0)
            {
            //do nothing
        }
        else if (action.compareTo("APPLY") == 0)
            {

            BOLHeaderData header = (BOLHeaderData) getSessionValue(req, "HEADER");
            params.put("HEADER", header);
            saveFooter(params, userInfo);
            removeSessionValue(req, "HEADER");
            removeSessionValue(req, "FOOTER");
            setSessionValue(req, "HEADER", params.get("HEADER"));
            setSessionValue(req, "FOOTER", params.get("FOOTER"));
        }
    }
    setSessionValue(req, BOLId.CURRENT_SCREEN_ID, BOLId.FOOTER);
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to save BOL Footer.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param parmas java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void saveFooter(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{
    try
        {

        String LadingNo = "";
        String Fac = "";

        String Dept = "";
        String Div = "";
        String Sect = "";
        String Exp = "";
        String OrderNo = "";
        String Misc = "";

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();

        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
        LadingNo = header.getBolNum();
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);

        BOLUtil bolUtil = BOLUtil.getInstance();
        Fac = bolUtil.toUpperCase((String) params.get("FAC"));
        Dept = bolUtil.toUpperCase((String) params.get("DEPT"));
        Div = bolUtil.toUpperCase((String) params.get("DIV"));
        Sect = bolUtil.toUpperCase((String) params.get("SECT"));
        Exp = bolUtil.toUpperCase((String) params.get("EXP"));
        OrderNo = bolUtil.toUpperCase((String) params.get("ORDER_NO"));
        Misc = bolUtil.toUpperCase((String) params.get("MISC"));
        
        // acf2 logon

        IMSConnectionManager cm = bolUtil.getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("F");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        ;
        inMsg.setACCT__FAC__IN(Fac);
        inMsg.setACCT__DEPT__IN(Dept);
        inMsg.setACCT__DIV__IN(Div);
        inMsg.setACCT__SEC__IN(Sect);
        inMsg.setACCT__EXP__IN(Exp);
        inMsg.setACCT__ORDER__NO__IN(OrderNo);
        inMsg.setMISC__IN(Misc);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim(); //java.util.Vector list = new java.util.Vector();

            if (output.length() == 0)
                {
                //(this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                params.put("HEADER", header);

                BOLFooterData footer = new BOLFooterData();
                footer.setAcctFac(Fac);
                footer.setAcctDept(Dept);
                footer.setAcctDiv(Div);
                footer.setAcctSect(Sect);
                footer.setAcctExp(Exp);
                footer.setAcctOrderNo(OrderNo);
                footer.setAcctMisc(Misc);

                params.put("FOOTER", footer);

            }

            else if (output.length() != 0)
                {

                throw new BOLException(" received err in 'ApplyBtnPressed in BOLFooter'" + output);

            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();

            throw new BOLException(" received err in 'ApplyBtnPressed in BOLFooter'" + output);
        }

    }
    catch (BOLException e)
        {
		e.setMethod("saveFooter");
		e.setTranxID("AK010B31 ");
        throw e;
    }
    return;
}
}
