package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.data.BOLFooterData;
import cat.cis.poms.bol.data.BOLHeaderData;
import cat.cis.poms.bol.ims.AK0B31InMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg;
import cat.cis.poms.bol.ims.AK0B46InMsg;
import cat.cis.poms.bol.ims.AK0B46OutMsg;
import cat.cis.poms.bol.ims.AK0B50InMsg;
import cat.cis.poms.bol.ims.AK0B50OutMsg;
import cat.cis.poms.bol.ims.AK0B51InMsg;
import cat.cis.poms.bol.ims.AK0B51OutMsg;
import cat.cis.poms.bol.ims.AK0B80InMsg;
import cat.cis.poms.bol.ims.AK0B80OutMsg;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSUserInfo;

import com.ibm.connector.imstoc.DFSMsg;

/**
 * This command class handles the request for the View
 * BOL Header and redirects to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 
public class BOLHeaderCommand extends BOLBaseCommand
{
	 
	public static final String[] equipTypeR = {"CC", "CH", "CN", "GS", "ID", "MT", "RR", "RT", "TL" };
	public static final String[] equipTypeT = {"20", "2B", "40", "4B", "CI", "FR", "FT", "MT", "PU", "TV"};
	public static final String[] equipType = {"CC", "CH", "CN", "GS", "ID", "MT", "RR", "RT", "TL", " ", "20", "2B", "40", "4B", "CI", "FR", "FT", "MT", "PU", "TV"};
/**
 * BOLHeaderCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLHeaderCommand() {
	super();
}
/**
 * Method to copy BOL information from another BOL.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void copyBOL(Hashtable params, COPPSUserInfo userInfo) throws Exception
{

    try
        {

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        String LadingNo = (String) params.get("BOL_SELECTED");
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);

        String copyLadingNo = ((String) params.get("COPY_BOL")).toUpperCase();
        if (copyLadingNo.compareTo("") == 0)
            {

            throw new Exception("Please Enter Copy BOL Number");

        }
        String LadingFacR = copyLadingNo.substring(0, 4);
        String BolNoR = copyLadingNo.substring(4, 10);

        String DateShipped = "";
        String OriginCode = "";
        String OriginCity = "";
        String OriginState = "";

        String SealNo = "";
        String ContainerNo = "";

        String ClearanceFileNo = "";
        String ClearanceLtrNo = "";
        String DestinationCode = "";
        String AdrName = "";
        String AdrNameLine1 = "";
        String AdrTxtLine1 = "";
        String AdrTxtLine2 = "";
        String AdrCityName = "";
        String AdrState = "";
        String AdrPostalCode = "";
        String AdrCountry = "";

        String CarrierCode = "";
        String CarrierName = "";
        String Freight = "";
        String Consignee = "";
        String ContractNo = "";
        String ShipVia = "";
        String Stcc = "";
        BOLUtil bolUtil = BOLUtil.getInstance();
        DateShipped = bolUtil.toUpperCase((String) params.get("DATE_SHIPPED"));
        OriginCode = bolUtil.toUpperCase((String) params.get("ORIGIN_CODE"));
        OriginCity = bolUtil.toUpperCase((String) params.get("ORIGIN_CITY"));
        OriginState = bolUtil.toUpperCase((String) params.get("ORIGIN_STATE"));
        ShipVia = bolUtil.toUpperCase((String) params.get("SHIP_VIA"));
        CarrierCode = bolUtil.toUpperCase((String) params.get("ROUTE_CARRIER_CODE"));
        CarrierName = bolUtil.toUpperCase((String) params.get("CARRIER"));
        Freight = bolUtil.toUpperCase((String) params.get("FREIGHT"));
        Consignee = bolUtil.toUpperCase((String) params.get("CONSIGNEE"));
        ContractNo = bolUtil.toUpperCase((String) params.get("CONTRACT_NO"));
        Stcc = bolUtil.toUpperCase((String) params.get("STCC"));
        String DelTextArea = bolUtil.toUpperCase((String) params.get("DLR_INSTS"));

        String[] str = getDeliveryInst(DelTextArea);

        SealNo = bolUtil.toUpperCase((String) params.get("SEAL_NO"));
        ContainerNo = bolUtil.toUpperCase((String) params.get("CONTAINER_NO"));
        ClearanceFileNo = bolUtil.toUpperCase((String) params.get("CLR_FILE_NO"));
        ClearanceLtrNo = bolUtil.toUpperCase((String) params.get("CLR_LTR_NO"));
        DestinationCode = bolUtil.toUpperCase((String) params.get("DESTINATION"));
        AdrName = bolUtil.toUpperCase((String) params.get("SHIP_TO_NAME"));
        AdrNameLine1 = bolUtil.toUpperCase((String) params.get("ADDL_NAME"));
        AdrTxtLine1 = bolUtil.toUpperCase((String) params.get("ADDRESS1"));
        AdrTxtLine2 = bolUtil.toUpperCase((String) params.get("ADDRESS2"));
        AdrCityName = bolUtil.toUpperCase((String) params.get("CITY"));
        AdrState = bolUtil.toUpperCase((String) params.get("STATE"));
        AdrPostalCode = bolUtil.toUpperCase((String) params.get("ZIP"));
        AdrCountry = bolUtil.toUpperCase((String) params.get("COUNTRY"));
        // acf2 logon

        IMSConnectionManager cm = bolUtil.getIMSManager();
        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("R");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        inMsg.setFAC__BLDG__R__IN(LadingFacR);
        inMsg.setBL__NO__R__IN(BolNoR);

        inMsg.setORIGIN__CITY__CODE__IN(OriginCode);
        inMsg.setORIGIN__CITY__NAME__IN(OriginCity);
        inMsg.setORIGIN__STATE__IN(OriginState);
        inMsg.setSEAL__NO__1__IN(SealNo);
        //inMsg.setSEAL__NO__2__IN(SealNo2);
        inMsg.setTRANSP__MODE__IN(ShipVia);
        inMsg.setCONSIGNEE__IN(Consignee);
        inMsg.setINLAND__FRT__CHRG__CODE__IN(Freight);
        inMsg.setCONTRACT__NO__IN(ContractNo);
        inMsg.setROUTE__OR__CARRIER__CODE__IN(CarrierCode);
        inMsg.setROUTE__OR__CARRIER__NAME__IN(CarrierName);
        inMsg.setDEL__INST__LN1__IN(str[0]);
        inMsg.setDEL__INST__LN2__IN(str[1]);
        inMsg.setDEL__INST__LN3__IN(str[2]);
        inMsg.setDEL__INST__LN4__IN(str[3]);
        inMsg.setDEL__INST__LN5__IN(str[4]);
        inMsg.setCONTAINER__NUMBER__1__IN(ContainerNo);
        //inMsg.setCONTAINER__NUMBER__2__IN(ContainerNo2);
        inMsg.setCLRN__LTR__FILE__NO__IN(ClearanceFileNo);
        inMsg.setCLRN__LTR__NO__IN(ClearanceLtrNo);
        inMsg.setDESTINATION__CITY__CODE__IN(DestinationCode);
        inMsg.setADR__NAME__IN(AdrName);
        inMsg.setADR__NM__LN1__IN(AdrNameLine1);
        inMsg.setADR__TXT__LN1__IN(AdrTxtLine1);
        inMsg.setADR__TXT__LN2__IN(AdrTxtLine2);
        inMsg.setADR__CITY__NAME__IN(AdrCityName);
        inMsg.setADR__STATE__IN(AdrState);
        inMsg.setADR__POSTAL__ZONE__CODE__IN(AdrPostalCode);
        inMsg.setADR__COUNTRY__IN(AdrCountry);
        inMsg.setSTCC__CODE__IN(Stcc);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {

                //  (this.getSession().removeValue("sessionReIssueMsg"));

                params.put("NOTES_BREAKDOWN31", out.getNOTES__BREAKDOWN());
                BOLHeaderData header = new BOLHeaderData();
                // have to remove NOTES_BREAKDOWN80
                // (this.getSession()).removeValue("sessionNotesBreakdown80");
                header.setIssue(out.getISSUE__OUT());
                header.setDateShipped(DateShipped);
                header.setFactory(LadingFac);
                //header.setBuilding(BolNo);
                header.setOriginCode(OriginCode);
                header.setOriginCity(OriginCity);
                header.setOriginState(OriginState);
                header.setShipVia(ShipVia);
                header.setCarrierCode(out.getROUTE__OR__CARRIER__CODE__OUT());
                header.setCarrierName(out.getROUTE__OR__CARRIER__NAME__OUT());

                header.setConsignee(Consignee);
                header.setFreight(Freight);
                header.setContractNo(ContractNo);

                header.setSealNo1(SealNo);
                header.setContainerNum1(ContainerNo);
                header.setClearanceFileNo(ClearanceFileNo);
                header.setClearanceLtrNo(ClearanceLtrNo);
                header.setDestinationCode(DestinationCode);
                header.setAddressName(out.getADR__NAME__OUT());
                header.setAddressName1(out.getADR__NM__LN1__OUT());
                header.setAddressLine1(out.getADR__TXT__LN1__OUT());
                header.setAddressLine2(out.getADR__TXT__LN2__OUT());
                header.setAddressCity(out.getADR__CITY__NAME__OUT());
                header.setAddressState(out.getADR__STATE__OUT());
                header.setAddressPostal(out.getADR__POSTAL__ZONE__CODE__OUT());
                header.setAddressCountry(out.getADR__COUNTRY__OUT());
                header.setDeliveryInstLine1(out.getDEL__INST__LN1__OUT());
                header.setDeliveryInstLine2(out.getDEL__INST__LN2__OUT());
                header.setDeliveryInstLine3(out.getDEL__INST__LN3__OUT());
                header.setDeliveryInstLine4(out.getDEL__INST__LN4__OUT());
                header.setDeliveryInstLine5(out.getDEL__INST__LN5__OUT());
                header.setStccCode(out.getSTCC__CODE__OUT());
                params.put("HEADER", header);
            }

            else if (output.length() != 0)
                {
                throw new BOLException(output);

            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
	        e.setMethod("copyBOL");
	        e.setTranxID("AK010B31 ");
        throw e;
    }
    return;
}
/**
 * Method to delete BOL Header.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public boolean deleteHeader(Hashtable params, COPPSUserInfo userinfo) throws Exception
{
 	boolean flag = false;   
	try
        {
        String logonid = userinfo.getLogonId();
        String badge = userinfo.getBadge();
        String bolNum = (String)params.get("BOL_SELECTED");
        String LadingFac = bolNum.substring(0, 4);
        String BolNo = bolNum.substring(4, 10);

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("d");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
             output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();
             

            if (output.length() == 0)
                {
                 //System.out.println("successful delete");
                 flag = true;
            }

            else if (output.length() != 0)
                {
	                //throw new Exception(out.getERROR__MSG__ERR__MSG__OUT()+ " - " + output);
                	if(output.compareTo("BILL OF LADING SUCCESSFULLY DELETED") == 0)
                	{
	                	flag = true;
                	}
                	else
                	{
                		throw new BOLException(output);
                	}
            }

        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
             

        }

    }
    catch (BOLException e)
        {
         	e.setMethod("deleteHeader");
         	e.setTranxID("AK010B31 ");
	        throw e;
    }
    return flag;
}
/**
* Gets Car Ordered based on shipVia.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param shipVia java.lang.String
* @return java.lang.String[]
*/
public static String[] getCarOrdered(String shipVia)
{
    String[] carOrdered = null;
    if (shipVia.compareTo("R") == 0)
        {
        carOrdered = equipTypeR;
    }
    else if (shipVia.compareTo("T") == 0)
        {
        carOrdered = equipTypeT;
    }
    else
        {
        carOrdered = equipType;
    }
    return carOrdered;
}
/**
 * Method to break the delivery Instruction string
 * into 5 parts.
 * .
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param str java.lang.String
 * @return java.lang.String[]
 */
public String[] getDeliveryInst(java.lang.String str)
{
    String[] stri = { " ", " ", " ", " ", " " };
    if (str != null)
        {

        StringTokenizer token = new StringTokenizer(str, "\n");

        int n = 0;
        String note = "";
        while (token.hasMoreTokens())
            {
            note = token.nextToken();
            if (n == 0)
                {
                stri[0] = note;
            }
            if (n == 1)
                {
                stri[1] = note;
            }
            if (n == 2)
                {
                stri[2] = note;
            }
            if (n == 3)
                {
                stri[3] = note;
            }
            if (n == 4)
                {
                stri[4] = note;
            }
            n++;
        }

    }
    return stri;
}
/**
 * Method to manual update BOL Header.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @param log cat.cis.poms.com.log.ComLog
 * @exception java.lang.Exception
 */
public void manualUpdate(Hashtable params, COPPSUserInfo userInfo, ComLog log)
    throws Exception
{
 	  
	try
        {

        // load up BOL header bean
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
		String Bldg = "";
        
        String Dock = "";
        String OriginCode = "";
        String OriginCity = "";
        String OriginState = "";
        String CarrierCode = "";
        String CarrierName = "";
        String Freight = "";
        String Consignee = "";
        String ContractNo = "";
        String ShipVia = "";
        String CarOrderNo = "";
        String SealNo = "";
        String SealNo2 = "";
        String ContainerNo = "";
        String ContainerNo2 = "";
        String ClearanceFileNo = "";
        String ClearanceLtrNo = "";

        String DestinationCode = "";
        String AdrName = "";
        String AdrNameLine1 = "";
        String AdrTxtLine1 = "";
        String AdrTxtLine2 = "";
        String AdrCityName = "";
        String AdrState = "";
        String AdrPostalCode = "";
        String AdrCountry = "";
        
       
        String Stcc = "";

        BOLHeaderData header = (BOLHeaderData)params.get("HEADER");
        String LadingNo = (String) params.get("BOL_SELECTED");
        String LadingFac = header.getFactory();
        Bldg = header.getBuilding();
       

        BOLUtil bolUtil = BOLUtil.getInstance();
        
        Dock = bolUtil.toUpperCase((String)params.get("DK"));
        if(Dock.equals(""))
        {
	        Dock = " ";
        }
		OriginCode = bolUtil.toUpperCase((String) params.get("ORIGIN_CODE"));
		OriginCity = bolUtil.toUpperCase((String) params.get("ORIGIN_CITY"));
        OriginState = bolUtil.toUpperCase((String) params.get("ORIGIN_STATE"));
        ShipVia = bolUtil.toUpperCase((String)params.get("SHIP_VIA"));
        CarOrderNo = bolUtil.toUpperCase((String)params.get("CAR_ORDERED"));
        
        

        if (CarOrderNo.length() > 1)
            {
            CarOrderNo = CarOrderNo.substring(0, 2);
        }

        CarrierCode = bolUtil.toUpperCase((String) params.get("ROUTE_CARRIER_CODE"));
        CarrierName = bolUtil.toUpperCase((String) params.get("CARRIER"));
        Freight = bolUtil.toUpperCase((String) params.get("FREIGHT"));
        SealNo = bolUtil.toUpperCase((String) params.get("SEAL_NO"));
        Consignee = bolUtil.toUpperCase((String) params.get("CONSIGNEE"));
		ContractNo = bolUtil.toUpperCase((String) params.get("CONTRACT_NO"));
        Stcc = bolUtil.toUpperCase((String) params.get("STCC"));
        ContainerNo = bolUtil.toUpperCase((String) params.get("CONTAINER_NO"));
        ClearanceFileNo = bolUtil.toUpperCase((String) params.get("CLR_FILE_NO"));
        ClearanceLtrNo = bolUtil.toUpperCase((String) params.get("CLR_LTR_NO"));
        DestinationCode = bolUtil.toUpperCase((String) params.get("DESTINATION"));
        AdrName = bolUtil.toUpperCase((String) params.get("SHIP_TO_NAME"));
        AdrNameLine1 = bolUtil.toUpperCase((String) params.get("ADDL_NAME"));
        AdrTxtLine1 = bolUtil.toUpperCase((String) params.get("ADDRESS1"));
        AdrTxtLine2 = bolUtil.toUpperCase((String) params.get("ADDRESS2"));
        AdrCityName = bolUtil.toUpperCase((String) params.get("CITY"));
        AdrState = bolUtil.toUpperCase((String) params.get("STATE"));
        AdrPostalCode = bolUtil.toUpperCase((String) params.get("ZIP"));
        AdrCountry = bolUtil.toUpperCase((String) params.get("COUNTRY"));
        
        String DelTextArea = bolUtil.toUpperCase((String) params.get("DLR_INSTS"));

        String[] str = getDeliveryInst(DelTextArea);
       
        // acf2 logon

        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B46InMsg inMsg = new AK0B46InMsg();
        AK0B46OutMsg outMsg = new AK0B46OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 816);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B46 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("H");
        inMsg.setFAC__IN(LadingFac);
        inMsg.setBLDG__IN(Bldg);
        inMsg.setDOCK__IN(Dock);
        inMsg.setBOL__NO__IN(LadingNo);
        inMsg.setISSUE__IN("00");
        inMsg.setSEAL__NO1__IN(SealNo);
        inMsg.setSEAL__NO2__IN(SealNo2);
        inMsg.setORIGIN__CITY__CODE__IN(OriginCode);
        inMsg.setORIGIN__CITY__NAME__IN(OriginCity);
        inMsg.setORIGIN__STATE__IN(OriginState);
        inMsg.setSHIP__VIA__IN(ShipVia);
        inMsg.setEQUIP__TYPE__IN(CarOrderNo);
        inMsg.setCONSIGNEE__IN(Consignee);
        inMsg.setINLAND__FRT__CHRG__CODE__IN(Freight);

        inMsg.setCARRIER__CODE__IN(CarrierCode);
        inMsg.setCARRIER__NAME__IN(CarrierName);

        inMsg.setCONTAINER__NO1__IN(ContainerNo);
        inMsg.setCONTAINER__NO2__IN(ContainerNo2);
        inMsg.setCLRN__LTR__FILE__NO__IN(ClearanceFileNo);
        inMsg.setCLRN__LTR__NO__IN(ClearanceLtrNo);
        inMsg.setDESTINATION__CITY__CODE__IN(DestinationCode);
        inMsg.setADR__NAME__IN(AdrName);
        inMsg.setADR__NM__LN1__IN(AdrNameLine1);
        inMsg.setADR__TXT__LN1__IN(AdrTxtLine1);
        inMsg.setADR__TXT__LN2__IN(AdrTxtLine2);
        inMsg.setADR__CITY__NAME__IN(AdrCityName);
        inMsg.setADR__STATE__IN(AdrState);
        inMsg.setADR__POSTAL__ZONE__CODE__IN(AdrPostalCode);
        inMsg.setADR__COUNTRY__IN(AdrCountry);
        inMsg.setDEL__INST__LN1__IN(str[0]);
        inMsg.setDEL__INST__LN2__IN(str[1]);
        inMsg.setDEL__INST__LN3__IN(str[2]);
        inMsg.setDEL__INST__LN4__IN(str[3]);
        inMsg.setDEL__INST__LN5__IN(str[4]);
        inMsg.setCONTRACT__NO__IN(ContractNo);
        inMsg.setSTCC__CODE__IN(Stcc);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B46OutMsg)
            {
            AK0B46OutMsg out = (AK0B46OutMsg) bean;
            
            output = out.getERROR__MSG__OUT();
            output = output.trim();
           

            if (output.length() == 0)
                {

                header.setDock(out.getDOCK__OUT());	
                header.setIssue(out.getISSUE__OUT());
               	header.setOriginCode(OriginCode);
                header.setOriginCity(OriginCity);
                header.setOriginState(OriginState);
                header.setShipVia(ShipVia);
                header.setCarOrderNo(CarOrderNo);
                header.setCarrierCode(CarrierCode);
                header.setCarrierName(CarrierName);
                header.setConsignee(Consignee);
                header.setFreight(Freight);
                header.setContractNo(ContractNo);
                header.setSealNo1(SealNo);
                header.setSealNo2(SealNo2);
                header.setContainerNum1(ContainerNo);
                header.setContainerNum2(ContainerNo2);
           		header.setClearanceFileNo(ClearanceFileNo);
           		header.setClearanceLtrNo(ClearanceLtrNo);
           		header.setDestinationCode(DestinationCode);
           		header.setAddressName(AdrName);
           		header.setAddressName1(AdrNameLine1);
           		header.setAddressLine1(AdrTxtLine1);
           		header.setAddressLine2(AdrTxtLine2);
           		header.setAddressCity(AdrCityName);
           		header.setAddressState(AdrState);
           		header.setAddressCountry(AdrCountry);
           		header.setAddressPostal(AdrPostalCode);
           		header.setDeliveryInstLine1(str[0]);
           		header.setDeliveryInstLine2(str[1]);
           		header.setDeliveryInstLine3(str[2]);
           		header.setDeliveryInstLine4(str[3]);
           		header.setDeliveryInstLine5(str[4]);
           		header.setStccCode(Stcc);
           		header.setManualInd("M");
           		
                

            }

            else if (output.length() != 0)
                {
                
                throw new BOLException(output);
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
            
        }
    }
    catch (BOLException e)
        {
		e.setMethod("manualUpdate");
		e.setTranxID("AK010B46 ");
        throw e;
    }

    return;
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log = BOLUtil.getInstance().getLog("BOLHeader", "performTask()", cwsId);
    try
    {
	    
    //getting the user parameters for the request
    COPPSUserInfo userInfo = getUserInfo(req, log);
    Hashtable params = acquireParameters(req);

    String action = (String) params.get(BOLId.ACTION);
    String screen = (String) params.get(BOLId.CURRENT_SCREEN_ID);

    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_HEADER);

    if (screen != null)
        {
        if (screen.compareTo("0") != 0)
            {
            int id = Integer.parseInt(screen);
            url = BOLId.urlArr[id];
        }
        else if (action.compareTo("OPEN") == 0)
            {
            String bolNo = (String) getSessionValue(req, "BOL_SELECTED");
            String mode = (String) getSessionValue(req, BOLId.EDIT_MODE);
            params.put("BOL_SELECTED", bolNo);
            retrieveHeader(params, userInfo);
            
            setSessionValue(req, "BOL_SELECTED", bolNo);
            BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
            setSessionValue(req, "HEADER", header);
            setSessionValue(req, "SHIPPING_CHARGES", params.get("SHIPPING_CHARGES"));
            setSessionValue(
                req,
                "SHIPPING_CHARGES_TOTAL",
                params.get("SHIPPING_CHARGES_TOTAL"));
            setSessionValue(req, "VEHICLE_BREAKDOWN80", params.get("VEHICLE_BREAKDOWN80"));
            setSessionValue(req, "NOTES_BREAKDOWN80", params.get("NOTES_BREAKDOWN80"));
            removeSessionValue(req, "NOTES_BREAKDOWN31");
            setSessionValue(req, "FOOTER", params.get("FOOTER"));
            
           
            
            if (mode.compareTo("UPDATE") == 0 && header.getManualInd().compareTo("Y") == 0)
                {
                setSessionValue(req, BOLId.EDIT_MODE, "MANUAL_BUILD");
            }

        }
        else if (action.compareTo("APPLY") == 0)
            {
            String bolNo = (String) params.get("BOL_SELECTED");
            updateHeader(params, userInfo);
           
            setSessionValue(req, "BOL_SELECTED", bolNo);
            setSessionValue(req, "HEADER", params.get("HEADER"));
            setSessionValue(req, "NOTES_BREAKDOWN31", params.get("NOTES_BREAKDOWN31"));
            removeSessionValue(req, "NOTES_BREAKDOWN80");
            

        }
        else if (action.compareTo("DELETE") == 0)
            {
            
            boolean flag = deleteHeader(params, userInfo);
            if (flag == true)
                {
                req.getParameterValues("ACTION")[0] = "OPEN_UPDATE";
                setSessionValue(req, BOLId.EDIT_MODE, "UPDATE");
                //setSessionValue(req, "BOL_SELECTED", bolNo);
                setSessionValue(req, "HEADER", null);
                
                url = BOLUrl.EDIT_SERVLET;
            }

        }
        else if (action.compareTo("MANUAL_APPLY") == 0)
            {
            BOLHeaderData header = (BOLHeaderData) getSessionValue(req, "HEADER");
            params.put("HEADER", header);
            manualUpdate(params, userInfo, log);
            

            setSessionValue(req, "BOL_SELECTED", header.getBolNum());
            setSessionValue(req, "HEADER", params.get("HEADER"));
            setSessionValue(req, BOLId.EDIT_MODE, "MANUAL_BUILD");

        }
        else if (action.compareTo("COPY") == 0)
            {
            copyBOL(params, userInfo);
            setSessionValue(req, "HEADER", params.get("HEADER"));
            String bolNo = (String) params.get("BOL_SELECTED");
            setSessionValue(req, "BOL_SELECTED", bolNo);
            

        }
        else if (action.compareTo("PRINT") == 0)
            {
            printBOL(params, userInfo);
            String bolNo = (String) params.get("BOL_SELECTED");
            setSessionValue(req, "BOL_SELECTED", bolNo);
            //setSessionValue(req, "HEADER", params.get("HEADER"));
            
        }
        else if (action.compareTo("PRINT_SHIPPING_LABELS") == 0)
            {
            printShippingLabels(params, userInfo);
            String bolNo = (String) params.get("BOL_SELECTED");
            setSessionValue(req, "BOL_SELECTED", bolNo);
            //setSessionValue(req, "HEADER", params.get("HEADER"));
            
        }
    }
        setSessionValue(req, BOLId.CURRENT_SCREEN_ID, BOLId.HEADER);
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to print BOL.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void printBOL(Hashtable params, COPPSUserInfo userInfo) throws Exception
{

    try
        {

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        String LadingNo = (String) params.get("BOL_SELECTED");
        String Lterm = ((String)params.get("LTERM")).toUpperCase();
        

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B51InMsg inMsg = new AK0B51InMsg();
        AK0B51OutMsg outMsg = new AK0B51OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 283);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B51 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setPRINTER__LTERM1(Lterm);
        inMsg.setLADING__NO__IN(0, LadingNo);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B51OutMsg)
            {
            AK0B51OutMsg out = (AK0B51OutMsg) bean;

            output = out.getERR__MSG__OUT();
            output = output.trim();
            if(output.length() != 0)
            {
	            BOLException exc = new BOLException(output);
	            if(output.compareTo("BILL OF LADING PRINTED SUCCESSFULLY") == 0)
	            {
		            
		            exc.setInformation(true);
		            
	            }
	            throw exc;
            }
            
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
	        e.setMethod("printBOL");
	        e.setTranxID("AK010B51 ");
        throw e;
    }

    return;
}
/**
 * Method to print Shipping Labels.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void printShippingLabels(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{

    try
        {

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLUtil bolUtil = BOLUtil.getInstance();
        String LadingNo = bolUtil.toUpperCase((String) params.get("BOL_SELECTED"));
        String Lterm = bolUtil.toUpperCase((String) params.get("LTERM"));

        IMSConnectionManager cm = bolUtil.getIMSManager();

        AK0B50InMsg inMsg = new AK0B50InMsg();
        AK0B50OutMsg outMsg = new AK0B50OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 283);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B50 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setPRINTER__LTERM1(Lterm);
        inMsg.setLADING__NO__IN(0, LadingNo);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B50OutMsg)
            {
            AK0B50OutMsg out = (AK0B50OutMsg) bean;

            output = out.getERR__MSG__OUT();
            output = output.trim();

            if (output.length() != 0)
                {

                BOLException exc = new BOLException(output);
                if (output.compareTo("BILL OF LADING SILVER TAGS PRINTED SUCCESSFULLY") == 0)
                    {
                    exc.setInformation(true);

                }
				throw exc;
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
	        e.setMethod("printShippingLabels");
	        e.setTranxID("AK010B50 ");
        throw e;
    }

    return;
}
/**
 * Method to retrieve BOL Header.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public Hashtable retrieveHeader(
    Hashtable params,
    COPPSUserInfo userinfo)
    throws Exception
{
    
    try
        {

        String logonid = userinfo.getLogonId();
        String badge = userinfo.getBadge();
		String bolNum = (String)params.get("BOL_SELECTED");
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B80InMsg inMsg = new AK0B80InMsg();
        AK0B80OutMsg outMsg = new AK0B80OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 35);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B80 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setLADING__NO__IN(bolNum);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
				throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B80OutMsg)
            {
            AK0B80OutMsg out = (AK0B80OutMsg) bean;
            output = out.getERROR__MSG__OUT();
            output = output.trim();
            
            if (output.length() == 0)
                {

                BOLHeaderData header = new BOLHeaderData();
                header.setFactory(out.getFAC__OUT());
                header.setDock(out.getDOCK__OUT());
                header.setBolNum(out.getBOL__NO__OUT());
                header.setDateShipped(out.getSHIPPED__DATE__OUT());
                header.setIssue(out.getISSUE__OUT());
                header.setOriginCode(out.getORIGIN__CITY__CODE__OUT());
                header.setOriginCity(out.getORIGIN__CITY__NAME__OUT());
                header.setOriginState(out.getORIGIN__STATE__OUT());
                header.setDestinationCode(out.getDESTINATION__CITY__CODE__OUT());
                header.setShipVia(out.getSHIP__VIA__OUT());
                header.setCarOrderNo(out.getEQUIP__TYPE__OUT());
                header.setConsignee(out.getCONSIGNEE__OUT());
                header.setFreight(out.getINLAND__FRT__CHRG__CODE__OUT());
                header.setSealNo1(out.getSEAL__NO1__OUT());
                header.setSealNo2(out.getSEAL__NO2__OUT());
                header.setContainerNum1(out.getCONTAINER__NO1__OUT());
                header.setContainerNum2(out.getCONTAINER__NO2__OUT());
                header.setClearanceLtrNo(out.getCLRN__LTR__NO__OUT());
                header.setClearanceFileNo(out.getCLRN__LTR__FILE__NO__OUT());
                header.setContractNo(out.getCONTRACT__NO__OUT());
                header.setCarrierCode(out.getCARRIER__CODE__OUT());
                header.setCarrierName(out.getCARRIER__NAME__OUT());
                header.setDealerCode(out.getDLR__CODE__OUT());
                header.setAddressName(out.getADR__NAME__OUT());
                header.setAddressName1(out.getADR__NM__LN1__OUT());
                header.setAddressLine1(out.getADR__TXT__LN1__OUT());
                header.setAddressLine2(out.getADR__TXT__LN2__OUT());
                header.setAddressCity(out.getADR__CITY__NAME__OUT());
                header.setAddressState(out.getADR__STATE__OUT());
                header.setAddressPostal(out.getADR__POSTAL__ZONE__CODE__OUT());
                header.setAddressCountry(out.getADR__COUNTRY__OUT());
                header.setDeliveryInstLine1(out.getDEL__INST__LN1__OUT());
                header.setDeliveryInstLine2(out.getDEL__INST__LN2__OUT());
                header.setDeliveryInstLine3(out.getDEL__INST__LN3__OUT());
                header.setDeliveryInstLine4(out.getDEL__INST__LN4__OUT());
                header.setDeliveryInstLine5(out.getDEL__INST__LN5__OUT());
                header.setTotalWeight(out.getTOTAL__WEIGHT__OUT());
                header.setCommittedDate(out.getCOMMITTED__DATE__OUT());
                header.setExportTo(out.getEXPORT__TO__OUT());
                header.setLtLind(out.getLTL__IND__OUT());
                header.setCargoDesc(out.getACCT__FAC__OUT());
                header.setStccCode(out.getSTCC__CODE__OUT());
                header.setManualInd(out.getMANUAL__IND__OUT());
                header.setBuilding(out.getBLDG__OUT());
                params.put("HEADER", header);
                //header.setNotesBreakDown80(out.getNOTES__BREAKDOWN());

                BOLFooterData footer = new BOLFooterData();
                footer.setAcctFac(out.getACCT__FAC__OUT());
                footer.setAcctDept(out.getACCT__DEPT__OUT());
                footer.setAcctDiv(out.getACCT__DIV__OUT());
                footer.setAcctSect(out.getACCT__SEC__OUT());
                footer.setAcctOrderNo(out.getACCT__ORDER__NO__OUT());
                footer.setAcctMisc(out.getMISC__OUT());
                footer.setAcctExp(out.getACCT__EXP__OUT());
                params.put("FOOTER", footer);
                params.put("SHIPPING_CHARGES", out.getSHIPPING__CHARGES());
                params.put("SHIPPING_CHARGES_TOTAL", new Double(out.getFRT__CHRG__TOTAL__OUT()));
                
                String PrintInd = out.getPRINT__IND__OUT();
                if (PrintInd.equals("Y"))
                    {
                    header.setReIssueMsg("This BOL has already been PRINTED. Any changes will result in a REISSUE");
                }
               
                params.put("NOTES_BREAKDOWN80", out.getNOTES__BREAKDOWN());
                //have to remove NOTES_BREAKDOWN31
                
                params.put("VEHICLE_BREAKDOWN80", out.getVEHICLE__BREAKDOWN());
               
            }
            else if (output.length() != 0)
                {
                throw new BOLException(out.getERROR__MSG__OUT() + " - " + output);
            }

        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
	        e.setMethod("retrieveHeader");
	        e.setTranxID("AK010B80 ");
        throw e;

    }
    return params;
    
}
/**
 * Method to update BOL Header.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void updateHeader(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{

    try
        {
        BOLHeaderData header = new BOLHeaderData();
        String logonid = userInfo.getLogonId();
        String badge = userInfo.getBadge();

        String LadingNo = (String) params.get("BOL_SELECTED");
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);

        String fac = "";
        String DateShipped = "";
        String OriginCode = "";
        String OriginCity = "";
        String OriginState = "";

        String SealNo = "";
        String ContainerNo = "";
        String ClearanceFileNo = "";
        String ClearanceLtrNo = "";
        String DestinationCode = "";
        String AdrName = "";
        String AdrNameLine1 = "";
        String AdrTxtLine1 = "";
        String AdrTxtLine2 = "";
        String AdrCityName = "";
        String AdrState = "";
        String AdrPostalCode = "";
        String AdrCountry = "";
        String CarrierCode = "";
        String CarrierName = "";
        String Freight = "";
        String Consignee = "";
        String ContractNo = "";
        String ShipVia = "";
        String CarOrderNo = "";
        String Stcc = "";
        BOLUtil bolUtil = BOLUtil.getInstance();

        fac = bolUtil.toUpperCase((String) params.get("FAC"));
        DateShipped = bolUtil.toUpperCase((String) params.get("DATE_SHIPPED"));
        OriginCode = bolUtil.toUpperCase((String) params.get("ORIGIN_CODE"));
        OriginCity = bolUtil.toUpperCase((String) params.get("ORIGIN_CITY"));
        OriginState = bolUtil.toUpperCase((String) params.get("ORIGIN_STATE"));
        ShipVia = bolUtil.toUpperCase((String) params.get("SHIP_VIA"));
        CarOrderNo = bolUtil.toUpperCase((String) params.get("CAR_ORDERED"));
        if (CarOrderNo.length() > 1)
            {
            CarOrderNo = CarOrderNo.substring(0, 2);
        }

        CarrierCode = bolUtil.toUpperCase((String) params.get("ROUTE_CARRIER_CODE"));
        CarrierName = bolUtil.toUpperCase((String) params.get("CARRIER"));
        Freight = bolUtil.toUpperCase((String) params.get("FREIGHT"));
        Consignee = bolUtil.toUpperCase((String) params.get("CONSIGNEE"));
        ContractNo = bolUtil.toUpperCase((String) params.get("CONTRACT_NO"));
        Stcc = bolUtil.toUpperCase((String) params.get("STCC"));
        String DelTextArea = bolUtil.toUpperCase((String) params.get("DLR_INSTS"));

        String[] str = getDeliveryInst(DelTextArea);

        SealNo = bolUtil.toUpperCase((String) params.get("SEAL_NO"));
        ContainerNo = bolUtil.toUpperCase((String) params.get("CONTAINER_NO"));
        ClearanceFileNo = bolUtil.toUpperCase((String) params.get("CLR_FILE_NO"));
        ClearanceLtrNo = bolUtil.toUpperCase((String) params.get("CLR_LTR_NO"));
        DestinationCode = bolUtil.toUpperCase((String) params.get("DESTINATION"));
        AdrName = bolUtil.toUpperCase((String) params.get("SHIP_TO_NAME"));
        AdrNameLine1 = bolUtil.toUpperCase((String) params.get("ADDL_NAME"));
        AdrTxtLine1 = bolUtil.toUpperCase((String) params.get("ADDRESS1"));
        AdrTxtLine2 = bolUtil.toUpperCase((String) params.get("ADDRESS2"));
        AdrCityName = bolUtil.toUpperCase((String) params.get("CITY"));
        AdrState = bolUtil.toUpperCase((String) params.get("STATE"));
        AdrPostalCode = bolUtil.toUpperCase((String) params.get("ZIP"));
        AdrCountry = bolUtil.toUpperCase((String) params.get("COUNTRY"));

        // acf2 logon

        IMSConnectionManager cm = bolUtil.getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("H");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        //inMsg.setDATE__SHIPPED__IN("");
        inMsg.setORIGIN__CITY__CODE__IN(OriginCode);
        inMsg.setORIGIN__CITY__NAME__IN(OriginCity);
        inMsg.setORIGIN__STATE__IN(OriginState);
        inMsg.setSEAL__NO__1__IN(SealNo);
        inMsg.setSEAL__NO__2__IN("");
        inMsg.setTRANSP__MODE__IN(ShipVia);
        inMsg.setEQUIP__DESC__CODE__IN(CarOrderNo);
        inMsg.setCONSIGNEE__IN(Consignee);
        inMsg.setINLAND__FRT__CHRG__CODE__IN(Freight);
        inMsg.setCONTRACT__NO__IN(ContractNo);
        inMsg.setROUTE__OR__CARRIER__CODE__IN(CarrierCode);
        inMsg.setROUTE__OR__CARRIER__NAME__IN(CarrierName);
        inMsg.setDEL__INST__LN1__IN(str[0]);
        inMsg.setDEL__INST__LN2__IN(str[1]);
        inMsg.setDEL__INST__LN3__IN(str[2]);
        inMsg.setDEL__INST__LN4__IN(str[3]);
        inMsg.setDEL__INST__LN5__IN(str[4]);
        inMsg.setCONTAINER__NUMBER__1__IN(ContainerNo);
        inMsg.setCONTAINER__NUMBER__2__IN("");
        inMsg.setCLRN__LTR__FILE__NO__IN(ClearanceFileNo);
        inMsg.setCLRN__LTR__NO__IN(ClearanceLtrNo);
        inMsg.setDESTINATION__CITY__CODE__IN(DestinationCode);
        inMsg.setADR__NAME__IN(AdrName);
        inMsg.setADR__NM__LN1__IN(AdrNameLine1);
        inMsg.setADR__TXT__LN1__IN(AdrTxtLine1);
        inMsg.setADR__TXT__LN2__IN(AdrTxtLine2);
        inMsg.setADR__CITY__NAME__IN(AdrCityName);
        inMsg.setADR__STATE__IN(AdrState);
        inMsg.setADR__POSTAL__ZONE__CODE__IN(AdrPostalCode);
        inMsg.setADR__COUNTRY__IN(AdrCountry);
        inMsg.setSTCC__CODE__IN(Stcc);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;
            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {

                //(this.getSession()).putValue("sessionNotesBreakdown", cmd.getAK0B30OutMsg1NOTES__BREAKDOWN());
                header.setReIssueMsg(BOLId.STRING_INIT);
                // (this.getSession().removeValue("sessionReIssueMsg"));
                params.put("NOTES_BREAKDOWN31", out.getNOTES__BREAKDOWN());
                // have to remove NOTES_BREAKDOWN80
                //(this.getSession()).putValue( "sessionNotesBreakdown31", out.getNOTES__BREAKDOWN());
                //(this.getSession()).removeValue("sessionNotesBreakdown80");
                header.setFactory(fac);
                header.setDock(out.getDOCK__OUT());
                header.setBolNum(out.getBOL__NO__OUT());
                header.setDateShipped(DateShipped);
                header.setIssue(out.getISSUE__OUT());
                header.setOriginCode(OriginCode);
                header.setOriginCity(out.getCITY__OUT());
                header.setOriginState(out.getSTATE__OUT());
                header.setDestinationCode(DestinationCode);
                header.setShipVia(ShipVia);
                header.setCarOrderNo(CarOrderNo);
                header.setConsignee(Consignee);
                header.setFreight(Freight);
                header.setSealNo1(SealNo);
                header.setSealNo2("");
                header.setContainerNum1(ContainerNo);
                header.setContainerNum2("");
                header.setClearanceLtrNo(ClearanceLtrNo);
                header.setClearanceFileNo(ClearanceFileNo);
                header.setContractNo(ContractNo);
                header.setCarrierCode(CarrierCode);
                header.setCarrierName(out.getROUTE__OR__CARRIER__NAME__OUT());
                header.setDealerCode("");
                header.setAddressName(AdrName);
                header.setAddressName1(AdrNameLine1);
                header.setAddressLine1(AdrTxtLine1);
                header.setAddressLine2(AdrTxtLine2);
                header.setAddressCity(AdrCityName);
                header.setAddressState(AdrState);
                header.setAddressPostal(AdrPostalCode);
                header.setAddressCountry(AdrCountry);
                header.setDeliveryInstLine1(str[0]);
                header.setDeliveryInstLine2(str[1]);
                header.setDeliveryInstLine3(str[2]);
                header.setDeliveryInstLine4(str[3]);
                header.setDeliveryInstLine5(str[4]);
                header.setTotalWeight("");
                header.setCommittedDate("");
                header.setExportTo("");
                header.setLtLind("");
                header.setCargoDesc("");
                header.setStccCode(out.getSTCC__CODE__OUT());
                header.setManualInd("U");

                params.put("HEADER", header);
            }

            else if (output.length() != 0)
                {
                throw new BOLException(out.getERROR__MSG__ERR__MSG__OUT());
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
	        e.setMethod("updateHeader");
	        e.setTranxID("AK010B31 ");
        throw e;
    }
    return;
}
}
