package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

import java.util.Hashtable;
import java.util.Vector;
import java.util.StringTokenizer;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLString;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.copps.model.COPPSUserInfo;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import com.ibm.connector.imstoc.DFSMsg;

import cat.cis.poms.bol.data.BOLHeaderData;
import cat.cis.poms.bol.data.BOLDetailsData;
import cat.cis.poms.bol.ims.AK0B46InMsg;
import cat.cis.poms.bol.ims.AK0B46OutMsg;
import cat.cis.poms.bol.ims.AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT;
import cat.cis.poms.bol.ims.AK0B80OutMsg_VEHICLE__BREAKDOWN;
import cat.cis.poms.bol.ims.AK0B80OutMsg_NOTES__BREAKDOWN;
import cat.cis.poms.bol.ims.AK0B31InMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg;
import cat.cis.poms.bol.ims.AK0B31OutMsg_NOTES__BREAKDOWN;

/**
 * This command class handles the request for the View
 * BOL Manual Details and redirects
 * to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLManualDetailsCommand extends BOLBaseCommand
{
/**
 * BOLManualDetailsCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLManualDetailsCommand() {
	super();
}
/**
 * Method to add manual Details.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void addDetails(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{

    try
        {
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
        String LadingNo = header.getBolNum();
        String Fac = header.getFactory();
        String Bldg = header.getBuilding();
        String Qty = "";
        String PackDesc = "";
        String Desc = "";
        String Gross = "";
        String Net = "";
        String High = "";
        String Wide = "";
        String Long = "";
        String HazMatCode = "    ";
        String HazMatCode1 = "";
        String HazMatCode2 = "";
        String HazMatCode3 = "";
        String HazMatCode4 = "";

        String Line = (String) params.get("MANUAL_LINE_NO");
        if (Line == null)
            {
            Line = "0";
        }
            
		BOLUtil bolUtil = BOLUtil.getInstance();
        Qty = bolUtil.toUpperCase((String) params.get("QTY"));
        PackDesc = bolUtil.toUpperCase((String) params.get("PACK_DESC"));
        Desc = bolUtil.toUpperCase((String) params.get("DESC"));
        Gross = bolUtil.toUpperCase((String) params.get("GROSS"));
        Net = bolUtil.toUpperCase((String) params.get("NET"));
        High = bolUtil.toUpperCase((String) params.get("HEIGHT"));
        Wide = bolUtil.toUpperCase((String) params.get("WIDTH"));
        Long = bolUtil.toUpperCase((String) params.get("LENGTH"));
        HazMatCode = bolUtil.toUpperCase((String) params.get("HAZ_MAT_CODE"));
        if (HazMatCode.length() > 0)
            {
            HazMatCode1 = HazMatCode.substring(0, 1);
        }
        if (HazMatCode.length() > 1)
            {
            HazMatCode2 = HazMatCode.substring(1, 2);
        }
        if (HazMatCode.length() > 2)
            {
            HazMatCode3 = HazMatCode.substring(2, 3);
        }
        if (HazMatCode.length() > 3)
            {
            HazMatCode4 = HazMatCode.substring(3, 4);
        }

        //	(this.getSession()).putValue("sessionClearanceLtrNo", (this.getRequest()).getParameterValues(ClearanceLtrNo));
        short QtyIn = Short.valueOf(Qty).shortValue();
        short LineNoIn = Short.valueOf(Line).shortValue();
        ++LineNoIn;
        String LineNo = String.valueOf(LineNoIn);
        params.put("MANUAL_LINE_NO", LineNo);

        int GrossIn = Integer.valueOf(Gross).intValue();
        int NetIn = Integer.valueOf(Net).intValue();
        int HighIn = Integer.valueOf(High).intValue();
        int LongIn = Integer.valueOf(Long).intValue();
        int WideIn = Integer.valueOf(Wide).intValue();

        IMSConnectionManager cm = bolUtil.getIMSManager();

        AK0B46InMsg inMsg = new AK0B46InMsg();
        AK0B46OutMsg outMsg = new AK0B46OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 816);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B46 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setBOL__NO__IN(LadingNo);
        inMsg.setRECORD__TYPE__IN("D");
        inMsg.setFAC__IN(Fac);
        inMsg.setBLDG__IN(Bldg);
        inMsg.setTRAN__TYPE__IN("A");
        inMsg.setDIM__WT__LINE__NO__IN(LineNoIn);
        inMsg.setQTY__IN(QtyIn);
        inMsg.setLENGTH__IN(LongIn);
        inMsg.setWIDTH__IN(WideIn);
        inMsg.setHEIGHT__IN(HighIn);
        inMsg.setGROSS__WT__IN(GrossIn);
        inMsg.setNET__WT__IN(NetIn);
        inMsg.setPACK__DESC__IN(PackDesc);
        inMsg.setPACKG__LIST__DESC__IN(Desc);
        inMsg.setHAZARDOUS__REF__CODE1__IN(HazMatCode1);
        inMsg.setHAZARDOUS__REF__CODE2__IN(HazMatCode2);
        inMsg.setHAZARDOUS__REF__CODE3__IN(HazMatCode3);
        inMsg.setHAZARDOUS__REF__CODE4__IN(HazMatCode4);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B46OutMsg)
            {
            AK0B46OutMsg out = (AK0B46OutMsg) bean;
            output = out.getERROR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {
                //(this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                params.put("VEHICLE_BREAKDOWN46", out.getVEHICLE__BREAKDOWN__OUT());
                //this.getSession().removeValue("sessionVehicleBreakdown");
            }

            else if (output.length() != 0)
                {
                throw new BOLException(output);
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
	        e.setMethod("addDetails");
	        e.setTranxID("AK010B46 ");
        throw e;
    }

    return;

}
/**
 * Method to delete manual Details.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void deleteDetails(Hashtable params, COPPSUserInfo userInfo) throws Exception
{

    try
        {
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
        String LadingNo = header.getBolNum();
        String Fac = header.getFactory();
        String Bldg = header.getBuilding();
		short LineNoIn = 0;
		String deleteItem = (String)params.get("DELETE_SELECTION");
       
        AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT a[] =
            (AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[]) params.get("VEHICLE_BREAKDOWN46");
            
		if(a != null)
		{
			int delete = Integer.valueOf(deleteItem).intValue();
        	LineNoIn = a[delete].getDIM__WT__LINE__NO__OUT();
		}

		AK0B80OutMsg_VEHICLE__BREAKDOWN b[] =
            (AK0B80OutMsg_VEHICLE__BREAKDOWN[]) params.get("VEHICLE_BREAKDOWN80");
		if(a== null && b != null)
		{
			int delete = Integer.valueOf(deleteItem).intValue();
        	LineNoIn = Integer.valueOf(b[delete].getDIM__WT__LINE__NO__OUT()).shortValue();
		}
		
		
        
		 

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B46InMsg inMsg = new AK0B46InMsg();
        AK0B46OutMsg outMsg = new AK0B46OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 816);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B46 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setBOL__NO__IN(LadingNo);
        inMsg.setRECORD__TYPE__IN("D");
        inMsg.setFAC__IN(Fac);
        inMsg.setBLDG__IN(Bldg);
        inMsg.setTRAN__TYPE__IN("D");
        inMsg.setDIM__WT__LINE__NO__IN(LineNoIn);

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B46OutMsg)
            {
            AK0B46OutMsg out = (AK0B46OutMsg) bean;
            
            output = out.getERROR__MSG__OUT();
            output = output.trim();
             

            if (output.length() == 0)
                {
                
                //(this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                params.put("VEHICLE_BREAKDOWN46", out.getVEHICLE__BREAKDOWN__OUT());
                //this.getSession().removeValue("sessionVehicleBreakdown");
                
            }

            else if (output.length() != 0)
                {
                throw new BOLException(output);
            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }

    }
    catch (BOLException e)
        {
	        e.setMethod("deleteDetails");
	        e.setTranxID("AK010B46 ");
       throw e;
    }

    return;

}
/**
 * Method to execute the request from the View
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log =
        BOLUtil.getInstance().getLog("BOLManualDetails", "performTask()", cwsId);
    try
    {
	    
    //getting the user parameters for the request

    COPPSUserInfo userInfo = getUserInfo(req, log);
    Hashtable params = acquireParameters(req);
    String action = (String) params.get(BOLId.ACTION);
    String screen = (String) params.get(BOLId.CURRENT_SCREEN_ID);
    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_DETAILS);
    if (screen != null)
        {
        if (screen.compareTo("4") != 0)
            {
            int id = Integer.parseInt(screen);
            url = BOLId.urlArr[id];
        }
        else if (action.compareTo("OPEN") == 0)
            {

            Object[] vehicleBreakdown80 =
                (Object[]) getSessionValue(req, "VEHICLE_BREAKDOWN80");
            if (vehicleBreakdown80 != null)
                {
                params.put("VEHICLE_BREAKDOWN80", vehicleBreakdown80);
            }
            Object[] vechicleBreakDown46 =
            (Object[]) getSessionValue(req, "VEHICLE_BREAKDOWN46");
            if (vechicleBreakDown46 != null)
                {
                params.put("VEHICLE_BREAKDOWN46", vechicleBreakDown46);
            }
            retrieveDetails(params);
            setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));
            setSessionValue(req, "DETAIL_TABLE", params.get("DETAIL_TABLE"));
            setSessionValue(req, "MANUAL_LINE_NO", params.get("MANUAL_LINE_NO"));
        }
        else if (action.compareTo("APPLY") == 0)
            {

            setSessionValue(req, BOLId.CURRENT_SCREEN_ID, "4");
            setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);
            BOLHeaderData header = (BOLHeaderData) getSessionValue(req, "HEADER");
            params.put("HEADER", header);
            saveNotes(params, userInfo);
            retrieveDetails(params);
            setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));

        }
        else if (action.compareTo("ADD") == 0)
            {
            BOLHeaderData header = (BOLHeaderData) getSessionValue(req, "HEADER");
            params.put("HEADER", header);
            String LineNo = (String) getSessionValue(req, "MANUAL_LINE_NO");
            if(LineNo != null)
            {
            	params.put("MANUAL_LINE_NO", LineNo);
            }
            addDetails(params, userInfo);
            retrieveDetails(params);
            setSessionValue(req, "VEHICLE_BREAKDOWN46", params.get("VEHICLE_BREAKDOWN46"));
            removeSessionValue(req, "VEHICLE_BREAKDOWN80");
            setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));
            setSessionValue(req, "DETAIL_TABLE", params.get("DETAIL_TABLE"));
            setSessionValue(req, "MANUAL_LINE_NO", params.get("MANUAL_LINE_NO"));
        }
        else if (action.compareTo("DELETE") == 0)
            {
            BOLHeaderData header = (BOLHeaderData) getSessionValue(req, "HEADER");
            Object[] vechicleBreakDown46 =
                (Object[]) getSessionValue(req, "VEHICLE_BREAKDOWN46");
            if (vechicleBreakDown46 != null)
                {
                params.put("VEHICLE_BREAKDOWN46", vechicleBreakDown46);
            }
            Object[] vehicleBreakdown =
                (Object[]) getSessionValue(req, "VEHICLE_BREAKDOWN80");
            if (vehicleBreakdown != null)
                {
                params.put("VEHICLE_BREAKDOWN80", vehicleBreakdown);
            }

            params.put("HEADER", header);
            deleteDetails(params, userInfo);
            retrieveDetails(params);
            setSessionValue(req, "VEHICLE_BREAKDOWN46", params.get("VEHICLE_BREAKDOWN46"));
            removeSessionValue(req, "VEHICLE_BREAKDOWN80");
            setSessionValue(req, "DETAIL_NOTES", params.get("DETAIL_NOTES"));
            setSessionValue(req, "DETAIL_TABLE", params.get("DETAIL_TABLE"));
        }
    }
    setSessionValue(req, BOLId.CURRENT_SCREEN_ID, BOLId.MANUAL_DETAILS);
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_DATA);

    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to process notes.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param obj java.lang.Object[]
 * @return java.lang.String
 */
public String processNotes(Object[] obj)
{

    AK0B31OutMsg_NOTES__BREAKDOWN[] c = (AK0B31OutMsg_NOTES__BREAKDOWN[]) obj;

    String desc = "";
    String code = "";
    int numProgramNotes = 0;
    int numManual = 0;
    for (int n = 0; n < 30; n++)
        {
        desc = c[n].getSHIPPING__NOTES__OUT().trim();
        if (desc.length() > 0)
            {
            code = c[n].getNOTE__CODE__OUT().trim();
            if (code.equals("P"))
                {
                ++numProgramNotes;

            }
            else
                {
                ++numManual;
            }
        }
        else
            {
            ++numManual;

        }
    }

    int numNotes = numProgramNotes + numManual;

    StringBuffer manual = new StringBuffer("");
    for (int n = 0; n < numNotes; n++)
        {
        desc = c[n].getSHIPPING__NOTES__OUT().trim();
        if (desc.length() > 0)
            {
            code = c[n].getNOTE__CODE__OUT().trim();
            if (code.compareTo("P") != 0)
                {
                if (manual.toString().compareTo("") == 0)
                    {
                    manual.append(desc);
                }
                else
                    {
                    manual.append("\n");
                    manual.append(desc);
                }
            }
        }
    }

    return manual.toString();
}
/**
 * Method to retrieve manual Details.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 */
public void retrieveDetails(Hashtable params)
{

    AK0B80OutMsg_VEHICLE__BREAKDOWN[] d =
        (AK0B80OutMsg_VEHICLE__BREAKDOWN[]) params.get("VEHICLE_BREAKDOWN80");
	AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[] a =
        (AK0B46OutMsg_VEHICLE__BREAKDOWN__OUT[]) params.get("VEHICLE_BREAKDOWN46");
    
    String desc = null;
    String code = null;
    String manual = "";
    int numDescs = 0;
    int numNotes = 0;
    int numProgramNotes = 0;
    String LineNo = null;
    int line = 0;
    int numTotal = 0;
    int numManual = 0;
    String note;

    if (a != null)
        {
        for (int i = 0; i < 50; i++)
            {
            desc = a[i].getPACKG__LIST__DESC__OUT().trim();
            if (desc.length() > 0)
                {
                ++numDescs;
            }
            else
                {
                break;
            }
        }
    }
    else if (d != null)
        {
        for (int i = 0; i < 50; i++)
            {
            desc = d[i].getPACKG__LIST__DESC__OUT().trim();
            if (desc.length() > 0)
                {
                ++numDescs;
            }
            else
                {
                break;
            }
        }
    }

    AK0B80OutMsg_NOTES__BREAKDOWN[] c =
        (AK0B80OutMsg_NOTES__BREAKDOWN[]) params.get("NotesBreakdown80");
    AK0B31OutMsg_NOTES__BREAKDOWN[] b =
        (AK0B31OutMsg_NOTES__BREAKDOWN[]) params.get("NOTES_BREAKDOWN31");

    if (b != null)
        {

        for (int n = 0; n < 30; n++)
            {
            desc = b[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = b[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {

                    ++numProgramNotes;
                }
                else
                    {
                    ++numManual;
                }
            }

            else
                {
                ++numManual;
            }

        }

    }
    else if (c != null)
        {
        for (int n = 0; n < 30; n++)
            {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
                    ++numProgramNotes;
                }
                else
                    {
                    ++numManual;
                }
            }

            else
                {
                ++numManual;
            }
        }

    }

    numNotes = numProgramNotes + numManual;
    numTotal = numProgramNotes + numDescs;
    String test = "4040404";
    String test2 = "40404";
   	String test3 = "404";
    Vector detailsTable = new Vector();
    BOLDetailsData data = null;
    StringBuffer descBuffer = null;
    BOLString bolS = null;
    String e = null;
    if (d == null)
        {
        for (int i = 0; i < numDescs; i++)
            {
	            data = new BOLDetailsData();
            e = String.valueOf(i);
            bolS = new BOLString(e);
            //data.setQty(bolS.stripLeadingZeroes());
             

            line = a[i].getDIM__WT__LINE__NO__OUT();
            LineNo = String.valueOf(line).toString();
            if(line != 999)
            {
            	data.setLineNo(LineNo);
            	params.put("MANUAL_LINE_NO", LineNo);
            }
            e = String.valueOf(a[i].getQTY__OUT()).toString();
             if (e.equals(test3))
                {
                e = "";
            }
                bolS = new BOLString(e);
            
            data.setQty(bolS.stripLeadingZeroesReturnSpace());
            
            data.setUnits(a[i].getPACK__DESC__OUT().trim());
			
            descBuffer = new StringBuffer(a[i].getPACKG__ID__OUT().trim());
            descBuffer.append("     ");
            descBuffer.append(a[i].getPACKG__LIST__DESC__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(a[i].getHAZARDOUS__REF__CODE1__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(a[i].getHAZARDOUS__REF__CODE2__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(a[i].getHAZARDOUS__REF__CODE3__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(a[i].getHAZARDOUS__REF__CODE4__OUT().trim());
            data.setDesc(descBuffer.toString());
		
            e = String.valueOf(a[i].getHEIGHT__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setHeight(bolS.stripLeadingZeroesReturnSpace());
            
            

            e = String.valueOf(a[i].getWIDTH__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setWidth(bolS.stripLeadingZeroesReturnSpace());
            

            e = String.valueOf(a[i].getLENGTH__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setLength(bolS.stripLeadingZeroesReturnSpace());
            

            e = String.valueOf(a[i].getGROSS__WT__OUT()).toString();
            if (e.equals(test))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setWeight(bolS.stripLeadingZeroesReturnSpace());
            detailsTable.add(data);

            
        }
    }
    else
        {
        for (int i = 0; i < numDescs; i++)
            {
	        data = new BOLDetailsData();
            e = String.valueOf(i).toString();
            bolS = new BOLString(e);
            
            LineNo = d[i].getDIM__WT__LINE__NO__OUT();
            
            if(LineNo.compareTo("999") != 0)
            {
            data.setLineNo(LineNo);
            params.put("MANUAL_LINE_NO", LineNo);
            }
            e = String.valueOf(d[i].getQTY__OUT()).toString();
            if (e.equals(test3))
                {
                e = "";
            }
                bolS = new BOLString(e);
            data.setQty(bolS.stripLeadingZeroesReturnSpace());
            
            data.setUnits(d[i].getPACK__DESC__OUT().trim());

            descBuffer = new StringBuffer(d[i].getPACKG__ID__OUT().trim());
            descBuffer.append("     ");
            descBuffer.append(d[i].getPACKG__LIST__DESC__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(d[i].getHAZARDOUS__REF__CODE1__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(d[i].getHAZARDOUS__REF__CODE2__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(d[i].getHAZARDOUS__REF__CODE3__OUT().trim());
            descBuffer.append(" ");
            descBuffer.append(d[i].getHAZARDOUS__REF__CODE4__OUT().trim());

            data.setDesc(descBuffer.toString());

            e = String.valueOf(d[i].getHEIGHT__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setHeight(bolS.stripLeadingZeroesReturnSpace());
            

            e = String.valueOf(d[i].getWIDTH__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setWidth(bolS.stripLeadingZeroesReturnSpace());
            

            e = String.valueOf(d[i].getLENGTH__OUT()).toString();
            if (e.equals(test2))
                {
                e = "";
            }
            bolS = new BOLString(e);
            data.setLength(bolS.stripLeadingZeroesReturnSpace());
            

            e = String.valueOf(d[i].getGROSS__WT__OUT()).toString();
            if (e.equals(test))
                {
                e = "";
            }
            bolS = new BOLString(e);
             
            data.setWeight(bolS.stripLeadingZeroesReturnSpace());
            detailsTable.add(data);
        }
    }

    int i = numDescs;
    if (c == null)
        {

        for (int n = 0; n < numNotes; n++)
            {
            desc = b[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = b[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
	                    data = new BOLDetailsData();
                    data.setDesc(b[n].getSHIPPING__NOTES__OUT().trim());
                    i++;
                    detailsTable.add(data);
                }
                else
                    {
                    if (manual == "")
                        {
                        manual = desc;
                    }
                    else
                        {
                        manual = manual + "\n" + desc;
                    }
                    i++;
                }
            }

        }
    }
    else
        {

        for (int n = 0; n < numNotes; n++)
            {
            desc = c[n].getSHIPPING__NOTES__OUT().trim();
            if (desc.length() > 0)
                {
                code = c[n].getNOTE__CODE__OUT().trim();
                if (code.equals("P"))
                    {
	                data = new BOLDetailsData();
                    data.setDesc(c[n].getSHIPPING__NOTES__OUT().trim());
                    i++;
                    detailsTable.add(data);
                }
                else
                    {
                    if (manual == "")
                        {
                        manual = desc;
                    }
                    else
                        {
                        manual = manual + "\n" + desc;
                    }
                    i++;
                }
            }
        }
    }
    

    
	params.put("DETAIL_NOTES", manual);
    params.put("DETAIL_TABLE", detailsTable);
    
    return;

}
/**
 * Method to save notes.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.userInfo
 * @exception java.lang.Exception
 */
public void saveNotes(Hashtable params, COPPSUserInfo userInfo)
    throws Exception
{

    try
        {
        String userNotes = null;
        String note = null;
        String badge = null;
        String LadingNo = null;
        String Headerdate = null;
        String ClearanceFileNo = null;
        String ClearanceLtrNo = null;

        userNotes = ((String) params.get("BOL_DTL_NOTES")).toUpperCase();

        if ((userNotes == null) || (userNotes.length() == 0))
        {
            return;
        }
        BOLHeaderData header = (BOLHeaderData) params.get("HEADER");
        // load up BOL header bean
        String logonid = userInfo.getAcf2Id();
        badge = userInfo.getBadge();
        LadingNo = header.getBolNum();
        String LadingFac = LadingNo.substring(0, 4);
        String BolNo = LadingNo.substring(4, 10);

        Headerdate = header.getDateShipped();
        if (Headerdate == null)
            {
            Headerdate = "";
        }

        ClearanceFileNo = header.getClearanceFileNo();

        if (ClearanceFileNo == null)
            {
            ClearanceFileNo = "";
        }

        ClearanceLtrNo = header.getClearanceLtrNo();
        if (ClearanceLtrNo == null)
            {
            ClearanceLtrNo = "";
        }

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B31InMsg inMsg = new AK0B31InMsg();
        AK0B31OutMsg outMsg = new AK0B31OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 2170);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B31 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setRECORD__TYPE__IN("N");
        inMsg.setFAC__BLDG__IN(LadingFac);
        inMsg.setBL__NO__IN(BolNo);
        inMsg.setCLRN__LTR__FILE__NO__IN(ClearanceFileNo);
        inMsg.setCLRN__LTR__NO__IN(ClearanceLtrNo);
        
        StringTokenizer token = new StringTokenizer(userNotes, "\n");
        int n = 0;
        while (token.hasMoreTokens())
            {
            note = token.nextToken();
            inMsg.setMANUAL__NOTE(n, note);

            n++;
        }
        inMsg.setSHORT__CUT__NOTE(0, (String) params.get("SCNOTE0"));
        inMsg.setSHORT__CUT__NOTE(1, (String) params.get("SCNOTE1"));
        inMsg.setSHORT__CUT__NOTE(2, (String) params.get("SCNOTE2"));
        inMsg.setSHORT__CUT__NOTE(3, (String) params.get("SCNOTE3"));
        inMsg.setSHORT__CUT__NOTE(4, (String) params.get("SCNOTE4"));
        inMsg.setSHORT__CUT__NOTE(5, (String) params.get("SCNOTE5"));
        inMsg.setSHORT__CUT__NOTE(6, (String) params.get("SCNOTE6"));
        inMsg.setSHORT__CUT__NOTE(7, (String) params.get("SCNOTE7"));
        inMsg.setSHORT__CUT__NOTE(8, (String) params.get("SCNOTE8"));
        inMsg.setSHORT__CUT__NOTE(9, (String) params.get("SCNOTE9"));

        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B31OutMsg)
            {
            AK0B31OutMsg out = (AK0B31OutMsg) bean;

            output = out.getERROR__MSG__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() == 0)
                {

                
                //(this.getSession().removeValue("sessionReIssueMsg"));
                header.setReIssueMsg(BOLId.STRING_INIT);
                header.setIssue(out.getISSUE__OUT());
                params.put("NOTES_BREAKDOWN31", out.getNOTES__BREAKDOWN());
                //(this.getSession()).removeValue("sessionNotesBreakdown80");
                String manual = processNotes(out.getNOTES__BREAKDOWN());
            	params.put("DETAIL_NOTES", manual);
            }

            else if (output.length() != 0)
                {
                throw new BOLException(output);

            }
        }
        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
	        e.setMethod("saveNotes");
	        e.setTranxID("AK010B31 ");
        throw e;
    }

    return;

}
}
