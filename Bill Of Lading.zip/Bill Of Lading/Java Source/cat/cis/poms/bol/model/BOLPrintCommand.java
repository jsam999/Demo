package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;
import java.util.Vector;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.ims.AK0B43InMsg;
import cat.cis.poms.bol.ims.AK0B43OutMsg;
import cat.cis.poms.bol.ims.AK0B50InMsg;
import cat.cis.poms.bol.ims.AK0B50OutMsg;
import cat.cis.poms.bol.ims.AK0B51InMsg;
import cat.cis.poms.bol.ims.AK0B51OutMsg;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSUserInfo;

import com.ibm.connector.imstoc.DFSMsg;

/**
 * This command class handles the request for the View
 * BOL Print/Print Shipping Labels and redirects
 * to appropriate JSP's.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 
public class BOLPrintCommand extends BOLBaseCommand
{
/**
 * BOLPrintCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLPrintCommand() {
	super();
}
/**
 * Method to add BOL number to selected BOL list.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param newBOL java.lang.String
 * @param curBOLs java.util.Vector
 * @param xrefBol java.lang.String
 * @return java.util.Vector
 * @exception java.lang.Exception
 */
public Vector add(String newBOL, Vector curBOLs, String xrefBol)
    throws Exception
{

    if (newBOL == null || newBOL.equals(""))
        {
        newBOL = xrefBol;
    }

    if (newBOL.equals(""))
        {
        throw new Exception("Please provide a BOL to add");
    }

    if (curBOLs == null)
        {
        curBOLs = new java.util.Vector();
    }

    newBOL = newBOL.trim();

    if (newBOL.length() == 10)
        {
	    int size = curBOLs.size();
	    String bolNo = null;
	    for(int i=0; i <size; i++)
        {
	        bolNo = (String)curBOLs.elementAt(i);
	        if(bolNo.compareTo(newBOL)== 0)
	        {
		        return curBOLs;
	        }
        }
        curBOLs.addElement(newBOL);
    }
    else
        {
        throw new Exception("Invalid BOL Number provided");
    }

    return curBOLs;
}
/**
 * Retrieve mso cross reference from the database.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param msoNo java.lang.String
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @return java.util.Vector
 * @exception java.lang.Exception
 */
public Vector msoXRef(String msoNo, COPPSUserInfo userInfo) throws Exception
{
    Vector bolLst = null;
    try
        {
        //	System.out.println("Hey we are in X-ref");
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
		
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B43InMsg inMsg = new AK0B43InMsg();
        AK0B43OutMsg outMsg = new AK0B43OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 30);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B43 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setMSO__NO__IN(msoNo);
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B43OutMsg)
            {
            AK0B43OutMsg out = (AK0B43OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getMSO__ERR__MSG__OUT();
            output = output.trim();
            
            if (output.length() == 0)
                {
                String[] b = out.getBLS__OUT();
                bolLst = new Vector();

                String bol = null;

                for (int n = 0; n < 25; n++)
                    {
                    bol = "";
                    bol = b[n];
                    bolLst.addElement(bol); 
                }

               
            
            }

            else if (output.length() != 0)
                {
                throw new BOLException(out.getMSO__ERR__MSG__OUT());

            }
            }
            if (bean instanceof DFSMsg)
                {
                DFSMsg out = (DFSMsg) bean;
                output = out.getDFSMessage();
                throw new BOLException(output);

            }
        }
    catch (BOLException e)
        {
	        e.setMethod("msoXRef");
	        e.setTranxID("AK010B43 ");
        throw e;
    }

    return bolLst;
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log = BOLUtil.getInstance().getLog("BOLPrint", "performTask()", cwsId);
    try
    {
	   
    //getting the user parameters for the request

    COPPSUserInfo userInfo = getUserInfo(req, log);
    Hashtable params = acquireParameters(req);
   
    String action = (String) params.get(BOLId.ACTION);

    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_PRINT);

    if (action != null)
        {
        if (action.compareTo("OPEN_PRINT") == 0)
            {
            removeSessionValue(req, "BOL_SEL_LIST");
            removeSessionValue(req, "BOL_LIST");
            removeSessionValue(req, "MSO");
            setSessionValue(req,"PRINT_EDIT_MODE", "PRINT");
        }
        else if (action.compareTo("OPEN_PRINT_SHIPPING_LABELS") == 0)
            {
            removeSessionValue(req, "BOL_SEL_LIST");
            removeSessionValue(req, "BOL_LIST");
            removeSessionValue(req, "MSO");
            setSessionValue(req,"PRINT_EDIT_MODE", "PRINT_SHIPPING_LABELS");
        }
        else if (action.compareTo("ADD") == 0)
            {
            String bolNo = (String) params.get("BOL_NO");
            Vector bolList = (Vector) getSessionValue(req, "BOL_SEL_LIST");
            String selBol = (String) params.get("BOL_LIST");
            bolList = add(bolNo, bolList, selBol);
            setSessionValue(req, "BOL_SEL_LIST", bolList);
        }
        else if (action.compareTo("REMOVE") == 0)
            {
            String bolNo = (String) params.get("BOL_SEL_LIST");
            Vector bolList = (Vector) getSessionValue(req, "BOL_SEL_LIST");
            remove(bolNo, bolList);
            setSessionValue(req, "BOL_SEL_LIST", bolList);
        }
        else if (action.compareTo("REMOVE_ALL") == 0)
            {
            setSessionValue(req, "BOL_SEL_LIST", new Vector());
        }
        else if (action.compareTo("XREF") == 0)
            {
            String mso = (String) params.get("MSO");
            Vector bolList = msoXRef(mso, userInfo);
            setSessionValue(req, "BOL_LIST", bolList);
            setSessionValue(req, "MSO", mso);
        }
        else if (action.compareTo("PRINT") == 0)
            {
            Vector bolLst = (Vector) getSessionValue(req, "BOL_SEL_LIST");
            if(bolLst == null)
            {
	            throw new Exception("Please enter BOL Number(s) to be printed");
            }
            params.put("BOL_SEL_LIST", bolLst);
            print(params, userInfo);
            //setSessionValue(req, "RESULT", params.get("RESULT"));
        }
        else if (action.compareTo("PRINT_SHIPPING_LABELS") == 0)
        {
            Vector bolLst = (Vector) getSessionValue(req, "BOL_SEL_LIST");
            if(bolLst == null)
            {
	            throw new Exception("Please enter BOL Number(s) to be printed");
            }
            params.put("BOL_SEL_LIST", bolLst);
            printShippingLabels(params, userInfo); 
            
        }
        else if (action.compareTo("CLOSE") == 0)
            {
            screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);
            
        }

    }
        req.getAttribute("PRINT_EDIT_MODE");
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
	}
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to print BOL invoice.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param container java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @exception java.lang.Exception
 */
public void print(Hashtable container, COPPSUserInfo userInfo) throws Exception
{
    try
        {

        // load up BOL header bean
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        Vector currBols = (Vector) container.get("BOL_SEL_LIST");
        int numOrders = currBols.size();

        String Lterm = (String) container.get("LTERM");
		if(Lterm == null || (Lterm.trim()).compareTo("") == 0)
		{
        	throw new BOLException("Please Enter LTERM");
		}
        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B51InMsg inMsg = new AK0B51InMsg();
        AK0B51OutMsg outMsg = new AK0B51OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 283);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B51 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setPRINTER__LTERM1(Lterm);

        for (int c = 0; c < numOrders; c++)
            {
            inMsg.setLADING__NO__IN(c, (String) currBols.elementAt(c));
        }
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {

            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B51OutMsg)
            {
            AK0B51OutMsg out = (AK0B51OutMsg) bean;

            output = out.getERR__MSG__OUT();
            output = output.trim();
            if (output.length() != 0)
                {
	            BOLException exc = new BOLException(output);
                        
                if (output.compareTo("BILL OF LADING PRINTED SUCCESSFULLY") == 0)
                    {
                    exc.setInformation(true);
                    
                }
               throw exc;
            }

        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
			e.setMethod("print");
			e.setTranxID("AK010B51 ");
        throw e;
    }

    return;
}
/**
 * Method to print Shipping labels
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param params java.util.Hashtable
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * exception java.land.Exception
 */
public void printShippingLabels(
    Hashtable params,
    COPPSUserInfo userInfo)
    throws Exception
{

    try
        {

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
		BOLUtil bolUtil = BOLUtil.getInstance();
        //String LadingNo = bolUtil.toUpperCase((String) params.get("BOL_SEL_LIST"));
        Vector currBols = (Vector) params.get("BOL_SEL_LIST");
        int numOrders = currBols.size();
        
        String Lterm = bolUtil.toUpperCase((String) params.get("LTERM"));
		/*
		if(LadingNo == null || (LadingNo.trim()).compareTo("") == 0)
		{
        	throw new BOLException("Please Enter BOL number");
		}
		*/
		if(Lterm == null || (Lterm.trim()).compareTo("") == 0)
		{
        	throw new BOLException("Please Enter LTERM");
		}
        IMSConnectionManager cm = bolUtil.getIMSManager();

        AK0B50InMsg inMsg = new AK0B50InMsg();
        AK0B50OutMsg outMsg = new AK0B50OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 283);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__IN("AK010B50 ");
        inMsg.setBADGE__NO__IN(badge);
        inMsg.setUSER__ACF2__IN(logonid);
        inMsg.setPRINTER__LTERM1(Lterm);
        //inMsg.setLADING__NO__IN(0, LadingNo);
		for (int c = 0; c < numOrders; c++)
            {
            inMsg.setLADING__NO__IN(c, (String) currBols.elementAt(c));
        }
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B50OutMsg)
            {
            AK0B50OutMsg out = (AK0B50OutMsg) bean;

            output = out.getERR__MSG__OUT();
            output = output.trim();

            if (output.length() != 0)
                {

                BOLException exc = new BOLException(output);
                   if (output.compareTo("BILL OF LADING SILVER TAGS PRINTED SUCCESSFULLY") == 0)
                    {
                    exc.setInformation(true);
                    
                }
                throw exc;
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
	        e.setMethod("printShippingLabels");
	        e.setTranxID("AK010B50 ");
        throw e;
    }

    return;
}
/**
 * Method to remove the BOL number from BOL list
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param selItem java.lang.String
 * @param curList java.util.Vector
 */
public void remove(String selItem, Vector curList)
{

    if (curList == null)
    {
        return;
    }
    int numItems = curList.size();
    String txt = null;
    for (int i = 0; i < numItems; i++)
        {

        txt = (String) curList.elementAt(i);

        if (txt.compareTo(selItem) == 0)
            {
            curList.removeElementAt(i);
            return;
        }
    }

    return;
}
}
