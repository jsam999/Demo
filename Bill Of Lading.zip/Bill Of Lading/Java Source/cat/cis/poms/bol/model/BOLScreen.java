package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Vector;

/**
 * This class contains the BOL screen list for the user based on
 * security setup in COPPS Security tables in IMS
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

public class BOLScreen {
	private Vector screenList = null;
/**
 * BOLScreen default constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLScreen() {
	super();
}
/**
 * BOLScreen constructor taking screen list.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param list java.util.Vector
 */
public BOLScreen(Vector list) {
	super();
	screenList = list;
}
/**
 * Given a screenTitle, this method checks, if the user
 * has authorization to access this functionality
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 * @param screenTitle java.lang.String
 */
public boolean checkAvailable(String screenTitle) {
	int size = 0;

	if(screenList != null)
	{
		size = screenList.size();
		String str = null;
		for(int i= 0; i < size; i++)
		{
			str = (String)screenList.elementAt(i);
			str = str.trim();
			if(screenTitle.compareTo(str) == 0)
			{
				return true;
			}
		}
	}
	return false;
}
/**
 * Method checks if user is authorized to build BOL
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includeBuild() {
	return checkAvailable("BOL ORDER CONSOLIDATION");
}
/**
 * Method checks if user is authorized to inquire BOL
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includeInquiry() {
	return checkAvailable("BOL INQUIRY");
}
/**
 * Method checks if user is authorized to manual build BOL
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includeManualBuild() {
	return checkAvailable("BOL MANUAL BOL");
}
/**
 * Method checks if user is authorized to print BOL
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includePrint() {
	return checkAvailable("BOL PRINT");
}
/**
 * Method checks if user is authorized to print Shipping labels of BOL
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includePrintShippingLabels() {
	return checkAvailable("BOL PRINT SHIPPING LABELS");
}
/**
 * Method checks if user is authorized to update BOL
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean includeUpdate() {
	return checkAvailable("BOL UPDATE EXISTING BOL");
}
}
