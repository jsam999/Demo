package cat.cis.poms.bol.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletContext;

import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLException;
import cat.cis.poms.copps.model.COPPSUserInfo;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;
import com.ibm.connector.imstoc.DFSMsg;
import cat.cis.poms.bol.ims.AK0B25InMsg;
import cat.cis.poms.bol.ims.AK0B25OutMsg;
import cat.cis.poms.bol.ims.AK0B25InMsg_MSO__TABLE__IN;
import cat.cis.poms.bol.ims.AK0B20InMsg;
import cat.cis.poms.bol.ims.AK0B20OutMsg;
import cat.cis.poms.bol.ims.AK0B20OutMsg_VEHICLE__BREAKDOWN;
import cat.cis.poms.bol.data.BOLVehicleData;
import cat.cis.poms.bol.data.BOLVehicleItem;

/**
 * This command class handles the request for the View
 * BOL Vehicle Assignment and redirects
 * to appropriate JSP's.
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

 
public class BOLVechileAssignmentCommand extends BOLBaseCommand
{
/**
 * BOLVechileAssignmentCommand default constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLVechileAssignmentCommand() {
	super();
}
/**
 * add a vehicle to the vehicle list - insertion point based on alpha sort.
 * note, in this implementation, vector must already be allocated
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param vehicle cat.cis.poms.bol.data.BOLVehicleData - vehicle to add
 * @param list java.util.Vector - vehicle list
 */
public void addVehicle(BOLVehicleData vehicle, Vector list) {
	BOLVehicleData vh = null;

	 // retrieve sort field
	String vehName = vehicle.getVehicleName();
	
	int numVehicles = list.size();
	
	// loop through list and determine where the new element should be inserted which
	// is indicated by whether it is higher in the alpha ordering
	for (int i=0;i<numVehicles;i++) {
		vh = (BOLVehicleData)list.elementAt(i);
		if (vehName.compareTo(vh.getVehicleName()) < 0) {
			list.insertElementAt(vehicle,i);
			return;
		}
	}

	// element simply needs to be added at the end
	list.addElement(vehicle);
	
	return;
	
}
/**
 * Method to change vehicle
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param items java.lang.String[] - array of vehicle's
 * @param vehList java.util.Vector - list of cat.cis.poms.bol.data.BOLVehicleData
 * @return java.util.Vector - list of cat.cis.poms.bol.data.BOLVehcileItem's
 */
public Vector changeVehicle(String[] items, Vector vehList)
{

    int numItems = items.length;
    int numVehicles = vehList.size();
    int pos = 0; // position in items array

    BOLVehicleData vehicle = null;
    BOLVehicleData vehicleOut = null;
    BOLVehicleItem item = null;
    Vector vehItems = null;
    Vector sn = new Vector(); // new vehicle assignments
    int j = 0;
    Hashtable vehHash = new Hashtable();
    // vehicle hash table used for parsing items
    String vehName = null;
    Vector itemList = null;
    String vehSrch = null;

    //start change

    for (int i = 0; i < numVehicles; i++)
        {
        vehicle = (BOLVehicleData) vehList.elementAt(i);
        vehItems = vehicle.getItems();
        numItems = vehItems.size();
        vehName = vehicle.getVehicleName();

        for (j = 0; j < numItems; j++)
            {
            item = (BOLVehicleItem) vehItems.elementAt(j);

            vehSrch = items[pos].toUpperCase();

            vehicleOut = (BOLVehicleData) vehHash.get(vehSrch);
            if (vehicleOut == null)
                { // nope, it's a new one
                vehicleOut = new BOLVehicleData();
                vehicleOut.setVehicleName(vehSrch);
                vehicleOut.setNumItems(1);
                vehicleOut.setTotalWeight(item.getGrossWeight());
                itemList = new Vector();
                itemList.addElement(item);
                vehicleOut.setItems(itemList);
                vehHash.put(vehSrch, vehicleOut);
                // add element in alphabetical order
                addVehicle(vehicleOut, sn);
            }
            // vehicle exists, simply update the weight and the items list
            else
                {
                itemList = vehicleOut.getItems();
                itemList.addElement(item);
                vehicleOut.setItems(itemList);
                vehicleOut.addTotalWeight(item.getGrossWeight());
                vehicleOut.addNumItems(1);
            }
            ++pos;
        }

    }

    return sn;
}
/**
 * Method to execute the request from the View
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @param res javax.servlet.ServletContext
 * @exception java.lang.Exception
 */
public void performTask(
    HttpServletRequest req,
    HttpServletResponse res,
    ServletContext context)
    throws Exception
{
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log =
        BOLUtil.getInstance().getLog("BOLVechileAssignment", "performTask()", cwsId);
    try
    {
	//getting the user parameters for the request

    COPPSUserInfo userInfo = getUserInfo(req, log);
    Hashtable params = acquireParameters(req);
    String action = (String) params.get(BOLId.ACTION);

    String url = BOLUrl.MAIN_FRAME;
    String[] screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_VEC_ASSIGN);

    if (action != null)
        {

        if (action.compareTo("OPEN") == 0)
            {

            Vector msoList = (Vector) getSessionValue(req, "MSO_LIST");
            Vector vehicleItems = retrieveVehicle(msoList, userInfo);
            setSessionValue(req, "VEHICLE_ITEMS", vehicleItems);
            setSessionValue(req, "SHOW_UPDATE", "N");
        }
        else if (action.compareTo("CHANGE") == 0)
            {

            Object data = (Object) params.get("VEHICLE_RESULT_COLUMN");
            String[] items = null;
            if (data instanceof String[])
                {
                items = (String[]) data;
            }
            else
                {
                items = new String[1];
                items[0] = (String) data;
            }
            Vector vechicleList = (Vector) getSessionValue(req, "VEHICLE_ITEMS");
            if (vechicleList != null)
                {
                Vector vehicleItems = changeVehicle(items, vechicleList);
                setSessionValue(req, "VEHICLE_ITEMS", vehicleItems);
                setSessionValue(req, "SHOW_UPDATE", "Y");
            }

        }
        else if (action.compareTo("UPDATE") == 0)
            {

            Object data = (Object) params.get("VEHICLE_RESULT_COLUMN");
            String[] items = null;
            if (data instanceof String[])
                {
                items = (String[]) data;
            }
            else
                {
                items = new String[1];
                items[0] = (String) data;
            }
            Vector vechicleList = (Vector) getSessionValue(req, "VEHICLE_ITEMS");
            if (vechicleList != null)
                {
                saveVehicle(vechicleList, userInfo);

            }
            setSessionValue(req, "SHOW_UPDATE", "N");
        }
        else if (action.compareTo("CLOSE") == 0)
            {

            screenUrl = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);

        }

    }
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, context, url);
    }
    catch (BOLException e)
        {
        log.logFatal(e.getErrorDetails(), e);
        throw e;
    }
}
/**
 * Method to retrieve vehicle
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param currOrders java.util.Vector mso list
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 * @return java.util.Vector list of cat.cis.poms.bol.data.BOLVechicleItem's
 */
public Vector retrieveVehicle(
    Vector currOrders,
    COPPSUserInfo userInfo)
    throws Exception
{
   
	Vector sn = new Vector();
	try
        {

        if ((currOrders == null) || (currOrders.size() < 1))
            {

            throw new Exception("Please enter MSO(s) to consolidate");

        }

        
        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();
        String[] ordersList = new String[currOrders.size()];
        int numOrders = currOrders.size();
        for (int i = 0; i < numOrders; i++)
            {
            ordersList[i] = (String) currOrders.elementAt(i);
        }

        // acf2 logon
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B20InMsg inMsg = new AK0B20InMsg();
        AK0B20OutMsg outMsg = new AK0B20OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);

        inMsg.setLL__IN((short) 150);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__MSG__IN("AK010B20 ");
        inMsg.setBADGE__IN(badge);
        inMsg.setACF2__USER__ID__IN(logonid);
        for (int c = 0; c < ordersList.length; c++)
        {
            inMsg.setMSO__IN(c, ordersList[c]);
        }
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B20OutMsg)
            {
            AK0B20OutMsg out = (AK0B20OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getMSO__ERR__MSG__OUT();
            output = output.trim();
            
            if (output.length() == 0)
                {

                AK0B20OutMsg_VEHICLE__BREAKDOWN[] vb = out.getVEHICLE__BREAKDOWN();

                // BJD
                // extract out vehicle breakdown structure and place in object representation

                Hashtable vehHash = new Hashtable();
                // vehicle hash table used for parsing items
                BOLVehicleData vehicle = null;
                BOLVehicleItem item = null;
                Vector itemList = null;
                String desc = null;
                String vehName = null;
                
                // final holder for vehicle information

                // loop through vehicle breakdown output and place into objects
                int numItems = vb.length;
                for (int i = 0; i < numItems; i++)
                    {
                    desc = vb[i].getVEHNUM().trim();

                    // assumption: empty string represents end of list
                    if (desc.length() <= 0)
                        {
                        break;
                    }

                    // load up vehicle item object which represents one row in the result table
                    item = new BOLVehicleItem();
                    item.setPackDesc(vb[i].getPACK__DESC__OUT().trim());
                    item.setIdNo(vb[i].getPACKG__ID__NO__OUT().trim());
                    item.setDescription(vb[i].getPACKG__LIST__DESC__OUT().trim());
                    item.setGrossWeight(Integer.parseInt(vb[i].getGROSS__WT__OUT().trim()));
                    item.setNetWeight(Integer.parseInt(vb[i].getNET__WT__OUT().trim()));
                    item.setHeight(Integer.parseInt(vb[i].getHEIGHT__OUT().trim()));
                    item.setWidth(Integer.parseInt(vb[i].getWIDTH__OUT().trim()));
                    item.setLength(Integer.parseInt(vb[i].getLENGTH__OUT().trim()));
                    item.setVehName(vb[i].getVEHNUM().trim());
                    item.setLineNo(vb[i].getDIM__WT__LINE__OUT().trim());
                    vehName = item.getVehName();

                    // add item to appropriate vehicle
                    vehicle = (BOLVehicleData) vehHash.get(vehName);

                    // determine if vehicle already has items
                    if (vehicle == null)
                        { // nope, it's a new one
                        vehicle = new BOLVehicleData();
                        vehicle.setVehicleName(vehName);
                        vehicle.setNumItems(1);
                        vehicle.setTotalWeight(item.getGrossWeight());
                        itemList = new java.util.Vector();
                        itemList.addElement(item);
                        vehicle.setItems(itemList);
                        vehHash.put(vehName, vehicle);
                        sn.addElement(vehicle);
                    }
                    // vehicle exists, simply update the weight and the items list
                    else
                        {
                        itemList = vehicle.getItems();
                        itemList.addElement(item);
                        vehicle.setItems(itemList);
                        vehicle.addTotalWeight(item.getGrossWeight());
                        vehicle.addNumItems(1);
                    }
                }


                    
               
                 
                
                 
            }
            else if (output.length() != 0)
                {
                throw new BOLException(output + out.getFill_0());
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);
        }

    }
    catch (BOLException e)
        {
	        e.setMethod("retrieveVehicle");
	        e.setTranxID("AK010B20 ");
        throw e;
    }
    return sn;
}
/**
 * Method to save vehicle list
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param vehList java.util.Vector - vehicle list to be saved
 * @param userInfo cat.cis.poms.copps.model.COPPSUserInfo
 */
public void saveVehicle(Vector vehList, COPPSUserInfo userInfo)
    throws Exception
{
    try
        {

        String logonid = userInfo.getAcf2Id();
        String badge = userInfo.getBadge();

        int c = 0;
        String mso = "";
        AK0B25InMsg_MSO__TABLE__IN[] a =
            (AK0B25InMsg_MSO__TABLE__IN[]) new AK0B25InMsg_MSO__TABLE__IN[120];

        int numVehicles = vehList.size();

        BOLVehicleItem item = null; // item on the vehicle
        BOLVehicleData vehicle = null;
        // vehicle items are contained in
        String vehName = null; // holder for vehicle name
        Vector items = null;
        int j = 0; // your basic loop variable 8^)
        int numItems;

        // loop through each vehicle and check if the vehicle name in the item is the same as the
        // vehicle it is contained in.  If not, then it has been moved since original load
        for (int i = 0; i < numVehicles; i++)
            {
            vehicle = (BOLVehicleData) vehList.elementAt(i);

            // extract off vehicle name
            vehName = vehicle.getVehicleName();

            // retrieve items on that vehicle and loop through each one checking the vehicle names
            items = vehicle.getItems();
            numItems = items.size();
            for (j = 0; j < numItems; j++)
                {
                item = (BOLVehicleItem) items.elementAt(j);

                // check if the vehicle name in the item is the same as the vehicle it is placed in. If not,
                // call to make the db change since it has moved
                if (vehName.compareTo(item.getVehName()) != 0)
                    {
                    a[c] = new AK0B25InMsg_MSO__TABLE__IN();
                    mso = item.getIdNo().substring(0, 7);
                    a[c].setMSO__NO__IN(mso);
                    a[c].setDIM__WT__LINE__NO__IN(item.getLineNo());
                    a[c].setVEHNUM__IN(vehName);
                    item.setVehName(vehName);
                    c++;
                }

            }
        }

       
        IMSConnectionManager cm = BOLUtil.getInstance().getIMSManager();

        AK0B25InMsg inMsg = new AK0B25InMsg();
        AK0B25OutMsg outMsg = new AK0B25OutMsg();
        IMSTransaction ims = new IMSTransaction(cm, outMsg);
        inMsg.setLL__IN((short) 1588);
        inMsg.setZZ__IN((short) 0);
        inMsg.setTRAN__CODE__MSG__IN("AK010B25 ");
        inMsg.setBADGE__IN(badge);
        inMsg.setACF2__USER__ID__IN(logonid);
        for (int i = 0; i < c; i++)
        {
            inMsg.setMSO__TABLE__IN(i, a[i]);
        }
        Object bean = null;

        try
            {
            bean = ims.callIMS(inMsg);
        }
        catch (Exception e)
            {
            throw new BOLException(e.getMessage());
        }

        String output = null;

        if (bean instanceof AK0B25OutMsg)
            {
            AK0B25OutMsg out = (AK0B25OutMsg) bean;
            // retreive ims data and populate output screen fields
            output = out.getMSO__ERR__MSG__OUT();
            output = output.trim();

            if (output.length() != 0)
                {
                throw new BOLException(out.getMSO__NO__ERR__MSG__OUT());
            }
        }

        if (bean instanceof DFSMsg)
            {
            DFSMsg out = (DFSMsg) bean;
            output = out.getDFSMessage();
            throw new BOLException(output);

        }
    }
    catch (BOLException e)
        {
		e.setMethod("saveVehicle");
		e.setTranxID("AK010B25 ");
        throw e;
    }
    return;
}
}
