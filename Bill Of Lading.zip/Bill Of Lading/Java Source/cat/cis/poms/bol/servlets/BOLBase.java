package cat.cis.poms.bol.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.com.servlet.ComBaseServlet;

/**
 * This abstract Servlet extended from ComBaseServlet
 * provides additional functionality needed specifically
 * by BOL system
 * 
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
 
public abstract class BOLBase extends ComBaseServlet {
/**
 * BOLBase constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLBase() {
	super();
}
/**
 * Method to execute the request.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 * @exception javax.servlet.ServletException
 */
public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
{
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_SCREEN);
    super.doGet(req, res);

}
/**
 * Method to execute the request.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 * @exception javax.servlet.ServletException
 */
public void doPost(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
{
    setSessionValue(req, BOLId.FRAME_TYPE, BOLId.BOL_SCREEN);
    super.doPost(req, res);

}
/**
 * Gets AttributeValue from servlet context
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param key java.lang.String
 * @return java.lang.Object
 */
public Object getAttributeValue(String key)
{
    return getServletContext().getAttribute(key);
}
/**
 * Sets AttributeValue to the servlet context
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param key java.lang.String
 * @param value java.lang.Object
 */
public void setAttributeValue(String key, Object value)
{
	 getServletContext().setAttribute(key,value);
}
}
