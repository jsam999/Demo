package cat.cis.poms.bol.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cat.cis.poms.bol.model.BOLBaseCommand;

/**
 * This Servlet acts as a controller for the View
 * BOL Build, directing the request to appropriate command/model
 * and redirect to appropriate JSP's.
 * 
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
 
public class BOLBuild extends BOLBase
{
/**
 * BOLBuild constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
public BOLBuild() {
	super();
}
/**
 * Method to execute the request.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performGetTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req,res);
}
/**
 * Method to execute the request.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performPostTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
		performTask(req,res);
}
/**
 * Method to execute the request. Retrieves the appropriate command
 * from the session and executes the request
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{
    BOLBaseCommand command = (BOLBaseCommand) getAttributeValue("BOL_BUILD");
    command.performTask(req, res, getServletContext());
}
}
