package cat.cis.poms.bol.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.bol.model.BOLAdditionalChargesCommand;
import cat.cis.poms.bol.model.BOLBuildCommand;
import cat.cis.poms.bol.model.BOLDetailsCommand;
import cat.cis.poms.bol.model.BOLEditCommand;
import cat.cis.poms.bol.model.BOLFooterCommand;
import cat.cis.poms.bol.model.BOLHeaderCommand;
import cat.cis.poms.bol.model.BOLManualDetailsCommand;
import cat.cis.poms.bol.model.BOLPrintCommand;
import cat.cis.poms.bol.model.BOLScreen;
import cat.cis.poms.bol.model.BOLVechileAssignmentCommand;
import cat.cis.poms.bol.util.BOLId;
import cat.cis.poms.bol.util.BOLUrl;
import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.model.COPPSSecurity;
import cat.cis.poms.copps.model.COPPSUserInfo;

/**
 * This Servlet acts as a controller for the Links on Menu bar (View),
 * directing the request to appropriate command/model
 * and redirect to appropriate JSP's.
 * 
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
 
public class BOLController extends BOLBase
{
/**
 * BOLController constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLController() {
	super();
}
/**
 * Method to initialize application, to set logger configuration
 * and to load all the ommands
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @exception javax.servlet.ServletException
 */
public void init() throws ServletException
{
    super.init();
    try
        {
        BOLUtil.getInstance().initApplication(getServletContext());
        loadCommands();
    }
    catch (Exception e)
        {
        throw new javax.servlet.ServletException(e.getMessage());
    }
}
/**
 * Method to load all the ommands
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
private void loadCommands()
{
	setAttributeValue("BOL_ADDITIONAL_CHARGES", new BOLAdditionalChargesCommand());
	setAttributeValue("BOL_BUILD", new BOLBuildCommand());
	setAttributeValue("BOL_DETAILS", new BOLDetailsCommand());
	setAttributeValue("BOL_EDIT", new BOLEditCommand());
	setAttributeValue("BOL_FOOTER", new BOLFooterCommand());
	setAttributeValue("BOL_HEADER", new BOLHeaderCommand());
	setAttributeValue("BOL_MANUAL_DETAILS", new BOLManualDetailsCommand());
	setAttributeValue("BOL_PRINT", new BOLPrintCommand());
	setAttributeValue("BOL_VECHILE_ASSIGNMENT", new BOLVechileAssignmentCommand());
}
/**
 * Method to execute the request.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performGetTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req,res);
}
/**
 * Method to execute the request.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performPostTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
		performTask(req,res);
}
/**
 * Method to execute the request. Retrieves the appropriate command
 * from the session and executes the request
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{

	
    //getting the CWSID
    String cwsId = getUserId(req);
    ComLog log =
        BOLUtil.getInstance().getLog("BOLController", "performTask()", cwsId);
    log.logTrace("Getting parameters");
	COPPSSecurity coppsSecurity = null;
    COPPSUserInfo userInfo = (COPPSUserInfo) getSessionValue(req, "SECURITY");
    if (userInfo == null)
        {
        coppsSecurity = new COPPSSecurity(log);
        userInfo = coppsSecurity.getUserInfo();
        setSessionValue(req, "SECURITY", userInfo);
    }

    BOLScreen screen = (BOLScreen) getSessionValue(req, BOLId.SCREEN_LIST);
    if (screen == null)
        {
        coppsSecurity = new COPPSSecurity(log);
        Vector screenList = coppsSecurity.getScreenList();
        screen = new BOLScreen(screenList);
        setSessionValue(req, BOLId.SCREEN_LIST, screen);
    }
    String url = BOLUrl.MAIN_FRAME;
    String screenUrl[] = BOLUrl.getScreenUrl(BOLUrl.BOL_BUILD);
    setSessionValue(req, BOLId.SCREEN_URL, screenUrl);
    redirect(req, res, url);

}
}
