package cat.cis.poms.bol.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cat.cis.poms.bol.model.BOLBaseCommand;

/**
 * This Servlet acts as a controller, directing
 * the request to appropriate model's and redirect
 * to appropriate JSP's.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: venky
 */
 
public class BOLFooter extends BOLBase
{
/**
 * BOLFooter constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLFooter() {
	super();
}
/**
 * Method to execute the request. Retrieves the appropriate command
 * from the session and executes the request
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performGetTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{
    performTask(req, res);
}
/**
 * Method to execute the request. Retrieves the appropriate command
 * from the session and executes the request
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performPostTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{
    performTask(req, res);
}
/**
 * Method to execute the request. Retrieves the appropriate command
 * from the session and executes the request
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{
    BOLBaseCommand command = (BOLBaseCommand) getAttributeValue("BOL_FOOTER");
    command.performTask(req, res, getServletContext());
}
}
