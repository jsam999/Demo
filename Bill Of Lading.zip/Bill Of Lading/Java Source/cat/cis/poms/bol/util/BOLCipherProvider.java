/**
 * Copyright (c) 2003 Caterpillar Inc. All Rights Reserved.
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential. This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others. Copyright notice is precautionary
 * only, and does not imply publication.
 */
package cat.cis.poms.bol.util;

import cat.cis.tuf.common.crypto.CommonCipherProvider;

/**
 * This class provides the methods to encrypt/decrypt data.
 *
 * @author Shibu Pillai (CAT-IDC)
 * @version 1.0.0 (01/10/05)
 */
public class BOLCipherProvider extends CommonCipherProvider {

	/**
	 * Default Constructor.
	 */
	public BOLCipherProvider() {
		super();
	}

	/**
	 * Returns profile file name.
	 * @return String profile file name
	 */
	protected String getProfileFileName() {
		return "tuf-pool-crypto";
	}

	/**
	 * Returns key store file name.
	 * @return String key store file name
	 */
	protected String getKeyStoreFileName() {
		return "tuf-pool-crypto.jck";
	}
}
