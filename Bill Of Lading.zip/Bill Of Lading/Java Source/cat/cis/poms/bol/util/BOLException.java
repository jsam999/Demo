package cat.cis.poms.bol.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
 import cat.cis.poms.com.exception.ComException;
/**
 * BOL specific exceptions.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class BOLException extends ComException {
	private String tranxId = BOLId.STRING_INIT;
	private String method = BOLId.STRING_INIT;
/**
 * BOLException constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLException() {
	super();
}
/**
 * BOLException constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param exc java.lang.Exception
 */
public BOLException(Exception exc) {
	super(exc);
}
/**
 * BOLException constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param s java.lang.String
 */
public BOLException(String s) {
	super(s);
}
/**
 * Gets the error details.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getErrorDetails()
{
	StringBuffer buffer = new StringBuffer("\nError Message: ");
	buffer.append(getMessage());
	buffer.append("\nError Details: Tranx ID: ");
	buffer.append(tranxId);
	buffer.append("Method: ");
	buffer.append(method);
	return buffer.toString();
}
/**
 * Sets method name where the error occurs.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inMethod java.lang.String
 */
public void setMethod(String inMethod)
{
	method = inMethod;
}
/**
 * Sets transaction Id,for which the exception was
 * generated.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inMethod java.lang.String
 */
public void setTranxID(String inTranxId)
{
	tranxId = inTranxId;
}
}
