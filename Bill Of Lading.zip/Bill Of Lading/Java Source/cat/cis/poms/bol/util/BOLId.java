package cat.cis.poms.bol.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
/**
 * Class defining all ID's used in BOL application. This class is
 * declared final, so that it cannot be inherited
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 public final class BOLId {
	 public final static String RESULT_PAGE = "RESULT_PAGE";
	 public final static String PATH = "PATH";
	 public final static String ACTION = "ACTION";
	 public final static String USER_INFO = "USER_INFO";
	 public final static String INPUT_PAGE = "INPUT_PAGE";
	 public final static String SCREEN_INFO = "SCREEN_INFO";
	 public final static String DOWNLOAD = "DOWNLOAD";
	 public final static String SHOW = "SHOW";
	 public final static String CURRENT = "CURRENT";
	 public final static String RESULT_TDS = "TRADE_DISCOUNTS";
	 public final static String SCREEN_URL = "SCREEN_URL";
	 public final static String SUBJECT = "SUBJECT";
	 public final static String MESSAGE = "MESSAGE";
	 public final static String DEALER_CODE = "dealer_code";
	 public final static String SALES_MODELS = "sales_models";
	 public final static String EFFECTIVITY_DATE = "effectivity_date";
	 public final static String TRADE_DISCOUNTS = "TRADE_DISCOUNTS";
	 public final static String BOL_DATA = "BOL_DATA";
	 public final static String BOL_SCREEN = "BOL_SCREEN";
	 public final static String CURRENT_SCREEN_ID = "SCREEN_ID";
	 public final static String FRAME_TYPE = "FRAME_TYPE";
	 public final static String SCREEN_LIST = "SCREEN_LIST";
	 public final static String EDIT_MODE = "EDIT_MODE";
	 public final static String UPDATE = "UPDATE";
	 public final static String INQUIRY = "INQUIRY";

	
	 public final static String VECH_ASSIGN = "VECH_ASSIGN";
	 public final static String BUILD_SELECTION = "BUILD_SELECTION";
	 public final static String BUILD = "BUILD";

	 public final static String HEADER = "0";
	 public final static String DETAILS = "1";
	 public final static String FOOTER = "2";
	 public final static String ADD_CHARGES = "3";
	 public final static String MANUAL_DETAILS = "4";

	 public final static String[] urlArr = {BOLUrl.HEADER_SERVLET, BOLUrl.DETAILS_SERVLET, BOLUrl.FOOTER_SERVLET, BOLUrl.ADD_CHARGES_SERVLET, BOLUrl.MANUAL_DETAILS_SERVLET };
	 public final static String STRING_INIT = "";
}
