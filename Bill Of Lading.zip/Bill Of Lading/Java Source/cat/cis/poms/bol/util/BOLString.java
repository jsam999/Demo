package cat.cis.poms.bol.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

 import java.util.StringTokenizer;
 
/**
 * BOLString - handle BOL specific string functionality
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 
public class BOLString {
	private StringBuffer fieldString = null; // internal holder for string
/**
 * BOLString default constructor
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLString() {
	super();
}
/**
 * BOLString constructor that allows initialization with a given string
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param str java.lang.String - string to initialize buffer with
 */
public BOLString(java.lang.String str) {
	setString(new StringBuffer(str));
}
/**
 * Retrieve current contents of local string
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return local string
 */
public java.lang.StringBuffer getString() {
	return fieldString;
}
/**
 * This function compensates for a bug within Visual Age for Java when placing quoted text
 * into an input field.  Essentially this corrects the problem by replacing all '"' characters
 * with an extra space after it
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String - corrected string
 */
public java.lang.String quoteCorrect() {

	// retrieve the local string
	String s = getString().toString();

	// determine if work is required
	if ((s == null) || (s.length() == 0))
	{
	  return s;
	}
	
	StringBuffer rtrn = new StringBuffer();

	// create a stringTokenizer to parse local string 
	StringTokenizer token = new StringTokenizer(s,"\"");

	// simply loop through tokens and append and extra space after the delimiter
	while (token.hasMoreTokens()) {
	  rtrn.append(token.nextToken());
	  //only append the extra characters if not last element in string
	  if (token.hasMoreTokens()) {
	    rtrn.append("\";");
	  }
	}

	return rtrn.toString();
}
/**
 * Initializes local string with the given string
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param string to initialize 
 */
public void setString(java.lang.StringBuffer string)
{
    fieldString = string;
}
/**
 * Strip off leading zeroes from the local string
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String local string stripped of leading zeroes
 */
public String stripLeadingZeroes() {

	// retrieve local string to strip leading zeroes from
	StringBuffer sb = getString();

	int len = 0;

	// determine if work needs to be done
	if ((sb == null) || ((len = sb.length()) == 0))
	{
	  return null;
	}
	char c;
	int idx=0; // index position of first non-zero character
	
	// start interrogating string until first non-zero character found
	for (int i=0; i<len; i++) {
		c = sb.charAt(i);
		if (c != '0') {
			idx = i;
			break;
		}
	}

	// convert it to a string and return the remaining portion after the zeroes
	String s = new String(sb);
	s = s.substring(idx);
	return s;
}
/**
 * Strip off leading zeroes from the local string. If the string is null, then a initialized string is returned.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String stripLeadingZeroesReturnSpace()
{
    String s = stripLeadingZeroes();
    if (s == null)
        {
        return "";
    }
    else
        {
        return s;
    }
}
/**
 * Method returns string from the StringBuffer.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String toString() {
	StringBuffer str = getString();
	if (str == null)
	{
	   return null;
	}
	return str.toString();
}
}
