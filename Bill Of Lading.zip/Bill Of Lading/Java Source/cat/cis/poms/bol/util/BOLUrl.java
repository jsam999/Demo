package cat.cis.poms.bol.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

 import java.util.Hashtable;
  
/**
 * Abstract class defining all Servlet/JSP's URL
 * used in this application. ( For easier Maintanence)
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */

 
public abstract class BOLUrl
{
	//Path info for Servlets
	public static String uri = "/";
	public static String path1 = "cat.cis.poms.bol.servlets.";

	public static String CONTROLLER = null;
	public static String FEEDBACK = null;
	public static String BUILD_SERVLET = null;
	
	public static String VECH_ASSIGN_SERVLET = null;
	
	public static String HEADER_SERVLET = null;
	public static String FOOTER_SERVLET = null;
	public static String ADD_CHARGES_SERVLET = null;
	public static String MANUAL_DETAILS_SERVLET = null;
	public static String DETAILS_SERVLET = null;
	public static String EDIT_SERVLET = null;
	
	public static String PRINT_SERVLET = null;
	
	//JSP URL's
	public static String SCREEN_DETAILS = "/bol/util/BOLBody.jsp";
	public static String MAIN_FRAME = "/bol/util/BOLMainFrame.jsp";
	public static String DATA_FRAME = "/bol/util/BOLDetails.jsp";
	public static String COPYRIGHT = "/bol/util/BOLCopyright.jsp";
	public static String HELP = "/bol/util/BOLHelp.jsp";
	public static String CONTACTS = "/bol/util/BOLContacts.jsp";
	public static String INCLUDE = "/bol/res/BOLInclude.jsp"; 
	
	//Screen ID's
	public static String BOL_BUILD = "BOL_BUILD";
	public static String BOL_SELECTION = "BOL_SELECTION";
	public static String BOL_VEC_ASSIGN = "BOL_VEC_ASSIGN";
	public static String BOL_HEADER = "BOL_HEADER";
	public static String BOL_DETAILS = "BOL_DETAILS";
	public static String BOL_FOOTER = "BOL_FOOTER";
	public static String BOL_ADD_CHARGES = "BOL_TRAFFIC";
	public static String BOL_EDIT = "BOL_UPDATE";
	public static String BOL_MANUAL_BUILD = "BOL_MANUAL_BUILD";
	public static String BOL_PRINT = "BOL_PRINT";
	
	//Hashtable loading all the JSP URL's for each screen ID's
	private static Hashtable navigation = null;

	//statically initializing all the URL's, Navigation table
	static
	{
		initUrls();
	}
/**
 * Method to get JSP URL's, given a screen ID.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String[]
 * @param screenId java.lang.String
 */
public static String[] getScreenUrl(String screenId) {
	String screen[] = (String[])navigation.get(screenId);
	return screen;
}
/**
 * Method to initialize the Servlet/JSP URL's.
 * Called only ONCE at the time this abstract class is loaded.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public static void initUrls()
{
	CONTROLLER = uri + path1 + "BOLController"; 
	FEEDBACK = uri + path1 + "BOLMailServlet";
	BUILD_SERVLET = uri + path1 + "BOLBuild";
	VECH_ASSIGN_SERVLET = uri + path1 + "BOLVechileAssignment";
	
	HEADER_SERVLET = uri + path1 + "BOLHeader";
	FOOTER_SERVLET = uri + path1 + "BOLFooter";
	DETAILS_SERVLET = uri + path1 + "BOLDetails";
	ADD_CHARGES_SERVLET = uri + path1 + "BOLAdditionalCharges";
	MANUAL_DETAILS_SERVLET = uri + path1 + "BOLManualDetails";
	EDIT_SERVLET = uri + path1 + "BOLEdit";
	
	PRINT_SERVLET = uri + path1 + "BOLPrint";
	
	navigation = new Hashtable();
	String bol_build[] = {"/bol/res/BOLBuild.jsp", "/bol/res/BOLBuildAction.html"};
	String bol_selection[] = {"/bol/res/BOLSelection.jsp", "/bol/res/BOLSelectionAction.html"};
	String bol_vec_assign[] = {"/bol/res/BOLVechicleAssignment.jsp", "/bol/res/BOLVechicleAssignmentAction.jsp"};
	String bol_header[] = {"/bol/res/BOLHeader.jsp", "/bol/res/BOLHeaderAction.jsp"};
	String bol_details[] = {"/bol/res/BOLDetails.jsp", "/bol/res/BOLDetailsAction.jsp"};
	String bol_footer[] = {"/bol/res/BOLFooter.jsp", "/bol/res/BOLFooterAction.jsp"};
	String bol_traffic[] = {"/bol/res/BOLAddCharges.jsp", "/bol/res/BOLAddChargesAction.html"};
	String bol_edit[] = {"/bol/res/BOLEdit.jsp", "/bol/res/BOLEditAction.jsp"};
	String bol_manual_build[] = {"/bol/res/BOLManualBuild.jsp", "/bol/res/BOLManualBuildAction.html"};
	String bol_print[] = {"/bol/res/BOLPrint.jsp", "/bol/res/BOLPrintAction.jsp"};
	
	navigation.put(BOL_BUILD,bol_build);
	navigation.put(BOL_SELECTION, bol_selection);
	navigation.put(BOL_VEC_ASSIGN, bol_vec_assign);
	navigation.put(BOL_HEADER, bol_header);
	navigation.put(BOL_DETAILS, bol_details);
	navigation.put(BOL_FOOTER, bol_footer);
	navigation.put(BOL_ADD_CHARGES, bol_traffic);
	
	navigation.put(BOL_EDIT, bol_edit);
	navigation.put(BOL_MANUAL_BUILD, bol_manual_build);
	navigation.put(BOL_PRINT, bol_print);
	
}
}
