package cat.cis.poms.bol.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.io.IOException;

import javax.servlet.ServletContext;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.com.servlet.ComFunctions;
import cat.cis.tuf.common.crypto.CryptoUtils;
import cat.cis.tuf.common.logging.FatalEvent;
import cat.cis.tuf.common.util.Counter;

/**
 * This class is a singleton class, used to define all the utility methods.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky, POMS
 */


public class BOLUtil
{
	private static BOLUtil util = null;	 
/**
 * BOLUtil constructor.
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public BOLUtil() {
	super();
}
/**
 * This method creates a new IMSConnectionManager Object and returns.
 * This method is defined, not to repeat the property file name,
 * all over the application. Property file name used in only one place,
 * helps in easier maintanence.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.util.IMSConnectionManager
 */
public IMSConnectionManager getIMSManager() {
	IMSConnectionManager ims = new IMSConnectionManager("copps/copps_cis");
	ims.setTrace(false);
 	return ims;
}
/**
 * Method returns a BOLUtil object. Only one object is created
 * for this class.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.copps.model.COPPSUtil
 */
public static BOLUtil getInstance() {
	if(util == null)
	{
		util = new BOLUtil();
	}
	return util;
}
/**
 * This method creates a new ComLog Object and returns.
 * This method is defined, not to repeat the LogKey,
 * all over the application. LogKey name used in only one place,
 * helps in easier maintanence.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param className java.lang.Servlet
 * @param methodName java.lang.Servlet
 * @param userId java.lang.Servlet
 * @return cat.cis.poms.log.ComLog
 */
public ComLog getLog(String className, String methodName, String userId)
{
	ComLog log = new ComLog("bol", className, methodName, userId);
	return log;
}
/**
 * Method to initialize some parameters once,
 * at the beginning of the application.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param context javax.servlet.ServletContext
 */
public void initApplication(ServletContext context)
{
	//Call to initialize the rootUri property once,
	//in the ComFunctions object.(Set the rootUri once,
	//so as to avoid, repeated calls to get the rootUri)
	ComFunctions.initRootUri(context);

	//Call to initialize logger configuration
	initLoggerConfiguration(context);
}
/**
 * Method to initialize logger configuration once,
 * at the beginning of the application.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param context javax.servlet.ServletContext
 */
public void initLoggerConfiguration(ServletContext context)
{
	ComLog.initLoggerConfiguration("bol", "bol_log", context);
}

/**
 * Method to trim a string and convert to uppercase.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 * @param s java.lang.String
 */
public String toUpperCase(String s) {
	String str = BOLId.STRING_INIT;
	if(s != null)
	{
		str = s.trim().toUpperCase();
	}
	return str;
}

/**
 * Method to encrypt data.
 * 
 * @since 01-01-2006 (WAS 6 Migration)
 * @return java.lang.String
 * @param data java.lang.String
 */
public String encrypt(String data){
	byte[] epwdbt = CryptoUtils.getInstance().encrypt(data.getBytes(),"pool-profile");
	String epwd = new BASE64Encoder().encode(epwdbt);
	return new String(epwd);
}

/**
 * Method to decrypt data.
 * 
 * @since 01-01-2006 (WAS 6 Migration)
 * @return java.lang.String
 * @param data java.lang.String
 */
public String decrypt(String data){
	if(!data.startsWith("{XOR}")) {
		return data;
	}
	try {
		String encryptedData = data.substring(5);
		CryptoUtils cu = CryptoUtils.getInstance();
		byte[] decodedData = new BASE64Decoder().decodeBuffer(encryptedData);
		byte[] decryptedDataBytes = CryptoUtils.getInstance().decrypt(decodedData,"pool-profile");
		return new String(decryptedDataBytes);
	} catch(IOException ioEx) {
		new FatalEvent("bol", Counter.getNext(), "BOLUtil", 
				"decrypt", "Decryption failed: " + ioEx.getMessage());
		return null;
	}
}

}
