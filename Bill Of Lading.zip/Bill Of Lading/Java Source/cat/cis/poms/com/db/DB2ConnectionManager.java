package cat.cis.poms.com.db;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;
import cat.cis.tuf.server.connector.jdbc.DBConnection;
import cat.cis.tuf.common.pool.PoolManager;
import cat.cis.poms.com.log.ComLog;


/**
 *
 * DB2 Connection Manager
 * This class is used to connect to and disconnect from DB2.  
 * TUF frameworks wraps around the app servers Connection pool.
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * 
 */

public class DB2ConnectionManager
{

    /**
     * Connection object to the specified database
     */
    private DBConnection connection = null;

    /**
     * Connection pool name, from where a connection is obtained
     */
    private String poolName = "";

    
    /**
     * log Object used for tracing
     */
    private ComLog log = null;

    
    /**
     * Transaction ID to identify database interaction
     */
    private int tranxId = -1;

    /**
     * Statement object to execute a query
     */
    private Statement stmt = null;

    /**
     * PreparedStatement object to execute a query
     */
    private PreparedStatement ps = null;

/**
 * Obtains a connection from the connection pool
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param     dbPoolName  name of the connection pool.
 * @param     logInfo  logging information.
 *  
 *  
 */

public DB2ConnectionManager(String dbPoolName, ComLog logInfo)
{
    super();
    poolName = dbPoolName;
    tranxId = logInfo.getTranxId();
    log = new ComLog("DBConnectionManager", logInfo);

}
/**
 * This method is used to change DB2 Connection pool name.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param dbPoolName  name of the connection pool
 */

public void changePoolName(String dbPoolName)
{
	poolName = dbPoolName;
}
/**
 * This method is used to release a connection 
 * back to the connection pool for reuse.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void closeStatement()
{
	log.setMethodName("closeStatement()");
	if (connection != null)
	{
		// Remove connections with the same connection spec
		try
		{
			//log.logTrace("closing statements");
			if (stmt != null)
			{
				stmt.close();
				stmt = null;
			}
			if(ps != null)
			{
				ps.close();
				ps = null;
			}
		}
		catch (Exception e)
		{
			log.logFatal("closing statements", e);
		}
	}
}
/**
 * This method is used to commit any changes to the database
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void commit() throws SQLException
{
	log.setMethodName("commit()");
	if (connection != null)
	{
		connection.commit();
		log.logTrace("Committed database changes");
	}
}
/**
 * This method is used to get a connection 
 * from the connection pool.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void connect() throws Exception
{
	log.setMethodName("connect[1]");
//	log.logTrace("Getting connection");
	connection = (DBConnection)PoolManager.getCurrent().allocate(poolName, tranxId, 1000L);
	if (connection == null)
	{
		log.logWarning("Could not allocate a DB2 connection!");
		throw new Exception("Could not allocate a DB2 connection!");
	}
//	log.logTrace("Got connection");
}
/**
 * This method is used to release a connection 
 * back to the connection pool for reuse.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void disconnect()
{
	log.setMethodName("disconnect()");
	if (connection != null)
	{
		// Remove connections with the same connection spec
		try
		{
//			log.logTrace("Releasing connections");
			if (stmt != null)
			{
				stmt.close();
				stmt = null;
			}
			if(ps != null)
			{
				ps.close();
				ps = null;
			}
			connection.free();
		}
		catch (Exception e)
		{
			log.logFatal("Error releasing connections", e);
			connection.remove();
			
		}
		connection = null;
	}
}
/**
 * Method to execute SQL Query
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param sql java.lang.String
 * @return java.sql.ResultSet
 */
public ResultSet executeQuery(String sql) throws Exception
{
	log.setMethodName("executeQuery[1]"); 
	if (connection == null)
	{
		connect();
	}
	closeStatement();
	stmt = connection.createStatement();
	ResultSet rs = null;
	
	try
	{
//		log.logTrace("SQL= " + sql);
		rs = stmt.executeQuery(sql);
	}
	catch (Exception sqle)
	{
		log.logFatal("Exception " + sqle.getMessage(), sqle); 
		throw sqle;
	}
	
	
	return rs;
}
/**
 * Method to execute SQL Query
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param sql java.lang.String
 * @param v java.util.Vector
 * @return java.sql.ResultSet
 */

 
public ResultSet executeQuery(String sql, Vector v) throws Exception
{
	//log.setMethodName("executeQuery[PS]2888");
	if (connection == null)
	{
		connect();
	}
	closeStatement();
	ps = connection.prepareStatement(sql);
	int size = v.size();
	Object obj = null;
	Double d = null;
	for (int i = 0; i < size; i++)
	{
		obj = v.elementAt(i);
		if (obj instanceof Double)
		{
			d = (Double) obj;
			if (d.isInfinite())
			{
				obj = new Double(0.0);
			}
			else if (d.isNaN())
			{
				obj = new Double(0.0);
			}
		}
		
		if ((obj instanceof Short) && (obj != null))
		{
			obj = new Integer(((Short) obj).intValue());
		}
		
		ps.setObject(i + 1, obj);
	}
	ResultSet rs = null;
	try
	{
		rs = ps.executeQuery();
	}
	catch (Exception sqle)
	{
		log.logFatal("Exception " + sqle.getMessage(), sqle);
		throw sqle;
	}
	
	
	return rs;
}
/**
 * Updates a DB2 table.  Supports reconnect logic so that the code will automatically
 * attempt a reconnect when a connection goes stale.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return int
 * @param ps java.lang.String
 * @exception java.lang.Exception
 */
public int executeUpdate(String sql) throws Exception
{
	log.setMethodName("executeUpdate(1)"); 
	if (connection == null)
	{
		connect();
	}
	closeStatement();
	stmt = connection.createStatement();
	int rs = 0;

	try
	{
//		log.logTrace("Updating " + sql); 
		rs = stmt.executeUpdate(sql);
	}
	catch (Exception sqle)
	{
		log.logFatal("Exception " + sqle.getMessage(), sqle); 
		throw sqle;
	}
	// Added finally block to close out statement afterwards
	// Were getting tons of "TUF Coding Errors" without this
	// DNM 02/12/2002
	finally
	{
		if (stmt != null)
		{
			stmt.close();
			stmt = null;
		}
	}	

	return rs;
}
/**
 * Updates a DB2 table.  Supports reconnect logic so that the code will automatically
 * attempt a reconnect when a connection goes stale.
 *
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param ps java.lang.String
 * @param v java.util.Vector -- holds list of parameters
 * @return java.sql.ResultSet
 */
public int executeUpdate(String sql, Vector v) throws Exception
{
	//log.setMethodName("executeUpdate(2999)");
	if (connection == null)
	{
		connect();
	}
	closeStatement();
	ps = connection.prepareStatement(sql);
	int size = v.size();
	Object obj = null;
	Double d = null;
	for (int i = 0; i < size; i++)
	{
		obj = v.elementAt(i);
		if (obj instanceof Double)
		{
			d = (Double) obj;
			if (d.isInfinite())
			{
				obj = new Double(0.0);
			}
			else if (d.isNaN())
			{
				obj = new Double(0.0);
			}
		}
		
		if (obj instanceof Short)
		{
			obj = new Integer(((Short) obj).intValue());
		}
		
		ps.setObject(i + 1, obj);
	}
	int rs = 0;
	try
	{
		rs = ps.executeUpdate();
	}
	catch (Exception sqle)
	{
		log.logFatal("Exception " + sqle.getMessage(), sqle);
		throw sqle;
	}
	// Added finally block to close out statement afterwards
	// Were getting tons of "TUF Coding Errors" without this
	// DNM 02/12/2002
	finally
	{
		if (ps != null)
		{
			ps.close();
			ps = null;
		}
	}
		
	return rs;
}
}
