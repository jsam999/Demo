package cat.cis.poms.com.email;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 


import cat.cis.tuf.common.email.EMailDocument;
import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.common.directory.PersonFactory;
 
/**
 *
 * Mail component
 * This class is an interface to send mails.  
 * Mail service is implemented using TUF frameworks
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 *
 */
public class ComMailService {
	EMailDocument mail = new EMailDocument();
/**
 * CmsMailService constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public ComMailService()
{
	super();
}
/**
 * Method to add person to BCC list
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void addSendBcc(String person) throws Exception
{
	Person aPerson = PersonFactory.getInstance().getPersonByLogonId(person);
	mail.addSendBCC(aPerson);
}
/**
 * Method to add person to CC list
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void addSendCc(String person) throws Exception
{
	Person aPerson = PersonFactory.getInstance().getPersonByLogonId(person);
	mail.addSendCC(aPerson);
}
/**
 * Method to add person to TO list
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void addSendTo(String person) throws Exception
{
	Person aPerson = PersonFactory.getInstance().getPersonByLogonId(person);
	mail.addSendTO(aPerson);
}
/**
 * Method to send the mail.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void send() throws Exception
{
	mail.send();
}
/**
 * Method to set the Originator of the mail.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void setFrom(String person) throws Exception
{
	Person aPerson = PersonFactory.getInstance().getPersonByLogonId(person);
	mail.setFrom(aPerson.getEmailId());
}
/**
 * Method to set the Message of the mail.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void setMessage(String message)
{
	mail.setContent(message);
}
/**
 * Method to set the Subject of the mail.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param person java.lang.String
 */
public void setSubject(String subject)
{
	mail.setSubject(subject);
}
}
