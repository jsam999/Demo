package cat.cis.poms.com.exception;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
/**
 * Exception class designed for POMS COMMON FRAMEWORKS
 * This exception class is a wrapper class to all the Exceptions
 * which may occur in the system.
 * This class was created for extensibility in
 * the future, so that any details can be added to the system,
 * without affecting other areas in the code.
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
public class ComException extends Exception
{
	private java.lang.Exception e;
	private boolean information = false;
/**
 * ComException constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public ComException()
{
	super();
}
/**
 * ComException constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param exc java.lang.Exception
 */
public ComException(Exception exc)
{
	super();
	this.e = exc;
}
/**
 * ComException constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param s java.lang.String
 */
public ComException(String s)
{
	super(s);
}
/**
 * Gets Exception object.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.Exception
 */
public java.lang.Exception getException()
{
	return e;
}
/**
 * Gets Exception message
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getMessage()
{
	if (e != null)
	{
		return e.getMessage();
	}
	else
	{
		return super.getMessage();
	}
}
/**
 * Method to check if the exception is 
 * a error message or information. (In some situation
 * exception object has been used for providing 
 * information instead of error message)
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public boolean isInformation()
{
    if (e != null && e instanceof ComException)
        {
        return ((ComException)e).isInformation();
    }
    else
        {
        return information;
    }
}
/**
* Method to set the flag if the exception is 
* a error message or information. Set to true
* if the exception is information.
*
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param flag boolean
*/
public void setInformation(boolean flag)
{
    information = flag;
}
}
