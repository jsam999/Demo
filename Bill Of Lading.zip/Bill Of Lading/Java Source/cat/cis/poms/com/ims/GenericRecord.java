package cat.cis.poms.com.ims;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import com.ibm.record.CustomRecord;
import com.ibm.record.RecordException;
import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
/**
 *
 * GenericRecord
 *
 * @version       1.1,  1/27/2000
 *
 * @author        Lawrence McAlpin (POMS)
 *
 * GenericRecord is a general-purpose CustomRecord extension that is used
 * to call IMS transactions.
 */
public class GenericRecord extends CustomRecord {
	private int recLen = -1;
/**
 * Creates a record of length len.
 * @param len int
 */
 
public GenericRecord(int len) throws RecordException
{
	recLen = len - 4;
	try {
		com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
		attrs.setFloatingPointFormat((int)0);
		attrs.setEndian((int)0);
		attrs.setRemoteIntEndian((int)0);
		attrs.setCodePage((java.lang.String)"037");
		attrs.setMachine((int)0);
		this.setRecordAttributes(attrs);
		this.setRecordType(new CustomRecordType(GenericRecordType.class,len));
		this.setBytes(new byte[len]);
		this.setInitialValues();
		this.enableNotification();

		setLL((short)len);
		setZZ((short)0);
	} catch (Exception e) {
		throw new RecordException(e.getMessage());
	}
}
/**
 * Creates a record of length len.
 * @param len int
 */
 
public GenericRecord(String rec) throws RecordException
{
	this(rec.length()+4);
	setData(rec);
}
/**
 * This method returns the output of an IMS transaction.
 * @return java.lang.String
 */
 
public String getData() throws RecordConversionFailureException {
	  return getDataAsString();
 }
/**
 * This method returns the output of an IMS transaction.
 * @return java.lang.String
 */

 public byte[] getDataAsBytes() throws RecordConversionFailureException {
	  return getDataAsString().getBytes();
 }
/**
 * This method returns the output of an IMS transaction.
 * @return java.lang.String
 */

 public String getDataAsString() throws RecordConversionFailureException {
	  return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,recLen,false,false,false,1-recLen,0,"X("+recLen+")",false,true);
 }
/**
 * This method returns a portion of the output of an IMS transaction.
 * @return java.lang.String
 */

 public String getDataAsSubstring(int iStart,int iEnd) throws RecordConversionFailureException {
	  return getDataAsString().substring(iStart,iEnd);
 }
/**
 * This method sets the data area, used when sending data to an IMS transaction.
 * @param data java.lang.String
 */


public void setData(String data) throws RecordConversionFailureException {
  java.lang.String oldData = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,recLen,false,false,false,1-recLen,0,"X("+recLen+")",false,true);
  com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,data,9,0,recLen,false,false,false,1-recLen,0,"X("+recLen+")",false,true);
  return;
}
protected void setLL(short aLL__IN) throws RecordConversionFailureException {
	short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	return;
}
protected void setZZ(short aZZ__IN) throws RecordConversionFailureException {
	short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
	return;
}
}
