package cat.cis.poms.com.ims;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
import com.ibm.ivj.eab.record.cobol.CobolInitialValueObject;
import com.ibm.ivj.eab.record.cobol.CobolType;
import com.ibm.record.Field;

/**
 * GenericRecordType
 *
 * @version       1.1,  1/27/2000
 *
 * @author        Lawrence McAlpin (POMS)
 *
 * GenericRecordType is an extension of <code>com.ibm.ivj.eab.record.cobol.CobolDynamicRecordType</code>
 * that is general in purpose and can be used for any transaction.
 * 
 * It defines three COBOL regions: the required LL and ZZ parameters, and a general-purpose DATA area
 * of arbitrary length.
 *
 */
public class GenericRecordType extends com.ibm.ivj.eab.record.cobol.CobolDynamicRecordType {
/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
 /**
 * GenericRecordType constructor; requires length of record.
 * @param len int
 */
public GenericRecordType(int len) {
	addField(new Field(new CobolType("S9(4):COMP"), "LL", new CobolInitialValueObject("0", "0")));
	addField(new Field(new CobolType("S9(4):COMP"), "ZZ", new CobolInitialValueObject("0", "0")));
	addField(new Field(new CobolType("X("+ len + "):DISPLAY"), "BYTES", new CobolInitialValueObject(" ", null)));
}
}
