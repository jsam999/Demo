package cat.cis.poms.com.ims;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
import java.util.Properties;

import cat.cis.poms.bol.util.BOLUtil;
import cat.cis.tuf.common.util.TUFUtils;
import cat.cis.tuf.server.util.TUFServerUtil;
import cat.cis.was.connectors.CatWasConnectionManagerWrapper;

import com.ibm.connector.imstoc.IMSConnectionSpec;
import com.ibm.connector.imstoc.IMSInteractionSpec;
import com.ibm.connector.imstoc.IMSLogonInfoItems;
import com.ibm.connector.infrastructure.RASService;
import com.ibm.connector.infrastructure.java.JavaCoordinator;
import com.ibm.connector.infrastructure.java.JavaRASService;
import com.ibm.connector.infrastructure.java.JavaRuntimeContext;
/**
 *
 * IMS Connection Manager
 *
 * This class is used to connect to and disconnect from IMS.  
 *
 * @version       1.0,  1/27/2000
 *
 * @author        Lawrence McAlpin (POMS)
 *
 */
 
public class IMSConnectionManager {
	private String user = null;
	private String password = null;
	private JavaRuntimeContext runtimeContext = null;
	private String dataStore = null;
	private String hostname = null;
	private int portNumber = -1;
	private IMSInteractionSpec interactionSpec = null;
	private IMSConnectionSpec connectionSpec = null;
	private boolean connected = false;
	private boolean fTrace = false;
/**
 * ConnectorManager constructor comment.
 */
public IMSConnectionManager(String aPropertyFile) 
{
	super();

	//CatWasEnvironment catWasEnv = CatWasEnvironment.getInstance();
	//catWasEnv.reset(aPropertyFile);
	Properties p = TUFServerUtil.getInstance().getProperties(aPropertyFile);
	//String xxx = p.getProperty(key);
	
	String user1 = p.getProperty("jdbc2.user");
	String password1 = p.getProperty("jdbc2.password");
	password1 = BOLUtil.getInstance().decrypt(password1);
	/*
	 * Modified by pillasm 09-Jun-2005
	 * Modified for the application to pickup
	 * the IMS values dynamically.
	 * */
	String dataStore1 = null;
	String hostName1 = null;
	if(TUFUtils.getInstance().isProduction()) {
		dataStore1 = p.getProperty("comm.ims.dataStore.prod");
		hostName1 = p.getProperty("comm.ims.hostName.prod");
	}
	else if(TUFUtils.getInstance().isStaging()) {
		dataStore1 = p.getProperty("comm.ims.dataStore.staging");
		hostName1 = p.getProperty("comm.ims.hostName.staging");
	}
	else if(TUFUtils.getInstance().isQA()) {
		dataStore1 = p.getProperty("comm.ims.dataStore.qa");
		hostName1 = p.getProperty("comm.ims.hostName.qa");
	}
	else if(TUFUtils.getInstance().isTest()) {
		dataStore1 = p.getProperty("comm.ims.dataStore.test");
		hostName1 = p.getProperty("comm.ims.hostName.test");
	}
	else if(TUFUtils.getInstance().isDevelopment()) {
		dataStore1 = p.getProperty("comm.ims.dataStore.test");
		hostName1 = p.getProperty("comm.ims.hostName.test");
	}
	
	String portNumberWS1 = p.getProperty("comm.ims.portNumber");
	int portNumber1 = 0;
	if (portNumberWS1 != null)
	{
		portNumber1 = Integer.parseInt(portNumberWS1);
	}

	// Initialize connector classes
	setUser(user1);
	setPassword(password1);
	setDatastore(dataStore1);
	setHostName(hostName1);
	setPortNumber(portNumber1);
}
/**
 * This method was created in VisualAge.
 */
public void connect() {
	if (isConnected())
	{
		return;
	}
	connected = true;
	
	// Set up the runtime context for this transaction
	runtimeContext = new JavaRuntimeContext();

	// Set Id and password
	com.ibm.connector.imstoc.IMSLogonInfoItems _logonInfoItems = null;		
	_logonInfoItems = new IMSLogonInfoItems(runtimeContext.getLogonInfo(),connectionSpec);
	_logonInfoItems.setUser(user);
	_logonInfoItems.setPassword(password);
	_logonInfoItems.setGroup("");  // set to blank, groups are not used at Caterpillar.
		
	// Get connection from connection pool
	JavaRuntimeContext.setCurrent(runtimeContext);
	if (fTrace)
	{
		JavaRASService aRASService = (JavaRASService)runtimeContext.getRASService();
		aRASService.setTraceLevel(RASService.RAS_TRACE_ENTRY_EXIT);
	} else {
		JavaRASService aRASService = (JavaRASService)runtimeContext.getRASService();
		aRASService.setTraceLevel(RASService.RAS_TRACE_ERROR_EXCEPTION);
	}
	runtimeContext.setConnectionManager(CatWasConnectionManagerWrapper.getConnectionManagerStatic());
}
/**
 * This method was created in VisualAge.
 */
public void disconnect() {
	if (runtimeContext == null)
	{
		return;
	}
	if (! isConnected())
	{
		return;
	}
	connected = false;
		
	// Commit the transaction
	((JavaCoordinator)runtimeContext.getCoordinator()).commit();

	// End the runtime context and return it to the pool.				
	runtimeContext.close();
	JavaRuntimeContext.removeCurrent();
}
/**
 * This method was created in VisualAge.
 * @return com.ibm.connector.imstoc.IMSConnectionSpec
 */
public IMSConnectionSpec getConnectionSpec() {
	if (connectionSpec == null)
	{
		connectionSpec = new IMSConnectionSpec();
	}
	return connectionSpec;
}
/**
 * This method was created in VisualAge.
 */
public String getDatastore() {
	return dataStore;
}
/**
 * This method was created in VisualAge.
 */
public String getHostName() {
	return hostname;
}
/**
 * This method was created in VisualAge.
 * @return com.ibm.connector.imstoc.IMSInteractionSpec
 */
public IMSInteractionSpec getInteractionSpec() {
	if (interactionSpec == null)
	{
		interactionSpec = new IMSInteractionSpec();
		interactionSpec.setMode(IMSInteractionSpec.MODE_SEND_RECEIVE);
		interactionSpec.setSyncLevel(IMSInteractionSpec.SYNC_LEVEL_NONE);
	}
	return interactionSpec;
}
/**
 * This method was created in VisualAge.
 */
public int getPortNumber() {
	return portNumber;
}
/**
 * This method was created in VisualAge.
 * @return boolean
 */
public boolean isConnected() {
	return connected;
}
/**
 * This method was created in VisualAge.
 */
protected void setDatastore(String dataStore) {
	this.dataStore = dataStore;
	getInteractionSpec().setDataStoreName(dataStore);
}
/**
 * This method was created in VisualAge.
 */
protected void setHostName(String hostname) {
	this.hostname = hostname;
	getConnectionSpec().setHostName(hostname);
}
/**
 * This method was created in VisualAge.
 * @param password java.lang.String
 */
protected void setPassword(String password) {
	this.password = password;
}
/**
 * This method was created in VisualAge.
 */
protected void setPortNumber(int portNumber) {
	this.portNumber = portNumber;
	getConnectionSpec().setPortNumber(portNumber);
}
/**
 * This method was created in VisualAge.
 * @param fTrace boolean
 */
public void setTrace(boolean fTrace) {
	this.fTrace = fTrace;
}
/**
 * This method was created in VisualAge.
 * @param user java.lang.String
 */
protected void setUser(String user) {
	this.user = user;
}
}
