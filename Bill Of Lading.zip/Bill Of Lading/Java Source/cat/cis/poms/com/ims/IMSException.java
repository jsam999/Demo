package cat.cis.poms.com.ims;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

/**
 * IMSException
 *
 * This class interprets IMSTOCResourceException error codes.  It provides an
 * error message that is appropriate for displaying to the user.
 *
 * @version       1.1,  1/27/2000
 *
 * @author        Lawrence McAlpin (POMS)
 *
 */
 
public class IMSException extends Exception {
	String message = "Unknown IMS exception.  Contact the application support analyst!";
/**
 * IMSException constructor.
 * @param s java.lang.String
 */
public IMSException(String s) {
	super(s);
	if (s.equals("SECFAIL"))
	{
		message = "There was a security violation with your user ID and password.  Please correct them if necessary, or contact a systems support analyst.";
	}
	else if (s.equals("SECFNUID"))
	{
		message = "The user ID field was blank.";
	}
	else if (s.equals("SECFNOPW"))
	{
		message = "The password field was blank.";
	}
	else if (s.equals("SECFNPUI"))
	{
		message = "The user ID and password fields are blank.";
	}
	else if (s.equals("NFNDDST"))
	{
		message = "The destination could not be located.  Make sure the datastore and hostname are correct.";
	}
	else
	{
		message = "IMSTOC Exception Code: " + s;
	}
}
/**
 * This method returns an explanation of the error condition that
 * the system encountered.
 * @return java.lang.String
 */
public String getMessage() {
	return this.message;
}
}
