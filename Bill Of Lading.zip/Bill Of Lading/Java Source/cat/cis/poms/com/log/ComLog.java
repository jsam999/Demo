package cat.cis.poms.com.log;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 


import cat.cis.tuf.common.logging.InformationalEvent;
import cat.cis.tuf.common.logging.LoggerConfiguration;
import cat.cis.tuf.common.logging.FatalEvent;
import cat.cis.tuf.common.logging.UsageEvent;
import cat.cis.tuf.common.logging.TraceEvent;
import cat.cis.tuf.common.logging.WarningEvent;
import cat.cis.tuf.common.logging.EventDispatcher;
import cat.cis.tuf.common.util.Counter;
import cat.cis.tuf.server.util.TUFServerUtil;
import cat.cis.tuf.common.directory.PersonFactory;
import cat.cis.tuf.common.directory.Person;
import javax.servlet.ServletContext;

 /**
 *
 * Logging interface
 * This class is an interface to log warning/fatal/trace events.  
 * Logging is implemented using TUF frameworks
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 */
public class ComLog {
	//Current ClassName where the log object is being used
	private String className = null;

	//Current MethodName where the log object is being used
	private String methodName = null;

	//Current User ID
	private String userId = "";

	//Current Transaction ID
	private int tranxId = -1;

	//Key used to identify with a specific Logger Configuration
	private String logKey = null;

	//Timing object, for determing execution time
	//of any piece of code
	private TimingProfile timer = null;

	//Flag to enable/disable tracing
	private static boolean trace = true;
	
/**
 * ComLog constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public ComLog(Object object, ComLog info)
{
	super();
	className = object.getClass().getName();
	tranxId = info.getTranxId();
	userId = info.getUserId();
	logKey = info.getLogKey();
}
/**
 * ComLog constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inClassName java.lang.String
 * @param inMethodName java.lang.String
 * @param logInfo cat.cis.poms.com.log
 */
public ComLog(String inClassName, String inMethodName, ComLog logInfo)
{
	super();
	className = inClassName;
	methodName = inMethodName;
	tranxId = logInfo.getTranxId();
	userId = logInfo.getUserId();
	logKey = logInfo.getLogKey();
}
/**
 * ComLog constructor used, where all the
 * parameters are available.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inLogKey java.lang.String
 * @param inClassName java.lang.String
 * @param inMethodName java.lang.String
 * @param inUserId java.lang.String
 */
public ComLog(String inLogKey, String inClassName, String inMethodName, String inUserId)
{
	super();
	className = inClassName;
	methodName = inMethodName;
	tranxId = Counter.getNext();
	userId = inUserId;
	logKey = inLogKey;
}
/**
 * Method to stop timer
 * and log the time to the trace file
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void endTiming()
{
	if(timer != null)
	{
		timer.end();
		logTrace(timer.toString());
	}
}
/**
 * Gets the log key.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String getLogKey() {
	return logKey;
}
/**
* Gets the transaction id.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return int
*/
public int getTranxId()
{
    return tranxId;
}
/**
* Gets the user id.
* 
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @return java.lang.String
*/
public String getUserId()
{
    return userId;
}
/**
 * Method used to initialize Logger Configuration
 * synchronized because, possibility of different applications
 * deployed in the same webapp, can try to use this method
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inLogId java.lang.String
 * @param inPropFileName java.lang.String
 * @param context javax.servlet.ServletContext
 */
public static synchronized void initLoggerConfiguration(String inLogId, String inPropFileName, ServletContext context)
{
	LoggerConfiguration lc = new LoggerConfiguration(inLogId, TUFServerUtil.getInstance().getProperties( inPropFileName ) );
	//lc.setAppRoot( TUFServerUtil.getInstance().getDirectoryRoot( context ) );
	EventDispatcher.register( lc );
}
/**
 * Method to log all the fatal events
 * Used when any fatal events, while execution of code
 * should be logged.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 * @param exc java.lang.Exception
 */
public void logFatal(String message, Exception exc)
{
    try
        {
        new FatalEvent(logKey, tranxId, className, methodName, message, exc);
    }
    catch (Exception e)
        {
        e.printStackTrace();
        System.out.flush();
    }
}
/**
 * Method to log all the information events
 * Used when any information while execution of code
 * should be logged.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 */
public void logInformation(String message)
{
	try
	{
		new InformationalEvent(logKey, tranxId, className, methodName, message);
	}
	catch (Exception e)
	{
		logFatal(message, e);
	}
}
/**
 * Method to log all the trace events
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 */
public void logTrace(String message)
{
	try
	{
		if(trace)//Flag can be turned on or off
		{
			//TUF frameworks information event is used for tracing.
			//This method is used for debugging purposes.
			new InformationalEvent(logKey, tranxId, className, methodName, message);
		}
	}
	catch (Exception e)
	{
		logFatal(message, e);
	}
}
/**
 * Method to log all the trace events.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 */
public void logTrace(boolean begin)
{
	try
	{
		new TraceEvent(logKey, tranxId, className, methodName, begin);
	}
	catch (Exception e)
	{
		logFatal("Exception in logTrace", e);
	}
}
/**
 * Method to log all the usage events
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 */
public void logUsage(String message)
{
	try
	{
		Person aPerson = PersonFactory.getInstance().getPersonByLogonId(userId);
		new UsageEvent(logKey, tranxId, message, aPerson, 0);
	}
	catch (Exception obj)
	{
		logFatal("Exception in logUsage", obj);
	}
}
/**
 * Method to log all the warning events
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String
 */
public void logWarning(String message)
{
	try
	{
		new WarningEvent(logKey, tranxId, className, methodName, message);
	}
	catch (Exception e)
	{
		logFatal(message, e);
	}
}
/**
 * Sets the log key.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inLogKey java.lang.String
 */
public void setLogKey(String inLogKey)
{
	logKey = inLogKey;
}
/**
 * Sets the method name.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inMethodName java.lang.String
 */
public void setMethodName(String inMethodName)
{
	methodName = inMethodName;
}
/**
 * Sets the trace flag
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param _trace boolean
 */
public static void setTrace(boolean inTrace)
{
	trace = inTrace;
}
/**
 * Method to start the timer. Used for monitering
 * time for any specific piece of code.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inLabel java.lang.String
 */
public void startTiming(String inLabel)
{
	if(timer == null)
	{
		timer = new TimingProfile(inLabel);
	}
	else
	{
		timer.setLabel(inLabel);
		timer.reset();
	}
	timer.start();
}
}
