package cat.cis.poms.com.log;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

import java.util.GregorianCalendar;

/**
* This class is used for measuring time
* for code execution, in performace tuning.
* 
* @author: Venky,POMS
* @since 1.3.0 (10/15/2002 3:51:55 PM)
*/
public class TimingProfile
{
    GregorianCalendar fieldStartTime = null;
    GregorianCalendar fieldEndTime = null;
    String fieldLabel = "";
/**
 * TimingProfile constructor
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public TimingProfile () {
}
/**
 * TimingProfile constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param label java.lang.String
 */
public TimingProfile ( String label) {
setLabel(label);
}
/**
 * Method to collect time at the end of code execution.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void end() {
	fieldEndTime = new java.util.GregorianCalendar();
	/* Perform the end method. */
	return;
}
/**
 * Gets the label.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String.
 */
public String getLabel() {
	/* Returns the label property value. */
	if (fieldLabel == null) {
		try {
			fieldLabel = new String();
		} catch (Throwable exception) {
			System.err.println("Exception creating label property.");
		}
	};
	return fieldLabel;
}
/**
 * Method to print the total time taken, for the code
 * to execute
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void print() {
	System.out.println(toString());
	/* Perform the print method. */
	return;
}
/**
 * Reset the start and end time objects.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void reset() {
	fieldEndTime = null;
	fieldStartTime = null;
	/* Perform the reset method. */
	return;
}
/**
 * Sets the label property (java.lang.String) value.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param label The new value for the property.
 */
public void setLabel(String label) {
	fieldLabel = label;
	return;
}
/**
 * Method to collect time before the code execution begins
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public void start() {
	fieldStartTime = new java.util.GregorianCalendar();
	/* Perform the start method. */
	return;
}
/**
 * Method to calcuate the total time taken
 * for a piece of code to execute and converts
 * the result in a string format.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.String
 */
public String toString() {
	StringBuffer holdString = new StringBuffer(getLabel());
	holdString.append(" : ");
	holdString.append(fieldEndTime.getTime().getTime() - fieldStartTime.getTime().getTime());
	holdString.append(" ms ");
	/* Perform the toString method. */
	return holdString.toString();
}
}
