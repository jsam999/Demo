/**
****************************************************************
Date           : 12/28/2012
Reason         : Changed for Websphere to Tomcat Migration
****************************************************************
**/
package cat.cis.poms.com.servlet;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */



import java.util.Hashtable;
import java.util.Enumeration;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import cat.cis.poms.com.exception.ComException;
import cat.cis.poms.com.log.ComLog;

/**
 * This is an abstract servlet implementing
 * common functions used by all servlets 
 * 
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 *
 */
public abstract class ComBaseServlet extends HttpServlet
{
    private static boolean trace = true;
    private static boolean initLog = false;
/**
 * ComBaseServlet constructor.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public ComBaseServlet() {
	super();
}
/**
 * This method takes all parameters from the request and
 * puts them into a hashtable to return
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.util.Hashtable
 * @param req javax.servlet.HttpServletRequest
 */
/* Changed for Websphere to Tomcat Migration for CAT Migration Project � STARTS */
public Hashtable acquireParameters(HttpServletRequest req)
{
	/*Hashtable table = null;
	Enumeration enum = req.getParameterNames();
	if (enum != null)
	{
		table = new Hashtable();
		String name = null;
		String[] value = null;
		
		while (enum.hasMoreElements())
		{
			 name = (String) enum.nextElement();
			 value = req.getParameterValues(name);

			// if there is only one value for an element, the value is
			// extracted and added to the Hashtable.
			if (value != null && value.length == 1)
			{
				table.put(name, value[0]);
			}
			// if there is more than one value for an element,
			// the value is extracted and added to the Hashtable.
			else
				if (value != null && value.length > 1)
				{
					table.put(name, value);
				}
		}
	}
	return table;*/
	Hashtable table = null;
	Enumeration enumerate = req.getParameterNames();
	if (enumerate != null)
	{
		table = new Hashtable();
		String name = null;
		String[] value = null;
		
		while (enumerate.hasMoreElements())
		{
			 name = (String) enumerate.nextElement();
			 value = req.getParameterValues(name);

			// if there is only one value for an element, the value is
			// extracted and added to the Hashtable.
			if (value != null && value.length == 1)
			{
				table.put(name, value[0]);
			}
			// if there is more than one value for an element,
			// the value is extracted and added to the Hashtable.
			else
				if (value != null && value.length > 1)
				{
					table.put(name, value);
				}
		}
	}
	return table;
}
/* Changed for Websphere to Tomcat Migration for CAT Migration Project � ENDS */
/**
 * This method takes all parameters to handle GET request
 * from a browser/HTML page
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 * @exception java.lang.ServletException
 * @exception java.lang.IOException
 */
public void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
{
    try
        {
        performGetTask(req, res);
    }
    catch (Exception e)
        {
        handleException(req, res, new ComException(e));
    }
}
/**
 * This method takes all parameters to handle POST request
 * from a browser/HTML page
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 */
public void doPost(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException
{
    try
        {
        performPostTask(req, res);
    }
    catch (Exception e)
        {
        handleException(req, res, new ComException(e));
    }
}
/**
 * This method creates a new ComLog Object and returns.
 * This method is defined, not to repeat the LogKey,
 * all over the application. LogKey name used in only one place,
 * helps in easier maintanence.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param methodName java.lang.String
 * @param req javax.servlet.http.HttpServletRequest
 * @return cat.cis.poms.log.ComLog
 * @exception java.lang.Exception
 */
public ComLog getLog(String methodName, HttpServletRequest req)
    throws Exception
{
    if (initLog == false)
        {
        ComLog.initLoggerConfiguration("common", "common_log", getServletContext());
        initLog = true;
    }
    ComLog log = new ComLog("common", "ComBaseServlet", methodName, "COMMON");
    return log;
}
/**
 * Gets session value
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.lang.Object
 * @param req javax.servlet.http.HttpServletRequest
 * @param key java.lang.String
 */
public Object getSessionValue(HttpServletRequest req, String key) {
	return req.getSession().getAttribute(key);
	 
}
/**
 * This method is to get the User ID from session cache
 * or from CWS cookie
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @return java.lang.String
 * @exception java.lang.Exception
 */
public String getUserId(HttpServletRequest req) throws Exception
{
	ComLog log = getLog("getUserId", req);
	String userId = ComFunctions.getRemoteUser(req, log);
	return userId;
}
/**
 * This method is to handle all the Exceptions occuring
 * in the servlets. If any Exception occurs it is redirected
 * to an error page, where the message is extracted from
 * the Exception and displayed to the user
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param res javax.servlet.HttpServletResponse
 * @param exc java.lang.Exception
 * @exception javax.servlet.ServletException
 * @exception java.io.IOException
 */
public void handleException(
    HttpServletRequest req,
    HttpServletResponse res,
    Exception exc)
    throws ServletException, IOException
{
     	req.setAttribute("ComException", exc);
        String url = "/common/error/ErrorPage.jsp";
        redirect(req, res, url);
    
}
/**
 * Abstract method is to implement GET request
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 * @exception java.lang.Exception
 */
public abstract void performGetTask(
    HttpServletRequest req,
    HttpServletResponse res)
    throws Exception;
/**
 * Abstract method is to implement POST request
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 * @exception java.lang.Exception
 */
public abstract void performPostTask(HttpServletRequest req, HttpServletResponse res) throws Exception;
/**
 * Method used to forward JSP's/Servlet's
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.HttpServletRequest
 * @param req javax.servlet.HttpServletResponse
 * @param url java.lang.String
 */
protected void redirect(
    HttpServletRequest req,
    HttpServletResponse res,
    String url)
    throws ServletException, IOException
{
    if (trace) //flag to switch off logging
        {
        try
            {
            ComLog log = getLog("_redirect", req);
            log.logTrace("URL: " + ComFunctions.formatURL(url));
        }
        catch (Exception e)
            {
            // do nothing
        }
    }

    RequestDispatcher rd =
        getServletContext().getRequestDispatcher(ComFunctions.formatURL(url));
    rd.forward(req, res);
}
/**
 * Method to remove session value
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param key java.lang.String
 */
public void removeSessionValue(HttpServletRequest req, String key) {
	req.getSession().removeAttribute(key);
	 
}
/**
 * Sets the session value.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param key java.lang.String
 * @param obj java.lang.Object
 */
public void  setSessionValue(HttpServletRequest req, String key, Object obj) {
	req.getSession().setAttribute(key, obj);
}
}
