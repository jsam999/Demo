package cat.cis.poms.com.servlet;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import cat.cis.poms.com.log.ComLog;
import cat.cis.tuf.common.directory.Person;
import cat.cis.tuf.server.security.SecurityWrapper;
import cat.cis.tuf.server.util.TUFServerUtil;

/**
 * This is an abstract class implementing
 * common functions 
 *
 * @author: Venky,POMS
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 *
 */
public abstract class ComFunctions {
	//root uri of a webapp obtained from the server
	private static String rootUri = null;
	/**
	 * ComFunctions constructor.
	 * 
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 */
	public ComFunctions() {
		super();
	}
	/**
	 * Method to add URI to the jsp/servlet URL's.
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param uri java.lang.String
	 * @param url java.lang.String
	 * @return java.lang.String
	 */
	public static String addURI(String uri, String url) {
		String urlFormatted = "";
		if (url == null) {
			return urlFormatted;
		}
		if (url.length() < 1) {
			return urlFormatted;
		}
		if (url.charAt(0) != '/') {
			urlFormatted = uri + url;
		} else {
			urlFormatted = uri + url.substring(1, url.length());
		}
		return urlFormatted;
	}
	/**
	 * Method to format a Servlet URL in a Servlet forward request
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param servlet java.lang.String
	 * @return java.lang.String
	 */
	public static String formatRedirectServletURL(String servlet) {

		String uri = "/servlet/";
		return addURI(uri, servlet);

	}
	/**
	 * Method to format a web URL in a Servlet forward request
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param servlet java.lang.String
	 * @return java.lang.String
	 */
	public static String formatRedirectWebURL(String file) {

		String uri = "/";
		return addURI(uri, file);
	}
	/**
	 * Method to format a Servlet URL in a JSP page
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @return java.lang.String
	 * @param servlet java.lang.String
	 */
	public static String formatServletURL(String servlet) {

		String uri = rootUri + "/servlet/";
		return addURI(uri, servlet);
	}
	/**
	 * Method identifies a Servlet or JSP and formats
	 * the URL in a Servlet forward request
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @return java.lang.String
	 * @param servlet java.lang.String
	 */
	public static String formatURL(String url) {

		if (url != null) {
			int index = url.length() - 4;

			if (url.lastIndexOf(".jsp", index) != -1
				|| url.lastIndexOf("html", index) != -1) {
				return formatRedirectWebURL(url);
			} else {
				return formatRedirectServletURL(url);
			}
		} else {
			url = "";
		}
		return url;
	}
	/**
	 * Method to format a JSP URL in a JSP page
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @return java.lang.String
	 * @param servlet java.lang.String
	 */
	public static String formatWebURL(String file) {

		String uri = rootUri + "/";
		return addURI(uri, file);
	}
	/**
	 * Method to identify CWSID. CWSID is idenfied
	 * using browser cookie and TUF Framework classes.
	 * Once CWSID is idenfied, it is stored in session cache
	 * for subsequent access.
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param req javax.servlet.HttpServletRequest
	 * @return java.lang.String
	 * @exception java.lang.Exception
	 */
	public static String getRemoteUser(HttpServletRequest req)
		throws Exception {
		String cwsId = null;
		String servername = req.getServerName();
		int server_port = (req).getServerPort();
/*		if (server_port == 8080)
			// localhost
			{
			//throw new Exception("If you are getting this error message, it means you are on a developer's machine (localhost) and forgot to uncomment the line that sets the userid in ComFunctions.getRemoteUser.");
			cwsId = "sivakj";
			return cwsId;
		}
*/
		//retrieve CWSID from session cache
		cwsId = (String) req.getSession().getAttribute("CWSID");
		if (cwsId == null) {
			Person p =
				SecurityWrapper.getInstance().getRemoteUser(req.getCookies());
			if (p != null) {
				cwsId = p.getLogonId();
			}
			req.getSession().setAttribute("CWSID", cwsId);
		}
		if (cwsId != null) {
			cwsId = cwsId.toUpperCase();
		}

		if (cwsId == null) {
			throw new Exception("CWSID null. Please logon to the system.<BR>Try accessing the system again.");
		}
		return cwsId;
	}
	/**
	 * Method to identify CWSID. CWSID is idenfied
	 * using browser cookie and TUF Framework classes.
	 * Once CWSID is idenfied, it is stored in session cache
	 * for subsequent access.
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param req javax.servlet.HttpServletRequest
	 * @param log cat.cis.poms.log.ComLog
	 * @return java.lang.String
	 */
	public static String getRemoteUser(HttpServletRequest req, ComLog log)
		throws Exception {
		String cwsId = null;
		//retrieve CWSID from session cache
		cwsId = (String) req.getSession().getAttribute("CWSID");
		if (cwsId == null) {
			Person p =
				SecurityWrapper.getInstance().getRemoteUser(req.getCookies());
			if (p != null) {
				cwsId = p.getLogonId();
			}
			req.getSession().setAttribute("CWSID", cwsId);
		} 
		if (cwsId != null) {
			cwsId = cwsId.toUpperCase();
		}
		log.logTrace("CWSID " + cwsId);

		if (cwsId == null) {
			throw new Exception("CWSID null. Please logon to the system.<BR>Try accessing the system again.");
		}
		return cwsId;
	}
	/**
	 * Method to initialize rootUri. TUF frameworks
	 * is used to get the rootUri
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param context javax.servlet.ServletContext
	 */
	public static void initRootUri() {
		if (rootUri == null) {
			rootUri = TUFServerUtil.getInstance().getRootURI();
		}
	}
	/**
	 * Method to initialize rootUri. TUF frameworks
	 * is used to get the rootUri
	 *
	 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
	 * @param context javax.servlet.ServletContext
	 */
	public static void initRootUri(ServletContext context) {
		if (rootUri == null) {
			rootUri = TUFServerUtil.getInstance().getRootURI();
		}
	}
}
