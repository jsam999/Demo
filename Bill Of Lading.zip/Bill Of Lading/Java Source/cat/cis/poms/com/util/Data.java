package cat.cis.poms.com.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Hashtable;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Vector;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.io.Serializable;
/**
 * Data hashtable based implementation.
 *
 * @since 1.2,  1/27/2000
 * @author Lawerence McAlpin, POMS
 */
public class Data implements Serializable {
	transient protected Hashtable properties=new Hashtable(20);
	
/**
* Method to clear the hashtable
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
*/
public void clear()
{
    properties.clear();
}
/**
* Method to check if the property is stored in hashtable
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @param propertyName java.lang.String
*/
public boolean containsProperty(String propertyName)
{
    return properties.containsKey(propertyName);
}
/**
* Method to check if hashtables are same
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @param obj java.lang.Object
* @return boolean
*/
public boolean equals(Object obj)
{
    if (obj instanceof Data)
        {
        Data intf = (Data) obj;
        Enumeration ps = intf.properties();
        Object objval = null;
        Object this_val = null;
        String key = null;
        while (ps.hasMoreElements())
            {
           key = (String) ps.nextElement();
            if (this.containsProperty(key))
                {
                 objval = intf.getProperty(key);
                 this_val = this.getProperty(key);
                if (!objval.equals(this_val))
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        return true;
    }
    else
    {
        return false;
    }
}
/**
 * Gets property.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @return java.lang.Object
 */
public Object get(String propertyName) {
	return getProperty(propertyName);
}
/**
 * Gets Calendar.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @return java.util.Calendar
 */
public Calendar getCalendar(String propertyName)
{
    Calendar c = (Calendar) getProperty(propertyName);
    if (c == null)
        {
        c = Calendar.getInstance();
    }
    return c;
}
/**
* Gets Hashtable.
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @return java.util.Hashtable
*/
public Hashtable getInternal()
{
    return properties;
}
/**
* Gets Property from Hashtable
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @param propertyName java.lang.String
* @return java.lang.Object
*/
public Object getProperty(String propertyName) {
	return properties.get(propertyName);
}
/**
 * Gets SortVector.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @return cat.cis.poms.com.util.SortVector
 */
public SortVector getSortVector(String propertyName)
{
    SortVector sv = (SortVector) getProperty(propertyName);
    if (sv == null)
        {
        sv = new SortVector();
    }
    return sv;
}
/**
 * Gets String.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @return java.lang.String
 */
public String getString(String propertyName)
{
    String s = (String) getProperty(propertyName);
    if (s == null)
        {
        s = "";
    }
    return s;
}
/**
 * Gets Vector.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @return java.util.Vector
 */
public Vector getVector(String propertyName)
{
    Vector v = (Vector) getProperty(propertyName);
    if (v == null)
        {
        v = new Vector();
    }
    return v;
}
/**
 * Merges contents of two hashtables.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param data cat.cis.poms.com.util.Data
 */
public void merge(Data data)
{
    Enumeration en = data.properties();
    String key = null;
    Object prop = null;

    while (en.hasMoreElements())
        {
        key = (String) en.nextElement();
        prop = data.getProperty(key);
        properties.put(key, prop);
    }
}
/**
 * Gets all the keys from the hashtable
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return java.util.Enumeration
 */
public Enumeration properties()
{
    return properties.keys();
}
/**
 * Sets the property in hashtable
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @param propertyValue java.lang.Object
 */
public void put(String propertyName, Object propertyValue)
{
    setProperty(propertyName, propertyValue);
}
/**
* Reads properties from an object and loads in hashtable
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @param is java.io.ObjectInputStream
* @exception java.io.IOException
* @exception java.lang.ClassNotFoundException
*/
private void readObject(ObjectInputStream is)
    throws IOException, ClassNotFoundException
{
    //System.err.println("HTData.readObject is="+is);
    int size = is.readInt();
    //System.err.println("\tHTData.readObject, size = "+size);		
    properties = new Hashtable(20);
    String key = null;
    Object val = null;
    for (int i = 0; i < size; i++)
        {
        key = (String) is.readObject();
        val = is.readObject();
        //System.err.println("\treadObject, "+key+" : "+val);
        properties.put(key, val);
    }
}
/**
 * Removes the remove the property from hashtable
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param s java.lang.String
 */
public void remove(String s)
{
    getInternal().remove(s);
}
/**
 * Sets the hashtable in this object
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param ht java.util.Hashtable
 */
public void setInternal(Hashtable ht)
{
    properties = ht;
}
/**
 * Sets the property in hashtable
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param propertyName java.lang.String
 * @param propertyValue java.lang.String
 */
public void setProperty(String propertyName, Object propertyValue)
{
    if (propertyValue == null)
        {
        properties.remove(propertyName);
    }
    else
        {
        properties.put(propertyName, propertyValue);
    }
}
/**
 * Converts all the properties from the Hashtable into
 * one single string as key/value pair
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return java.lang.String
 */
public String toString()
{

    StringBuffer ret = new StringBuffer("");
    Enumeration e = properties();
    String key = null;
    Object val = null;

    while (e.hasMoreElements())
        {
        key = (String) e.nextElement();
        val = properties.get(key);
        //			System.err.println("key="+key+" : val="+val);
        ret.append(key + " : " + val + "\n");
    }
    return ret.toString();
}
/**
* Reads properties from the hashtable to an object
*
* @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
* @param os java.io.ObjectOutputStream
* @exception java.io.IOException
*/
private void writeObject(ObjectOutputStream os) throws IOException
{
    os.writeInt(properties.size());
    Enumeration e = properties.keys();
    String key = null;
    Object val = null;
    while (e.hasMoreElements())
        {
        key = (String) e.nextElement();
        val = properties.get(key);
        os.writeObject(key);
        os.writeObject(val);
    }
}
}
