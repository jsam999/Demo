package cat.cis.poms.com.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.math.BigDecimal;
import java.sql.Date;
import java.util.Calendar;
import java.util.Vector;
/**
 * Utility class with methods to do date formatting, 
 * string formatting, source code formatting
 *
 * @since 1.2,  1/27/2000
 * @author Lawerence McAlpin, POMS
 */
public class POMSUtil {
	public final static String UNKNOWN_SOURCE = "UNKNOWN_SOURCE";
	public final static String UNKNOWN_DATE = "N/A";
/**
 * POMSUtil constructor comment.
 */
public POMSUtil() {
	super();
}
/**
 * When comparing doubles with ==, the two numbers must be 
 * exactly the same.  This can be problematic sometimes because
 * due to rounding errors, you can sometimes calculate a value
 * that is "different" by a fraction of a percent from the
 * truncated value you get when retrieving a number from a 
 * database, etc.  Sometimes, we are only concerned with the
 * portion of the decimal that we will display.
 *
 * approximatelyEqual takes in a <I>precision</I> variable
 * which identifies to how many decimal places we consider
 * a value to be equal.
 *
 * For example:
 *
 * approximatelyEqual(3.001, 3.002, 2) would return true
 * because we reduce each decimal to 3.00.
 *
 * approximatelyEqual(3.0011, 3.0016, 3) would return false
 * because we round the number to the thousandth place (the
 * precision is 3), and 3.001 != 3.002.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param first double
 * @param second double
 * @param int precision
 * @return boolean
 */
public static boolean approximatelyEqual(double first,double second,int precision)
{
	double rFirst = reducePrecision(first,precision);
	double rSecond = reducePrecision(second,precision);
	return (rFirst == rSecond);
}
/**
 * Converts the date as stored in SQL to the format we display
 * it in.
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.lang.String
 * @return java.lang.String
 */
public static String convertDB2ToFmtDate(String dbDate) 
{
	String effectiveDate = null;
	String sYear = "0000";
	int tMonth = 0;
	String sDay = "00";
	
	if (dbDate.trim().length() == 8)
	{
		sYear = dbDate.substring(0,4);
		tMonth = Integer.parseInt(dbDate.substring(4,6));
		sDay = dbDate.substring(6,8);
	} else if (dbDate.trim().length() == 10) {
		sYear = dbDate.substring(0,4);
		tMonth = Integer.parseInt(dbDate.substring(5,7));
		sDay = dbDate.substring(8,10);
	}

	String sMonth = "???";
	switch (tMonth)
	{
		case 1: 
				sMonth = "Jan";
				break;
		case 2: 
				sMonth = "Feb";
				break;
		case 3: 
				sMonth = "Mar";
				break;
		case 4: 
				sMonth = "Apr";
				break;
		case 5: 
				sMonth = "May";
				break;
		case 6: 
				sMonth = "Jun";
				break;
		case 7: 
				sMonth = "Jul";
				break;
		case 8: 
				sMonth = "Aug";
				break;
		case 9: 
				sMonth = "Sep";
				break;
		case 10: 
				sMonth = "Oct";
				break;
		case 11: 
				sMonth = "Nov";
				break;
		case 12: 
				sMonth = "Dec";
				break;
		default: 
				sMonth = "Jan";
				break;
	}
	effectiveDate = sDay + sMonth + sYear;

	if (effectiveDate.equals("00???0000"))
	{
		return POMSUtil.UNKNOWN_DATE;
	}
	return effectiveDate;
}
/**
 * Converts the date as stored in SQL to the format we display
 * it in.
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.sql.Date
 * @return java.lang.String
 */
public static String convertDB2ToFmtDate(Date dbDate) 
{
	return convertDB2ToFmtDate(dbDate.toString());
}
/**
 * Converts the date as stored in SQL to International Date format 
 *  
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.lang.String
 * @return java.lang.String
 */
public static String convertDB2ToInternationalDate(String dbDate) {
	String effectiveDate = null;
	String sYear = "0000";
	String sMonth = "00";
	String sDay = "00";
	
	if (dbDate.trim().length() == 8)
	{
		sYear = dbDate.substring(0,4);
		sMonth = dbDate.substring(4,6);
		sDay = dbDate.substring(6,8);
	} else if (dbDate.trim().length() == 10) {
		sYear = dbDate.substring(0,4);
		sMonth = dbDate.substring(5,7);
		sDay = dbDate.substring(8,10);
	}


	effectiveDate = sYear + sMonth + sDay;
	
	return effectiveDate;
}
/**
 * Method to convert date to IMS date format.
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.lang.String
 * @return java.lang.String
 * @exception java.lang.Exception
 */
public static String convertFmtToIMSDate(String effDate) throws Exception 
{
	String dbDate = null;
	
	if (effDate.trim().length() == 9)
	{
		String sYear = effDate.substring(5,9);
		String sDay = effDate.substring(0,2);
		String sMonth = effDate.substring(2,5).toUpperCase();
		int tMonth = 0;
		if (sMonth.equals("JAN"))
		{
			tMonth = 1;
		}
		else if (sMonth.equals("FEB"))
		{
			tMonth = 2;
		}
		else if (sMonth.equals("MAR"))
		{
			tMonth = 3;
		}
		else if (sMonth.equals("APR"))
		{
			tMonth = 4;
		}
		else if (sMonth.equals("MAY"))
		{
			tMonth = 5;
		}
		else if (sMonth.equals("JUN"))
		{
			tMonth = 6;
		}
		else if (sMonth.equals("JUL"))
		{
			tMonth = 7;
		}
		else if (sMonth.equals("AUG"))
		{
			tMonth = 8;
		}
		else if (sMonth.equals("SEP"))
		{
			tMonth = 9;
		}
		else if (sMonth.equals("OCT"))
		{
			tMonth = 10;
		}
		else if (sMonth.equals("NOV"))
		{
			tMonth = 11;
		}
		else if (sMonth.equals("DEC"))
		{
			tMonth = 12;
		}
		else
		{
			throw new Exception(effDate + " is not a valid date.");
		}
		String cMonth = "";
		if (tMonth < 10)
		{
			cMonth = "0" + tMonth;
		}
		else
		{
			cMonth = "" + tMonth;
		}

		dbDate = sYear + cMonth + sDay; //sDay + cMonth + sYear;
	}
	
	return dbDate;
}
/**
 * Method to convert date to SQL date format.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.lang.String
 * @return java.lang.String
 * @exception javal.lang.Exception
 */
public static java.sql.Date convertFmtToSQLDate(String effDate1) throws Exception 
{
	int iYear = 0;
	int iMonth = 0;
	int iDay = 0;

	String effDate = effDate1.toUpperCase().trim();

	if (effDate.length() == 8)
	{
		effDate = "0" + effDate;
	}
	if (effDate.length() == 9)
	{
		iYear = Integer.parseInt(effDate.substring(5,9));
		
		if (iYear < 1970)
		{
			throw new Exception(effDate + " is not a properly formatted date.  The date must be later than 01Jan1970.");
		}
		iYear -= 1900;
		iDay = Integer.parseInt(effDate.substring(0,2));
		String sMonth = effDate.substring(2,5);

		if (sMonth.equals("JAN"))
		{
			iMonth = 0;
		}
		else if (sMonth.equals("FEB"))
		{
			iMonth = 1;
		}
		else if (sMonth.equals("MAR"))
		{
			iMonth = 2;
		}
		else if (sMonth.equals("APR"))
		{
			iMonth = 3;
		}
		else if (sMonth.equals("MAY"))
		{
			iMonth = 4;
		}
		else if (sMonth.equals("JUN"))
		{
			iMonth = 5;
		}
		else if (sMonth.equals("JUL"))
		{
			iMonth = 6;
		}
		else if (sMonth.equals("AUG"))
		{
			iMonth = 7;
		}
		else if (sMonth.equals("SEP"))
		{
			iMonth = 8;
		}
		else if (sMonth.equals("OCT"))
		{
			iMonth = 9;
		}
		else if (sMonth.equals("NOV"))
		{
			iMonth = 10;
		}
		else if (sMonth.equals("DEC"))
		{
			iMonth = 11;
		}
		else
		{
		    throw new Exception(effDate + " is not a properly formatted date.  The date must be provided in a ddMMMyyyy format.  For example: 31Mar1999");
		}
	} else
	{
	    throw new Exception(effDate + " is not a properly formatted date.  The date must be provided in a ddMMMyyyy format.  For example: 31Mar1999");
	}
	return new Date(iYear,iMonth,iDay);
}
/**
 * Method to convert source code to country name
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param pricingSource java.lang.String
 * @return java.lang.String
 */
public static String convertSourceCode(String inPricingSource)
{
    String pricingSource = trimString(inPricingSource);
    String sourceCountry = UNKNOWN_SOURCE;

    if (pricingSource.equals("12"))
        {
        sourceCountry = "U.S.A.";
    }
    else if (pricingSource.equals("13"))
        {
        sourceCountry = "U.S.A.";
    }
    else if (pricingSource.equals("16"))
        {
        sourceCountry = "U.S.A. (ALL OTHER)";
    }
    else if (pricingSource.equals("25"))
        {
        sourceCountry = "BELGIUM";
    }
    else if (pricingSource.equals("37"))
        {
        sourceCountry = "FRANCE";
    }
        else if (pricingSource.equals("R7"))
        {
	        sourceCountry = "UNITED KINGDOM";
        }
    else if (pricingSource.equals("R9"))
    {
        sourceCountry = "FRANCE";
    }
    else if (pricingSource.equals("34"))
    {
        sourceCountry = "UNITED KINGDOM";
    }
    else if (pricingSource.equals("EY"))
    {
        sourceCountry = "GERMANY";
    }
    else if (pricingSource.equals("R8"))
    {
        sourceCountry = "U.S.A. (MINNEAPOLIS)";
    }
    else if (pricingSource.equals("66"))
    {
        sourceCountry = "JAPAN";
    }
    else if (pricingSource.equals("82"))
    {
        sourceCountry = "BRAZIL";
    }
    else if (pricingSource.equals("84"))
    {
        sourceCountry = "JAPAN";
    }
    else if (pricingSource.equals("U2"))
	{
        sourceCountry = "UNITED KINGDOM";
	}
    else if (pricingSource.equals("KK"))
    {
        sourceCountry = "SWEDEN";
    }
    else if (pricingSource.equals("LV"))
    {
        sourceCountry = "NETHERLANDS";
    }
    else if (pricingSource.equals("LF"))
    {
        sourceCountry = "UNITED KINGDOM";
    }
    else if (pricingSource.equals("N5"))
        {
	        sourceCountry = "INDIA";
        }
        else if (pricingSource.equals("J5"))
        {
	        sourceCountry = "U.S.A. (WACO)";
        }
    else if (pricingSource.equals("AL"))
    {
        sourceCountry = "ALL SOURCES";
    }
    return sourceCountry;
}
/**
 * Formats a string for display in HTML: removes characters
 * that could be confused for tags and replaces them with
 * the proper escape characters.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param dbDate java.lang.String
 * @return java.lang.String
 */
public static String fixString(String inText) 
{
	StringBuffer outText = new StringBuffer("");
	if (inText == null)
	{
		return "";
	}
	int inTextLength = inText.length();
	char c;
	for (int i = 0; i < inTextLength; i++)
	{
		c = inText.charAt(i);
		switch (c)
		{
			case '&':
				outText.append("&amp;");
				break;
			case '\"':
				outText.append("&quot;");
				break;
			case '>':
				outText.append("&gt;");
				break;
			case '<':
				outText.append("&lt;");
				break;
			default:
				outText.append(c);
		}
	}
	return trimString(outText.toString());
}
/**
 * Method to format double.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val double
 * @param precision int
 * @return java.lang.String
 */
public static String formatNumber(double val, int precision) {
/*	int times = 1;
	for (int i = 0; i < precision; i++)
		times *= 10;
	double tempVal = Math.round(val * times);
	double newVal = tempVal / times;

	String tempString = String.valueOf(newVal);
*/
	StringBuffer pattern = new StringBuffer("#,###");
	if (precision > 0) 
	{
		pattern.append(".");
		for (int i = 0; i < precision; i++)
		{
			pattern.append("#");
		}
	}
	java.text.DecimalFormat df = new java.text.DecimalFormat(pattern.toString());
	StringBuffer tempString = new StringBuffer(df.format(val));
		

	int iNumDecimals = 0;
	boolean fFoundDecimal = false;
	int tempStringLength = tempString.length();
	for (int i = 0; i < tempStringLength; i++)
	{
		if (fFoundDecimal == true)
		{
			iNumDecimals++;
		}
		if (tempString.toString().charAt(i) == '.')
		{
			fFoundDecimal = true;
		}
	}
	
	// if no decimal place found, add one
	if (! fFoundDecimal)
	{
		tempString.append(".");
	}
	// pad String out to the 'precision' number of decimal places
	for (int i = iNumDecimals; i < precision; i++)
	{
		tempString.append("0");
	}
	return tempString.toString();
}
/**
 * Method to format int value
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val double
 * @return java.lang.String
 */
public static String formatNumber(int val) {
	String value = (new Integer(val)).toString();
	return value;
}
/**
 * Method to format BigDecimal.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val BigDecimal
 * @param precision int
 * @return java.lang.String
 */
public static String formatNumber(BigDecimal val, int precision) 
{
	if (val == null)
	{
		return "null";
	}
	return formatNumber(val.doubleValue(),precision);
}
/**
 * Method to format short value
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val short
 * @return java.lang.String
 */
public static String formatNumber(short val) {
	String value = (new Short(val)).toString();
	return value;
}
/**
 * Method to format string
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val short
 * @return java.lang.String
 */
public static String formatString(String inText) 
{
	return trimString(fixString(inText));
}
/**
 * Returns today's date.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return java.sql.Date
 */
public static Date getCurrentDate() {
	Calendar c = Calendar.getInstance();
	int iyear = c.get(Calendar.YEAR) - 1900;
	int imonth = c.get(Calendar.MONTH);
	int iday = c.get(Calendar.DATE);
	return new Date(iyear,imonth,iday);
}
/**
 * Method to format Quarter.
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param qtr int
 * @return java.lang.String
 */
public static String getDateFromQtr(int qtr) {
	switch (qtr)
	{
		case 1:
			return "31Mar";
		case 2:
			return "30Jun";
		case 3:
			return "30Sep";
		case 4:
			return "31Dec";
		default:
			return "??Err";
	} 
}
/**
 * Returns date oofset by the number of days specified
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param i int no of days to be offset
 * @return java.sql.Date
 */
public static Date getNonCurrentDate(int i) {
	Calendar c = Calendar.getInstance();
	c.add(Calendar.DATE,i);
	int iyear = c.get(Calendar.YEAR) - 1900;
	int imonth = c.get(Calendar.MONTH);
	int iday = c.get(Calendar.DATE);
	return new Date(iyear,imonth,iday);
}
/**
 * Method to get Quarter information from SQL date format
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param effDate java.lang.String
 * @return int
 */
public static int getQtrFromSQLDate(String effDate) {
	String sMonth = effDate.substring(5,7).toUpperCase();
	int i = (new Integer(sMonth)).intValue();
	if (i <= 3)
	{
		return 1;
	}
	if (i <= 6)
	{
		return 2;
	}
	if (i <= 9)
	{
		return 3;
	}
	if (i <= 12)
	{
		return 4;
	}
	return 0;
}
/**
 * Returns the source facility codes we price by.  (Therefore,
 * it excludes Decatur and Aurora, etc., because all US facilities,
 * except R8 are grouped under 16.)
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return java.util.Vector
 */
public static Vector getSourceCodes() 
{
	Vector returnMe = new Vector();
	returnMe.addElement("16");
	returnMe.addElement("R8");
	returnMe.addElement("25");
	returnMe.addElement("82");
	returnMe.addElement("37");
	returnMe.addElement("R9");
	returnMe.addElement("EY");
	returnMe.addElement("66");
	returnMe.addElement("84");
	returnMe.addElement("LV");
	returnMe.addElement("KK");
	returnMe.addElement("34");
	returnMe.addElement("LF");
	returnMe.addElement("U2");
	return returnMe;
}
/**
 * Method to get Year information from SQL date format
 * 
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param effDate java.lang.String
 * @return java.lang.String
 */
public static String getYearFromSQLDate(String effDate) {
	String sYear = effDate.substring(0,4).toUpperCase();
	return sYear;
}
/**
 * Pads the left end (for right alignment).
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val java.lang.String
 * @param len int
 * @return java.lang.String
 */
public static String leftPad(String val,int len) {
	StringBuffer returnValue = new StringBuffer("");

	int count = len - val.length();
	for (int i = 0; i < count; i++)
	{
		returnValue.append(" ");
	}
	returnValue.append(val);
	
	return returnValue.toString();
}
/**
 * Pads the right end.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val java.lang.String
 * @param len int
 * @return java.lang.String
 */
public static String pad(String val,int len) {
	StringBuffer returnValue = new StringBuffer("");
	
	returnValue.append(val);
	int count = len - val.length();
	for (int i = 0; i < count; i++)
	{
		returnValue.append(" ");
	}
	return returnValue.toString();
}
/**
 * Method to reduce precision.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param in double
 * @param prec int
 * @return double
 */
public static double reducePrecision(double in,int prec)
{
	String temp = formatNumber(in,prec);
	return stringToDouble(temp);
}
/**
 * Method to add seperators
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param value java.lang.String
 * @return java.lang.String
 */
public static String stringAddSeparators(String value) {
	boolean bFlagFoundDecimal = true;// assume there is no decimal
	int iCountdownToComma = 4;  // we decrement this counter, and put in
								// a comma when it is zero; starts out 
								// at four since we will start the countdown
								// when we have the decimal, and we need
								// to add three digits after that
	StringBuffer szReturnString = new StringBuffer("");      // the string we return
	int iCounter = 0;
	boolean bNegative = false;
	char cDecimal = '.';
	char cSeparator = ',';
	
	// is this a negative number?
	if (value.charAt(0) == '-')
	{
		bNegative = true;
	}
	// is there a decimal point?
	int valueLength = value.length();
	for (iCounter=0;iCounter<valueLength;iCounter++)
	{
		if (value.charAt(iCounter)==cDecimal)    // found decimal
		{
			bFlagFoundDecimal = false;  // there is a decimal, so we set the flag
										// to false because the next loop hasn't    
										// found it yet
			break;
		}
	}
	
	// construct a REVERSE IMAGE of what we will return
	char cAdd;
	for (iCounter=value.length()-1;iCounter>=0;iCounter--)
	{
		cAdd = value.charAt(iCounter);
		if (bFlagFoundDecimal)
		{
			if (cAdd >= '0' && cAdd <= '9')// skip nondigits such as the minus sign
			{
				continue;
			}
			if ((--iCountdownToComma) == 0) // iCountdownToComma is a zero
			{
				szReturnString.append(cSeparator);
				iCountdownToComma = 3;  // wait three digits to add another comma
			}
			szReturnString.append(cAdd);                                         
		} else {
			szReturnString.append(cAdd);
			if (cAdd==cDecimal)
			{
				bFlagFoundDecimal = true; 
			} 
		}
	}
	
	// change the string so that characters are in the proper order
	StringBuffer returnThis = new StringBuffer("");
	for (int i = szReturnString.length()-1; i >= 0; i--)
	{
		returnThis.append(szReturnString.toString().charAt(i));
	}
	
	if (bNegative)  // restore negative sign if the number was negative
	{
		returnThis.insert(0,"-");// + returnThis;
	}
	return returnThis.toString();
}
/**
 * Method to convert formatted double value to string
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param doubleValue java.lang.String
 * @return double
 */
public static double stringToDouble(String doubleValue) {
//	try {
		StringBuffer convertMe = new StringBuffer("");
		int doubleValueLength = doubleValue.length();
		char c;
		for (int i = 0; i < doubleValueLength; i++)
		{
			c = doubleValue.charAt(i);
			if ((c >= '0' && c <= '9') || (c == '.') || (c == '-'))
			{
				convertMe.append(c);
			}
		}
		if (convertMe.length() == 0)
		{
			return 0.00;
		}

		double value = (new Double(convertMe.toString())).doubleValue();
		
		return value;
/*	} catch (NumberFormatException e) {
		return 0.00;
	}*/
}
/**
 * Method to convert formatted int value to string
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param intValue java.lang.String
 * @return int
 */
public static int stringToInt(String intValue) {
//	try {
		StringBuffer convertMe = new StringBuffer("");
		int intValueLength = intValue.length();
		char c;
		for (int i = 0; i < intValueLength; i++)
		{
			c = intValue.charAt(i);
			if ((c >= '0' && c <= '9') || (c == '.')  || (c == '-'))
			{
				convertMe.append(c);
			}
		}
		if (convertMe.length() == 0)
		{
			return 0;
		}
//		return ((new Double(convertMe)).doubleValue());
		return Integer.parseInt(convertMe.toString());
/*	} catch (NumberFormatException e) {
		return 0;
	}*/
}
/**
 * Method to convert formatted short value to string
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param intValue java.lang.String
 * @return short
 */
public static short  stringToShort(String intValue) {
//	try {
		StringBuffer convertMe = new StringBuffer("");
		int intValueLength = intValue.length();
		char c;
		for (int i = 0; i < intValueLength; i++)
		{
			c = intValue.charAt(i);
			if ((c >= '0' && c <= '9') || (c == '.') || (c == '-'))
			{
				convertMe.append(c);
			}
		}
		if (convertMe.length() == 0)
		{
			return (short)0;
		}
//		return ((new Double(convertMe)).doubleValue());
		return Short.parseShort(convertMe.toString());
/*	} catch (NumberFormatException e) {
		return 0;
	}*/
}
/**
 * Method to trim spaces in between a string
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param val java.lang.String
 * @return java.lang.String
 */
public static String trimString(String val) {
	StringBuffer returnValue = new StringBuffer("");
	if (val == null)
	{
		return returnValue.toString();
	}
	String tempValue = val.trim();
	boolean fFoundNonSpace = false;
	int tempValueLength = tempValue.length();
	for (int i = 0; i < tempValueLength; i++)
	{
		if ((tempValue.charAt(i) != ' ') && (!fFoundNonSpace))
		{
			fFoundNonSpace = true;
		}
		if (fFoundNonSpace)
		{
			returnValue.append(tempValue.charAt(i));
		}
	}
	
	return returnValue.toString();
}

/**
 * This method checks if user input is valid.
 * 
 * @since: (05/26/04 1:29:28 PM)
 * @param name java.lang.String	
 * @param namVal java.lang.String	
 * @return boolean false if not valid. 
 */
public static boolean validate(String name, String namVal) {
	if(namVal != null && namVal.trim().length() != 0) {
		namVal.toUpperCase();
		if(namVal.indexOf("<SCRIPT") != -1 
			|| namVal.indexOf("ALERT(") != -1
			|| namVal.indexOf("<SCRIPT/>") != -1) {
			//throw new Exception("Input values are not valid - " + name);
			return false;
		}
	}
	return true;
}

/**
 * This method checks if user input is valid.
 * 
 * @since: (05/26/04 1:29:28 PM)
 * @param name java.lang.String	
 * @param namVal java.lang.String	
 * @return boolean false if not valid. 
 */
public static boolean validate(String name, String[] valArr) {
	boolean valid = true;
	if(valArr != null) {
		for(int counter=0; counter<valArr.length; counter++) {
			if(!validate(name, valArr[counter])) {
				valid = false;
			}
		}
	}
	return valid;
}

}
