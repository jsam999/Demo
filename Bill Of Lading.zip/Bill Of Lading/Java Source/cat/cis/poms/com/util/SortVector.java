package cat.cis.poms.com.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Vector;


/**

 * This class is used to store a sorted list.
 *
 * @since 1.2,  1/27/2000
 * @author Lawerence McAlpin, POMS
 */
 
public class SortVector extends Vector{
/**
 * If argument is not <code>null</code>, 
 * adds all it's elements to this <code>Vector2</code>.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param v java.lang.Vector, that elements should be added.
 */
public void addElements(Vector v)
{
    if (v != null)
        {
        for (int i = 0; i < v.size(); i++)
            {
            addElement(v.elementAt(i));
        }
    }
}
/**
 * Finds necessary position for <code>Object</code> and 
 * adds it to this <code>Vector2</code>.
 * By the way returns founded position.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param object <code>Object</code>, should be added.
 */
public int addSortElement(Object object)
{
    return addSortElement(object, 0);
}
/**
 * Finds necessary position for <code>Object</code> and
 * adds it to this <code>Vector2</code>.
 * By the way returns founded position.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param object <code>Object</code>, should be added.
 * @param startIndex
 */
public int addSortElement(Object obj, int startIndex)
{
    String s = obj.toString().toUpperCase();
    int i = startIndex;
    while ((i < size())
        && (s.compareTo(elementAt(i).toString().toUpperCase()) > 0))
        {
        i++;
    }
    insertElementAt(obj, i);
    return i;
}
/**
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @deprecated, replaced with <code>addSortElement(Object)</code>.
 *
 */
public int addSorting(Object object)
{
    return addSortElement(object);
}
/**
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @deprecated, replaced with <code>addSortElement(Object,int)</code>.
 *
 */
public int addSorting(Object obj, int startIndex)
{
    return addSortElement(obj, startIndex);
}
/**
 * Determines whether another object is equal to this <code>Vector2</code>.      
 * Returns <code>true</true> if argument is not <code>null</code> 
 * and is a <code>Vector2</code> object, that contains the same elements, as this 
 * <code>Vector2<code>. This <code>Vector2<code> should also contain all of
 * argusment's elements.
 *
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return <true> if the argument is the same; <false> otherwise.
 */
public boolean equals(Object obj)
{
    if (obj instanceof Vector)
        {
        Vector v = (Vector) obj;
        int size = size();
        if (size != v.size())
            {
            return false;
        }
        for (int i = 0; i < size; i++)
            {
            if (!(contains(v.elementAt(i)) && v.contains(elementAt(i))))
                {
                return false;
            }
        }
        return true;
    }
    else
        {
        return false;
    }
}
/**
 * If argument is not <code>null</code>,
 * removes all it's elements from this <code>Vector2</code>.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @param v <code>Vector</code>, that elements should be removed.
 */
public void removeElements(Vector v)
{
    if (v != null)
        {
        for (int i = 0; i < v.size(); i++)
            {
            removeElement(v.elementAt(i));
        }
    }
}
/**
 * @deprecated, replaced with <code>addSortElement(Object)</code>.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @see #addSortElement(Object)
 */
public int sortAdd(Object object)
{
    return addSortElement(object);
}
/**
 * @deprecated, replaced with <code>addSortElement(Object, int)</code>.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @see #addSortElement(Object, int)
 */
public int sortAdd(Object obj, int startIndex)
{
    return addSortElement(obj, startIndex);
}
/**
 * Determines whether all elements of this SortVector are unique.
 *
 * @since 1.2,1/27/2000 by Lawerence McAlpin, POMS
 * @return <code>true</code> if all elements are unique,
 * <code>false</code> otherwise.
 */
public synchronized boolean unique()
{
    Object object = null;
	for (int i = 0; i < size(); i++)
        {
        object = elementAt(i);
        //		for(int j = 0; j < i; j++)
        //			if(object.equals(elementAt(j)))
        //				return false;
        for (int j = i + 1; j < size(); j++)
        {
            if (object.equals(elementAt(j)))
            {
                return false;
            }
        }
    }
    return true;
}
}
