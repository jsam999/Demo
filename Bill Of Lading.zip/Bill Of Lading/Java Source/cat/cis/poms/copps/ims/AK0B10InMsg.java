package cat.cis.poms.copps.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.copps.ims.AK0B10InMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B10InMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B10InMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.copps.ims.AK0B10InMsg.class,112));
         this.setBytes(new byte[112]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param]   
	* 		 
	*/

   public java.lang.String getACF2__USER__ID__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,9,false,false,false,-6,0,"X(7)",false,true);
   }
   public java.lang.String getFill_0()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,8,false,false,false,-7,0,"X(08)",false,true);
   }
   public java.lang.String getFill_1()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,82,false,false,false,-81,0,"X(82)",false,true);
   }
   public short getLL__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.copps.ims.AK0B10InMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public java.lang.String getSYSTEM__CODE__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,2,false,false,false,-1,0,"X(2)",false,true);
   }
   public java.lang.String getTRAN__CODE__MSG__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
   }
   public short getZZ__IN()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__IN",null,getLL__IN());
         firePropertyChange("ZZ__IN",null,getZZ__IN());
         firePropertyChange("TRAN__CODE__MSG__IN",null,getTRAN__CODE__MSG__IN());
         firePropertyChange("ACF2__USER__ID__IN",null,getACF2__USER__ID__IN());
         firePropertyChange("fill_0",null,getFill_0());
         firePropertyChange("SYSTEM__CODE__IN",null,getSYSTEM__CODE__IN());
         firePropertyChange("fill_1",null,getFill_1());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   /*
	* Modification History
	* 
	* 05-Sep-2005	pillasm (CAT-IDC)
	* 		This method didn't allow cws id with length greater than 7 chars. To allow longer cws login ids,
	* 		parameter 'PIC field length' of methods com.ibm.ivj.eab.record.cobol.CobolType.toString() [5th i/p param] and  
	* 		com.ibm.ivj.eab.record.cobol.CobolType.fromString() [6th i/p param] are modified and increased from 7 to 9.  
	* 		 
	*/

   public void setACF2__USER__ID__IN(java.lang.String aACF2__USER__ID__IN)
      throws RecordConversionFailureException {
      java.lang.String oldACF2__USER__ID__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,9,false,false,false,-6,0,"X(7)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aACF2__USER__ID__IN,9,0,9,false,false,false,-6,0,"X(7)",false,true);
      firePropertyChange("ACF2__USER__ID__IN",oldACF2__USER__ID__IN,aACF2__USER__ID__IN);
      return;
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setFill_0(java.lang.String aFill_0)
      throws RecordConversionFailureException {
      java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,20,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,20,aFill_0,9,0,8,false,false,false,-7,0,"X(08)",false,true);
      firePropertyChange("fill_0",oldFill_0,aFill_0);
      return;
   }
   public void setFill_1(java.lang.String aFill_1)
      throws RecordConversionFailureException {
      java.lang.String oldFill_1 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,30,9,0,82,false,false,false,-81,0,"X(82)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,30,aFill_1,9,0,82,false,false,false,-81,0,"X(82)",false,true);
      firePropertyChange("fill_1",oldFill_1,aFill_1);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,7,false,false,false,-6,0,"X(7)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,20, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,8,false,false,false,-7,0,"X(08)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,28, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,30, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,82,false,false,false,-81,0,"X(82)",false,true);
      return;
   }
   public void setLL__IN(short aLL__IN)
      throws RecordConversionFailureException {
      short oldLL__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__IN",oldLL__IN,aLL__IN);
      return;
   }
   public void setSYSTEM__CODE__IN(java.lang.String aSYSTEM__CODE__IN)
      throws RecordConversionFailureException {
      java.lang.String oldSYSTEM__CODE__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,28,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,28,aSYSTEM__CODE__IN,9,0,2,false,false,false,-1,0,"X(2)",false,true);
      firePropertyChange("SYSTEM__CODE__IN",oldSYSTEM__CODE__IN,aSYSTEM__CODE__IN);
      return;
   }
   public void setTRAN__CODE__MSG__IN(java.lang.String aTRAN__CODE__MSG__IN)
      throws RecordConversionFailureException {
      java.lang.String oldTRAN__CODE__MSG__IN = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aTRAN__CODE__MSG__IN,9,0,9,false,false,false,-8,0,"X(09)",false,true);
      firePropertyChange("TRAN__CODE__MSG__IN",oldTRAN__CODE__MSG__IN,aTRAN__CODE__MSG__IN);
      return;
   }
   public void setZZ__IN(short aZZ__IN)
      throws RecordConversionFailureException {
      short oldZZ__IN = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__IN,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__IN",oldZZ__IN,aZZ__IN);
      return;
   }
}
