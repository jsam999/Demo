package cat.cis.poms.copps.ims;

/**
 * Class: cat.cis.poms.copps.ims.AK0B10InMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B10InMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.PropertyDescriptor getACF2__USER__ID__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ACF2__USER__ID__IN", Class.forName(getBeanClassName()), "getACF2__USER__ID__IN", "setACF2__USER__ID__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ACF2__USER__ID__IN");
      aDescriptor.setDisplayName("ACF2__USER__ID__IN");
      aDescriptor.setShortDescription("ACF2__USER__ID__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.copps.ims.AK0B10InMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.copps.ims.AK0B10InMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.copps.ims.AK0B10InMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_0");
      aDescriptor.setDisplayName("fill_0");
      aDescriptor.setShortDescription("fill_0");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFill_1PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_1", Class.forName(getBeanClassName()), "getFill_1", "setFill_1" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_1");
      aDescriptor.setDisplayName("fill_1");
      aDescriptor.setShortDescription("fill_1");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__IN", Class.forName(getBeanClassName()), "getLL__IN", "setLL__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__IN");
      aDescriptor.setDisplayName("LL__IN");
      aDescriptor.setShortDescription("LL__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__INPropertyDescriptor()
            ,getZZ__INPropertyDescriptor()
            ,getTRAN__CODE__MSG__INPropertyDescriptor()
            ,getACF2__USER__ID__INPropertyDescriptor()
            ,getFill_0PropertyDescriptor()
            ,getSYSTEM__CODE__INPropertyDescriptor()
            ,getFill_1PropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getSYSTEM__CODE__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("SYSTEM__CODE__IN", Class.forName(getBeanClassName()), "getSYSTEM__CODE__IN", "setSYSTEM__CODE__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("SYSTEM__CODE__IN");
      aDescriptor.setDisplayName("SYSTEM__CODE__IN");
      aDescriptor.setShortDescription("SYSTEM__CODE__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getTRAN__CODE__MSG__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("TRAN__CODE__MSG__IN", Class.forName(getBeanClassName()), "getTRAN__CODE__MSG__IN", "setTRAN__CODE__MSG__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("TRAN__CODE__MSG__IN");
      aDescriptor.setDisplayName("TRAN__CODE__MSG__IN");
      aDescriptor.setShortDescription("TRAN__CODE__MSG__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__INPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__IN", Class.forName(getBeanClassName()), "getZZ__IN", "setZZ__IN" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__IN");
      aDescriptor.setDisplayName("ZZ__IN");
      aDescriptor.setShortDescription("ZZ__IN");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }
}
