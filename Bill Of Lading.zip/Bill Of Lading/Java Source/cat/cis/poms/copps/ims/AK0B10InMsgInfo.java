package cat.cis.poms.copps.ims;

//
//
// FILE NAME: AK0B10InMsgInfo.java
// Generated from c:\temp\t1ak0b10.cobol COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B10InMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B10InMsgInfo () throws RecordException
   {
      int[] arraySize = new int[1];
      ArrayField arrField = null;

      addField(new Field(new CobolType("S9(4):COMP"), "LL__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("S9(4):COMP"), "ZZ__IN", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("X(09):DISPLAY"), "TRAN__CODE__MSG__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(7):DISPLAY"), "ACF2__USER__ID__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(08):DISPLAY"), "fill_0", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(2):DISPLAY"), "SYSTEM__CODE__IN", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(82):DISPLAY"), "fill_1", new CobolInitialValueObject(" ", null)));

   }
}
