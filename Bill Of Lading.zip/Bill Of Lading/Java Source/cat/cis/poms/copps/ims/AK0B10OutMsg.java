package cat.cis.poms.copps.ims;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import com.ibm.record.CustomRecordType;
import com.ibm.record.RecordConversionFailureException;
import com.ibm.record.RecordConversionUnsupportedException;
import com.ibm.record.RecordException;
/**
 * Class: cat.cis.poms.copps.ims.AK0B10OutMsg
 * This is a generated file.  Do not edit.
 */

public class AK0B10OutMsg extends com.ibm.record.CustomRecord
{

	  private boolean notifyWhenContentsUpdated = false;
	  private PropertyChangeSupport listeners = new PropertyChangeSupport( this );

   public AK0B10OutMsg()
      throws RecordException
   {
      try {
         com.ibm.ivj.eab.record.cobol.CobolRecordAttributes attrs = new com.ibm.ivj.eab.record.cobol.CobolRecordAttributes();
         attrs.setFloatingPointFormat((int)0);
         attrs.setEndian((int)0);
         attrs.setRemoteIntEndian((int)0);
         attrs.setCodePage((java.lang.String)"037");
         attrs.setMachine((int)0);
         this.setRecordAttributes(attrs);
         this.setRecordType(new CustomRecordType(cat.cis.poms.copps.ims.AK0B10OutMsg.class,900));
         this.setBytes(new byte[900]);
         this.setInitialValues();
         this.enableNotification();
      } catch (Exception e) {
         throw new RecordException(e.getMessage());
      }
   }
   public void addPropertyChangeListener(PropertyChangeListener x) {
      listeners.addPropertyChangeListener( x );
   }
   public void disableNotification()
   {
      super.disableNotification();
      notifyWhenContentsUpdated = false;
      return;
   }
   public void enableNotification()
   {
      super.enableNotification();
      notifyWhenContentsUpdated = true;
      return;
   }
   protected void firePropertyChange(String prop, byte oldObj, byte newObj) {
      listeners.firePropertyChange( prop, new Byte(oldObj), new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, char oldObj, char newObj) {
      listeners.firePropertyChange( prop, new Character(oldObj), new Character(newObj) );
   }
   protected void firePropertyChange(String prop, double oldObj, double newObj) {
      listeners.firePropertyChange( prop, new Double(oldObj), new Double(newObj) );
   }
   protected void firePropertyChange(String prop, float oldObj, float newObj) {
      listeners.firePropertyChange( prop, new Float(oldObj), new Float(newObj) );
   }
   protected void firePropertyChange(String prop, int oldObj, int newObj) {
      listeners.firePropertyChange( prop, new Integer(oldObj), new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, long oldObj, long newObj) {
      listeners.firePropertyChange( prop, new Long(oldObj), new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, byte newObj) {
      listeners.firePropertyChange( prop, oldObj, new Byte(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, char newObj) {
      listeners.firePropertyChange( prop, oldObj, new Character(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, double newObj) {
      listeners.firePropertyChange( prop, oldObj, new Double(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, float newObj) {
      listeners.firePropertyChange( prop, oldObj, new Float(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, int newObj) {
      listeners.firePropertyChange( prop, oldObj, new Integer(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, long newObj) {
      listeners.firePropertyChange( prop, oldObj, new Long(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, Object newObj) {
      listeners.firePropertyChange( prop, oldObj, newObj);
   }
   protected void firePropertyChange(String prop, Object oldObj, short newObj) {
      listeners.firePropertyChange( prop, oldObj, new Short(newObj) );
   }
   protected void firePropertyChange(String prop, Object oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, oldObj, new Boolean(newObj) );
   }
   protected void firePropertyChange(String prop, short oldObj, short newObj) {
      listeners.firePropertyChange( prop, new Short(oldObj), new Short(newObj) );
   }
   protected void firePropertyChange(String prop, boolean oldObj, boolean newObj) {
      listeners.firePropertyChange( prop, new Boolean(oldObj), new Boolean(newObj) );
   }
   public java.lang.String[] getAVAIL__SCREENS__OUT()
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 40;
         java.lang.String[] returnArray = new java.lang.String[20];
         int[] dim = {20};
         for(int i0=0;i0<20;i0++) {
            int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            java.lang.String element = (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,40,false,false,false,-39,0,"X(40)",false,true);
            returnArray[i0] = element;
         }
         return returnArray;
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getAVAIL__SCREENS__OUT(int index)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 40;
         int[] dim = {20};
         int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         return (java.lang.String)com.ibm.ivj.eab.record.cobol.CobolType.toString(this,offset,9,0,40,false,false,false,-39,0,"X(40)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public java.lang.String getERR__MSG__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,816,9,0,60,false,false,false,-59,0,"X(60)",false,true);
   }
   public java.lang.String getFill_0()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,876,9,0,24,false,false,false,-23,0,"X(24)",false,true);
   }
   public java.lang.String getFNCT__CD__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,9,9,0,4,false,false,false,-3,0,"X(04)",false,true);
   }
   public short getLL__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public static Class getMetadataClass() {
      try {
         return Class.forName("cat.cis.poms.copps.ims.AK0B10OutMsgInfo");
      } catch (ClassNotFoundException e) {
         return null;
      }
   }
   public java.lang.String getUSER__BADGE__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,5,false,false,false,-4,0,"X(05)",false,true);
   }
   public java.lang.String getUSER__INITIALS__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,3,false,false,false,-2,0,"X(03)",false,true);
   }
   public short getZZ__OUT()
      throws RecordConversionFailureException {
      return com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
   }
   public void notifyAllVars()
      throws RecordConversionFailureException
   {
      if (notifyWhenContentsUpdated) {
         firePropertyChange("LL__OUT",null,getLL__OUT());
         firePropertyChange("ZZ__OUT",null,getZZ__OUT());
         firePropertyChange("USER__BADGE__OUT",null,getUSER__BADGE__OUT());
         firePropertyChange("FNCT__CD__OUT",null,getFNCT__CD__OUT());
         firePropertyChange("USER__INITIALS__OUT",null,getUSER__INITIALS__OUT());
         firePropertyChange("AVAIL__SCREENS__OUT",null,getAVAIL__SCREENS__OUT());
         firePropertyChange("ERR__MSG__OUT",null,getERR__MSG__OUT());
         firePropertyChange("fill_0",null,getFill_0());
      }
   }
   public void removePropertyChangeListener(PropertyChangeListener x) {
      listeners.removePropertyChangeListener( x );
   }
   public void setAVAIL__SCREENS__OUT(java.lang.String[] aAVAIL__SCREENS__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 40;
         int[] dim = {20};
         for(int i0=0;i0<20;i0++) {
            int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(i0,dim,elementSize);
            com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aAVAIL__SCREENS__OUT[i0],9,0,40,false,false,false,-39,0,"X(40)",false,true);
         }
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setAVAIL__SCREENS__OUT(int index, java.lang.String aAVAIL__SCREENS__OUT)
      throws RecordConversionFailureException {
      try
      {
         int elementSize = 40;
         int[] dim = {20};
         int offset = 16 + com.ibm.ivj.eab.record.cobol.CobolArrayType.getElementOffset(index,dim,elementSize);
         com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,offset,aAVAIL__SCREENS__OUT,9,0,40,false,false,false,-39,0,"X(40)",false,true);
      }
      catch (Exception exc)
      {
         throw new RecordConversionFailureException();
      }
   }
   public void setBytes(byte[] contents)
   {
      super.setBytes(contents);
      notifyAllVars();
   }
   public void setERR__MSG__OUT(java.lang.String aERR__MSG__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldERR__MSG__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,816,9,0,60,false,false,false,-59,0,"X(60)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,816,aERR__MSG__OUT,9,0,60,false,false,false,-59,0,"X(60)",false,true);
      firePropertyChange("ERR__MSG__OUT",oldERR__MSG__OUT,aERR__MSG__OUT);
      return;
   }
   public void setFill_0(java.lang.String aFill_0)
      throws RecordConversionFailureException {
      java.lang.String oldFill_0 = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,876,9,0,24,false,false,false,-23,0,"X(24)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,876,aFill_0,9,0,24,false,false,false,-23,0,"X(24)",false,true);
      firePropertyChange("fill_0",oldFill_0,aFill_0);
      return;
   }
   public void setFNCT__CD__OUT(java.lang.String aFNCT__CD__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldFNCT__CD__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,9,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,9,aFNCT__CD__OUT,9,0,4,false,false,false,-3,0,"X(04)",false,true);
      firePropertyChange("FNCT__CD__OUT",oldFNCT__CD__OUT,aFNCT__CD__OUT);
      return;
   }
   public void setInitialValues() throws
      RecordConversionFailureException,
      RecordConversionUnsupportedException
   {
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,0, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShortInitialValue(this,2, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject("0,0"),0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,4, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,9, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,4,false,false,false,-3,0,"X(04)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,13, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,16, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,56, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,96, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,136, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,176, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,216, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,256, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,296, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,336, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,376, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,416, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,456, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,496, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,536, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,576, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,616, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,656, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,696, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,736, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,776, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,40,false,false,false,-39,0,"X(40)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,816, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,60,false,false,false,-59,0,"X(60)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromStringInitialValue(this,876, new com.ibm.ivj.eab.record.cobol.CobolInitialValueObject(" ,null"),9,0,24,false,false,false,-23,0,"X(24)",false,true);
      return;
   }
   public void setLL__OUT(short aLL__OUT)
      throws RecordConversionFailureException {
      short oldLL__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,0,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,0,aLL__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("LL__OUT",oldLL__OUT,aLL__OUT);
      return;
   }
   public void setUSER__BADGE__OUT(java.lang.String aUSER__BADGE__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldUSER__BADGE__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,4,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,4,aUSER__BADGE__OUT,9,0,5,false,false,false,-4,0,"X(05)",false,true);
      firePropertyChange("USER__BADGE__OUT",oldUSER__BADGE__OUT,aUSER__BADGE__OUT);
      return;
   }
   public void setUSER__INITIALS__OUT(java.lang.String aUSER__INITIALS__OUT)
      throws RecordConversionFailureException {
      java.lang.String oldUSER__INITIALS__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toString(this,13,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      com.ibm.ivj.eab.record.cobol.CobolType.fromString(this,13,aUSER__INITIALS__OUT,9,0,3,false,false,false,-2,0,"X(03)",false,true);
      firePropertyChange("USER__INITIALS__OUT",oldUSER__INITIALS__OUT,aUSER__INITIALS__OUT);
      return;
   }
   public void setZZ__OUT(short aZZ__OUT)
      throws RecordConversionFailureException {
      short oldZZ__OUT = com.ibm.ivj.eab.record.cobol.CobolType.toShort(this,2,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      com.ibm.ivj.eab.record.cobol.CobolType.fromShort(this,2,aZZ__OUT,0,4,5,true,false,true,-4,0,"S9(4)",false,false);
      firePropertyChange("ZZ__OUT",oldZZ__OUT,aZZ__OUT);
      return;
   }
}
