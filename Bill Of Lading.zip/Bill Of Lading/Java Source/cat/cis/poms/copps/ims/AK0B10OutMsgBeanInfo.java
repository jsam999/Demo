package cat.cis.poms.copps.ims;

/**
 * Class: cat.cis.poms.copps.ims.AK0B10OutMsgBeanInfo
 * This is a generated file.  Do not edit.
 */
import java.beans.SimpleBeanInfo;

public class AK0B10OutMsgBeanInfo extends SimpleBeanInfo
{
   public java.beans.BeanInfo[] getAdditionalBeanInfo() {
      java.lang.Class superClass;
      java.beans.BeanInfo superBeanInfo = null;

      try {
         superClass = getBeanDescriptor().getBeanClass().getSuperclass();
      } catch (java.lang.Throwable exception) {
         return null;
      }

      try {
         superBeanInfo = java.beans.Introspector.getBeanInfo(superClass);
      } catch (java.beans.IntrospectionException ie) {}

      if (superBeanInfo != null) {
         java.beans.BeanInfo[] ret = new java.beans.BeanInfo[1];
         ret[0] = superBeanInfo;
         return ret;
      }
      return null;
   }
   public java.beans.PropertyDescriptor getAVAIL__SCREENS__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.IndexedPropertyDescriptor("AVAIL__SCREENS__OUT", Class.forName(getBeanClassName()), "getAVAIL__SCREENS__OUT", "setAVAIL__SCREENS__OUT", "getAVAIL__SCREENS__OUT", "setAVAIL__SCREENS__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("AVAIL__SCREENS__OUT");
      aDescriptor.setDisplayName("AVAIL__SCREENS__OUT");
      aDescriptor.setShortDescription("AVAIL__SCREENS__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public static java.lang.Class getBeanClass()
   {
      return(cat.cis.poms.copps.ims.AK0B10OutMsg.class);
   }
   public static java.lang.String getBeanClassName()
   {
      return("cat.cis.poms.copps.ims.AK0B10OutMsg");
   }
   public java.beans.BeanDescriptor getBeanDescriptor() {
      java.beans.BeanDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.BeanDescriptor(cat.cis.poms.copps.ims.AK0B10OutMsg.class);
      } catch (Throwable exception) {
      };
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getERR__MSG__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ERR__MSG__OUT", Class.forName(getBeanClassName()), "getERR__MSG__OUT", "setERR__MSG__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ERR__MSG__OUT");
      aDescriptor.setDisplayName("ERR__MSG__OUT");
      aDescriptor.setShortDescription("ERR__MSG__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.EventSetDescriptor[] getEventSetDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor getFill_0PropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("fill_0", Class.forName(getBeanClassName()), "getFill_0", "setFill_0" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("fill_0");
      aDescriptor.setDisplayName("fill_0");
      aDescriptor.setShortDescription("fill_0");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getFNCT__CD__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("FNCT__CD__OUT", Class.forName(getBeanClassName()), "getFNCT__CD__OUT", "setFNCT__CD__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("FNCT__CD__OUT");
      aDescriptor.setDisplayName("FNCT__CD__OUT");
      aDescriptor.setShortDescription("FNCT__CD__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getLL__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("LL__OUT", Class.forName(getBeanClassName()), "getLL__OUT", "setLL__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("LL__OUT");
      aDescriptor.setDisplayName("LL__OUT");
      aDescriptor.setShortDescription("LL__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.MethodDescriptor[] getMethodDescriptors()
   {
      return null;
   }
   public java.beans.PropertyDescriptor[] getPropertyDescriptors()
   {
      try {
         java.beans.PropertyDescriptor aDescriptorList[] = {
            getLL__OUTPropertyDescriptor()
            ,getZZ__OUTPropertyDescriptor()
            ,getUSER__BADGE__OUTPropertyDescriptor()
            ,getFNCT__CD__OUTPropertyDescriptor()
            ,getUSER__INITIALS__OUTPropertyDescriptor()
            ,getAVAIL__SCREENS__OUTPropertyDescriptor()
            ,getERR__MSG__OUTPropertyDescriptor()
            ,getFill_0PropertyDescriptor()
         };
         return aDescriptorList;
      } catch (java.lang.Throwable exception) {
         handleException(exception);
      }
      return null;
   }
   public java.beans.PropertyDescriptor getUSER__BADGE__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("USER__BADGE__OUT", Class.forName(getBeanClassName()), "getUSER__BADGE__OUT", "setUSER__BADGE__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("USER__BADGE__OUT");
      aDescriptor.setDisplayName("USER__BADGE__OUT");
      aDescriptor.setShortDescription("USER__BADGE__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getUSER__INITIALS__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("USER__INITIALS__OUT", Class.forName(getBeanClassName()), "getUSER__INITIALS__OUT", "setUSER__INITIALS__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("USER__INITIALS__OUT");
      aDescriptor.setDisplayName("USER__INITIALS__OUT");
      aDescriptor.setShortDescription("USER__INITIALS__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   public java.beans.PropertyDescriptor getZZ__OUTPropertyDescriptor()
      throws java.beans.IntrospectionException
   {
      java.beans.PropertyDescriptor aDescriptor = null;
      try {
         aDescriptor = new java.beans.PropertyDescriptor("ZZ__OUT", Class.forName(getBeanClassName()), "getZZ__OUT", "setZZ__OUT" );
      } catch (java.lang.ClassNotFoundException exception) {
         handleException(exception);
      }

      aDescriptor.setBound(true);
      aDescriptor.setName("ZZ__OUT");
      aDescriptor.setDisplayName("ZZ__OUT");
      aDescriptor.setShortDescription("ZZ__OUT");
      aDescriptor.setHidden(false);
      aDescriptor.setExpert(false);
      return aDescriptor;
   }
   private void handleException(java.lang.Throwable exception) {

   	/* Uncomment the following lines to print uncaught exceptions to stdout */
	// System.out.println("--------- UNCAUGHT EXCEPTION ---------");
	// exception.printStackTrace(System.out);
   }
}
