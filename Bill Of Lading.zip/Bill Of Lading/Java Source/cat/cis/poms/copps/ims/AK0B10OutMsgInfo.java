package cat.cis.poms.copps.ims;

//
//
// FILE NAME: AK0B10OutMsgInfo.java
// Generated from c:\temp\t1ak0b10.cobol COBOL source file.
//

import com.ibm.ivj.eab.record.cobol.*;
import com.ibm.record.*;

/**
*  This class defines a shared dynamic record type definition.
*/
public class AK0B10OutMsgInfo extends CobolDynamicRecordType
{
   /**
   *  This ctor defines the record type (its content).
   */
   public AK0B10OutMsgInfo () throws RecordException
   {
      int[] arraySize = new int[1];
      ArrayField arrField = null;

      addField(new Field(new CobolType("S9(4):COMP"), "LL__OUT", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("S9(4):COMP"), "ZZ__OUT", new CobolInitialValueObject("0", "0")));

      addField(new Field(new CobolType("X(05):DISPLAY"), "USER__BADGE__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(04):DISPLAY"), "FNCT__CD__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(03):DISPLAY"), "USER__INITIALS__OUT", new CobolInitialValueObject(" ", null)));

      arraySize[0] = 20;
      arrField = new ArrayField(new CobolArrayType(arraySize, new CobolType("X(40):DISPLAY")), "AVAIL__SCREENS__OUT", new CobolInitialValueObject(" ", null));
      addField(arrField);

      addField(new Field(new CobolType("X(60):DISPLAY"), "ERR__MSG__OUT", new CobolInitialValueObject(" ", null)));

      addField(new Field(new CobolType("X(24):DISPLAY"), "fill_0", new CobolInitialValueObject(" ", null)));

   }
}
