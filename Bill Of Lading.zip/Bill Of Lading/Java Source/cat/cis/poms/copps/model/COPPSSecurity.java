package cat.cis.poms.copps.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Vector;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.ims.IMSTransaction;

import cat.cis.poms.copps.ims.AK0B10InMsg;
import cat.cis.poms.copps.ims.AK0B10OutMsg;
import cat.cis.poms.copps.util.COPPSException;
import cat.cis.poms.copps.util.COPPSProperties;
import cat.cis.poms.copps.util.COPPSUtil;
import com.ibm.connector.imstoc.DFSMsg;
import com.ibm.connector.imstoc.IMSTOCResourceException;
 
/**
 * Class defined to get UserInfo from
 * database
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
 
 public class COPPSSecurity
{
   /**
    * This field is holds the log object. Log object is part of the
    * security object, to use for tracing
    */
	private ComLog log = null;
	
    /**
     * This field is holds list of applications/screens the user is authorized to access
     */
    private Vector screenList = null;
/**
* COPPSSecurity constructor 
*
* @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
* @param  info   cat.cis.poms.com.log.ComLog
*  
*/
public COPPSSecurity(ComLog info)
{
    super();
    log = new ComLog(this, info);
}
/**
 * Returns a Vector that contains list of screens/applications
 * which can be accessed by this user.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return  <code>java.util.Vector</code> that contains the list of
 *          screens/applications.
 * @exception cat.cis.poms.copps.util.COPPSException
 */
public Vector getScreenList() throws COPPSException
{
    if (screenList == null)
        {
        getUserInfo();
    }
    return screenList;
}
/**
 * Users list of screens are mapped with respective URL's
 * for launching the applications
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param screenList java.util.Vector
 * @return java.util.Vector
 * 
 */

private Vector getUserApps(Vector screenList)
{
	Vector list = null;
	if (screenList != null)
	{
		int size = screenList.size();
		list = new Vector();
		int bolCount = 0;
		String appName = null;
		for (int i = 0; i < size; i++)
		{
			appName = (String) screenList.elementAt(i);
			if (appName.startsWith("BOL"))
			{
				if (bolCount != 1)
				{
					list.addElement("BOL - Bill of Lading");
					bolCount = 1;
				}
			}
			else
				if (appName.startsWith("EEC"))
				{
					list.addElement("EEC - European Economic Commission");
				}
				else
					if (appName.startsWith("TRADE"))
					{
						list.addElement("TDS - Trade Discount System");
					}
		}
	}
	Vector appList = null;
	if (list != null)
	{
		int size = list.size();
		appList = new Vector();
		String appName = null;
		String appInitial = null;
		String appUrl = null;
		String[] arr = null;
		for (int i = 0; i < size; i++)
		{
			appName = (String) list.elementAt(i);
			appInitial = appName.substring(0, 3);
			try
			{
				appUrl = COPPSProperties.getInstance().getUrl(appInitial);
			}
			catch (Exception e)
			{
				appUrl = "";
			}
			arr =new String[2];
			arr[0] = appName;
			arr[1] = appUrl;
			appList.addElement(arr);
		}
	}
	return appList;
}
/**
 * Method retrieves userinfo from the IMS database
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.copps.model.COPPSUserInfo
 * @exception  COPPSException
 */
public COPPSUserInfo getUserInfo() throws COPPSException
{
	COPPSUserInfo info = null;
	log.setMethodName("getScreenList");
	log.logTrace("Getting user info");
	String cwsId = log.getUserId();
	
	try
	{
		// Log access attempt
		boolean okHandler = false;
		IMSConnectionManager cm = COPPSUtil.getInstance().getIMSManager();
		AK0B10InMsg inMsg = new AK0B10InMsg();
		AK0B10OutMsg outMsg = new AK0B10OutMsg();
		IMSTransaction ims = new IMSTransaction(cm, outMsg);
		inMsg.setLL__IN((short) 112);
		inMsg.setZZ__IN((short) 0);

		//database name ("AK010B10 ") has a space character at the end.
		inMsg.setTRAN__CODE__MSG__IN("AK010B10 ");
		inMsg.setACF2__USER__ID__IN(cwsId);
		Object bean = null;
		try
		{
			//log.logTrace("Calling IMS DB");
			bean = ims.callIMS(inMsg);
		}
		catch (IMSTOCResourceException e)
		{
			if (e.getReasonCode().trim().equals("SECFAIL"))
			{
				log.logWarning("COPPS Security Violation");
				throw new COPPSException("There was a security violation with your user ID and password.  Please correct them, if necessary, or call the COPPS Hotline (309-675-4500).");
			}
			else
			{
				log.logWarning("User id " + cwsId + " received " + e.getMessage());
				throw new COPPSException(e.getMessage());
			}
		}
		catch (Exception e)
		{
			throw e;
		}
		String output = "";
		if (bean instanceof AK0B10OutMsg)
		{
			AK0B10OutMsg out = (AK0B10OutMsg) bean;
			// retreive ims data and populate output screen fields			
			output = out.getERR__MSG__OUT();
			output = output.trim();
			if (output.length() == 0)
			{
				java.util.Vector list = new java.util.Vector();
				String nextScreen = null;
				for (int i0 = 0; i0 < 20; i0++)
				{
					nextScreen = out.getAVAIL__SCREENS__OUT(i0);
					if (nextScreen.trim().length() != 0)
					{
						list.addElement(nextScreen);
						log.logTrace("Getting screen info " + nextScreen);
					}
				}
				screenList = list;
				Vector userApps = getUserApps(list);
				info = new COPPSUserInfo();
				info.setLogonId(cwsId);
				info.setAcf2Id(cwsId);
				info.setUserApps(userApps);
				info.setBadge(out.getUSER__BADGE__OUT());
				info.setFunction(out.getFNCT__CD__OUT());
				info.setUserInitial(out.getUSER__INITIALS__OUT());
				okHandler = true;
			}
			else
				if (output.length() != 0)
				{
					log.logWarning(output);
					throw new COPPSException(output);
				}
		}
		if (bean instanceof DFSMsg)
		{
			DFSMsg out = (DFSMsg) bean;
			output = out.getDFSMessage();
			log.logWarning(output);
			throw new COPPSException(output);
		}
	}
	catch (Exception e)
	{
		log.logFatal("Exception occured ", e);
		throw new COPPSException(e.getMessage());
	}
	log.logTrace("Got user info");
	return info;
}
}
