package cat.cis.poms.copps.model;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Vector;

/**
 * Class template for UserInfo details
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSUserInfo
{
    /**
     * This field is defined to hold the CWSID of the user.
     *  
     */
    private String logonId = null;

    /**
     * This field is defined to hold the acf2Id of the user.
     *  
     */
    private String acf2Id = null;

    /**
     * This Vector is defined to contain the list of screens/applications
     * the user has access to.
     *  
     */
    private Vector userApps = null;

    /**
     * This field is defined to hold the badge number of the user.
     *  
     */
    private String badge = null;

    /**
     * This field is defined to hold the function of the user like DLR
     *  
     */
    private String function = null;

    /**
     * This field is defined to hold the initials of the user
     *  
     */
    private String userInitial = null;
/**
 * COPPSUserInfo constructor
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public COPPSUserInfo() {
	super();
}
/**
 * Returns the ACF2ID of the user.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */

public String getAcf2Id()
{
    return acf2Id;
}
/**
 * Returns the BADGE Number of the user.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 *  
 */
public String getBadge()
{
    return badge;
}
/**
 * Returns the DEALER CODE, if the user is a dealer. If the user
 * is a dealer, then the badge number contains the dealer code information
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */
public String getDealerCode()
{
    String dealerCode = "";
    if (getFunction() != null && getFunction().trim().compareTo("DLR") == 0)
        {
        if (badge != null)
            {
            dealerCode = badge.substring(1, 5).trim();
        }
    }
    return dealerCode;
}
/**
 * Returns the FUNCTION, information if the user is a dealer.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */
public String getFunction()
{
    return function;
}
/**
 * Returns the CWSID, of the user.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */
public String getLogonId()
{
    return logonId;
}
/**
 * Returns the count of no of screens/applications the user can access.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */
public int getScreenCount()
{
    int count = 0;
    if (userApps != null)
        {
        count = userApps.size();
    }
    return count;
}
/**
 * Returns the list of no of screens/applications the user can access.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.util.Vector
 */
public Vector getUserApps()
{
    return userApps;
}
/**
 * Returns the initials, of the user.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return <code>java.lang.String</code>
 */
public String getUserInitial()
{
    return userInitial;
}
/**
 * Checks whether the user is a dealer. If the function value is DLR then the user is
 * a dealer.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean isDealer()
{
	//DLR code indicates the user is a dealer
	if (getFunction().trim().compareTo("DLR") == 0)
	{
		return true;
	}
	return false;
}
/**
 * Checks whether the user has logged on
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return boolean
 */
public boolean isLogonOk()
{
	//If the user has a function, user is a valid user
	if (getFunction() == null)
	{
		return false;
	}
	return true;
}
/**
 * Sets the ACF2ID for the user.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inAcf2Id  <code>java.lang.String</code> 
 */
public void setAcf2Id(String inAcf2Id)
{
    acf2Id = inAcf2Id;
}
/**
 * Sets the BADGE NUMBer for the user.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inBadge  <code>java.lang.String</code> 
 */
public void setBadge(String inBadge)
{
    badge = inBadge;
}
/**
 * Sets the FUNCTION code for the user.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inFunction  <code>java.lang.String</code> 
 */
public void setFunction(String inFunction)
{
    function = inFunction;
}
/**
 * Sets the LOGONID for the user.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inLogonId  <code>java.lang.String</code> 
 */
public void setLogonId(String inLogonId)
{
    logonId = inLogonId;
}
/**
 * Sets the list of applications/screens for which the user have access.
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inUserApps  <code>java.util.Vector</code> 
 */
public void setUserApps(Vector inUserApps)
{
    userApps = inUserApps;
}
/**
 * Sets the intitals for the user
 *   
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param inUserInitial  <code>java.lang.String</code> 
 */
public void setUserInitial(String inUserInitial)
{
    userInitial = inUserInitial;
}
}
