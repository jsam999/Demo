package cat.cis.poms.copps.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.com.servlet.ComBaseServlet;
import cat.cis.poms.copps.model.COPPSSecurity;
import cat.cis.poms.copps.model.COPPSUserInfo;
import cat.cis.poms.copps.util.COPPSId;
import cat.cis.poms.copps.util.COPPSUrl;
import cat.cis.poms.copps.util.COPPSUtil;

 /**
 * This Servlet acts as a controller, directing
 * the request to appropriate model's and response
 * to appropriate JSP's.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSController extends ComBaseServlet
{
/**
 * COPPSController constructor comment.
 */
public COPPSController() {
	super();
}
/**
 * Method to initialize the logging framework for this application once, when this
 * servlet is created.
 *
 * @exception  javax.servlet.ServletException
 */
public void init() throws javax.servlet.ServletException
{
	super.init();
	try
	{
		//call to initialize the application.
		COPPSUtil.getInstance().initApplication(getServletContext());
	}
	catch(Exception e)
	{
		throw new javax.servlet.ServletException(e.getMessage());
	}
}
/**
 * Method to process GET request from the client. Inturn this method
 * calls performTask
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performGetTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req, res);
}
/**
 * Method to process POST request from the client. Inturn this method
 * calls performTask
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performPostTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req, res);
}
/**
 * Method to process GET/POST request from the client and redirects to
 * appropriate VIEW page for showing the results
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	//get the CWSID
	String cwsId = getUserId(req);
	ComLog log = COPPSUtil.getInstance().getLog("COPPSController", "performTask()", cwsId);

	//get the parameters, entered by the user
	Hashtable params = acquireParameters(req);
	String url = COPPSUrl.MAIN_FRAME;
	String action = (String) params.get(COPPSId.ACTION);
	log.logTrace("Getting User info");

	//Checking if the userinfo is stored in the session, if the
	//system was accessed earlier
	COPPSUserInfo userInfo = (COPPSUserInfo) req.getSession().getAttribute(COPPSId.USER_INFO);
	if (userInfo == null || userInfo.getUserApps() == null)
	{

		//call to the COPPSSecurity object, to get the UserInfo from the
		//database.
		COPPSSecurity coppsSecurity = new COPPSSecurity(log);
		userInfo = coppsSecurity.getUserInfo();
		//storing the userinfo in session.(faster access for the subsequent access
		req.getSession().setAttribute(COPPSId.USER_INFO, userInfo);
	}
	String[] screenUrl = COPPSUrl.getScreenUrl(COPPSUrl.SCREEN_LIST);
	req.getSession().setAttribute(COPPSId.SCREEN_URL, screenUrl);

	//Opening only body (details, action buttons)
	url = COPPSUrl.SCREEN_DETAILS;
	if (action != null && action.compareTo("OPEN") == 0)
	{
		//Opening the entire frame (header, details, action buttons)
		url = COPPSUrl.MAIN_FRAME;
	}
	log.logTrace("Opening the url " + url);
	redirect(req, res, url);
	log.logUsage("COPPSSecurity accessed");
}
}
