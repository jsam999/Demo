package cat.cis.poms.copps.servlets;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cat.cis.poms.com.log.ComLog;
import cat.cis.poms.copps.util.COPPSId;
import cat.cis.poms.copps.util.COPPSUtil;
import cat.cis.poms.copps.util.COPPSUrl;
import cat.cis.poms.com.email.ComMailService;
import cat.cis.poms.com.servlet.ComBaseServlet;
 
/**
 * This Servlet used to send mails to administrators
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSMailServlet extends ComBaseServlet
{
/**
 * COPPSMailServlet constructor comment.
 */
public COPPSMailServlet() {
	super();
}
/**
 * Method to process POST request from the client. Inturn this method
 * calls performTask
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performGetTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req,res);
}
/**
 * Method to process POST request from the client. Inturn this method
 * calls performTask
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performPostTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	performTask(req,res);
}
/**
 * Method to process mail request from the client.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param req javax.servlet.http.HttpServletRequest
 * @param res javax.servlet.http.HttpServletResponse
 * @exception  java.lang.Exception
 */
public void performTask(HttpServletRequest req, HttpServletResponse res) throws Exception
{
	//get the CWSID
	String cwsId = getUserId(req);
	
	ComLog log = COPPSUtil.getInstance().getLog("COPPSMailServlet", "performTask()", cwsId);
	log.logTrace("Getting parameters");
	//get the parameters, entered by the user
	Hashtable params = acquireParameters(req);
	String action = (String) params.get(COPPSId.ACTION);
	if (action != null && action.compareTo("SEND") == 0)
	{
		String message = (String) params.get("MESSAGE");
		String subject = (String) params.get("SUBJECT");
		
		//send Mail
		sendMail(message, subject, cwsId, log);
	}
	String[] screenUrl = COPPSUrl.getScreenUrl(COPPSUrl.MAIL);
	req.getSession().setAttribute(COPPSId.SCREEN_URL, screenUrl);
	String url = COPPSUrl.SCREEN_DETAILS;
	redirect(req, res, url);
	log.logTrace("Feedback sent");
	log.logUsage("Feedback to Administrator");
}
/**
 * Method to send the mail. Inturn uses TUF to send mail
 * Creation date: (4/21/01 9:36:19 AM)
 *
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param message java.lang.String message of the mail to be sent
 * @param subject java.lang.String subject of the mail to be sent
 * @param userId java.lang.String CWSID of the user sending the mail
 * @param log java.lang.String
 * @exception java.lang.Exception
 */
private void sendMail(String message, String subject, String userId, ComLog log) throws Exception
{
	 
	log.logTrace("Mail component accessed");
	ComMailService email = new ComMailService();
	email.setFrom(userId);
	email.addSendTo("pillasm");
	email.addSendTo("hennetp");
	email.setSubject("(COPPS) " + subject);
	email.setMessage(message);
	
	email.send();
	log.logTrace("Feedback sent successfully...");
}
}
