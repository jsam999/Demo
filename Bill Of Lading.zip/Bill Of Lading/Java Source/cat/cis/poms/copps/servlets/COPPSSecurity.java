package cat.cis.poms.copps.servlets;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import javax.servlet.ServletException;

import cat.cis.tuf.common.logging.FatalEvent;
/**
 * Insert the type's description here.
 * Creation date: (1/21/2003 9:37:50 AM)
 * @author: Administrator
 */
public class COPPSSecurity extends HttpServlet {
/**
 * Process incoming requests for information
 * 
 * @param req Object that encapsulates the request to the servlet 
 * @param res Object that encapsulates the response from the servlet
 * @throws ServletException if exception occurs
 * @throws IOException if IOException occurs
 */
public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException {

	try
	{
		performTask(req, res);
	}
	catch(Exception e)
	{
		new FatalEvent("common", 0, "COPPSSecurity", "doGet", "", e);
	}
}
/**
 * Process incoming requests for information
 * 
 * @param req Object that encapsulates the request to the servlet 
 * @param res Object that encapsulates the response from the servlet
 * @throws ServletException if exception occurs
 * @throws IOException if IOException occurs
 */
public void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException {

	try
	{
		performTask(req, res);
	}
	catch(Exception e)
	{
		new FatalEvent("common", 0, "COPPSSecurity", "doPost", "", e);
	}
}
/**
 * Process incoming requests for information
 * 
 * @param req Object that encapsulates the request to the servlet 
 * @param res Object that encapsulates the response from the servlet
 * @throws Exception if exception occurs
 */
public void performTask(HttpServletRequest req, HttpServletResponse res)
    throws Exception
{
	String url = "/COPPSUrlChange.html";
	RequestDispatcher rd =
        getServletContext().getRequestDispatcher(url);
    rd.forward(req, res);
}
}
