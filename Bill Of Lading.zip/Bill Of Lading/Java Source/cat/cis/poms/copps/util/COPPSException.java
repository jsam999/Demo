package cat.cis.poms.copps.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
 /**
 * Exception class used for all exceptions generated
 * COPPS Security
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSException extends Exception {
/**
 * COPPSException constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public COPPSException() {
	super();
}
/**
 * COPPSException constructor.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param s java.lang.String
 */
public COPPSException(String s) {
	super(s);
}
}
