package cat.cis.poms.copps.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */

/**
 * This class is used to define all the KEYS used in
 * the COPPS application.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public final class COPPSId
{
    public final static String USER_INFO = "USER_INFO";
    public final static String URL = "URL";
    public final static String ACTION = "ACTION";
    public final static String SCREEN_URL = "SCREEN_URL";
    public final static String SUBJECT = "SUBJECT";
    public final static String MESSAGE = "MESSAGE";
}
