package cat.cis.poms.copps.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.ResourceBundle;
import java.util.Locale;
import cat.cis.poms.com.servlet.ComFunctions;

 /**
 * This is a singleton class defined for getting properties
 * from property file.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSProperties
{
	//properties loaded from the file are stored in this
	//ResourceBundle object
	private ResourceBundle bundle = null;

	//singleton instance of this class
	private static COPPSProperties instance = null;
/**
 * COPPSProperties constructor comment.
 */
public COPPSProperties() {
	super();
}
/**
 * Method returning the ResourceBundle which
 * contains all the properties. Properties are
 * loaded only once. If a new property is added
 * to the file, then the ResourceBundle object
 * needs to be reinitialized.(Webapp/JVM needs to
 * be restarted.)
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return java.util.ResourceBundle
 */
private ResourceBundle getBundle()
{
	Locale locale = new Locale("en", "US");
	if (bundle == null)
	{
		bundle = ResourceBundle.getBundle("copps_apps", locale);
	}
	return bundle;
}
/**
 * Method returning singleton instance.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.copps.util.COPPSProperties
 */
public static COPPSProperties getInstance()
{
	if (instance == null)
	{
		instance = new COPPSProperties();
	}
	return instance;
}
/**
 * Given a KEY, this method retrieves the property value.
 * 
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param id java.lang.String
 * @return java.lang.String
 */
public String getProperty(String id) {
	return getBundle().getString(id);
}
/**
 * Given a KEY, this method retrieves the value
 * and formats the URL. The assumption here is,
 * this method is used, only to get a URL.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param id java.lang.String
 * @return java.lang.String
 * 
 */
public String getUrl(String id) {
	return ComFunctions.formatServletURL(getBundle().getString(id));
}
}
