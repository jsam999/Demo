package cat.cis.poms.copps.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 

import java.util.Hashtable;

/**
 * This class is used to define all the URL's used in COPPS.
 * This abstract class acts as a centralized repository of all
 * the URL's. (For easy maintanence)
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public abstract class COPPSUrl
{
	//URI & PATH are combined with servlet class names to form a
	//servlet URL
	public static final String uri = "/";
	public static final String path1 = "cat.cis.poms.copps.servlets.";

	//Servlet URL's
	public static final String CONTROLLER = uri + path1 + "COPPSController";
	public static final String FEEDBACK = uri + path1 + "COPPSMailServlet";
	
	//JSP URL's
	public static final String SCREEN_DETAILS = "/copps/res/COPPSBody.jsp";
	public static final String MAIN_FRAME = "/copps/res/COPPSMainFrame.jsp";
	public static final String COPY_RIGHT = "/copps/util/COPPSCopyright.jsp";
	public static final String HELP = "/copps/util/COPPSHelp.jsp";
	public static final String CONTACTS = "/copps/util/COPPSContacts.jsp";
	
	//Screen ID's
	public static final String MAIL = "MAIL";
	public static final String SCREEN_LIST = "SCREEN_LIST";

	//Hashtable containing all the JSP names for each screen layout
	private static Hashtable navigation = null;

	//Servlet/JSP URL's are statically initialized once at the begining
	static
	{
		initUrls();
	}
/**
 * Method to get JSP URL's, given a screen ID.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param screenId java.lang.String
 * @return java.lang.String[]
 * 
 */
public static String[] getScreenUrl(String screenId) {
	String[] screen = (String[])navigation.get(screenId);
	return screen;
}
/**
 * Method to initialize the Servlet/JSP URL's.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 */
public static void initUrls()
{
	//CONTROLLER = uri + path1 + "COPPSController";
	//FEEDBACK = uri + path1 + "COPPSMailServlet";
	navigation = new Hashtable();
	String[] mail = {"/copps/res/COPPSFeedback.jsp", "/copps/res/COPPSFeedbackAction.jsp"};
	String[] screenList = {"/copps/res/COPPSScreenList.jsp", "/copps/res/COPPSScreenListAction.jsp"};
	navigation.put(MAIL, mail);
	navigation.put(SCREEN_LIST, screenList);
}
}
