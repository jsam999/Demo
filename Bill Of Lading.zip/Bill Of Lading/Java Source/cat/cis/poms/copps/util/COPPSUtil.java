package cat.cis.poms.copps.util;

/*
 * Copyright (c) 2002 Caterpillar Inc.  All Rights Reserved.
 *
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 */
 
import cat.cis.poms.com.ims.IMSConnectionManager;
import cat.cis.poms.com.servlet.ComFunctions;
import javax.servlet.ServletContext;
import cat.cis.poms.com.log.ComLog;
 
/**
 * This class is a singleton class, used to define all the utility methods.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM)
 * @author: Venky,POMS
 */
public class COPPSUtil
{
	private static COPPSUtil util = new COPPSUtil();
/**
 * COPPSUtil constructor comment.
 */
public COPPSUtil() {
	super();
}
/**
 * This method creates a new IMSConnectionManager Object and returns.
 * This method is defined, not to repeat the property file name,
 * all over the application. Property file name used in only one place,
 * helps in easier maintanence.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.util.IMSConnectionManager
 */
public IMSConnectionManager getIMSManager()
{
	IMSConnectionManager ims = new IMSConnectionManager("copps/copps_cis");
	ims.setTrace(false);
	return ims;
}
/**
 * Method returning singleton instance.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @return cat.cis.poms.copps.util.COPPSUtil
 */
public static COPPSUtil getInstance()
{
    return util;
}
/**
 * This method creates a new ComLog Object.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param className java.lang.String
 * @param methodName java.lang.String
 * @param logInfo cat.cis.poms.com.log.ComLog
 * @return cat.cis.poms.log.ComLog
 */
public ComLog getLog(String className, String methodName, ComLog logInfo)
{
	ComLog log = new ComLog( className, methodName, logInfo);
	return log;
}
/**
 * This method creates a new ComLog Object and returns.
 * This method is defined, not to repeat the LogKey,
 * all over the application. LogKey name used in only one place,
 * helps in easier maintanence.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param className java.lang.String
 * @param methodName java.lang.String
 * @param userId java.lang.String
 * @return cat.cis.poms.log.ComLog
 */
public ComLog getLog(String className, String methodName, String userId)
{
	ComLog log = new ComLog("copps", className, methodName, userId);
	return log;
}
/**
 * Method to initialize some parameters once,
 * at the beginning of the application.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param context javax.servlet.ServletContext
 */
public void initApplication(ServletContext context)
{
	//Call to initialize the rootUri property once,
	//in the ComFunctions object.(Set the rootUri once,
	//so as to avoid, repeated calls to get the rootUri)
	ComFunctions.initRootUri(context);

	//Call to initialize logger configuration
	initLoggerConfiguration(context);
}
/**
 * Method to initialize logger configuration once,
 * at the beginning of the application.
 *
 * @since 1.3.0 (10/15/2002 3:51:55 PM) by Venky, POMS
 * @param context javax.servlet.ServletContext
 */
public void initLoggerConfiguration(ServletContext context)
{
	ComLog.initLoggerConfiguration("copps", "copps_log", context);
}
}
