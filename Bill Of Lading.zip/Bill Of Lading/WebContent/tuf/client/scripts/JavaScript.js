
function NewWindow(url,wind) { 
	if(!secWind || secWind.closed) {
		var secWind = window.open(url,wind,"width=795,height=535,menubar=no,resizable=yes,scrollbars=yes,toolbar=no")
	}
	else {
		secWind.focus()
	} 
} 

function Check(){
	confirm('Are you sure you want to delete the contact?');
}

/****************************************************
* netscapeKeyPress                                 *
* Handle return key input from a Netscape browser, * 
* which by default is the search operation         *
****************************************************/
function netscapeKeyPress(e) {
  if (e.which == 13)
    defaultAction();
}

/****************************************************
* microsoftKeyPress                                *
* Handle return key input from a Microsoft browser,* 
* which by default is the search operation         *
*
****************************************************/
function microsoftKeyPress() {
  if (window.event.keyCode == 13)
    defaultAction();
}

