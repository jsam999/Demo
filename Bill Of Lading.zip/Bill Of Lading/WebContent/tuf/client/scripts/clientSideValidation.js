/* 
 * This script includes general JavaScript convenience functions
 * to assist in the development of JSP applications.
 * <P>
 * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
 * <P>
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 * <P>
 * @author Ron Stalter, CIS ADE Implementation
 * @version 1.1.0 (12/22/00)
 */

// this creates and houses the validation controls for a form.
function createValidationList() {
	this.validationItemListing = new Array();
	this.addTextValidationItem = add$TextValidationItem;
	this.addSelectValidationItem = add$SelectValidationItem;
	this.getValidationControl = get$ValidationControl;
	this.validateItems = validation$ValuesOK;
}
	
function get$ValidationControl(someControl) {
	for ( var i = 0; i < this.validationItemListing.length; i++ ) {
		if ( someControl == this.validationItemListing[i].control ) {
			return this.validationItemListing[i];
		}
	}
	return null;	
}

// add a 'text' control to the validation list.
function add$TextValidationItem(someControl, isRequired, minlen, maxlen, allowChars, disallowChars, errorMessage) {
	if ( someControl.type.toLowerCase().indexOf("text") == -1) {
		alert("Error adding text control for validation checking.  Invalid control type.");
		return;
	}
	this.validationItemListing[this.validationItemListing.length] = new add$TextControl(someControl, isRequired, "text", minlen, maxlen, allowChars, disallowChars, errorMessage);
}

// add a 'select' control to the validation list.
function add$SelectValidationItem(someControl, isRequired, emptyItem, errorMessage) {
	if ( someControl.type.toLowerCase().indexOf("select") == -1) {
		alert("Error adding select control for validation checking.  Invalid control type.");
		return;
	}
	this.validationItemListing[this.validationItemListing.length] = new add$SelectControl(someControl, isRequired, "select", emptyItem, errorMessage);
}

// returns value that indicates if this control is a required field or not
function is$Required() {
	return this.req;
}

// sets the control as a required field that must be either selected or
// have text that meets the defintion criteria
function set$Required() {
	this.req = true;
}

// sets the control as NOT being a required field.
// however if text was entered it must meet the defintion criteria
function set$NotRequired() {
	this.req = false;
}

// this is a 'select' control definition.  All control defs should implement
// a validateSelf function
function add$SelectControl ( aControl, required, type, emptyItemValue, errorMessage ) {
	this.control = aControl;
	this.req = required;
	this.type = type;
	this.emptyItemValue = emptyItemValue;
	this.err = errorMessage;
	this.validateSelf = chk$SelectValidate;
	this.isRequired = is$Required;
	this.setRequired = set$Required;
	this.setNotRequired = set$NotRequired;
}

// this is a 'text' control definition.  All control defs should implement
// a validateSelf function
function add$TextControl ( aControl, required, type, minL, maxL, goodChrs, badChrs, errorMessage ) {
	this.control = aControl;
	this.req = required;
	this.type = type;
	this.minL = minL;
	this.maxL = maxL;
	this.goodChrs = goodChrs;
	this.badChrs = badChrs;
	this.err = errorMessage;
	this.validateSelf = chk$TextValidate;
	this.isRequired = is$Required;
	this.setRequired = set$Required;
	this.setNotRequired = set$NotRequired;
}

// error alert message and focus setting
function foundFault(message, control) {
	alert (message);
	control.focus();
}

// iterates through validation objects calling their validateSelf()
// any new object types added should implement that function.
function validation$ValuesOK() {
	for ( var i = 0; i < this.validationItemListing.length; i++ ) {
		if ( ! this.validationItemListing[i].validateSelf() ) {
			return false;
		}
	}
	return true;
}

// this is the 'select' control checking routine.
function chk$SelectValidate() {
	if ( this.req == true && ( this.control.options[this.control.selectedIndex].value == this.emptyItemValue) ) {
		foundFault(this.err + "\nIt is a required field.", this.control);
		return false;
	}
	return true;
}

// this function does the text box validation based on string values or regular expressions
function chk$TextValidate() {
	var tempStr = this.control.value;
	var stuff$ToCheck = ( tempStr.replace(/ /gi,"") != "" ) ? true : false;
	// check to see if this particular item is a input TEXT box
	if ( this.req == true && (!stuff$ToCheck) ) {
		foundFault(this.err + "\nIt is a required field.", this.control );
		return false;
	}
	// if this field is NOT required and is empty we're done
	if ( (this.req == false) && (!stuff$ToCheck) ) {
		return true;
	}
	//
	// even if a field is not required this checks for compliance of the given parameter values
	// check if valid characters were input according to object definition
	var theStr = this.control.value;
	var badSpecChars = this.badChrs;
	var okSpecChars = this.goodChrs;
	// check for bad characters first
	// if check for .source comes back true then it's a regular expression.
	if ( badSpecChars.source ) { 
		if ( badSpecChars.test(theStr) ) {
			foundFault(this.err, this.control);
			return false;
		}					
	} else {
		// must be a string of chars instead of a regular expression
		if ( badSpecChars != "" ) {
			for ( var j = 0; j < theStr.length; j++ ) {					
				var oneChar = theStr.substring( j, j + 1 );			//readability
				if ( badSpecChars.indexOf(oneChar) >= 0 ) {
					foundFault(this.err + "\nThe '" + oneChar + "' character is not allowed.", this.control);
					return false;
				}
			}
		}
	}
	if ( okSpecChars.source ) { 															//then must be reg expresssion
		if ( ! okSpecChars.test(theStr) ) {
			foundFault(this.err, this.control);
			return false;
		}					
	} else {
		// must be string
		if ( okSpecChars != "" ) {
			for ( var j = 0; j < theStr.length; j++ ) {					
				var oneChar = theStr.substring( j, j + 1 );			//readability
				if ( okSpecChars.indexOf(oneChar) < 0 ) {
					foundFault(this.err + "\nThe '" + oneChar + "' character is not allowed.", this.control);
					return false;
				}
			}
		}
	}
	if ( this.maxL > 0 ) {									//checking max length of fields
		if ( this.control.value.length > this.maxL ) {
			foundFault(this.err + "\nYou have entered " + this.control.value.length + " characters.\nThe maximum allowed length of " + this.maxL + " characters has been exceeded for this field. \n Please reduce the length of your input to within this limit.", this.control);
			return false;
		}
	}			
	if ( this.minL > 0 ) {			//checking min length of fields
		if ( this.control.value.length < this.minL ) {
			foundFault(this.err + "\nThe minimun allowed length of " + this.minL + " characters for this field has not been met. \n Please increase the length of your input within this limit.", this.control);
			return false;
		}
	}			
	return true;
}

