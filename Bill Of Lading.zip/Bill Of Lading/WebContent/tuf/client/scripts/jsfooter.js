// * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
// * 
// * This work contains Caterpillar Inc.'s unpublished
// * proprietary information which may constitute a trade secret
// * and/or be confidential.  This work may be used only for the
// * purposes for which it was provided, and may not be copied
// * or disclosed to others.  Copyright notice is precautionary
// * only, and does not imply publication.
// * 
// * @author Ron Stalter, CIS ADI
// * @version 1   17-Oct-2001
// *
// * This Javascript creates the standard footer for use at the bottom of a web page.
// *  Modifications:
// *	10-18-01	added support for old method call to addFooter to prevent breakage
// *						 of existing implementations
// *	10-18-01 added support for links to contact and web master names
// *  10-29-01 added support for page counter
// *
// pageFooter constructor
function PageFooter(secLevel, grpName, cntct, cntctLnk, wbMst, wbMstLnk, pgCntr, pgCntrVis) {
	var securityLevel=null;
	var restrictedTo=null;
	var contact=null;
	var contactLink=null;
	var webMaster=null;
	var webMasterLink=null;
	var pageCounter=false;
	var pageCounterVisable=false;
	// setter defs
	this.setSecurityLevel=setSec$Ftr;
	this.setRestrictedTo=setResTo$Ftr;
	this.setContact=setCntctNm$Ftr;
	this.setContactLink=setCntctLnk$Ftr;
	this.setWebMaster=setWbMstr$Ftr;
	this.setWebMasterLink=setWbMstrLnk$Ftr;
	this.setPageCounter=setPg$Cntr;
	this.setPageCounterVisable=setPgCntr$Vis;
	// render footer
	this.display=display$Ftr;
	// constructor params
	if (secLevel){this.securityLevel=secLevel;}else{this.securityLevel="NON-CONFIDENTIAL";}
	if (grpName){this.restrictedTo=grpName;}
	if (cntct){this.contact=cntct;}
	if (cntctLnk){this.contactLink=cntctLnk;}
	if (wbMst){this.webMaster=wbMst;}
	if (wbMstLnk){this.webMasterLink=wbMstLnk;}
	if (pgCntr){this.pageCounter=pgCntr;}
	if (pgCntrVis){this.pageCounterVisable=pgCntrVis;}
}
//setters
function setSec$Ftr(sL){this.securityLevel=sL;}
function setResTo$Ftr(gN){this.restrictedTo=gN;}
function setCntctNm$Ftr(n){this.contact=n;}
function setCntctLnk$Ftr(cNL){this.contactLink=cNL;}
function setWbMstr$Ftr(wMN){this.webMaster=wMN;}
function setWbMstrLnk$Ftr(wML){this.webMasterLink=wML;}
function setPg$Cntr(pC){this.pageCounter=pC;}
function setPgCntr$Vis(v){this.pageCounterVisable=v;}
function isSSL() {
	var protocol = getProtocol(document.location.href);
	return ( protocol == "https" ) ? true : false;
}
function getProtocol(someURL) {
	return someURL.substr(0, someURL.indexOf("://"));
}
// renders footer
function display$Ftr () {
	var footer$Today=new Date();
	var footer$Year=footer$Today.getYear();
	if ( footer$Year < 1900 ) {footer$Year=footer$Year + 1900;}
	var footer$Now=footer$Today.toLocaleString();
	var myOut="<table border=\"0\" cellspacing=\"0\" cellpadding=\"1\" align=\"left\">";
	myOut+="<tr><td><hr align=\"left\" noshade size=\"2\" width=\"300\"></td></tr>";
	var tempStr="<tr><td class=\"copyright\">Caterpillar Confidential:  <b>";
	var posCase=this.securityLevel.toUpperCase();
	switch (posCase) {
	    case "GREEN":
				tempStr+="Green</b></td></tr>";
				break;
	    case "YELLOW":
	    case "RED":
		 		// don't trust use of correct case
				tempStr+=(posCase == "RED")?"Red":"Yellow";
				tempStr+="</b></td></tr><tr><td class=\"copyright\">For Use Only By: ";
				tempStr+=(this.restrictedTo == null)?"Caterpillar Inc. Employees":this.restrictedTo+"</td></tr>";
				break;
	    case "NON-CONFIDENTIAL":
				tempStr="<tr><td class=\"copyright\">Non-Confidential</td></tr>";
				break;
		default:
				tempStr+="Invalid Security Classification Color</b></td></tr>";
				break;
	}
	myOut+=tempStr;
	if (this.contact != null) {
		myOut+="<tr><td class=\"copyright\">Content Owner: ";
		myOut+=(this.contactLink != null)?"<a href="+this.contactLink+">"+this.contact+"</a></td></tr>":this.contact+"</td></tr>";
	}
	if (this.webMaster != null) {
		myOut+="<tr><td class=\"copyright\">Web Master: ";
		myOut+=(this.webMasterLink != null)?"<a href="+this.webMasterLink+">"+this.webMaster+"</a></td></tr>":this.webMaster+"</td></tr>";
	}
	myOut+="<tr><td class=\"copyright\">Current Date:  "+footer$Now+"</td></tr>";
    myOut+="<tr><td class=\"copyright\">&#169; Caterpillar Inc.  "+footer$Year+" All Rights Reserved.</td></tr>";
	// A page counter implementation is no longer provided.  Methods and parameters
	// for controlling this behavior exist only for backwards compatibility purposes.
	myOut+="</table><br>";
	document.write(myOut);
}

//  function code below this line to support old implementations and should be considered depricated 10-18-2001
//  DJL - 07/24/2003 - Changed impl to call methods above.
function addFooter(classification) {
	var myPageFooter = new PageFooter();
		
	myPageFooter.setSecurityLevel(classification);
	myPageFooter.display();
}
