
	// functions associated with client side field validation helpers
	//

	function addControl ( aControlName, req, type, minL, maxL, badChrs, goodChrs, errorMessage ) {
		this.control = aControlName;
		this.req = req;
		this.type = type;
		this.minL = minL;
		this.maxL = maxL;
		this.badChrs = badChrs;
		this.goodChrs = goodChrs;
		this.err = errorMessage;
	}

	//chkThese.control, chkThese.req, chkThese.type, chkThese.minL, chkThese.maxL, chkThese.badChrs, chkThese.goodChrs, chkThese.err
	function CheckValues(formName) {
		for ( var i = 0; i < chkThese.length; i++ ) {
			// check if field is a required field first
		 	//if (chkThese[i].req == false) {
			//	continue;
			//}
			// check to see if this particular item is a select box
			if ( (chkThese[i].control.type.toLowerCase().indexOf("select") != -1) && (chkThese[i].type.toLowerCase().indexOf("selection") != -1) ) {
				if (chkThese[i].control.options[chkThese[i].control.selectedIndex].value.toLowerCase() == "empty"  && chkThese[i].req == true ) {
					alert ( chkThese[i].err + "\nIt is a required field." );
					chkThese[i].control.focus();
					return false;
				}
			}
			// check to see if this particular item is a input text box
			if ( (chkThese[i].control.type.toLowerCase().indexOf("text") != -1) && (chkThese[i].type.toLowerCase().indexOf("text") != -1 ) ) {
				if ( (chkThese[i].control.value == "" || chkThese[i].control.value.replace(/ /gi,"") == "") && chkThese[i].req == true ) {
					alert ( chkThese[i].err + "\nIt is a required field." );
					chkThese[i].control.focus();
					return false;
				}
			}
			// next check if valid characters were input according to matrix above
			if ( chkThese[i].type.toLowerCase() == "text" ) {			// if data type is text
				var theStr = chkThese[i].control.value;					//readability
				var badSpecChars = chkThese[i].badChrs;
				var okSpecChars = chkThese[i].goodChrs;
				for ( var j = 0; j < theStr.length; j++ ) {					
					var oneChar = theStr.substring( j, j + 1 );			//readability
					if ( (badSpecChars != "" && (badSpecChars.indexOf(oneChar) >= 0)) || (okSpecChars != "" && (okSpecChars.indexOf(oneChar) < 0)) ) {
						alert (chkThese[i].err + "\nThe '" + oneChar + "' character is not allowed.");
						chkThese[i].control.focus();
						return false;
					}
				}
			}
			if ( chkThese[i].type.toLowerCase() == "date" ) {
				if ( (chkThese[i].control.value.replace(/ /gi, "") == "") && chkThese[i].req == true ) {
					alert ( chkThese[i].err + "\nIt is a required field." );
					chkThese[i].control.focus();
					return false;
				} else {
					if ( !isDate(chkThese[i].control) ) {
						return false;
					}
				}
			}
			if ( chkThese[i].maxL > 0 ) {									//checking max length of fields
				if ( chkThese[i].control.value.length > chkThese[i].maxL ) {
					alert (chkThese[i].err + "\nThe maximum allowed length of " + chkThese[i].maxL + " characters has been exceeded for this field. \n Please reduce the length of your input to within this limit.");
					chkThese[i].control.focus();
					return false;
				}
			}			
			if ( chkThese[i].minL > 0 ) {			//checking min length of fields
				if ( chkThese[i].control.value.length < chkThese[i].minL ) {
					alert (chkThese[i].err + "\nThe minimun allowed length of " + chkThese[i].minL + " characters for this field has not been met. \n Please increase the length of your input within this limit.");
					chkThese[i].control.focus();
					return false;
				}
			}			
		}
		return true;
	}
