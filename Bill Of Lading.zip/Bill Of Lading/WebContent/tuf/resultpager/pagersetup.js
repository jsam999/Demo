<%--
 * This file adds the imports and initializes the variables used by the result pager.
 * This JSP supports JSP spec version 1.1

 * 
 * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
 * 
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 * 
 * @author Mike Schmale, CIS ADE Implementation
 * @version 20June2001
 --%>

<%@ page import="java.util.Hashtable, cat.cis.tuf.server.util.TUFServerUtil, java.util.Enumeration, java.lang.Integer, cat.cis.tuf.server.resultpager.PageIterator, cat.cis.tuf.server.resultpager.ObjectIterator, cat.cis.tuf.server.resultpager.ColumnSpec, cat.cis.tuf.common.util.sorting.Comparator" %> 
<jsp:useBean id="PIKey" type="java.lang.String" scope="request"/>
<jsp:useBean id="PIPages" type="java.util.Hashtable" scope="session" />
<%PageIterator resultpages = (PageIterator)PIPages.get(PIKey);%>

<% int col = new Integer(resultpages.getSortColumn()).intValue();
	String bgc = "evenrow"; 
	ObjectIterator objects = (ObjectIterator) resultpages.getCurrent();
 	int total = resultpages.getSize();
    	int current = resultpages.getCurrentNumber();
    	int nextt = current + 1;
    	int prev = current - 1;
    	int loop = 1;
    	int top = 1;
    	int bottom = 1;
    	
        if (current > 9) {
            if (current + 10 > total) {
                top = total;
            } else {
                top = current + 10;
            }
 
        } else {
            if (total < 20) {
                top = total;
            } else {
                top = 20;
            }
	}
        if (top - 19 < 1) {
             bottom = 1;
            } else {
                bottom = top - 19;
            }
        
      
%>
