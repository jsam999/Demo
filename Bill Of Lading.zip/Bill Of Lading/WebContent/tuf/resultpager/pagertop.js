<%--
 * This file creates the numbers to allow the user to page through a result set.
 * This JSP supports JSP spec version 1.1

 * 
 * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
 * 
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 * 
 * @author Mike Schmale, CIS ADE Implementation
 * @version 20June2001
 --%>
	

<script>
function getPage(Newpage){ 
	NewURL = "cat.cis.tuf.server.resultpager.PagerServlet?reqestedpage="+Newpage+"&PIKey="+<%=PIKey%>
	document.location = NewURL;
	}
</script>
</b><p class="content">
<%  if (total > 1){ //determines if 'Previous' and/or ... need to appear
    out.print("<table align='right' valign='top' class='content'><tr class='content'><td valign='top' class='content'> Page:");
    if (total > 20) {
        out.print("<br>of&nbsp;<a href='javascript:getPage(" + total + ")'>" + total + "</a></td><td valign='top' class='content'>");
    } else {
        out.print("</td><td valign='top' class='content'>");
    }
    if (current != 1) {
        out.print("<a href='javascript:getPage(" + prev + ")'>previous&nbsp;</a>  ");
    }
    if (bottom > 1) {
        out.print("...");
    }

    for (loop = bottom; loop <= top; loop++) {//writes the numbers
        if (loop == current) {
            out.print("<b>&nbsp;" + loop + "</b> ");
        } else {
            out.print("<a href='javascript:getPage(" + loop + ")'>" + loop + "</a>&nbsp;");
        }   
    }
    if (top < total) {// determines if ... and Next need to appear
        out.print("...");
    }
    if (current != total) {
        out.print("&nbsp<a href='javascript:getPage(" + nextt + ")'>next</a>");
    }
    out.println("</td></tr></table></p><br><br>");

}%>
