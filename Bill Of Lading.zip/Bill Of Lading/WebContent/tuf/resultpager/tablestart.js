<%--
 * This file creates table headings to enable sorting where appropriate.
 * This JSP supports JSP spec version 1.1

 * 
 * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
 * 
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 * 
 * @author Mike Schmale, CIS ADE Implementation
 * @version 20June2001
 --%>

  <%-- Creates the table headings --%>

		<div STYLE="tableheading">
		<tr CLASS="tableheading" >
<% 

	Enumeration heads = resultpages.getColumns().elements();
	ColumnSpec header = null;
	int column = -1;
	String root = TUFServerUtil.getInstance().getRootURI();
	String sortservlet = root + "/servlet/cat.cis.tuf.server.resultpager.SorterServlet?column=";
	
	while (heads.hasMoreElements()) {
	    header = (ColumnSpec) heads.nextElement();
	    column++;
	    
	    if( !header.isHidden() ) {
		    out.print("<td CLASS='tableheading' align='"+header.getAlignment()+"'>");
		
		    if ((header.getSortType() != null) && (objects.getSize() > 0)) {
		        out.print("<a href='" + sortservlet + column + "&PIKey="+PIKey+" '>" + header.getHeaderText());
		        if (column == col) {
		            out.print("&nbsp;<img src=\"" + root + "/tuf/client/images/");
		            if (header.getSortDirection()) {
		                out.print("true.gif\" border=\"0\">");
		            } else {
		                out.print("false.gif\" border=\"0\">");
		            }
		        }
		        out.print("</a></td>");
		
		    } else {
		        out.print(header.getHeaderText() + "&nbsp;</td>");
		    }
	    }
	}

%>
</tr></div>
<%-- End of the table headings --%>

<%-- Loops through the elements alternating styles for the odd and even rows --%>
<% int recnum=0;
	for( Enumeration enumeration = objects.getElements(); enumeration.hasMoreElements(); ) {

	if (bgc.equals("oddrow")) {
		bgc = "evenrow";
	}
	else { 
		bgc = "oddrow"; 
	}
%>
<tr class="<%= bgc %>">

