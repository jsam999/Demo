/*
 * This java script file contains data validations used by WebTest
 * 
 * Copyright (c) 2001 Caterpillar Inc.  All Rights Reserved.
 * 
 * This work contains Caterpillar Inc.'s unpublished
 * proprietary information which may constitute a trade secret
 * and/or be confidential.  This work may be used only for the
 * purposes for which it was provided, and may not be copied
 * or disclosed to others.  Copyright notice is precautionary
 * only, and does not imply publication.
 * 
 * @author Steve Monday, CIS ADE Implementation
 * @version 1.2.2 15Jul2001
 */
function isBlank(val) 
{
	if (val == null) { return true; }
	for (var i=0; i < val.length; i++) {
		if ((val.charAt(i) != ' ') && (val.charAt(i) != "\t") && (val.charAt(i) != "\n")) 
		{ 
		return false; 
		}
	}
	return true;
}

function isPositiveInteger(val)
{
	if (isInteger(val))
	{
		var num = parseInt(val);
		return num > 0;
	}
}

function isInteger(val)
{
	if (val == null)
	{
		return false;
	}
	var num = parseInt(val);
	return (!((isNaN(num)) || (num.toString() != val)));
}